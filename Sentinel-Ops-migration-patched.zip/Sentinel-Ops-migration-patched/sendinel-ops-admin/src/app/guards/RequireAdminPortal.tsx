import { Navigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";

export function RequireAdminPortal({ children }: { children: React.ReactNode }) {
  const { loading, isAuthenticated, isAdminPortal } = useAuth();

  if (loading) {
    return <div style={{ padding: 24 }}>Φόρτωση...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (!isAdminPortal) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}