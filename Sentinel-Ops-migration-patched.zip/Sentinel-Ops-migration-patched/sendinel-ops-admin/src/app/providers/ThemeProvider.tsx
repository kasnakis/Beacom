import type { PropsWithChildren } from "react";
import { useEffect } from "react";
import { useThemeStore } from "../../store/uiStore";

export function ThemeProvider({ children }: PropsWithChildren) {
  const theme = useThemeStore((state) => state.theme);

  useEffect(() => {
    const root = document.documentElement;

    root.dataset.theme = theme;
    root.style.colorScheme = theme;
  }, [theme]);

  return <>{children}</>;
}
