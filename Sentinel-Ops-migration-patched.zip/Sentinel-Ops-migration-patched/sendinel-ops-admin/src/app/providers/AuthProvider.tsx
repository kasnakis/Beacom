import { useEffect, type PropsWithChildren } from "react";
import { subscribeToAuthChanges } from "../../services/auth/authService";
import { getUserProfile } from "../../services/repositories/usersRepository";
import { useSessionStore } from "../../store/sessionStore";

export function AuthProvider({ children }: PropsWithChildren) {
  const setFirebaseUser = useSessionStore((state) => state.setFirebaseUser);
  const setProfile = useSessionStore((state) => state.setProfile);
  const setLoading = useSessionStore((state) => state.setLoading);
  const setError = useSessionStore((state) => state.setError);
  const clearSession = useSessionStore((state) => state.clearSession);

  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges(async (user) => {
      try {
        setLoading(true);
        setError(null);

        if (!user) {
          clearSession();
          return;
        }

        setFirebaseUser(user);

        const profile = await getUserProfile(user.uid);

        if (!profile) {
          setError("Δεν βρέθηκε προφίλ χρήστη στη βάση");
          setProfile(null);
          return;
        }

        setProfile(profile);
      } catch (error) {
        console.error("Auth bootstrap failed", error);
        setError("Αποτυχία φόρτωσης στοιχείων χρήστη");
        clearSession();
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, [setFirebaseUser, setProfile, setLoading, setError, clearSession]);

  return <>{children}</>;
}