import { Link, NavLink } from "react-router-dom";
import { navigation } from "../config/navigation";
import { ROUTES } from "../config/routes";

const navIcons: Record<string, string> = {
  Αρχική: "⌂",
  Χρήστες: "♙",
  Μέσα: "▧",
  "Τύποι Συμβάντων": "⚑",
  "Ζωντανή Εικόνα": "▣",
  "Ενεργοποίηση - Κινητοποίηση": "⌁",
  "Εξωτερικές Αρχές": "⚖",
  "Κέντρο Ειδοποιήσεων": "▤",
  Ιστορικό: "◷",
  Timeline: "☷",
  Audit: "⌕",
};

export function Sidebar() {
  return (
    <aside className="sidebar">
      <Link to={ROUTES.OVERVIEW} className="sidebar-brand" aria-label="Μετάβαση στην Αρχική">
        <img src="/branding/sendinel-logo.png" alt="SENTINEL Ops" className="sidebar-brand-logo" />

        <div>
          <strong>SENTINEL Ops</strong>
          <div className="muted">Admin Console</div>
        </div>
      </Link>

      <nav className="sidebar-nav">
        {navigation.map((item) => (
          <NavLink key={item.path} to={item.path} className="sidebar-link">
            <span className="sidebar-link-icon" aria-hidden="true">
              {navIcons[item.label] || "•"}
            </span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
