import { getAuth, signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { useThemeStore } from "../../store/uiStore";

export default function Topbar() {
  const navigate = useNavigate();
  const { profile } = useAuth();

  const theme = useThemeStore((state) => state.theme);
  const toggleTheme = useThemeStore((state) => state.toggleTheme);

  async function handleLogout() {
    try {
      const auth = getAuth();
      await signOut(auth);
      navigate("/login");
    } catch (err) {
      console.error("Logout error:", err);
    }
  }

  return (
    <div className="topbar">
      <div className="topbar-title">SENTINEL Ops</div>

      <div className="topbar-actions">
        <button
          type="button"
          onClick={toggleTheme}
          title={theme === "dark" ? "Ανοιχτό θέμα" : "Σκούρο θέμα"}
          className="theme-toggle-button"
        >
          {theme === "dark" ? "☀ Light" : "◐ Dark"}
        </button>

        <span className="topbar-user-name">{profile?.displayName || profile?.email}</span>

        <button type="button" onClick={handleLogout} className="logout-button">
          Logout
        </button>
      </div>
    </div>
  );
}
