import React from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { router } from "./router";
import { AppProviders } from "./providers/AppProviders";

import "../styles/tokens.css";
import "../styles/globals.css";
import "../styles/theme.css";
import "leaflet/dist/leaflet.css";

function ensureBrowserBranding() {
  document.title = "SENTINEL Ops Admin";

  const faviconHref = "/branding/sendinel-logo.png";
  let icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');

  if (!icon) {
    icon = document.createElement("link");
    icon.rel = "icon";
    document.head.appendChild(icon);
  }

  icon.type = "image/png";
  icon.href = faviconHref;
}

ensureBrowserBranding();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AppProviders>
      <RouterProvider router={router} />
    </AppProviders>
  </React.StrictMode>
);