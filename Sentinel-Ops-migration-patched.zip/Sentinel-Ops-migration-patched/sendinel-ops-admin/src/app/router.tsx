import { createBrowserRouter, Navigate } from "react-router-dom";
import { App } from "./App";
import { AppShell } from "./layout/AppShell";
import { RequireAuth } from "./guards/RequireAuth";
import { RequireAdminPortal } from "./guards/RequireAdminPortal";
import LoginPage from "../pages/auth/LoginPage";
import { OverviewPage } from "../pages/overview/OverviewPage";
import { GeneralSettingsPage } from "../pages/settings/GeneralSettingsPage";
import { SitesListPage } from "../pages/sites/SitesListPage";
import { SiteDetailPage } from "../pages/sites/SiteDetailPage";
import { UsersListPage } from "../pages/users/UsersListPage";
import { SiteAssetsPage } from "../pages/assets/SiteAssetsPage";
import { IncidentTypesListPage } from "../pages/incidentTypes/IncidentTypesListPage";
import { IncidentTypeDetailPage } from "../pages/incidentTypes/IncidentTypeDetailPage";
import { LiveDashboardPage } from "../pages/operations/LiveDashboardPage";
import { DispatchMonitorPage } from "../pages/operations/DispatchMonitorPage";
import { ExternalNotificationsPage } from "../pages/operations/ExternalNotificationsPage";
import { OperationalNotificationsCenterPage } from "../pages/operations/OperationalNotificationsCenterPage";
import { IncidentHistoryPage } from "../pages/operations/IncidentHistoryPage";
import { TimelinePage } from "../pages/operations/TimelinePage";
import AuditDashboardPage from "../pages/audit/AuditDashboardPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <Navigate to="/app/overview" replace /> },
      { path: "login", element: <LoginPage /> },
      {
        path: "app",
        element: (
          <RequireAuth>
            <RequireAdminPortal>
              <AppShell />
            </RequireAdminPortal>
          </RequireAuth>
        ),
        children: [
          { path: "overview", element: <OverviewPage /> },
          { path: "settings/general", element: <GeneralSettingsPage /> },

          { path: "sites/list", element: <SitesListPage /> },
          { path: "sites/:siteId", element: <SiteDetailPage /> },

          { path: "users/list", element: <UsersListPage /> },
          { path: "assets/site-assets", element: <SiteAssetsPage /> },

          { path: "incident-types/list", element: <IncidentTypesListPage /> },
          { path: "incident-types/:category", element: <IncidentTypeDetailPage /> },

          { path: "operations/live", element: <LiveDashboardPage /> },
          { path: "operations/dispatch", element: <DispatchMonitorPage /> },
          {
            path: "operations/external-notifications",
            element: <ExternalNotificationsPage />,
          },
          {
            path: "operations/notifications-center",
            element: <OperationalNotificationsCenterPage />,
          },
          { path: "operations/history", element: <IncidentHistoryPage /> },
          { path: "operations/timeline", element: <TimelinePage /> },

          { path: "audit", element: <AuditDashboardPage /> },
        ],
      },
    ],
  },
]);