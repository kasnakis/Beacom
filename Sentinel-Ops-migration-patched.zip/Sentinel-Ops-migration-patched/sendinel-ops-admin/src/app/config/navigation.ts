import { ROUTES } from "./routes";

export const navigation = [
  { label: "Αρχική", path: ROUTES.OVERVIEW },
  { label: "Υπηρεσιακές Μονάδες", path: ROUTES.SITES_LIST },
  { label: "Χρήστες", path: ROUTES.USERS_LIST },
  { label: "Μέσα", path: ROUTES.SITE_ASSETS },
  { label: "Τύποι Συμβάντων", path: ROUTES.INCIDENT_TYPES_LIST },
  { label: "Ζωντανή Εικόνα", path: ROUTES.LIVE_DASHBOARD },
  { label: "Ενεργοποίηση - Κινητοποίηση", path: ROUTES.DISPATCH },
  { label: "Εξωτερικές Αρχές", path: ROUTES.EXTERNAL_NOTIFICATIONS },
  { label: "Κέντρο Ειδοποιήσεων", path: ROUTES.OPERATIONAL_NOTIFICATIONS },
  { label: "Ιστορικό", path: ROUTES.HISTORY },
  { label: "Timeline", path: ROUTES.TIMELINE },
  { label: "Audit", path: ROUTES.AUDIT }
];
