export const ROUTES = {
  LOGIN: "/login",
  OVERVIEW: "/app/overview",
  SETTINGS_GENERAL: "/app/settings/general",
  SITES_LIST: "/app/sites/list",
  USERS_LIST: "/app/users/list",
  SITE_ASSETS: "/app/assets/site-assets",
  INCIDENT_TYPES_LIST: "/app/incident-types/list",
  LIVE_DASHBOARD: "/app/operations/live",
  DISPATCH: "/app/operations/dispatch",
  EXTERNAL_NOTIFICATIONS: "/app/operations/external-notifications",
  OPERATIONAL_NOTIFICATIONS: "/app/operations/notifications-center",
  HISTORY: "/app/operations/history",
  TIMELINE: "/app/operations/timeline",
  AUDIT: "/app/audit"
} as const;
