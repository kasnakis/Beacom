import { Link } from "react-router-dom";
import type { IncidentPolicy, RoleMap } from "../../../domain/models/incidentPolicy";

type Props = {
  items: IncidentPolicy[];
  selectedKey?: string | null;
  onSelect: (key: string) => void;
};

const CATEGORY_LABELS: Record<string, string> = {
  EMERGENCY_ACTIVATION: "Έκτακτη Κατάσταση ΣΑΕΚ",
  HSE_ACCIDENT: "Ατύχημα ΥΑΕ",
  ENVIRONMENTAL_INCIDENT: "Περιβαλλοντικό Συμβάν",
  NEAR_MISS: "Παρ’ ολίγον Ατύχημα",
  UNSAFE_ACTION: "Μη ασφαλής ενέργεια",
  UNSAFE_CONDITION: "Μη ασφαλής κατάσταση",
  SOS: "SOS",
};

const DISPATCH_MODE_LABELS: Record<string, string> = {
  NONE: "Χωρίς κινητοποίηση",
  AUTO: "Αυτόματη κινητοποίηση",
  MANUAL: "Χειροκίνητη κινητοποίηση",
  POST_VERIFY: "Μετά την επιβεβαίωση",
};

const NOTIFICATION_MODE_LABELS: Record<string, string> = {
  NONE: "Χωρίς ειδοποιήσεις",
  AUTO: "Αυτόματες ειδοποιήσεις",
  MANUAL: "Χειροκίνητες ειδοποιήσεις",
  POST_VERIFY: "Μετά την επιβεβαίωση",
};

const EXTERNAL_MODE_LABELS: Record<string, string> = {
  NONE: "Όχι",
  AUTO: "Αυτόματα",
  MANUAL: "Χειροκίνητα",
  PLAYBOOK_DRIVEN: "Μέσω playbook",
};

function boolLabel(value?: boolean) {
  return value ? "Ναι" : "Όχι";
}

function statusBadge(value?: boolean) {
  const active = value === true;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        borderRadius: 999,
        padding: "4px 9px",
        fontSize: 12,
        fontWeight: 800,
        border: `1px solid ${active ? "var(--success)" : "var(--border-strong)"}`,
        background: active ? "var(--success-soft)" : "var(--surface-2)",
        color: active ? "var(--success-strong)" : "var(--muted-strong)",
        whiteSpace: "nowrap",
      }}
    >
      {active ? "Ενεργό" : "Ανενεργό"}
    </span>
  );
}

function modeLabel(mode: unknown, labels: Record<string, string>) {
  const value = String(mode || "NONE");
  return labels[value] || value;
}

function countEnabled(map?: RoleMap) {
  if (!map) return 0;
  return Object.values(map).filter(Boolean).length;
}

function getDispatchMode(item: IncidentPolicy) {
  return item.dispatch?.mode || item.postVerifyDispatchMode || "NONE";
}

function getNotificationMode(item: IncidentPolicy) {
  return item.notifications?.mode || item.notificationMode || "NONE";
}

function getExternalMode(item: IncidentPolicy) {
  if (item.externalAuthorities?.mode) return item.externalAuthorities.mode;
  if (item.externalMode) return item.externalMode;
  return item.externalEnabled ? "MANUAL" : "NONE";
}

function getVerificationRequired(item: IncidentPolicy) {
  return Boolean(item.verification?.required ?? item.requiresVerification);
}

function getRolesCount(item: IncidentPolicy) {
  const verificationRoles = countEnabled(item.verification?.roles || item.verification?.allowedRoles || item.verificationRoles);
  const dispatchRoles = countEnabled(item.dispatch?.roles || item.dispatch?.responderRoles || item.dispatchRoles);
  const notifyRoles = countEnabled(item.notifications?.roles || item.notifications?.targets || item.notificationTargets);
  return verificationRoles + dispatchRoles + notifyRoles;
}

function getTeamsCount(item: IncidentPolicy) {
  return countEnabled(item.dispatch?.teams || item.dispatch?.responseTeams || item.dispatchTeams || item.notifications?.teams);
}

function getCardDescription(item: IncidentPolicy) {
  if (item.description) return item.description;
  if (item.key === "EMERGENCY_ACTIVATION") {
    return "Ροή ΣΑΕΚ / emergency για άμεση επιχειρησιακή ενεργοποίηση, κινητοποίηση και κλιμάκωση.";
  }
  if (item.key === "HSE_ACCIDENT") {
    return "Διαχείριση ατυχήματος Υγείας & Ασφάλειας με έλεγχο απόκρισης και τεκμηρίωση ενεργειών.";
  }
  if (item.key === "ENVIRONMENTAL_INCIDENT") {
    return "Διαχείριση περιβαλλοντικού συμβάντος, πιθανής ρύπανσης και εμπλοκής αρμόδιων ρόλων.";
  }
  if (item.key === "NEAR_MISS") {
    return "Καταγραφή και αξιολόγηση παρ’ ολίγον συμβάντος πριν εξελιχθεί σε ατύχημα.";
  }
  return "Πολιτική διαχείρισης συμβάντος με κανόνες επιβεβαίωσης, ειδοποιήσεων και κινητοποίησης.";
}

export function IncidentTypesGrid({ items, selectedKey, onSelect }: Props) {
  if (!items.length) {
    return (
      <div
        style={{
          marginTop: 16,
          padding: 20,
          borderRadius: 18,
          border: "1px solid var(--border)",
          background: "var(--surface)",
          color: "var(--text)",
        }}
      >
        Δεν βρέθηκαν τύποι συμβάντων για την επιλεγμένη υπηρεσιακή μονάδα.
      </div>
    );
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
        gap: 18,
        marginTop: 16,
      }}
    >
      {items.map((item) => {
        const selected = selectedKey === item.key;
        const verificationRequired = getVerificationRequired(item);
        const dispatchMode = getDispatchMode(item);
        const notificationMode = getNotificationMode(item);
        const externalMode = getExternalMode(item);
        const rolesCount = getRolesCount(item);
        const teamsCount = getTeamsCount(item);

        return (
          <article
            key={item.key}
            style={{
              display: "flex",
              flexDirection: "column",
              minHeight: 330,
              padding: 18,
              borderRadius: 22,
              border: selected ? "1px solid var(--accent)" : "1px solid var(--border)",
              background: selected
                ? "linear-gradient(180deg, var(--accent-soft), var(--surface))"
                : "var(--surface)",
              boxShadow: selected
                ? "0 18px 44px rgba(31, 95, 224, 0.14)"
                : "var(--shadow-soft)",
              color: "var(--text)",
            }}
          >
            <button
              type="button"
              onClick={() => onSelect(item.key)}
              style={{
                textAlign: "left",
                background: "transparent",
                border: "none",
                padding: 0,
                margin: 0,
                cursor: "pointer",
                width: "100%",
                color: "inherit",
                boxShadow: "none",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontSize: 19, fontWeight: 900, color: "var(--text-strong)", lineHeight: 1.2 }}>
                    {CATEGORY_LABELS[item.key] || item.displayName || item.key}
                  </div>
                  <div style={{ marginTop: 5, color: "var(--muted-strong)", fontSize: 12, fontWeight: 800 }}>
                    {item.key}
                  </div>
                </div>
                {statusBadge(item.active)}
              </div>

              <p style={{ margin: "14px 0 0", minHeight: 54, color: "var(--muted-strong)", fontSize: 13, lineHeight: 1.45 }}>
                {getCardDescription(item)}
              </p>
            </button>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                gap: 10,
                marginTop: 16,
              }}
            >
              <MiniStat label="Επιβεβαίωση" value={boolLabel(verificationRequired)} tone={verificationRequired ? "warning" : "success"} />
              <MiniStat label="Dispatch" value={modeLabel(dispatchMode, DISPATCH_MODE_LABELS)} tone={String(dispatchMode) === "NONE" ? "neutral" : "info"} />
              <MiniStat label="Ειδοποιήσεις" value={modeLabel(notificationMode, NOTIFICATION_MODE_LABELS)} tone={String(notificationMode) === "NONE" ? "neutral" : "info"} />
              <MiniStat label="Εξωτερικές αρχές" value={modeLabel(externalMode, EXTERNAL_MODE_LABELS)} tone={String(externalMode) === "NONE" ? "neutral" : "warning"} />
            </div>

            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: 8,
                marginTop: 14,
              }}
            >
              <SmallPill label={`${rolesCount} ρόλοι`} />
              <SmallPill label={`${teamsCount} ομάδες`} />
              <SmallPill label={`Closure: ${String(item.closure?.mode || item.closureMode || "MANUAL")}`} />
            </div>

            <div style={{ marginTop: "auto", paddingTop: 18, display: "flex", gap: 10, alignItems: "center" }}>
              <Link
                to={`/app/incident-types/${item.key}`}
                style={{
                  display: "inline-flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flex: "1 1 auto",
                  minHeight: 42,
                  borderRadius: 12,
                  border: "1px solid var(--accent)",
                  background: "var(--accent)",
                  color: "#ffffff",
                  fontWeight: 900,
                  boxShadow: "0 12px 24px rgba(31, 95, 224, 0.18)",
                }}
              >
                Διαχείριση
              </Link>
              <button
                type="button"
                onClick={() => onSelect(item.key)}
                className="secondary-button"
                style={{ minHeight: 42, fontWeight: 800 }}
              >
                Επιλογή
              </button>
            </div>
          </article>
        );
      })}
    </div>
  );
}

function MiniStat({ label, value, tone }: { label: string; value: string; tone: "success" | "warning" | "info" | "neutral" }) {
  const toneStyle: Record<typeof tone, { bg: string; border: string; color: string }> = {
    success: { bg: "var(--success-soft)", border: "var(--success)", color: "var(--success-strong)" },
    warning: { bg: "var(--warning-soft)", border: "var(--warning)", color: "var(--warning-strong)" },
    info: { bg: "var(--info-soft)", border: "var(--info)", color: "var(--info-strong)" },
    neutral: { bg: "var(--surface-2)", border: "var(--border)", color: "var(--text)" },
  };

  return (
    <div
      style={{
        borderRadius: 14,
        border: `1px solid ${toneStyle[tone].border}`,
        background: toneStyle[tone].bg,
        padding: 10,
        minHeight: 72,
      }}
    >
      <div style={{ fontSize: 12, color: "var(--muted-strong)", fontWeight: 750 }}>{label}</div>
      <div style={{ marginTop: 6, fontSize: 14, color: toneStyle[tone].color, fontWeight: 900, lineHeight: 1.2 }}>
        {value}
      </div>
    </div>
  );
}

function SmallPill({ label }: { label: string }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        borderRadius: 999,
        padding: "5px 9px",
        fontSize: 12,
        fontWeight: 800,
        border: "1px solid var(--border)",
        background: "var(--surface-2)",
        color: "var(--muted-strong)",
      }}
    >
      {label}
    </span>
  );
}
