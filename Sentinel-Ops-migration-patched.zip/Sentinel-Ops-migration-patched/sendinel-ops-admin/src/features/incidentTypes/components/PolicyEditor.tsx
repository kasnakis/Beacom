import { useEffect, useMemo, useState } from "react";
import type { IncidentPolicy } from "../../../domain/models/incidentPolicy";
import { useUpdateIncidentPolicy } from "../../../hooks/useUpdateIncidentPolicy";
import { GeneralSection } from "./sections/GeneralSection";
import { VerificationSection } from "./sections/VerificationSection";
import { DispatchSection } from "./sections/DispatchSection";
import { NotificationsSection } from "./sections/NotificationsSection";
import { ExternalSection } from "./sections/ExternalSection";
import { ClosureSection } from "./sections/ClosureSection";

type Props = {
  siteId: string;
  value: IncidentPolicy | null;
};

type PolicyTabKey =
  | "verification"
  | "dispatch"
  | "notifications"
  | "external"
  | "closure";

const POLICY_TABS: Array<{ key: PolicyTabKey; label: string; description: string }> = [
  {
    key: "verification",
    label: "Πολιτική επιβεβαίωσης",
    description: "Κανόνες αναγνώρισης / επιβεβαίωσης συμβάντος",
  },
  {
    key: "dispatch",
    label: "Πολιτική κινητοποίησης",
    description: "Ρόλοι, ομάδες και τρόπος dispatch",
  },
  {
    key: "notifications",
    label: "Πολιτική ειδοποιήσεων",
    description: "Στόχευση ενημερώσεων προς ρόλους και ομάδες",
  },
  {
    key: "external",
    label: "Πολιτική εξωτερικών αρχών",
    description: "Αρχές, κανάλια, εγκρίσεις και εκτέλεση",
  },
  {
    key: "closure",
    label: "Πολιτική ολοκλήρωσης συμβάντος",
    description: "Προϋποθέσεις κλεισίματος και override",
  },
];

function recordToSelectedSet(value?: Record<string, boolean>) {
  return new Set(
    Object.entries(value || {})
      .filter(([, enabled]) => enabled)
      .map(([key]) => key)
  );
}

function selectedSetToRecord(set: Set<string>) {
  return Array.from(set).reduce<Record<string, boolean>>((acc, key) => {
    acc[key] = true;
    return acc;
  }, {});
}

function toggleInSet(
  setter: React.Dispatch<React.SetStateAction<Set<string>>>,
  key: string
) {
  setter((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    return next;
  });
}

export function PolicyEditor({ siteId, value }: Props) {
  const mutation = useUpdateIncidentPolicy();

  const [displayName, setDisplayName] = useState("");
  const [active, setActive] = useState(false);

  const [requiresVerification, setRequiresVerification] = useState(false);
  const [minimumApprovals, setMinimumApprovals] = useState(1);
  const [verificationRoles, setVerificationRoles] = useState<Set<string>>(new Set());

  const [postVerifyDispatchMode, setPostVerifyDispatchMode] = useState("");
  const [allowAutoDispatch, setAllowAutoDispatch] = useState(false);
  const [trackingEnabled, setTrackingEnabled] = useState(false);
  const [dispatchRoles, setDispatchRoles] = useState<Set<string>>(new Set());
  const [dispatchTeams, setDispatchTeams] = useState<Set<string>>(new Set());

  const [notificationMode, setNotificationMode] = useState("");
  const [notificationTargets, setNotificationTargets] = useState<Set<string>>(new Set());

  const [externalEnabled, setExternalEnabled] = useState(false);
  const [externalMode, setExternalMode] = useState("");
  const [externalAuthorityTypes, setExternalAuthorityTypes] = useState<Set<string>>(new Set());

  const [requesterRoles, setRequesterRoles] = useState<Set<string>>(new Set());
  const [approverRoles, setApproverRoles] = useState<Set<string>>(new Set());
  const [executorRoles, setExecutorRoles] = useState<Set<string>>(new Set());
  const [approvalRequired, setApprovalRequired] = useState(false);
  const [acknowledgementRequired, setAcknowledgementRequired] = useState(false);
  const [channels, setChannels] = useState<Set<string>>(new Set());

  const [requiresVerifiedIncident, setRequiresVerifiedIncident] = useState(false);
  const [closureRoles, setClosureRoles] = useState<Set<string>>(new Set());
  const [requiresActionsCompleted, setRequiresActionsCompleted] = useState(false);
  const [requiresInvestigationCompleted, setRequiresInvestigationCompleted] = useState(false);
  const [overrideRoles, setOverrideRoles] = useState<Set<string>>(new Set());
  const [overrideRequiresNotes, setOverrideRequiresNotes] = useState(false);
  const [activeTab, setActiveTab] = useState<PolicyTabKey>("verification");

  useEffect(() => {
    if (!value) return;

    setDisplayName(value.displayName || "");
    setActive(Boolean(value.active));

    setRequiresVerification(
      Boolean(value.requiresVerification ?? value.verification?.required)
    );
    setMinimumApprovals(
      Number(value.minimumApprovals ?? value.verification?.minimumApprovals ?? 1)
    );
    setVerificationRoles(
      recordToSelectedSet(
        (value.verificationRoles as Record<string, boolean> | undefined) ??
          value.verification?.roles
      )
    );

    setPostVerifyDispatchMode(
      String(value.postVerifyDispatchMode ?? value.dispatch?.mode ?? "")
    );
    setAllowAutoDispatch(
      Boolean(value.allowAutoDispatch ?? value.dispatch?.allowAutoDispatch)
    );
    setTrackingEnabled(
      Boolean(value.trackingEnabled ?? value.dispatch?.trackingEnabled)
    );
    setDispatchRoles(
      recordToSelectedSet(
        (value.dispatchRoles as Record<string, boolean> | undefined) ??
          value.dispatch?.roles
      )
    );
    setDispatchTeams(
      recordToSelectedSet(
        (value.dispatchTeams as Record<string, boolean> | undefined) ??
          value.dispatch?.teams
      )
    );

    setNotificationMode(
      String(value.notificationMode ?? value.notifications?.mode ?? "")
    );
    setNotificationTargets(
      recordToSelectedSet(
        (value.notificationTargets as Record<string, boolean> | undefined) ??
          value.notifications?.targets
      )
    );

    setExternalEnabled(
      Boolean(value.externalEnabled ?? value.externalAuthorities?.enabled)
    );
    setExternalMode(
      String(value.externalMode ?? value.externalAuthorities?.mode ?? "")
    );
    setExternalAuthorityTypes(
      recordToSelectedSet(
        (value.externalAuthorityTypes as Record<string, boolean> | undefined) ??
          value.externalAuthorities?.authorityTypes ??
          value.externalAuthorities?.authorities
      )
    );

    setRequesterRoles(
      recordToSelectedSet(value.externalAuthorities?.allowedRequesterRoles)
    );
    setApproverRoles(
      recordToSelectedSet(value.externalAuthorities?.allowedApproverRoles)
    );
    setExecutorRoles(
      recordToSelectedSet(value.externalAuthorities?.allowedExecutorRoles)
    );
    setApprovalRequired(Boolean(value.externalAuthorities?.approvalRequired));
    setAcknowledgementRequired(
      Boolean(value.externalAuthorities?.requireAcknowledgement)
    );
    setChannels(recordToSelectedSet(value.externalAuthorities?.channels));

    setRequiresVerifiedIncident(
      Boolean(value.requiresVerifiedIncident ?? value.closure?.requiresVerifiedIncident)
    );
    setClosureRoles(
      recordToSelectedSet(
        (value.closureRoles as Record<string, boolean> | undefined) ??
          value.closure?.closureRoles ??
          value.closure?.allowedRoles
      )
    );
    setRequiresActionsCompleted(
      Boolean(value.closure?.requiresActionsCompleted)
    );
    setRequiresInvestigationCompleted(
      Boolean(value.closure?.requiresInvestigationCompleted)
    );
    setOverrideRoles(
      recordToSelectedSet(value.closure?.overrideRoles)
    );
    setOverrideRequiresNotes(
      Boolean(value.closure?.overrideRequiresNotes)
    );
  }, [value]);

  const verificationRolesRecord = useMemo(
    () => selectedSetToRecord(verificationRoles),
    [verificationRoles]
  );

  const dispatchRolesRecord = useMemo(
    () => selectedSetToRecord(dispatchRoles),
    [dispatchRoles]
  );

  const dispatchTeamsRecord = useMemo(
    () => selectedSetToRecord(dispatchTeams),
    [dispatchTeams]
  );

  const notificationTargetsRecord = useMemo(
    () => selectedSetToRecord(notificationTargets),
    [notificationTargets]
  );

  const externalAuthorityTypesRecord = useMemo(
    () => selectedSetToRecord(externalAuthorityTypes),
    [externalAuthorityTypes]
  );

  const requesterRolesRecord = useMemo(
    () => selectedSetToRecord(requesterRoles),
    [requesterRoles]
  );

  const approverRolesRecord = useMemo(
    () => selectedSetToRecord(approverRoles),
    [approverRoles]
  );

  const executorRolesRecord = useMemo(
    () => selectedSetToRecord(executorRoles),
    [executorRoles]
  );

  const channelsRecord = useMemo(
    () => selectedSetToRecord(channels),
    [channels]
  );

  const closureRolesRecord = useMemo(
    () => selectedSetToRecord(closureRoles),
    [closureRoles]
  );

  const overrideRolesRecord = useMemo(
    () => selectedSetToRecord(overrideRoles),
    [overrideRoles]
  );

  if (!value) {
    return <p>Επίλεξε policy για λεπτομέρειες</p>;
  }

  async function handleSave() {
    if (!value) return;

    await mutation.mutateAsync({
      siteId,
      key: value.key,
      values: {
        active,
        displayName,

        requiresVerification,
        verificationRoles: verificationRolesRecord,
        minimumApprovals,

        postVerifyDispatchMode,
        allowAutoDispatch,
        dispatchRoles: dispatchRolesRecord,
        dispatchTeams: dispatchTeamsRecord,
        trackingEnabled,

        notificationMode,
        notificationTargets: notificationTargetsRecord,

        externalEnabled,
        externalAuthorityTypes: externalAuthorityTypesRecord,
        externalMode,

        allowedRequesterRoles: requesterRolesRecord,
        allowedApproverRoles: approverRolesRecord,
        allowedExecutorRoles: executorRolesRecord,
        approvalRequired,
        acknowledgementRequired,
        externalChannels: channelsRecord,

        closureRoles: closureRolesRecord,
        requiresVerifiedIncident,
        requiresActionsCompleted,
        requiresInvestigationCompleted,
        overrideRoles: overrideRolesRecord,
        overrideRequiresNotes,
      },
    });
  }

  return (
    <div style={{ display: "grid", gap: 18 }}>
      <GeneralSection
        policyKey={value.key}
        displayName={displayName}
        active={active}
        onDisplayNameChange={setDisplayName}
        onActiveChange={setActive}
      />

      <section
        style={{
          border: "1px solid rgba(37, 99, 235, 0.28)",
          borderRadius: 18,
          overflow: "hidden",
          background: "rgba(255,255,255,0.03)",
        }}
      >
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 8,
            padding: 12,
            borderBottom: "1px solid rgba(148, 163, 184, 0.28)",
            background: "rgba(15, 23, 42, 0.04)",
            position: "sticky",
            top: 0,
            zIndex: 2,
          }}
        >
          {POLICY_TABS.map((tab) => {
            const selected = activeTab === tab.key;

            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                aria-pressed={selected}
                title={tab.description}
                style={{
                  border: selected
                    ? "1px solid rgba(37, 99, 235, 0.7)"
                    : "1px solid rgba(148, 163, 184, 0.35)",
                  borderRadius: 999,
                  padding: "10px 14px",
                  cursor: "pointer",
                  fontWeight: 700,
                  background: selected
                    ? "rgba(37, 99, 235, 0.14)"
                    : "rgba(255,255,255,0.72)",
                  color: selected ? "#1d4ed8" : "inherit",
                  boxShadow: selected
                    ? "0 10px 24px rgba(37, 99, 235, 0.14)"
                    : "none",
                }}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div
          style={{
            padding: 14,
            borderBottom: "1px solid rgba(148, 163, 184, 0.22)",
            background: "rgba(59, 130, 246, 0.08)",
          }}
        >
          <strong>{POLICY_TABS.find((tab) => tab.key === activeTab)?.label}</strong>
          <div style={{ marginTop: 4, opacity: 0.75 }}>
            {POLICY_TABS.find((tab) => tab.key === activeTab)?.description}
          </div>
        </div>

        <div style={{ padding: 14 }}>
          {activeTab === "verification" ? (
            <VerificationSection
              requiresVerification={requiresVerification}
              minimumApprovals={minimumApprovals}
              selectedRoles={verificationRoles}
              onRequiresVerificationChange={setRequiresVerification}
              onMinimumApprovalsChange={setMinimumApprovals}
              onToggleRole={(key) => toggleInSet(setVerificationRoles, key)}
            />
          ) : null}

          {activeTab === "dispatch" ? (
            <DispatchSection
              postVerifyDispatchMode={postVerifyDispatchMode}
              allowAutoDispatch={allowAutoDispatch}
              trackingEnabled={trackingEnabled}
              selectedRoles={dispatchRoles}
              selectedTeams={dispatchTeams}
              onDispatchModeChange={setPostVerifyDispatchMode}
              onAllowAutoDispatchChange={setAllowAutoDispatch}
              onTrackingEnabledChange={setTrackingEnabled}
              onToggleRole={(key) => toggleInSet(setDispatchRoles, key)}
              onToggleTeam={(key) => toggleInSet(setDispatchTeams, key)}
            />
          ) : null}

          {activeTab === "notifications" ? (
            <NotificationsSection
              notificationsEnabled={notificationMode !== "NONE"}
              retryEnabled={true}
              retryCount={3}
              selectedRoles={
                new Set(
                  [...notificationTargets].filter(
                    (key) =>
                      key.includes("MANAGER") ||
                      key.includes("COMMANDER") ||
                      key.includes("SUPERVISOR") ||
                      key.includes("RESPONDER") ||
                      key.includes("OFFICER") ||
                      key.includes("WARDEN") ||
                      key.includes("CONTROL")
                  )
                )
              }
              selectedTeams={
                new Set(
                  [...notificationTargets].filter(
                    (key) =>
                      key.includes("TEAM") ||
                      key === "GENERAL_USERS" ||
                      key === "MANAGEMENT"
                  )
                )
              }
              onNotificationsEnabledChange={(value) =>
                setNotificationMode(value ? "AUTO" : "NONE")
              }
              onRetryEnabledChange={() => {}}
              onRetryCountChange={() => {}}
              onToggleRole={(key: string) => toggleInSet(setNotificationTargets, key)}
              onToggleTeam={(key: string) => toggleInSet(setNotificationTargets, key)}
            />
          ) : null}

          {activeTab === "external" ? (
            <ExternalSection
              externalEnabled={externalEnabled}
              externalMode={externalMode}
              selectedAuthorityTypes={externalAuthorityTypes}
              requesterRoles={requesterRoles}
              approverRoles={approverRoles}
              executorRoles={executorRoles}
              approvalRequired={approvalRequired}
              acknowledgementRequired={acknowledgementRequired}
              channels={channels}
              onExternalEnabledChange={setExternalEnabled}
              onExternalModeChange={setExternalMode}
              onToggleAuthorityType={(key) => toggleInSet(setExternalAuthorityTypes, key)}
              onToggleRequesterRole={(key) => toggleInSet(setRequesterRoles, key)}
              onToggleApproverRole={(key) => toggleInSet(setApproverRoles, key)}
              onToggleExecutorRole={(key) => toggleInSet(setExecutorRoles, key)}
              onApprovalRequiredChange={setApprovalRequired}
              onAcknowledgementRequiredChange={setAcknowledgementRequired}
              onToggleChannel={(key) => toggleInSet(setChannels, key)}
            />
          ) : null}

          {activeTab === "closure" ? (
            <ClosureSection
              requiresVerifiedIncident={requiresVerifiedIncident}
              selectedRoles={closureRoles}
              requiresActionsCompleted={requiresActionsCompleted}
              requiresInvestigationCompleted={requiresInvestigationCompleted}
              overrideRoles={overrideRoles}
              overrideRequiresNotes={overrideRequiresNotes}
              onRequiresVerifiedIncidentChange={setRequiresVerifiedIncident}
              onToggleRole={(key) => toggleInSet(setClosureRoles, key)}
              onRequiresActionsCompletedChange={setRequiresActionsCompleted}
              onRequiresInvestigationCompletedChange={setRequiresInvestigationCompleted}
              onToggleOverrideRole={(key) => toggleInSet(setOverrideRoles, key)}
              onOverrideRequiresNotesChange={setOverrideRequiresNotes}
            />
          ) : null}
        </div>
      </section>

      <div
        style={{
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 16,
          padding: 16,
          background: "rgba(255,255,255,0.02)",
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          gap: 12,
        }}
      >
        <button
          type="button"
          onClick={handleSave}
          disabled={mutation.isPending}
          style={{
            padding: "12px 18px",
            borderRadius: 12,
            border: "none",
            cursor: mutation.isPending ? "not-allowed" : "pointer",
            fontWeight: 700,
          }}
        >
          {mutation.isPending ? "Αποθήκευση..." : "Αποθήκευση Πολιτικής"}
        </button>

        {mutation.isSuccess ? (
          <div style={{ color: "limegreen" }}>
            Οι αλλαγές αποθηκεύτηκαν
          </div>
        ) : null}

        {mutation.isError ? (
          <div style={{ color: "crimson" }}>
            Σφάλμα αποθήκευσης: {String(mutation.error)}
          </div>
        ) : null}
      </div>
    </div>
  );
}