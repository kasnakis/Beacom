type Props = {
  title?: string;
  options: readonly string[] | string[];
  selected: Set<string>;
  onToggle: (key: string) => void;
};

export function CheckboxGroup({ title, options, selected, onToggle }: Props) {
  return (
    <div>
      {title ? (
        <div style={{ marginBottom: 8, fontWeight: 600 }}>{title}</div>
      ) : null}

      <div style={{ display: "grid", gap: 8 }}>
        {options.map((option) => (
          <label
            key={option}
            style={{ display: "flex", gap: 10, alignItems: "center" }}
          >
            <input
              type="checkbox"
              checked={selected.has(option)}
              onChange={() => onToggle(option)}
            />
            <span>{option}</span>
          </label>
        ))}
      </div>
    </div>
  );
}