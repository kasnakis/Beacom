import { ROLE_OPTIONS } from "../../../../domain/enums/roles";
import { TEAM_OPTIONS } from "../../../../domain/enums/teams";
import {
  LabelWithKey,
  ROLE_LABELS_EL,
  TEAM_LABELS_EL,
} from "./PolicyLabels";

type Props = {
  notificationsEnabled: boolean;
  retryEnabled: boolean;
  retryCount: number;

  selectedRoles: Set<string>;
  selectedTeams: Set<string>;

  onNotificationsEnabledChange: (value: boolean) => void;
  onRetryEnabledChange: (value: boolean) => void;
  onRetryCountChange: (value: number) => void;

  onToggleRole: (role: string) => void;
  onToggleTeam: (team: string) => void;
};

const ROLES = ROLE_OPTIONS;
const TEAMS = TEAM_OPTIONS;

const recommendedRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "SUPERVISOR",
  "CONTROL_ROOM",
  "FIRST_AID_RESPONDER",
  "FIRE_SAFETY_COORDINATOR",
]);

const recommendedTeams = new Set([
  "EMERGENCY_TEAM",
  "FIRE_TEAM",
  "FIRST_AID_TEAM",
  "HSE_TEAM",
  "CONTROL_ROOM_TEAM",
]);

function roleHelper(role: string) {
  const helpers: Record<string, string> = {
    HSE_MANAGER:
      "Λαμβάνει κρίσιμες επιχειρησιακές ειδοποιήσεις και συντονίζει την απόκριση.",
    EMERGENCY_COMMANDER:
      "Κύριος αποδέκτης emergency dispatch και escalations.",
    SITE_MANAGER:
      "Λαμβάνει ενημέρωση για σοβαρά περιστατικά της μονάδας.",
    SUPERVISOR:
      "Χρήσιμος για άμεση επιχειρησιακή ενημέρωση και τοπικό συντονισμό.",
    CONTROL_ROOM:
      "Χρήσιμος για κεντρική παρακολούθηση και operational εικόνα.",
    FIRST_AID_RESPONDER:
      "Λαμβάνει medical / injury related notifications.",
    FIRE_SAFETY_COORDINATOR:
      "Λαμβάνει ειδοποιήσεις πυρκαγιάς και πυρασφάλειας.",
    WORKER:
      "Χρήση μόνο όταν απαιτείται ευρεία ενημέρωση προσωπικού.",
    VIEWER:
      "Ρόλος προβολής. Συνήθως δεν χρειάζεται operational notifications.",
  };

  return (
    helpers[role] ||
    "Μπορεί να λαμβάνει ειδοποιήσεις ανάλογα με την πολιτική."
  );
}

function teamHelper(team: string) {
  const helpers: Record<string, string> = {
    EMERGENCY_TEAM:
      "Κύρια ομάδα επιχειρησιακής ανταπόκρισης έκτακτης ανάγκης.",
    FIRE_TEAM:
      "Ομάδα πυρασφάλειας και αντιμετώπισης πυρκαγιάς.",
    FIRST_AID_TEAM:
      "Ομάδα πρώτων βοηθειών και υποστήριξης τραυματιών.",
    EVACUATION_TEAM:
      "Ομάδα εκκένωσης και καθοδήγησης προσωπικού.",
    HSE_TEAM:
      "Ομάδα Υγείας & Ασφάλειας για αξιολόγηση και διερεύνηση.",
    CONTROL_ROOM_TEAM:
      "Control room / επιχειρησιακή παρακολούθηση.",
    MANAGEMENT:
      "Διοικητική ενημέρωση. Χρήση με προσοχή.",
    GENERAL_USERS:
      "Γενική ειδοποίηση προσωπικού. Μπορεί να δημιουργήσει notification noise.",
  };

  return (
    helpers[team] ||
    "Η ομάδα μπορεί να λαμβάνει ειδοποιήσεις σύμφωνα με την πολιτική."
  );
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "success" | "warning" | "danger" | "info" | "neutral";
}) {
  return <span style={{ ...pillStyle, ...pillTone(tone) }}>{children}</span>;
}

function pillTone(
  tone: "success" | "warning" | "danger" | "info" | "neutral"
): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };
    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };
    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "inherit",
      };
  }
}

export function NotificationsSection({
  notificationsEnabled,
  retryEnabled,
  retryCount,
  selectedRoles,
  selectedTeams,
  onNotificationsEnabledChange,
  onRetryEnabledChange,
  onRetryCountChange,
  onToggleRole,
  onToggleTeam,
}: Props) {
  const noTargets =
    selectedRoles.size === 0 && selectedTeams.size === 0;

  const broadNotifications =
    selectedTeams.has("GENERAL_USERS") ||
    selectedTeams.has("MANAGEMENT");

  return (
    <section style={sectionStyle}>
      <div style={headerRow}>
        <div>
          <div style={eyebrowStyle}>Notification Policy</div>
          <div style={titleStyle}>Πολιτική ειδοποιήσεων</div>
          <div style={subtitleStyle}>
            Ορίζει ποιοι χρήστες και ομάδες θα λαμβάνουν
            push notifications και πώς θα γίνεται retry/error handling.
          </div>
        </div>

        <div style={summaryPills}>
          <StatusPill
            tone={notificationsEnabled ? "success" : "neutral"}
          >
            {notificationsEnabled
              ? "Ειδοποιήσεις ενεργές"
              : "Ειδοποιήσεις ανενεργές"}
          </StatusPill>

          <StatusPill
            tone={retryEnabled ? "warning" : "neutral"}
          >
            Retry: {retryEnabled ? "ON" : "OFF"}
          </StatusPill>

          <StatusPill
            tone={
              noTargets && notificationsEnabled
                ? "danger"
                : "success"
            }
          >
            {selectedRoles.size + selectedTeams.size} targets
          </StatusPill>
        </div>
      </div>

      <div style={helperBox}>
        <strong>Επιχειρησιακή λογική:</strong> Οι ειδοποιήσεις
        χρησιμοποιούνται για ενημέρωση, κινητοποίηση και escalation.
        Για emergency/SOS συμβάντα πρέπει να αποστέλλονται άμεσα
        στους σωστούς ρόλους και ομάδες.
      </div>

      <div style={flowBox}>
        <div style={flowTitle}>
          Κύκλος αποστολής notification
        </div>

        <div style={flowSteps}>
          <span>1. Δημιουργία request</span>
          <span>2. Εύρεση targets</span>
          <span>3. Αποστολή FCM</span>
          <span>4. Delivery result</span>
          <span>5. Retry / Failure handling</span>
        </div>

        <div style={flowHint}>
          Το σύστημα πρέπει να δείχνει καθαρά αν η ειδοποίηση
          στάλθηκε, απέτυχε, έγινε retry ή δεν βρέθηκαν αποδέκτες.
        </div>
      </div>

      <div style={toggleGrid}>
        <label style={toggleCard}>
          <div style={toggleLine}>
            <input
              type="checkbox"
              checked={notificationsEnabled}
              onChange={(e) =>
                onNotificationsEnabledChange(
                  e.target.checked
                )
              }
            />

            <div>
              <div style={toggleTitle}>
                Ενεργοποίηση ειδοποιήσεων
              </div>

              <div style={toggleDescription}>
                Όταν είναι ενεργό, το policy engine μπορεί να
                δημιουργήσει notification requests.
              </div>
            </div>
          </div>

          <div
            style={
              notificationsEnabled
                ? requirementStateOn
                : requirementStateOff
            }
          >
            {notificationsEnabled
              ? "Οι ειδοποιήσεις μπορούν να αποστέλλονται σύμφωνα με την πολιτική."
              : "Δεν θα δημιουργούνται notification requests από αυτό το policy."}
          </div>
        </label>

        <label style={toggleCard}>
          <div style={toggleLine}>
            <input
              type="checkbox"
              checked={retryEnabled}
              onChange={(e) =>
                onRetryEnabledChange(e.target.checked)
              }
            />

            <div>
              <div style={toggleTitle}>
                Retry αποτυχημένων ειδοποιήσεων
              </div>

              <div style={toggleDescription}>
                Αν αποτύχει προσωρινά η αποστολή,
                το σύστημα μπορεί να ξαναδοκιμάσει.
              </div>
            </div>
          </div>

          <div
            style={
              retryEnabled
                ? requirementStateOn
                : requirementStateOff
            }
          >
            {retryEnabled
              ? "Το notification engine μπορεί να κάνει retry σε προσωρινές αποτυχίες."
              : "Οι αποτυχημένες αποστολές θα παραμένουν failed χωρίς retry."}
          </div>
        </label>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>
          Μέγιστος αριθμός retries
        </div>

        <div style={hintStyle}>
          Ορίζει πόσες φορές θα επιχειρείται ξανά
          η αποστολή πριν θεωρηθεί οριστικά failed.
        </div>

        <input
          type="number"
          min={0}
          max={10}
          value={retryCount}
          onChange={(e) =>
            onRetryCountChange(Number(e.target.value))
          }
          style={numberInput}
        />
      </div>

      {noTargets && notificationsEnabled ? (
        <div style={dangerNotice}>
          Δεν έχουν επιλεγεί ρόλοι ή ομάδες αποδεκτών.
          Το σύστημα μπορεί να δημιουργεί notification requests
          χωρίς πραγματικούς παραλήπτες (NO_TARGETS).
        </div>
      ) : null}

      {broadNotifications ? (
        <div style={warningNotice}>
          Χρησιμοποιούνται broad notification targets
          (GENERAL_USERS / MANAGEMENT).
          Αυτό μπορεί να αυξήσει σημαντικά τον αριθμό
          ειδοποιήσεων και το notification noise.
        </div>
      ) : null}

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>
          Ρόλοι που λαμβάνουν ειδοποιήσεις
        </div>

        <div style={roleGrid}>
          {ROLES.map((role) => (
            <label
              key={role}
              style={
                selectedRoles.has(role)
                  ? selectedItem
                  : item
              }
            >
              <div style={toggleLine}>
                <input
                  type="checkbox"
                  checked={selectedRoles.has(role)}
                  onChange={() => onToggleRole(role)}
                />

                <div>
                  <div style={labelLine}>
                    <LabelWithKey
                      value={role}
                      labels={ROLE_LABELS_EL}
                    />

                    {recommendedRoles.has(role) ? (
                      <StatusPill tone="success">
                        Προτεινόμενο
                      </StatusPill>
                    ) : null}
                  </div>

                  <div style={itemHelper}>
                    {roleHelper(role)}
                  </div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>
          Ομάδες που λαμβάνουν ειδοποιήσεις
        </div>

        <div style={roleGrid}>
          {TEAMS.map((team) => (
            <label
              key={team}
              style={
                selectedTeams.has(team)
                  ? selectedItem
                  : item
              }
            >
              <div style={toggleLine}>
                <input
                  type="checkbox"
                  checked={selectedTeams.has(team)}
                  onChange={() => onToggleTeam(team)}
                />

                <div>
                  <div style={labelLine}>
                    <LabelWithKey
                      value={team}
                      labels={TEAM_LABELS_EL}
                    />

                    {recommendedTeams.has(team) ? (
                      <StatusPill tone="success">
                        Προτεινόμενο
                      </StatusPill>
                    ) : null}
                  </div>

                  <div style={itemHelper}>
                    {teamHelper(team)}
                  </div>
                </div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div style={messagePreviewBox}>
        <div style={messagePreviewTitle}>
          Τι πρέπει να βλέπει ο operator
        </div>

        <ul style={messageList}>
          <li>
            Πόσοι χρήστες/ομάδες ειδοποιήθηκαν.
          </li>

          <li>
            Αν υπήρξε PARTIAL DELIVERY ή FAILED delivery.
          </li>

          <li>
            Αν δεν βρέθηκαν targets (NO_TARGETS).
          </li>

          <li>
            Αν έγινε retry αποστολής.
          </li>

          <li>
            Αν υπάρχουν invalid FCM tokens.
          </li>

          <li>
            Ποιοι responders έλαβαν ειδοποίηση αλλά
            δεν ανταποκρίθηκαν.
          </li>
        </ul>
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 14,
  padding: 16,
  background: "var(--surface)",
};

const headerRow: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: "uppercase",
  letterSpacing: 0.8,
  opacity: 0.62,
  marginBottom: 4,
};

const titleStyle: React.CSSProperties = {
  fontWeight: 900,
  fontSize: 16,
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 5,
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.45,
  maxWidth: 780,
};

const summaryPills: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
};

const pillStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
};

const helperBox: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
  fontSize: 12,
  lineHeight: 1.5,
};

const flowBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
};

const flowTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 8,
};

const flowSteps: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  fontSize: 12,
  fontWeight: 700,
};

const flowHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.72,
};

const toggleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
  gap: 10,
  marginTop: 14,
};

const toggleCard: React.CSSProperties = {
  display: "grid",
  gap: 8,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
};

const toggleLine: React.CSSProperties = {
  display: "flex",
  gap: 8,
  alignItems: "flex-start",
};

const toggleTitle: React.CSSProperties = {
  fontWeight: 850,
};

const toggleDescription: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
};

const requirementStateOn: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--success-soft)",
  border: "1px solid var(--success)",
  fontSize: 12,
};

const requirementStateOff: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
};

const subSectionWrap: React.CSSProperties = {
  marginTop: 16,
};

const subSectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 6,
};

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
  marginBottom: 8,
};

const numberInput: React.CSSProperties = {
  width: 120,
  padding: "9px 10px",
  borderRadius: 10,
  border: "1px solid var(--border-strong)",
  background: "var(--surface-2)",
  color: "inherit",
};

const dangerNotice: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--danger)",
  background: "var(--danger-soft)",
  fontSize: 12,
};

const warningNotice: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--warning)",
  background: "var(--warning-soft)",
  fontSize: 12,
};

const roleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
};

const item: React.CSSProperties = {
  display: "grid",
  gap: 6,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
};

const selectedItem: React.CSSProperties = {
  ...item,
  border: "1px solid var(--success)",
  background: "var(--success-soft)",
};

const labelLine: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
};

const itemHelper: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  opacity: 0.68,
};

const messagePreviewBox: React.CSSProperties = {
  marginTop: 16,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
};

const messagePreviewTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 12,
  marginBottom: 6,
};

const messageList: React.CSSProperties = {
  margin: 0,
  paddingLeft: 18,
  display: "grid",
  gap: 5,
  fontSize: 12,
};