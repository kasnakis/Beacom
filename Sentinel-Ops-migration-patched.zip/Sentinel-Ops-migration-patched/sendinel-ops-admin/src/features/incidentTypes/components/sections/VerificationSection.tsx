import { ROLE_OPTIONS } from "../../../../domain/enums/roles";
import { LabelWithKey, ROLE_LABELS_EL } from "./PolicyLabels";

type Props = {
  requiresVerification: boolean;
  minimumApprovals: number;
  selectedRoles: Set<string>;

  onRequiresVerificationChange: (value: boolean) => void;
  onMinimumApprovalsChange: (value: number) => void;
  onToggleRole: (role: string) => void;
};

const ROLES = ROLE_OPTIONS;

const recommendedVerifierRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "SUPERVISOR",
]);

function roleHelper(role: string) {
  const helpers: Record<string, string> = {
    HSE_MANAGER: "Προτεινόμενος ρόλος για επιβεβαίωση HSE / emergency συμβάντων.",
    EMERGENCY_COMMANDER: "Κατάλληλος για επιβεβαίωση συμβάντων που ενεργοποιούν ΣΑΕΚ ή επιχειρησιακή κινητοποίηση.",
    SITE_MANAGER: "Μπορεί να επιβεβαιώνει σε επίπεδο μονάδας, ειδικά όταν έχει επιχειρησιακή ευθύνη.",
    SUPERVISOR: "Χρήσιμος για αρχική επιβεβαίωση απλών ή τοπικών συμβάντων. Προσοχή σε σοβαρά incidents.",
    WORKER: "Συνήθως δεν πρέπει να επιβεβαιώνει συμβάν για formal governance.",
    VIEWER: "Ρόλος προβολής. Δεν προτείνεται για verification.",
    TECHNICIAN: "Μπορεί να χρησιμοποιηθεί μόνο σε ειδικές τεχνικές ροές, όχι ως γενικός verifier.",
  };

  return helpers[role];
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "success" | "warning" | "danger" | "info" | "neutral";
}) {
  return <span style={{ ...pillStyle, ...pillTone(tone) }}>{children}</span>;
}

function pillTone(tone: "success" | "warning" | "danger" | "info" | "neutral"): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };
    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };
    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "inherit",
      };
  }
}

function RoleOption({
  role,
  checked,
  recommended,
  caution,
  onToggle,
}: {
  role: string;
  checked: boolean;
  recommended?: boolean;
  caution?: boolean;
  onToggle: () => void;
}) {
  const helper = roleHelper(role);

  return (
    <label style={checked ? selectedRoleItem : roleItem}>
      <div style={roleTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={roleTitleLine}>
            <LabelWithKey value={role} labels={ROLE_LABELS_EL} />
            {recommended ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
            {caution ? <StatusPill tone="warning">Προσοχή</StatusPill> : null}
          </div>
          {helper ? <div style={roleHelperText}>{helper}</div> : null}
        </div>
      </div>
    </label>
  );
}

export function VerificationSection({
  requiresVerification,
  minimumApprovals,
  selectedRoles,
  onRequiresVerificationChange,
  onMinimumApprovalsChange,
  onToggleRole,
}: Props) {
  const verifierCount = selectedRoles.size;
  const hasWeakVerifier =
    selectedRoles.has("WORKER") || selectedRoles.has("VIEWER") || selectedRoles.has("TECHNICIAN");

  return (
    <section style={sectionStyle}>
      <div style={headerRow}>
        <div>
          <div style={eyebrowStyle}>Verification Policy</div>
          <div style={titleStyle}>Πολιτική επιβεβαίωσης συμβάντος</div>
          <div style={subtitleStyle}>
            Ορίζει αν ένα συμβάν χρειάζεται επιχειρησιακή επιβεβαίωση, ποιοι ρόλοι μπορούν να την κάνουν και πώς αυτό επηρεάζει τη συνέχεια της ροής και το closure.
          </div>
        </div>

        <div style={summaryPills}>
          <StatusPill tone={requiresVerification ? "warning" : "neutral"}>
            {requiresVerification ? "Απαιτείται επιβεβαίωση" : "Δεν απαιτείται επιβεβαίωση"}
          </StatusPill>
          <StatusPill tone={verifierCount ? "success" : requiresVerification ? "danger" : "neutral"}>
            {verifierCount} ρόλοι verifier
          </StatusPill>
          <StatusPill tone={minimumApprovals > 1 ? "info" : "neutral"}>
            {minimumApprovals} απαιτούμενες εγκρίσεις
          </StatusPill>
        </div>
      </div>

      <div style={helperBox}>
        <strong>Σχέση με Closure Policy:</strong> αν στο closure είναι ενεργό το “Require Verified Incident before closure”, τότε το συμβάν πρέπει να έχει καθαρό status <strong>VERIFIED</strong> ή <strong>AUTO_VERIFIED</strong> πριν επιτραπεί το formal closure. Αν δεν έχει επιβεβαιωθεί, ο χρήστης πρέπει να βλέπει μήνυμα: “Το συμβάν πρέπει πρώτα να επιβεβαιωθεί.”
      </div>

      <div style={flowBox}>
        <div style={flowTitle}>Πρακτική ερμηνεία για τους χρήστες</div>
        <div style={flowSteps}>
          <span>1. Καταχώρηση συμβάντος</span>
          <span>2. Έλεγχος από αρμόδιο ρόλο</span>
          <span>3. Επιβεβαίωση ή συνέχιση ροής</span>
          <span>4. Κινητοποίηση / ενέργειες</span>
          <span>5. Closure μόνο αν επιτρέπεται από policy</span>
        </div>
        <div style={flowHint}>
          Η επιβεβαίωση δεν είναι απλό “OK”. Είναι governance βήμα που τεκμηριώνει ότι το συμβάν αναγνωρίστηκε από αρμόδιο ρόλο.
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Απαίτηση επιβεβαίωσης</div>
        <label style={requirementCard}>
          <div style={requirementTopLine}>
            <input
              type="checkbox"
              checked={requiresVerification}
              onChange={(event) => onRequiresVerificationChange(event.target.checked)}
            />
            <div>
              <div style={requirementTitle}>Require verification</div>
              <div style={requirementDescription}>
                Όταν είναι ενεργό, το συμβάν πρέπει να επιβεβαιωθεί από εξουσιοδοτημένο ρόλο. Αν συνδυαστεί με “Require Verified Incident before closure”, τότε το κλείσιμο πρέπει να μπλοκάρεται μέχρι να ολοκληρωθεί το verification.
              </div>
            </div>
          </div>
          <div style={requiresVerification ? requirementStateOn : requirementStateOff}>
            {requiresVerification
              ? "Ενεργό: το συμβάν χρειάζεται verification από έναν από τους επιλεγμένους ρόλους."
              : "Ανενεργό: το συμβάν μπορεί να συνεχίσει χωρίς ξεχωριστή επιβεβαίωση. Το closure θα ελεγχθεί από τους κανόνες closure policy."}
          </div>
        </label>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Ελάχιστες απαιτούμενες εγκρίσεις</div>
        <div style={hintStyle}>
          Για απλή ροή κρατήστε το 1. Μεγαλύτερη τιμή σημαίνει πιο αυστηρό governance, αλλά μπορεί να δυσκολέψει το pilot αν δεν υπάρχει αντίστοιχο UI/flow πολλαπλών εγκρίσεων.
        </div>

        <div style={numberRow}>
          <input
            type="number"
            min={1}
            max={10}
            value={minimumApprovals}
            onChange={(event) => {
              const next = Number(event.target.value);
              onMinimumApprovalsChange(Number.isFinite(next) && next > 0 ? next : 1);
            }}
            style={numberInput}
          />
          <div style={numberExplanation}>
            {minimumApprovals === 1
              ? "Τυπική ρύθμιση: αρκεί μία επιβεβαίωση από αρμόδιο ρόλο."
              : "Αυστηρή ρύθμιση: απαιτούνται πολλαπλές επιβεβαιώσεις. Ελέγξτε ότι το UI και το backend flow το υποστηρίζουν."}
          </div>
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που μπορούν να επιβεβαιώσουν συμβάν</div>
            <div style={hintStyle}>
              Αυτοί οι ρόλοι μπορούν να κάνουν verification όταν η πολιτική το απαιτεί.
            </div>
          </div>
          {requiresVerification && !verifierCount ? (
            <StatusPill tone="danger">Δεν έχει οριστεί verifier</StatusPill>
          ) : null}
          {hasWeakVerifier ? <StatusPill tone="warning">Προσοχή σε αδύναμο verifier role</StatusPill> : null}
        </div>

        <div style={operationalNote}>
          Για συμβάντα τύπου ΣΑΕΚ / emergency προτείνονται κυρίως HSE Manager, Emergency Commander και Site Manager. Ο Supervisor μπορεί να χρησιμοποιηθεί για αρχική επιβεβαίωση όταν η επιχειρησιακή ροή το προβλέπει.
        </div>

        <div style={roleGrid}>
          {ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              checked={selectedRoles.has(role)}
              recommended={recommendedVerifierRoles.has(role)}
              caution={role === "WORKER" || role === "VIEWER" || role === "TECHNICIAN"}
              onToggle={() => onToggleRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={messagePreviewBox}>
        <div style={messagePreviewTitle}>Μηνύματα που πρέπει να βλέπει ο χρήστης</div>
        <ul style={messageList}>
          {requiresVerification ? (
            <li>Το συμβάν απαιτεί επιβεβαίωση από εξουσιοδοτημένο ρόλο.</li>
          ) : (
            <li>Η πολιτική δεν απαιτεί verification πριν τη συνέχεια της ροής.</li>
          )}
          {requiresVerification && !verifierCount ? (
            <li>Δεν έχουν οριστεί ρόλοι που μπορούν να κάνουν επιβεβαίωση.</li>
          ) : null}
          <li>Αν το closure policy απαιτεί verified incident και το συμβάν δεν είναι VERIFIED/AUTO_VERIFIED, το κλείσιμο πρέπει να μπλοκάρεται.</li>
          <li>Σε απόρριψη ή μη επιβεβαίωση συμβάντος, πρέπει να υπάρχει καθαρή αιτιολογία στο ιστορικό.</li>
        </ul>
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 14,
  padding: 16,
  background: "var(--surface)",
};

const headerRow: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: "uppercase",
  letterSpacing: 0.8,
  opacity: 0.62,
  marginBottom: 4,
};

const titleStyle: React.CSSProperties = {
  fontWeight: 900,
  fontSize: 16,
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 5,
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.45,
  maxWidth: 780,
};

const summaryPills: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const pillStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const helperBox: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
  fontSize: 12,
  opacity: 0.92,
  lineHeight: 1.5,
};

const flowBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
};

const flowTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 8,
};

const flowSteps: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  fontSize: 12,
  fontWeight: 700,
};

const flowHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.4,
};

const subSectionWrap: React.CSSProperties = {
  marginTop: 16,
};

const sectionHeaderLine: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const subSectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 6,
};

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
  marginTop: 4,
  marginBottom: 6,
  lineHeight: 1.4,
};

const requirementCard: React.CSSProperties = {
  display: "grid",
  gap: 8,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const requirementTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 9,
};

const requirementTitle: React.CSSProperties = {
  fontWeight: 850,
  lineHeight: 1.35,
};

const requirementDescription: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.42,
};

const requirementStateOn: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--success-soft)",
  border: "1px solid var(--success)",
  fontSize: 12,
  lineHeight: 1.4,
};

const requirementStateOff: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.4,
};

const numberRow: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 12,
  flexWrap: "wrap",
  marginTop: 8,
};

const numberInput: React.CSSProperties = {
  width: 120,
  padding: "9px 10px",
  borderRadius: 10,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
};

const numberExplanation: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.78,
  lineHeight: 1.4,
  maxWidth: 680,
};

const operationalNote: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "var(--warning-soft)",
  border: "1px solid var(--warning)",
  fontSize: 12,
  lineHeight: 1.45,
};

const roleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
  marginTop: 8,
};

const roleItem: React.CSSProperties = {
  display: "grid",
  gap: 6,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const selectedRoleItem: React.CSSProperties = {
  ...roleItem,
  border: "1px solid var(--success)",
  background: "var(--success-soft)",
};

const roleTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 8,
};

const roleTitleLine: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
  lineHeight: 1.35,
};

const roleHelperText: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  opacity: 0.68,
  lineHeight: 1.35,
};

const messagePreviewBox: React.CSSProperties = {
  marginTop: 16,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
};

const messagePreviewTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 12,
  marginBottom: 6,
};

const messageList: React.CSSProperties = {
  margin: 0,
  paddingLeft: 18,
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.4,
};
