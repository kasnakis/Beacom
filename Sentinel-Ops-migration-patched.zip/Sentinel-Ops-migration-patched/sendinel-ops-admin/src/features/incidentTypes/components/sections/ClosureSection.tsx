import { ROLE_OPTIONS } from "../../../../domain/enums/roles";
import { LabelWithKey, ROLE_LABELS_EL } from "./PolicyLabels";

type Props = {
  requiresVerifiedIncident: boolean;
  selectedRoles: Set<string>;

  requiresActionsCompleted: boolean;
  requiresInvestigationCompleted: boolean;

  overrideRoles: Set<string>;
  overrideRequiresNotes: boolean;

  onRequiresVerifiedIncidentChange: (value: boolean) => void;
  onToggleRole: (role: string) => void;

  onRequiresActionsCompletedChange: (value: boolean) => void;
  onRequiresInvestigationCompletedChange: (value: boolean) => void;

  onToggleOverrideRole: (role: string) => void;
  onOverrideRequiresNotesChange: (value: boolean) => void;
};

const ROLES = ROLE_OPTIONS;

const recommendedClosureRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "SUPERVISOR",
]);

const recommendedOverrideRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
]);

function roleHelper(role: string) {
  const helpers: Record<string, string> = {
    HSE_MANAGER: "Κατάλληλος για closure όταν έχουν ολοκληρωθεί διερεύνηση και απαιτούμενες ενέργειες.",
    EMERGENCY_COMMANDER: "Κατάλληλος για επιχειρησιακό closure σε ενεργοποίηση ΣΑΕΚ ή σοβαρό συμβάν.",
    SITE_MANAGER: "Κατάλληλος για τελική έγκριση ολοκλήρωσης σε επίπεδο μονάδας.",
    SUPERVISOR: "Χρήσιμος για λειτουργικά συμβάντα. Προσοχή σε emergency closure χωρίς HSE/Commander.",
    WORKER: "Συνήθως δεν πρέπει να κλείνει συμβάν. Προτείνεται μόνο για ειδικές απλές ροές.",
    VIEWER: "Δεν προτείνεται για closure. Ρόλος προβολής.",
    TECHNICIAN: "Συνήθως όχι για formal incident closure, εκτός αν υπάρχει ειδική πολιτική.",
  };

  return helpers[role];
}

function countEnabled(values: Set<string>) {
  return values.size;
}

function StatusPill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "success" | "warning" | "danger" | "info" | "neutral" }) {
  return <span style={{ ...pillStyle, ...pillTone(tone) }}>{children}</span>;
}

function pillTone(tone: "success" | "warning" | "danger" | "info" | "neutral"): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };
    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };
    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "inherit",
      };
  }
}

function RequirementCard({
  title,
  description,
  checked,
  onChange,
  checkedText,
  uncheckedText,
}: {
  title: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  checkedText: string;
  uncheckedText: string;
}) {
  return (
    <label style={requirementCard}>
      <div style={requirementTopLine}>
        <input
          type="checkbox"
          checked={checked}
          onChange={(event) => onChange(event.target.checked)}
        />
        <div>
          <div style={requirementTitle}>{title}</div>
          <div style={requirementDescription}>{description}</div>
        </div>
      </div>
      <div style={checked ? requirementStateOn : requirementStateOff}>
        {checked ? checkedText : uncheckedText}
      </div>
    </label>
  );
}

function RoleOption({
  role,
  checked,
  recommended,
  caution,
  onToggle,
}: {
  role: string;
  checked: boolean;
  recommended?: boolean;
  caution?: boolean;
  onToggle: () => void;
}) {
  const helper = roleHelper(role);

  return (
    <label style={checked ? selectedRoleItem : authorityItem}>
      <div style={roleTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={roleTitleLine}>
            <LabelWithKey value={role} labels={ROLE_LABELS_EL} />
            {recommended ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
            {caution ? <StatusPill tone="warning">Προσοχή</StatusPill> : null}
          </div>
          {helper ? <div style={roleHelperText}>{helper}</div> : null}
        </div>
      </div>
    </label>
  );
}

export function ClosureSection({
  requiresVerifiedIncident,
  selectedRoles,
  requiresActionsCompleted,
  requiresInvestigationCompleted,
  overrideRoles,
  overrideRequiresNotes,
  onRequiresVerifiedIncidentChange,
  onToggleRole,
  onRequiresActionsCompletedChange,
  onRequiresInvestigationCompletedChange,
  onToggleOverrideRole,
  onOverrideRequiresNotesChange,
}: Props) {
  const closureRoleCount = countEnabled(selectedRoles);
  const overrideRoleCount = countEnabled(overrideRoles);
  const hasPotentiallyWideOverride = overrideRoles.has("SUPERVISOR") || overrideRoles.has("WORKER") || overrideRoles.has("TECHNICIAN");

  return (
    <section style={sectionStyle}>
      <div style={headerRow}>
        <div>
          <div style={eyebrowStyle}>Closure Policy</div>
          <div style={titleStyle}>Πολιτική ολοκλήρωσης συμβάντος</div>
          <div style={subtitleStyle}>
            Καθορίζει πότε ένα συμβάν μπορεί να κλείσει επίσημα, ποιοι ρόλοι έχουν δικαίωμα και ποιες προϋποθέσεις πρέπει να έχουν ολοκληρωθεί.
          </div>
        </div>

        <div style={summaryPills}>
          <StatusPill tone={requiresVerifiedIncident ? "warning" : "neutral"}>
            {requiresVerifiedIncident ? "Απαιτεί verification" : "Χωρίς απαίτηση verification"}
          </StatusPill>
          <StatusPill tone={closureRoleCount ? "success" : "danger"}>
            {closureRoleCount} ρόλοι closure
          </StatusPill>
          <StatusPill tone={overrideRoleCount ? "warning" : "neutral"}>
            {overrideRoleCount} ρόλοι override
          </StatusPill>
        </div>
      </div>

      <div style={helperBox}>
        <strong>Λογική λειτουργίας:</strong> το κουμπί ολοκλήρωσης πρέπει να ακολουθεί ακριβώς τις επιλογές αυτής της πολιτικής.
        Αν λείπει επιβεβαίωση, ενέργεια, διερεύνηση ή σωστός ρόλος, ο χρήστης πρέπει να βλέπει σαφές ελληνικό μήνυμα με οδηγίες.
      </div>

      <div style={flowBox}>
        <div style={flowTitle}>Προτεινόμενη επιχειρησιακή σειρά</div>
        <div style={flowSteps}>
          <span>1. Αντιμετώπιση</span>
          <span>2. Υπό έλεγχο</span>
          <span>3. Ολοκλήρωση ενεργειών</span>
          <span>4. Διερεύνηση</span>
          <span>5. Formal closure</span>
        </div>
        <div style={flowHint}>
          Το “Deactivation” ή “Υπό έλεγχο” δεν είναι απαραίτητα το ίδιο με το τελικό κλείσιμο. Το τελικό closure πρέπει να γίνεται με βάση τα παρακάτω requirements.
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Απαίτηση επιβεβαίωσης πριν από closure</div>
        <RequirementCard
          title="Require Verified Incident before closure"
          description="Όταν είναι ενεργό, το συμβάν πρέπει πρώτα να έχει καθαρό verification status πριν επιτραπεί formal closure. Αν είναι ανενεργό, το closure ελέγχεται μόνο από τους επιτρεπόμενους ρόλους και τις υπόλοιπες απαιτήσεις."
          checked={requiresVerifiedIncident}
          onChange={onRequiresVerifiedIncidentChange}
          checkedText="Ενεργό: αν το συμβάν δεν είναι VERIFIED ή AUTO_VERIFIED, το κλείσιμο πρέπει να μπλοκάρεται με μήνυμα: “Το συμβάν πρέπει πρώτα να επιβεβαιωθεί.”"
          uncheckedText="Ανενεργό: δεν απαιτείται verification πριν από closure. Παραμένουν ενεργοί οι έλεγχοι ρόλων, ενεργειών και διερεύνησης."
        />
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που μπορούν να ολοκληρώσουν συμβάν</div>
            <div style={hintStyle}>
              Επιλέξτε τους ρόλους που επιτρέπεται να κάνουν κανονικό closure όταν έχουν ικανοποιηθεί οι απαιτήσεις της πολιτικής.
            </div>
          </div>
          {!closureRoleCount ? <StatusPill tone="danger">Δεν έχει οριστεί ρόλος closure</StatusPill> : null}
        </div>

        <div style={operationalNote}>
          Για emergency/ΣΑΕΚ σενάρια προτείνονται κυρίως HSE Manager, Emergency Commander και Site Manager. Ο Supervisor μπορεί να έχει δικαίωμα closure σε ελεγχόμενα σενάρια, αλλά χρειάζεται προσοχή σε σοβαρά περιστατικά.
        </div>

        <div style={authorityGrid}>
          {ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              checked={selectedRoles.has(role)}
              recommended={recommendedClosureRoles.has(role)}
              caution={role === "WORKER" || role === "VIEWER" || role === "TECHNICIAN"}
              onToggle={() => onToggleRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Απαιτήσεις πριν από το κλείσιμο</div>
        <div style={hintStyle}>
          Οι απαιτήσεις αυτές εμποδίζουν το πρόωρο κλείσιμο. Αν κάτι λείπει, το UI πρέπει να καθοδηγεί τον χρήστη με σαφές μήνυμα.
        </div>

        <div style={requirementsGrid}>
          <RequirementCard
            title="Require all actions completed"
            description="Απαιτεί να έχουν ολοκληρωθεί οι επιχειρησιακές ενέργειες που δημιουργούνται από τη ροή του συμβάντος."
            checked={requiresActionsCompleted}
            onChange={onRequiresActionsCompletedChange}
            checkedText="Ενεργό: το closure πρέπει να μπλοκάρεται όταν υπάρχουν ανοικτές ή εκκρεμείς ενέργειες."
            uncheckedText="Ανενεργό: το συμβάν μπορεί να κλείσει ακόμη και αν υπάρχουν ανοικτές ενέργειες. Χρήσιμο μόνο σε απλές ροές."
          />

          <RequirementCard
            title="Require investigation completed"
            description="Απαιτεί να έχει συμπληρωθεί και ολοκληρωθεί η διερεύνηση του συμβάντος πριν από το formal closure."
            checked={requiresInvestigationCompleted}
            onChange={onRequiresInvestigationCompletedChange}
            checkedText="Ενεργό: το closure πρέπει να μπλοκάρεται με μήνυμα ότι η διερεύνηση δεν έχει ολοκληρωθεί."
            uncheckedText="Ανενεργό: δεν απαιτείται investigation για closure. Προσοχή σε σοβαρά HSE ή emergency incidents."
          />
        </div>

        <div style={messagePreviewBox}>
          <div style={messagePreviewTitle}>Μηνύματα που πρέπει να βλέπει ο χρήστης όταν μπλοκάρεται το closure</div>
          <ul style={messageList}>
            {requiresVerifiedIncident ? <li>Το συμβάν απαιτεί επιβεβαίωση πριν την ολοκλήρωση.</li> : null}
            {requiresActionsCompleted ? <li>Υπάρχουν ανοικτές ή εκκρεμείς επιχειρησιακές ενέργειες.</li> : null}
            {requiresInvestigationCompleted ? <li>Η διερεύνηση του συμβάντος δεν έχει ολοκληρωθεί.</li> : null}
            <li>Ο ρόλος σας δεν επιτρέπεται να ολοκληρώσει το συμβάν, αν δεν ανήκει στους ρόλους closure.</li>
            <li>Σε περίπτωση override, η αιτιολόγηση πρέπει να καταγραφεί στο ιστορικό.</li>
          </ul>
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Κανόνες παράκαμψης / override</div>
            <div style={hintStyle}>
              Το override πρέπει να χρησιμοποιείται μόνο όταν υπάρχει πραγματικός επιχειρησιακός λόγος. Δεν πρέπει να γίνει “εύκολο κουμπί” για να παρακάμπτονται οι πολιτικές.
            </div>
          </div>
          {hasPotentiallyWideOverride ? <StatusPill tone="warning">Προσοχή σε ευρύ override</StatusPill> : null}
        </div>

        <div style={overrideWarningBox}>
          <strong>Προτεινόμενη πρακτική:</strong> κρατήστε override κυρίως σε HSE Manager, Emergency Commander και πιθανώς Site Manager.
          Αν δοθεί σε πολλούς ρόλους, αποδυναμώνεται η λογική governance του closure.
        </div>

        <div style={authorityGrid}>
          {ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              checked={overrideRoles.has(role)}
              recommended={recommendedOverrideRoles.has(role)}
              caution={role === "SUPERVISOR" || role === "WORKER" || role === "VIEWER" || role === "TECHNICIAN"}
              onToggle={() => onToggleOverrideRole(role)}
            />
          ))}
        </div>

        <RequirementCard
          title="Override requires notes"
          description="Απαιτεί υποχρεωτική αιτιολόγηση όταν κάποιος παρακάμπτει policy requirements."
          checked={overrideRequiresNotes}
          onChange={onOverrideRequiresNotesChange}
          checkedText="Ενεργό: το override δεν πρέπει να εκτελείται χωρίς αιτιολόγηση, η οποία πρέπει να γράφεται στο audit trail."
          uncheckedText="Ανενεργό: επιτρέπεται override χωρίς υποχρεωτική σημείωση. Δεν προτείνεται για production/pilot governance."
        />
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 14,
  padding: 16,
  background: "var(--surface)",
};

const headerRow: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: "uppercase",
  letterSpacing: 0.8,
  opacity: 0.62,
  marginBottom: 4,
};

const titleStyle: React.CSSProperties = {
  fontWeight: 900,
  fontSize: 16,
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 5,
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.45,
  maxWidth: 760,
};

const summaryPills: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const pillStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const helperBox: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
  fontSize: 12,
  opacity: 0.92,
  lineHeight: 1.5,
};

const flowBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
};

const flowTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 8,
};

const flowSteps: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  fontSize: 12,
  fontWeight: 700,
};

const flowHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.4,
};

const subSectionWrap: React.CSSProperties = {
  marginTop: 16,
};

const sectionHeaderLine: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const subSectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 6,
};

const requirementsGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
  gap: 10,
  marginTop: 8,
};

const requirementCard: React.CSSProperties = {
  display: "grid",
  gap: 8,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const requirementTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 9,
};

const requirementTitle: React.CSSProperties = {
  fontWeight: 850,
  lineHeight: 1.35,
};

const requirementDescription: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.42,
};

const requirementStateOn: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--success-soft)",
  border: "1px solid var(--success)",
  fontSize: 12,
  lineHeight: 1.4,
};

const requirementStateOff: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.4,
};

const operationalNote: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "var(--warning-soft)",
  border: "1px solid var(--warning)",
  fontSize: 12,
  lineHeight: 1.45,
};

const overrideWarningBox: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "var(--danger-soft)",
  border: "1px solid var(--danger)",
  fontSize: 12,
  lineHeight: 1.45,
};

const authorityGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
  marginTop: 8,
};

const authorityItem: React.CSSProperties = {
  display: "grid",
  gap: 6,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const selectedRoleItem: React.CSSProperties = {
  ...authorityItem,
  border: "1px solid var(--success)",
  background: "var(--success-soft)",
};

const roleTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 8,
};

const roleTitleLine: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
  lineHeight: 1.35,
};

const roleHelperText: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  opacity: 0.68,
  lineHeight: 1.35,
};

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
  marginTop: 4,
  marginBottom: 6,
  lineHeight: 1.4,
};

const messagePreviewBox: React.CSSProperties = {
  marginTop: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
};

const messagePreviewTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 12,
  marginBottom: 6,
};

const messageList: React.CSSProperties = {
  margin: 0,
  paddingLeft: 18,
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.4,
};
