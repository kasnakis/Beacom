import { ROLE_OPTIONS } from "../../../../domain/enums/roles";
import {
  AUTHORITY_TYPE_LABELS_EL,
  CHANNEL_LABELS_EL,
  EXTERNAL_MODE_LABELS_EL,
  LabelWithKey,
  ROLE_LABELS_EL,
  optionLabel,
} from "./PolicyLabels";

type Props = {
  externalEnabled: boolean;
  externalMode: string;
  selectedAuthorityTypes: Set<string>;

  requesterRoles: Set<string>;
  approverRoles: Set<string>;
  executorRoles: Set<string>;

  approvalRequired: boolean;
  acknowledgementRequired: boolean;

  channels: Set<string>;

  onExternalEnabledChange: (value: boolean) => void;
  onExternalModeChange: (value: string) => void;
  onToggleAuthorityType: (authorityType: string) => void;

  onToggleRequesterRole: (role: string) => void;
  onToggleApproverRole: (role: string) => void;
  onToggleExecutorRole: (role: string) => void;

  onApprovalRequiredChange: (value: boolean) => void;
  onAcknowledgementRequiredChange: (value: boolean) => void;

  onToggleChannel: (channel: string) => void;
};

const EXTERNAL_MODES = ["NONE", "MANUAL", "AUTO", "PLAYBOOK_DRIVEN"];
const AUTHORITY_TYPES = [
  "FIRE_SERVICE",
  "POLICE",
  "EMS",
  "CIVIL_PROTECTION",
  "ENVIRONMENTAL_AUTHORITY",
];
const REQUESTER_ROLES = ROLE_OPTIONS;
const APPROVER_ROLES = ROLE_OPTIONS;
const EXECUTOR_ROLES = ROLE_OPTIONS;
const CHANNELS = ["PHONE", "EMAIL", "SMS", "RADIO"];

const recommendedRequesterRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "SUPERVISOR",
  "CONTROL_ROOM",
  "FIRST_AID_RESPONDER",
  "FIRE_SAFETY_COORDINATOR",
]);

const recommendedApproverRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
]);

const recommendedExecutorRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "CONTROL_ROOM",
  "FIRST_AID_RESPONDER",
  "FIRE_SAFETY_COORDINATOR",
]);

function modeDescription(mode: string) {
  switch (mode) {
    case "NONE":
      return "Δεν δημιουργούνται αιτήματα προς εξωτερικές αρχές για αυτόν τον τύπο συμβάντος.";
    case "MANUAL":
      return "Ο αρμόδιος χρήστης αποφασίζει και καταγράφει χειροκίνητα αν ειδοποιήθηκε κάποια αρχή.";
    case "AUTO":
      return "Η πολιτική δημιουργεί αυτόματα αιτήματα ειδοποίησης όταν το συμβάν πληροί τις προϋποθέσεις.";
    case "PLAYBOOK_DRIVEN":
      return "Η εμπλοκή εξωτερικών αρχών εκτελείται μέσα από συγκεκριμένα βήματα playbook.";
    default:
      return "Επιλέξτε τρόπο εμπλοκής εξωτερικών αρχών.";
  }
}

function authorityHelper(authorityType: string) {
  const helpers: Record<string, string> = {
    FIRE_SERVICE: "Χρήση σε πυρκαγιά, καπνό, ανάγκη εξωτερικής πυροσβεστικής συνδρομής ή έλεγχο μετά την κατάσβεση.",
    FIRE_BRIGADE: "Χρήση σε πυρκαγιά, καπνό, ανάγκη εξωτερικής πυροσβεστικής συνδρομής ή έλεγχο μετά την κατάσβεση.",
    POLICE: "Χρήση όταν απαιτείται ασφάλεια χώρου, ρύθμιση κυκλοφορίας, συμβάν με τρίτους ή συνδρομή αρχών.",
    EMS: "Χρήση όταν υπάρχει τραυματισμός, αναπνευστικό πρόβλημα, ανάγκη προληπτικής ιατρικής υποστήριξης ή διακομιδή.",
    CIVIL_PROTECTION: "Χρήση για σοβαρή κλιμάκωση, 112, ευρύτερο κίνδυνο ή ανάγκη συντονισμού με δημόσιες αρχές.",
    ENVIRONMENTAL_AUTHORITY: "Χρήση σε περιβαλλοντικό συμβάν, διαρροή, ρύπανση ή πιθανή επίπτωση εκτός εγκατάστασης.",
  };

  return helpers[authorityType];
}

function roleHelper(role: string, kind: "requester" | "approver" | "executor") {
  const common: Record<string, string> = {
    HSE_MANAGER: "Κεντρικός ρόλος για HSE, emergency και τεκμηρίωση αποφάσεων.",
    EMERGENCY_COMMANDER: "Κατάλληλος για αποφάσεις κλιμάκωσης σε ροές ΣΑΕΚ.",
    SITE_MANAGER: "Κατάλληλος για έγκριση/συντονισμό σε επίπεδο μονάδας.",
    SUPERVISOR: "Χρήσιμος για αρχική αναγνώριση και αίτημα ειδοποίησης, ανάλογα με τη ροή.",
    CONTROL_ROOM: "Χρήσιμος για πραγματική τηλεφωνική επικοινωνία και καταγραφή εκτέλεσης.",
    FIRST_AID_RESPONDER: "Κατάλληλος για ειδοποίηση/εκτέλεση σε ιατρικό περιστατικό ή ΕΚΑΒ.",
    FIRE_SAFETY_COORDINATOR: "Κατάλληλος για ειδοποίηση/εκτέλεση προς Πυροσβεστική σε πυρκαγιά.",
    WORKER: "Συνήθως δεν προτείνεται για formal εξωτερική ειδοποίηση, εκτός από ειδική ροή.",
    VIEWER: "Ρόλος προβολής. Δεν προτείνεται για επιχειρησιακές αποφάσεις.",
    TECHNICIAN: "Χρήσιμος μόνο σε ειδικά τεχνικά σενάρια.",
  };

  if (kind === "requester") {
    return common[role] || "Μπορεί να δημιουργήσει αίτημα ειδοποίησης, αν το επιτρέπει η πολιτική.";
  }

  if (kind === "approver") {
    return common[role] || "Μπορεί να εγκρίνει την ειδοποίηση πριν εκτελεστεί, αν απαιτείται έγκριση.";
  }

  return common[role] || "Μπορεί να καταγράψει ότι πραγματοποιήθηκε η πραγματική επικοινωνία.";
}

function channelHelper(channel: string) {
  const helpers: Record<string, string> = {
    PHONE: "Προτεινόμενο κύριο κανάλι για emergency ροές και άμεση επικοινωνία.",
    EMAIL: "Χρήσιμο για τεκμηρίωση ή μη επείγουσα ενημέρωση.",
    SMS: "Χρήσιμο για σύντομη ειδοποίηση, όπου υποστηρίζεται επιχειρησιακά.",
    RADIO: "Χρήσιμο για εσωτερικό επιχειρησιακό συντονισμό.",
  };

  return helpers[channel];
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "success" | "warning" | "danger" | "info" | "neutral";
}) {
  return <span style={{ ...pillStyle, ...pillTone(tone) }}>{children}</span>;
}

function pillTone(tone: "success" | "warning" | "danger" | "info" | "neutral"): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };
    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };
    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "inherit",
      };
  }
}

function RoleOption({
  role,
  checked,
  recommended,
  caution,
  kind,
  onToggle,
}: {
  role: string;
  checked: boolean;
  recommended?: boolean;
  caution?: boolean;
  kind: "requester" | "approver" | "executor";
  onToggle: () => void;
}) {
  return (
    <label style={checked ? selectedItem : authorityItem}>
      <div style={itemTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={labelLine}>
            <LabelWithKey value={role} labels={ROLE_LABELS_EL} />
            {recommended ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
            {caution ? <StatusPill tone="warning">Προσοχή</StatusPill> : null}
          </div>
          <div style={itemHelper}>{roleHelper(role, kind)}</div>
        </div>
      </div>
    </label>
  );
}

function AuthorityOption({
  authorityType,
  checked,
  onToggle,
}: {
  authorityType: string;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <label style={checked ? selectedItem : authorityItem}>
      <div style={itemTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={labelLine}>
            <LabelWithKey value={authorityType} labels={AUTHORITY_TYPE_LABELS_EL} />
          </div>
          <div style={itemHelper}>{authorityHelper(authorityType)}</div>
        </div>
      </div>
    </label>
  );
}

function ChannelOption({
  channel,
  checked,
  onToggle,
}: {
  channel: string;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <label style={checked ? selectedItem : authorityItem}>
      <div style={itemTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={labelLine}>
            <LabelWithKey value={channel} labels={CHANNEL_LABELS_EL} />
            {channel === "PHONE" ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
          </div>
          <div style={itemHelper}>{channelHelper(channel)}</div>
        </div>
      </div>
    </label>
  );
}

export function ExternalSection({
  externalEnabled,
  externalMode,
  selectedAuthorityTypes,
  requesterRoles,
  approverRoles,
  executorRoles,
  approvalRequired,
  acknowledgementRequired,
  channels,
  onExternalEnabledChange,
  onExternalModeChange,
  onToggleAuthorityType,
  onToggleRequesterRole,
  onToggleApproverRole,
  onToggleExecutorRole,
  onApprovalRequiredChange,
  onAcknowledgementRequiredChange,
  onToggleChannel,
}: Props) {
  const hasWeakApprover = approverRoles.has("WORKER") || approverRoles.has("VIEWER") || approverRoles.has("TECHNICIAN");
  const hasWeakExecutor = executorRoles.has("VIEWER");
  const modeDisabled = !externalEnabled || externalMode === "NONE";

  return (
    <section style={sectionStyle}>
      <div style={headerRow}>
        <div>
          <div style={eyebrowStyle}>External Authorities Policy</div>
          <div style={titleStyle}>Πολιτική εξωτερικών αρχών</div>
          <div style={subtitleStyle}>
            Ορίζει πότε εμπλέκονται εξωτερικές αρχές, ποιοι ρόλοι ζητούν/εγκρίνουν/εκτελούν την ειδοποίηση και πώς τεκμηριώνεται η επικοινωνία στο ιστορικό συμβάντος.
          </div>
        </div>

        <div style={summaryPills}>
          <StatusPill tone={externalEnabled ? "success" : "neutral"}>
            {externalEnabled ? "Ενεργό" : "Ανενεργό"}
          </StatusPill>
          <StatusPill tone={externalMode === "AUTO" ? "warning" : externalMode === "PLAYBOOK_DRIVEN" ? "info" : "neutral"}>
            {optionLabel(externalMode, EXTERNAL_MODE_LABELS_EL)}
          </StatusPill>
          <StatusPill tone={selectedAuthorityTypes.size ? "success" : externalEnabled ? "danger" : "neutral"}>
            {selectedAuthorityTypes.size} αρχές
          </StatusPill>
        </div>
      </div>

      <div style={helperBox}>
        <strong>Επιχειρησιακή λογική:</strong> η ενότητα αυτή δεν σημαίνει απαραίτητα ότι η εξωτερική αρχή ειδοποιείται αυτόματα. Ορίζει ποια αιτήματα δημιουργούνται, ποιοι μπορούν να τα εγκρίνουν και ποιοι καταγράφουν ότι έγινε η πραγματική επικοινωνία.
      </div>

      <div style={flowBox}>
        <div style={flowTitle}>Προτεινόμενη σειρά χειρισμού</div>
        <div style={flowSteps}>
          <span>1. Δημιουργία αιτήματος</span>
          <span>2. Έγκριση, αν απαιτείται</span>
          <span>3. Πραγματική επικοινωνία</span>
          <span>4. Καταγραφή αποτελέσματος</span>
          <span>5. Επιβεβαίωση λήψης</span>
        </div>
        <div style={flowHint}>
          Για ΣΑΕΚ/ασκήσεις είναι κρίσιμο να φαίνεται καθαρά ποιος αποφάσισε, ποιος τηλεφώνησε και τι απάντηση δόθηκε.
        </div>
      </div>

      <div style={toggleWrap}>
        <label style={mainToggleLabel}>
          <input
            type="checkbox"
            checked={externalEnabled}
            onChange={(e) => onExternalEnabledChange(e.target.checked)}
          />
          <span>
            <strong>Ενεργοποίηση εμπλοκής εξωτερικών αρχών</strong>
            <small>
              Όταν είναι ενεργό, η πολιτική μπορεί να δημιουργεί ή να επιτρέπει αιτήματα ειδοποίησης προς ΕΚΑΒ, Πυροσβεστική, Αστυνομία, Πολιτική Προστασία ή άλλη αρμόδια αρχή.
            </small>
          </span>
        </label>
      </div>

      <div style={fieldWrap}>
        <label style={labelStyle}>Τρόπος εμπλοκής εξωτερικών αρχών</label>
        <select
          value={externalMode}
          onChange={(e) => onExternalModeChange(e.target.value)}
          style={selectStyle}
        >
          {EXTERNAL_MODES.map((mode) => (
            <option key={mode} value={mode}>
              {optionLabel(mode, EXTERNAL_MODE_LABELS_EL)}
            </option>
          ))}
        </select>

        <div style={modeDescriptionBox}>
          {modeDescription(externalMode)}
        </div>
      </div>

      <div style={modeGuideBox}>
        <div style={modeGuideTitle}>Οδηγός επιλογής mode</div>
        <div style={modeGuideList}>
          <div><strong>Καμία:</strong> δεν δημιουργούνται αιτήματα προς εξωτερικές αρχές.</div>
          <div><strong>Χειροκίνητη:</strong> ο αρμόδιος χρήστης αποφασίζει και καταγράφει την ειδοποίηση.</div>
          <div><strong>Αυτόματη:</strong> η πολιτική δημιουργεί τις προβλεπόμενες ειδοποιήσεις όταν υπάρχουν τα κατάλληλα flags/severity.</div>
          <div><strong>Με playbook:</strong> η ειδοποίηση ακολουθεί συγκεκριμένα επιχειρησιακά βήματα.</div>
        </div>
      </div>

      {modeDisabled ? (
        <div style={disabledNotice}>
          Η εμπλοκή εξωτερικών αρχών είναι ανενεργή ή σε mode “Καμία”. Οι παρακάτω επιλογές μπορούν να παραμείνουν ως προετοιμασία, αλλά δεν πρέπει να δημιουργούνται ενεργά αιτήματα από αυτή την πολιτική.
        </div>
      ) : null}

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Κατηγορίες εξωτερικών αρχών</div>
            <div style={hintStyle}>
              Επιλέξτε ποιες αρχές μπορούν να εμπλακούν για τον συγκεκριμένο τύπο συμβάντος.
            </div>
          </div>
          {externalEnabled && !selectedAuthorityTypes.size ? (
            <StatusPill tone="danger">Δεν έχει επιλεγεί αρχή</StatusPill>
          ) : null}
        </div>

        <div style={authorityGrid}>
          {AUTHORITY_TYPES.map((authorityType) => (
            <AuthorityOption
              key={authorityType}
              authorityType={authorityType}
              checked={selectedAuthorityTypes.has(authorityType)}
              onToggle={() => onToggleAuthorityType(authorityType)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που μπορούν να ζητήσουν ειδοποίηση</div>
            <div style={hintStyle}>
              Οι ρόλοι αυτοί μπορούν να ξεκινήσουν αίτημα ειδοποίησης εξωτερικής αρχής.
            </div>
          </div>
          {externalEnabled && !requesterRoles.size ? <StatusPill tone="danger">Δεν έχει οριστεί requester</StatusPill> : null}
        </div>

        <div style={roleGrid}>
          {REQUESTER_ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              kind="requester"
              checked={requesterRoles.has(role)}
              recommended={recommendedRequesterRoles.has(role)}
              caution={role === "VIEWER"}
              onToggle={() => onToggleRequesterRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που εγκρίνουν την ειδοποίηση</div>
            <div style={hintStyle}>
              Χρησιμοποιούνται όταν είναι ενεργό το “Απαιτείται έγκριση πριν την ειδοποίηση”.
            </div>
          </div>
          {approvalRequired && !approverRoles.size ? <StatusPill tone="danger">Δεν έχει οριστεί approver</StatusPill> : null}
          {hasWeakApprover ? <StatusPill tone="warning">Προσοχή σε approver role</StatusPill> : null}
        </div>

        <div style={approvalNote}>
          Σε σοβαρό emergency/ΣΑΕΚ σενάριο, η έγκριση εξωτερικής ειδοποίησης καλό είναι να γίνεται από HSE Manager, Emergency Commander ή Site Manager, ώστε να υπάρχει σαφής επιχειρησιακή ευθύνη.
        </div>

        <div style={roleGrid}>
          {APPROVER_ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              kind="approver"
              checked={approverRoles.has(role)}
              recommended={recommendedApproverRoles.has(role)}
              caution={role === "WORKER" || role === "VIEWER" || role === "TECHNICIAN" || role === "SUPERVISOR"}
              onToggle={() => onToggleApproverRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που εκτελούν την ειδοποίηση</div>
            <div style={hintStyle}>
              Οι ρόλοι αυτοί μπορούν να καταγράψουν ότι έγινε η πραγματική επικοινωνία με την εξωτερική αρχή.
            </div>
          </div>
          {externalEnabled && !executorRoles.size ? <StatusPill tone="danger">Δεν έχει οριστεί executor</StatusPill> : null}
          {hasWeakExecutor ? <StatusPill tone="warning">Viewer ως executor</StatusPill> : null}
        </div>

        <div style={roleGrid}>
          {EXECUTOR_ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              kind="executor"
              checked={executorRoles.has(role)}
              recommended={recommendedExecutorRoles.has(role)}
              caution={role === "VIEWER"}
              onToggle={() => onToggleExecutorRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Κανόνες έγκρισης και επιβεβαίωσης λήψης</div>
        <div style={hintStyle}>
          Ορίστε αν χρειάζεται έγκριση πριν την πραγματική ειδοποίηση και αν πρέπει να καταγράφεται επιβεβαίωση λήψης/ανταπόκρισης.
        </div>

        <div style={rulesGrid}>
          <label style={ruleCard}>
            <div style={itemTopLine}>
              <input
                type="checkbox"
                checked={approvalRequired}
                onChange={(e) => onApprovalRequiredChange(e.target.checked)}
              />
              <div>
                <div style={ruleTitle}>Απαιτείται έγκριση πριν την ειδοποίηση</div>
                <div style={ruleDescription}>
                  Αν είναι ενεργό, το αίτημα πρέπει πρώτα να εγκριθεί από επιτρεπόμενο ρόλο πριν καταγραφεί ως πραγματικά εκτελεσμένο.
                </div>
              </div>
            </div>
            <div style={approvalRequired ? requirementStateOn : requirementStateOff}>
              {approvalRequired
                ? "Ενεργό: το σύστημα πρέπει να καθοδηγεί τον χρήστη να πάρει/δώσει έγκριση πριν την εκτέλεση."
                : "Ανενεργό: η ειδοποίηση μπορεί να καταγραφεί χωρίς ξεχωριστό approval step."}
            </div>
          </label>

          <label style={ruleCard}>
            <div style={itemTopLine}>
              <input
                type="checkbox"
                checked={acknowledgementRequired}
                onChange={(e) => onAcknowledgementRequiredChange(e.target.checked)}
              />
              <div>
                <div style={ruleTitle}>Απαιτείται καταγραφή επιβεβαίωσης λήψης</div>
                <div style={ruleDescription}>
                  Ζητά να καταγραφεί ότι η εξωτερική αρχή έλαβε την ειδοποίηση ή έδωσε κάποια απάντηση.
                </div>
              </div>
            </div>
            <div style={acknowledgementRequired ? requirementStateOn : requirementStateOff}>
              {acknowledgementRequired
                ? "Ενεργό: το workflow πρέπει να παραμένει τεκμηριωτικά ανοικτό μέχρι να καταγραφεί acknowledgement."
                : "Ανενεργό: αρκεί η καταγραφή ότι έγινε η επικοινωνία."}
            </div>
          </label>
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={subSectionTitle}>Κανάλια επικοινωνίας</div>
        <div style={hintStyle}>
          Επιλέξτε ποια κανάλια επιτρέπεται να χρησιμοποιούνται για την επικοινωνία με εξωτερικές αρχές.
        </div>

        <div style={authorityGrid}>
          {CHANNELS.map((channel) => (
            <ChannelOption
              key={channel}
              channel={channel}
              checked={channels.has(channel)}
              onToggle={() => onToggleChannel(channel)}
            />
          ))}
        </div>
      </div>

      <div style={messagePreviewBox}>
        <div style={messagePreviewTitle}>Μηνύματα που πρέπει να βλέπει ο χρήστης στη ροή συμβάντος</div>
        <ul style={messageList}>
          {externalEnabled ? (
            <li>Η πολιτική προβλέπει πιθανή εμπλοκή εξωτερικών αρχών για αυτόν τον τύπο συμβάντος.</li>
          ) : (
            <li>Η πολιτική δεν προβλέπει εμπλοκή εξωτερικών αρχών για αυτόν τον τύπο συμβάντος.</li>
          )}
          {approvalRequired ? <li>Πριν την ειδοποίηση απαιτείται έγκριση από αρμόδιο ρόλο.</li> : null}
          {acknowledgementRequired ? <li>Μετά την ειδοποίηση πρέπει να καταγραφεί επιβεβαίωση λήψης ή απάντηση.</li> : null}
          <li>Το ιστορικό πρέπει να δείχνει καθαρά ποιος ζήτησε, ποιος ενέκρινε και ποιος εκτέλεσε την επικοινωνία.</li>
          <li>Σε απόρριψη ειδοποίησης, πρέπει να καταγράφεται αιτιολογία, π.χ. “Εσωτερική επίλυση” ή “Δεν απαιτείται”.</li>
        </ul>
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 14,
  padding: 16,
  background: "var(--surface)",
};

const headerRow: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: "uppercase",
  letterSpacing: 0.8,
  opacity: 0.62,
  marginBottom: 4,
};

const titleStyle: React.CSSProperties = {
  fontWeight: 900,
  fontSize: 16,
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 5,
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.45,
  maxWidth: 780,
};

const summaryPills: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const pillStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const helperBox: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
  fontSize: 12,
  opacity: 0.92,
  lineHeight: 1.5,
};

const flowBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
};

const flowTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 8,
};

const flowSteps: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  fontSize: 12,
  fontWeight: 700,
};

const flowHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.4,
};

const toggleWrap: React.CSSProperties = {
  marginTop: 14,
};

const mainToggleLabel: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 10,
  padding: 12,
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
  fontSize: 13,
  lineHeight: 1.4,
  cursor: "pointer",
};

const fieldWrap: React.CSSProperties = {
  marginTop: 14,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  opacity: 0.72,
  marginBottom: 6,
};

const selectStyle: React.CSSProperties = {
  width: "100%",
  padding: "9px 10px",
  borderRadius: 10,
  border: "1px solid var(--border-strong)",
  background: "var(--surface-2)",
  color: "inherit",
};

const modeDescriptionBox: React.CSSProperties = {
  marginTop: 8,
  padding: 10,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  lineHeight: 1.45,
};

const modeGuideBox: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
};

const modeGuideTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 13,
  marginBottom: 6,
};

const modeGuideList: React.CSSProperties = {
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.45,
  opacity: 0.88,
};

const disabledNotice: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--warning)",
  background: "var(--warning-soft)",
  fontSize: 12,
  lineHeight: 1.45,
};

const subSectionWrap: React.CSSProperties = {
  marginTop: 16,
};

const sectionHeaderLine: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const subSectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 6,
  fontSize: 13,
};

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
  marginTop: 4,
  marginBottom: 6,
  lineHeight: 1.4,
};

const authorityGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
  marginTop: 8,
};

const roleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
  marginTop: 8,
};

const authorityItem: React.CSSProperties = {
  display: "grid",
  gap: 6,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const selectedItem: React.CSSProperties = {
  ...authorityItem,
  border: "1px solid var(--success)",
  background: "var(--success-soft)",
};

const itemTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 8,
};

const labelLine: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
  lineHeight: 1.35,
};

const itemHelper: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  opacity: 0.68,
  lineHeight: 1.35,
};

const approvalNote: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "var(--warning-soft)",
  border: "1px solid var(--warning)",
  fontSize: 12,
  lineHeight: 1.45,
};

const rulesGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
  gap: 10,
  marginTop: 8,
};

const ruleCard: React.CSSProperties = {
  display: "grid",
  gap: 8,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const ruleTitle: React.CSSProperties = {
  fontWeight: 850,
  lineHeight: 1.35,
};

const ruleDescription: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.42,
};

const requirementStateOn: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--success-soft)",
  border: "1px solid var(--success)",
  fontSize: 12,
  lineHeight: 1.4,
};

const requirementStateOff: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  opacity: 0.76,
  lineHeight: 1.4,
};

const messagePreviewBox: React.CSSProperties = {
  marginTop: 16,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info)",
};

const messagePreviewTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 12,
  marginBottom: 6,
};

const messageList: React.CSSProperties = {
  margin: 0,
  paddingLeft: 18,
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.4,
};
