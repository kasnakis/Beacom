export const ROLE_LABELS_EL: Record<string, string> = {
  WORKER: "Γενικός χρήστης",
  SUPERVISOR: "Επόπτης / Προϊστάμενος",
  SITE_MANAGER: "Διοίκηση μονάδας",
  DIRECTOR: "Διευθυντής / Επικεφαλής",
  CONTROL_ROOM: "Κέντρο ελέγχου",
  SECURITY_OFFICER: "Φύλαξη / Ασφάλεια χώρου",
  VIEWER: "Μόνο προβολή",
  HSE_MANAGER: "Υπεύθυνος Υγείας & Ασφάλειας",
  HSE_RESPONDER: "Ανταποκριτής Υ&Α",
  ENVIRONMENTAL_OFFICER: "Υπεύθυνος περιβάλλοντος",
  ENVIRONMENT_RESPONDER: "Ανταποκριτής περιβάλλοντος",
  EMERGENCY_COMMANDER: "Συντονιστής έκτακτης ανάγκης",
  COMMUNICATIONS_OFFICER: "Υπεύθυνος επικοινωνιών",
  FIRE_SAFETY_COORDINATOR: "Συντονιστής πυρασφάλειας",
  FIRST_AID_COORDINATOR: "Συντονιστής Α’ βοηθειών",
  PERSONNEL_COORDINATOR: "Συντονιστής προσωπικού",
  FIRE_TEAM_MEMBER: "Μέλος ομάδας πυρασφάλειας",
  FIRST_AID_RESPONDER: "Μέλος Α’ βοηθειών",
  EVACUATION_WARDEN: "Υπεύθυνος εκκένωσης",
  TECHNICIAN: "Τεχνικός",
};

export const TEAM_LABELS_EL: Record<string, string> = {
  GENERAL_USERS: "Όλοι οι χρήστες μονάδας",
  MANAGEMENT: "Διοίκηση",
  HSE_TEAM: "Ομάδα Υγείας & Ασφάλειας",
  ENVIRONMENT_TEAM: "Περιβαλλοντική ομάδα",
  EMERGENCY_TEAM: "Ομάδα έκτακτης ανάγκης",
  FIRE_TEAM: "Ομάδα πυρασφάλειας",
  FIRST_AID_TEAM: "Ομάδα Α’ βοηθειών",
  EVACUATION_TEAM: "Ομάδα εκκένωσης",
  SECURITY_TEAM: "Ομάδα φύλαξης / ασφάλειας",
  CONTROL_ROOM_TEAM: "Κέντρο ελέγχου / φυλάκιο",
  READ_ONLY_USERS: "Χρήστες μόνο προβολής",
  ENVIRONMENTAL_TEAM: "Περιβαλλοντική ομάδα",
  RESPONSE_TEAM: "Ομάδα απόκρισης",
};

export const AUTHORITY_TYPE_LABELS_EL: Record<string, string> = {
  FIRE_SERVICE: "Πυροσβεστική Υπηρεσία",
  FIRE_BRIGADE: "Πυροσβεστική Υπηρεσία",
  POLICE: "Αστυνομία",
  EMS: "ΕΚΑΒ",
  CIVIL_PROTECTION: "Πολιτική Προστασία / 112",
  ENVIRONMENTAL_AUTHORITY: "Περιβαλλοντική αρχή",
};

export const CHANNEL_LABELS_EL: Record<string, string> = {
  PHONE: "Τηλέφωνο",
  EMAIL: "Email",
  SMS: "SMS",
  RADIO: "Ασύρματος",
};

export const DISPATCH_MODE_LABELS_EL: Record<string, string> = {
  NONE: "Δεν χρησιμοποιείται dispatch",
  AUTO: "Αυτόματη κινητοποίηση",
  MANUAL: "Χειροκίνητη κινητοποίηση",
  POST_VERIFY: "Μετά την επιβεβαίωση",
};

export const NOTIFICATION_MODE_LABELS_EL: Record<string, string> = {
  NONE: "Δεν αποστέλλονται ειδοποιήσεις",
  AUTO: "Αυτόματη αποστολή ειδοποιήσεων",
  MANUAL: "Χειροκίνητη αποστολή",
  POST_VERIFY: "Μετά την επιβεβαίωση",
};

export const EXTERNAL_MODE_LABELS_EL: Record<string, string> = {
  NONE: "Δεν εμπλέκονται εξωτερικές αρχές",
  MANUAL: "Χειροκίνητη καταγραφή / ειδοποίηση",
  AUTO: "Αυτόματη δημιουργία από την πολιτική",
  PLAYBOOK_DRIVEN: "Καθοδήγηση από playbook",
};

export const NOTIFICATION_TARGET_LABELS_EL: Record<string, string> = {
  SITE_USERS: "Χρήστες της μονάδας",
  RESPONSE_TEAM: "Ομάδα απόκρισης",
  HSE_TEAM: "Ομάδα Υγείας & Ασφάλειας",
  CONTROL_ROOM: "Κέντρο ελέγχου",
  MANAGEMENT: "Διοίκηση",
};

export const CATEGORY_LABELS_EL: Record<string, string> = {
  EMERGENCY_ACTIVATION: "Ενεργοποίηση έκτακτης ανάγκης",
  HSE_ACCIDENT: "Ατύχημα Υγείας & Ασφάλειας",
  ENVIRONMENTAL_INCIDENT: "Περιβαλλοντικό συμβάν",
  NEAR_MISS: "Παρ’ ολίγον συμβάν",
  UNSAFE_ACTION: "Μη ασφαλής ενέργεια",
  UNSAFE_CONDITION: "Μη ασφαλής κατάσταση",
  SOS: "SOS",
};

export function greekLabel(key: string, labels: Record<string, string>) {
  return labels[key] ?? key;
}

type LabelWithKeyProps = {
  value: string;
  labels?: Record<string, string>;
};

export function LabelWithKey({ value, labels = {} }: LabelWithKeyProps) {
  const label = greekLabel(value, labels);

  if (label === value) {
    return <span>{value}</span>;
  }

  return (
    <span style={{ display: "inline-flex", flexDirection: "column", gap: 1 }}>
      <span>{label}</span>
      <span style={{ fontSize: 10, opacity: 0.55 }}>{value}</span>
    </span>
  );
}

export function optionLabel(value: string, labels: Record<string, string>) {
  const label = greekLabel(value, labels);
  return label === value ? value : `${label} (${value})`;
}
