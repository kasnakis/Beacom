import type { PropsWithChildren } from "react";

type Props = PropsWithChildren<{
  title: string;
  subtitle?: string;
}>;

export function PolicySection({ title, subtitle, children }: Props) {
  return (
    <div
      style={{
        border: "1px solid rgba(255,255,255,0.1)",
        borderRadius: 16,
        padding: 16,
        background: "rgba(255,255,255,0.02)",
      }}
    >
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontWeight: 700, fontSize: 16 }}>{title}</div>
        {subtitle ? (
          <div style={{ marginTop: 4, fontSize: 13, opacity: 0.75 }}>{subtitle}</div>
        ) : null}
      </div>

      {children}
    </div>
  );
}