import { ROLE_OPTIONS } from "../../../../domain/enums/roles";
import { TEAM_OPTIONS } from "../../../../domain/enums/teams";
import {
  DISPATCH_MODE_LABELS_EL,
  LabelWithKey,
  ROLE_LABELS_EL,
  TEAM_LABELS_EL,
  optionLabel,
} from "./PolicyLabels";

type Props = {
  postVerifyDispatchMode: string;
  allowAutoDispatch: boolean;
  trackingEnabled: boolean;
  selectedRoles: Set<string>;
  selectedTeams: Set<string>;
  onDispatchModeChange: (value: string) => void;
  onAllowAutoDispatchChange: (value: boolean) => void;
  onTrackingEnabledChange: (value: boolean) => void;
  onToggleRole: (role: string) => void;
  onToggleTeam: (team: string) => void;
};

const DISPATCH_MODES = ["NONE", "AUTO", "MANUAL", "POST_VERIFY"];
const DISPATCH_ROLES = ROLE_OPTIONS;
const DISPATCH_TEAMS = TEAM_OPTIONS;

const recommendedDispatchRoles = new Set([
  "HSE_MANAGER",
  "EMERGENCY_COMMANDER",
  "SITE_MANAGER",
  "SUPERVISOR",
  "FIRE_SAFETY_COORDINATOR",
  "FIRST_AID_COORDINATOR",
  "FIRST_AID_RESPONDER",
  "EVACUATION_WARDEN",
  "CONTROL_ROOM",
]);

const recommendedDispatchTeams = new Set([
  "EMERGENCY_TEAM",
  "FIRE_TEAM",
  "FIRST_AID_TEAM",
  "EVACUATION_TEAM",
  "HSE_TEAM",
  "CONTROL_ROOM_TEAM",
]);

function modeDescription(mode: string) {
  switch (mode) {
    case "NONE":
      return "Δεν δημιουργείται dispatch από αυτή την πολιτική. Το συμβάν μπορεί να καταγραφεί ή να παρακολουθείται χωρίς κινητοποίηση χρηστών/ομάδων.";
    case "AUTO":
      return "Το σύστημα δημιουργεί αυτόματα dispatch όταν το συμβάν πληροί τους κανόνες της πολιτικής. Χρήσιμο για emergency/SOS ροές όπου χρειάζεται άμεση ανταπόκριση.";
    case "MANUAL":
      return "Η κινητοποίηση γίνεται από χρήστη μέσα από το web/admin flow. Χρήσιμο όταν θέλουμε ανθρώπινη κρίση πριν σταλούν ειδοποιήσεις.";
    case "POST_VERIFY":
      return "Η κινητοποίηση ξεκινά μετά την επιβεβαίωση του συμβάντος. Χρήσιμο για συμβάντα που δεν πρέπει να κινητοποιήσουν ομάδες πριν αξιολογηθούν.";
    default:
      return "Επιλέξτε τρόπο ενεργοποίησης dispatch.";
  }
}

function roleHelper(role: string) {
  const helpers: Record<string, string> = {
    HSE_MANAGER: "Συντονίζει ή παρακολουθεί HSE / emergency κινητοποιήσεις.",
    EMERGENCY_COMMANDER: "Κεντρικός ρόλος για επιχειρησιακό συντονισμό έκτακτης ανάγκης.",
    SITE_MANAGER: "Παρακολουθεί και εγκρίνει επιχειρησιακή ανταπόκριση σε επίπεδο μονάδας.",
    SUPERVISOR: "Χρήσιμος για τοπική κινητοποίηση και αρχικό συντονισμό ομάδων.",
    FIRE_SAFETY_COORDINATOR: "Συντονίζει πυρασφάλεια και ανταπόκριση σε πυρκαγιά/καπνό.",
    FIRE_TEAM_MEMBER: "Μπορεί να κινητοποιηθεί ως μέλος ομάδας πυρασφάλειας.",
    FIRST_AID_COORDINATOR: "Συντονίζει πρώτες βοήθειες και πιθανή επικοινωνία με ΕΚΑΒ.",
    FIRST_AID_RESPONDER: "Μπορεί να κινητοποιηθεί ως ανταποκριτής πρώτων βοηθειών.",
    EVACUATION_WARDEN: "Μπορεί να κινητοποιηθεί για εκκένωση και σημεία συγκέντρωσης.",
    CONTROL_ROOM: "Χρήσιμος για παρακολούθηση και κεντρική επιχειρησιακή ενημέρωση.",
    SECURITY_OFFICER: "Χρήσιμος για ασφάλεια χώρου, αποκλεισμό περιοχής ή έλεγχο πρόσβασης.",
    ENVIRONMENTAL_OFFICER: "Χρήσιμος σε περιβαλλοντικό συμβάν ή πιθανή ρύπανση.",
    ENVIRONMENT_RESPONDER: "Μπορεί να κινητοποιηθεί για περιβαλλοντική ανταπόκριση.",
    WORKER: "Συνήθως δεν προτείνεται ως dispatch role, εκτός αν αφορά γενική ειδοποίηση ή ειδική ομάδα.",
    VIEWER: "Ρόλος προβολής. Δεν προτείνεται για dispatch.",
    TECHNICIAN: "Χρήσιμος μόνο σε ειδικά τεχνικά σενάρια.",
  };

  return helpers[role] || "Μπορεί να συμμετέχει στην κινητοποίηση αν το προβλέπει η επιχειρησιακή πολιτική.";
}

function teamHelper(team: string) {
  const helpers: Record<string, string> = {
    EMERGENCY_TEAM: "Κεντρική ομάδα ανταπόκρισης έκτακτης ανάγκης.",
    FIRE_TEAM: "Ομάδα πυρασφάλειας / αντιμετώπισης πυρκαγιάς.",
    FIRST_AID_TEAM: "Ομάδα πρώτων βοηθειών και αρχικής ιατρικής υποστήριξης.",
    EVACUATION_TEAM: "Ομάδα εκκένωσης και καθοδήγησης προς σημεία συγκέντρωσης.",
    HSE_TEAM: "Ομάδα Υγείας & Ασφάλειας για αξιολόγηση, έλεγχο και τεκμηρίωση.",
    ENVIRONMENT_TEAM: "Περιβαλλοντική ομάδα για διαρροές, ρύπανση ή περιβαλλοντικό έλεγχο.",
    ENVIRONMENTAL_TEAM: "Περιβαλλοντική ομάδα για διαρροές, ρύπανση ή περιβαλλοντικό έλεγχο.",
    SECURITY_TEAM: "Ομάδα ασφάλειας χώρου και ελέγχου πρόσβασης.",
    CONTROL_ROOM_TEAM: "Control Room / κεντρική παρακολούθηση και επικοινωνίες.",
    MANAGEMENT: "Διοίκηση / ενημέρωση επιχειρησιακής ευθύνης.",
    GENERAL_USERS: "Γενική ειδοποίηση χρηστών. Χρήση με προσοχή για να μην δημιουργείται notification noise.",
    RESPONSE_TEAM: "Γενική ομάδα ανταπόκρισης, όταν δεν γίνεται πιο ειδική διάκριση.",
  };

  return helpers[team] || "Ομάδα που μπορεί να κινητοποιηθεί σύμφωνα με την πολιτική του site.";
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "success" | "warning" | "danger" | "info" | "neutral";
}) {
  return <span style={{ ...pillStyle, ...pillTone(tone) }}>{children}</span>;
}

function pillTone(tone: "success" | "warning" | "danger" | "info" | "neutral"): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };
    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };
    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border-strong)",
        color: "var(--text)",
      };
  }
}

function RoleOption({
  role,
  checked,
  recommended,
  caution,
  onToggle,
}: {
  role: string;
  checked: boolean;
  recommended?: boolean;
  caution?: boolean;
  onToggle: () => void;
}) {
  return (
    <label style={checked ? selectedItem : dispatchItem}>
      <div style={itemTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={labelLine}>
            <LabelWithKey value={role} labels={ROLE_LABELS_EL} />
            {recommended ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
            {caution ? <StatusPill tone="warning">Προσοχή</StatusPill> : null}
          </div>
          <div style={itemHelper}>{roleHelper(role)}</div>
        </div>
      </div>
    </label>
  );
}

function TeamOption({
  team,
  checked,
  recommended,
  caution,
  onToggle,
}: {
  team: string;
  checked: boolean;
  recommended?: boolean;
  caution?: boolean;
  onToggle: () => void;
}) {
  return (
    <label style={checked ? selectedItem : dispatchItem}>
      <div style={itemTopLine}>
        <input type="checkbox" checked={checked} onChange={onToggle} />
        <div style={{ minWidth: 0 }}>
          <div style={labelLine}>
            <LabelWithKey value={team} labels={TEAM_LABELS_EL} />
            {recommended ? <StatusPill tone="success">Προτεινόμενο</StatusPill> : null}
            {caution ? <StatusPill tone="warning">Προσοχή</StatusPill> : null}
          </div>
          <div style={itemHelper}>{teamHelper(team)}</div>
        </div>
      </div>
    </label>
  );
}

export function DispatchSection({
  postVerifyDispatchMode,
  allowAutoDispatch,
  trackingEnabled,
  selectedRoles,
  selectedTeams,
  onDispatchModeChange,
  onAllowAutoDispatchChange,
  onTrackingEnabledChange,
  onToggleRole,
  onToggleTeam,
}: Props) {
  const dispatchDisabled = postVerifyDispatchMode === "NONE";
  const hasNoTargets = selectedRoles.size === 0 && selectedTeams.size === 0;
  const usesBroadTeam = selectedTeams.has("GENERAL_USERS") || selectedTeams.has("MANAGEMENT");
  const hasWeakRole = selectedRoles.has("VIEWER") || selectedRoles.has("WORKER");

  return (
    <section style={sectionStyle}>
      <div style={headerRow}>
        <div>
          <div style={eyebrowStyle}>Dispatch Policy</div>
          <div style={titleStyle}>Πολιτική κινητοποίησης / dispatch</div>
          <div style={subtitleStyle}>
            Ορίζει πώς κινητοποιούνται ρόλοι και ομάδες, πότε δημιουργείται dispatch και αν παρακολουθείται η ανταπόκριση χρηστών σε πραγματικό χρόνο.
          </div>
        </div>

        <div style={summaryPills}>
          <StatusPill tone={dispatchDisabled ? "neutral" : postVerifyDispatchMode === "AUTO" ? "warning" : "info"}>
            {optionLabel(postVerifyDispatchMode, DISPATCH_MODE_LABELS_EL)}
          </StatusPill>
          <StatusPill tone={allowAutoDispatch ? "success" : "neutral"}>
            {allowAutoDispatch ? "Auto dispatch ενεργό" : "Auto dispatch ανενεργό"}
          </StatusPill>
          <StatusPill tone={trackingEnabled ? "success" : "warning"}>
            {trackingEnabled ? "Tracking ενεργό" : "Tracking ανενεργό"}
          </StatusPill>
        </div>
      </div>

      <div style={helperBox}>
        <strong>Επιχειρησιακή λογική:</strong> το dispatch είναι η κινητοποίηση χρηστών ή ομάδων ώστε να λάβουν ειδοποίηση, να δηλώσουν “Κατευθύνομαι”, “Έφτασα” και όπου προβλέπεται “Ολοκλήρωσα”. Για ΣΑΕΚ/emergency ροές πρέπει να είναι ξεκάθαρο ποιοι κινητοποιήθηκαν και ποιος ανταποκρίθηκε.
      </div>

      <div style={flowBox}>
        <div style={flowTitle}>Κύκλος ανταπόκρισης responder</div>
        <div style={flowSteps}>
          <span>1. Requested</span>
          <span>2. Responding / Κατευθύνομαι</span>
          <span>3. Arrived / Έφτασα</span>
          <span>4. Completed / Ολοκλήρωσα</span>
          <span>5. Timeline & dispatch state</span>
        </div>
        <div style={flowHint}>
          Η ροή αυτή πρέπει να φαίνεται καθαρά στο Web Admin ώστε ο συντονιστής να γνωρίζει ποιοι έλαβαν ειδοποίηση, ποιοι ανταποκρίθηκαν και ποιοι έφτασαν στο σημείο.
        </div>
      </div>

      <div style={fieldWrap}>
        <label style={labelStyle}>Τρόπος ενεργοποίησης dispatch</label>
        <select
          value={postVerifyDispatchMode}
          onChange={(e) => onDispatchModeChange(e.target.value)}
          style={selectStyle}
        >
          {DISPATCH_MODES.map((mode) => (
            <option key={mode} value={mode}>
              {optionLabel(mode, DISPATCH_MODE_LABELS_EL)}
            </option>
          ))}
        </select>
        <div style={modeDescriptionBox}>{modeDescription(postVerifyDispatchMode)}</div>
      </div>

      <div style={modeGuideBox}>
        <div style={modeGuideTitle}>Οδηγός επιλογής mode</div>
        <div style={modeGuideList}>
          <div><strong>Καμία:</strong> δεν δημιουργείται dispatch για αυτό το policy.</div>
          <div><strong>Αυτόματη:</strong> άμεση κινητοποίηση με βάση την πολιτική. Κατάλληλο για SOS/emergency.</div>
          <div><strong>Χειροκίνητη:</strong> απαιτεί ενέργεια χρήστη στο web/admin πριν σταλεί κινητοποίηση.</div>
          <div><strong>Μετά την επιβεβαίωση:</strong> πρώτα verification, μετά κινητοποίηση. Κατάλληλο για μη άμεσες ροές.</div>
        </div>
      </div>

      {dispatchDisabled ? (
        <div style={disabledNotice}>
          Το dispatch είναι σε mode “Καμία”. Οι ρόλοι/ομάδες μπορούν να μείνουν ως προετοιμασία, αλλά δεν πρέπει να δημιουργείται ενεργή κινητοποίηση από αυτό το policy.
        </div>
      ) : null}

      {hasNoTargets && !dispatchDisabled ? (
        <div style={dangerNotice}>
          Δεν έχουν επιλεγεί ρόλοι ή ομάδες για dispatch. Αν η πολιτική είναι ενεργή, το σύστημα μπορεί να δημιουργήσει dispatch χωρίς πραγματικούς αποδέκτες.
        </div>
      ) : null}

      <div style={toggleGrid}>
        <label style={toggleCard}>
          <div style={itemTopLine}>
            <input
              type="checkbox"
              checked={allowAutoDispatch}
              onChange={(e) => onAllowAutoDispatchChange(e.target.checked)}
            />
            <div>
              <div style={toggleTitle}>Να επιτρέπεται αυτόματη κινητοποίηση</div>
              <div style={toggleDescription}>
                Όταν είναι ενεργό, το policy engine μπορεί να δημιουργήσει dispatch χωρίς χειροκίνητη παρέμβαση χρήστη.
              </div>
            </div>
          </div>
          <div style={allowAutoDispatch ? requirementStateOn : requirementStateOff}>
            {allowAutoDispatch
              ? "Ενεργό: κατάλληλο για emergency/SOS ροές όπου απαιτείται άμεση ανταπόκριση."
              : "Ανενεργό: η κινητοποίηση πρέπει να γίνεται χειροκίνητα ή από άλλη ροή."}
          </div>
        </label>

        <label style={toggleCard}>
          <div style={itemTopLine}>
            <input
              type="checkbox"
              checked={trackingEnabled}
              onChange={(e) => onTrackingEnabledChange(e.target.checked)}
            />
            <div>
              <div style={toggleTitle}>Παρακολούθηση ανταποκρινόμενων ενεργή</div>
              <div style={toggleDescription}>
                Επιτρέπει προβολή κατάστασης responders, όπως “Κατευθύνομαι”, “Έφτασα”, “Ολοκλήρωσα”.
              </div>
            </div>
          </div>
          <div style={trackingEnabled ? requirementStateOn : requirementStateOff}>
            {trackingEnabled
              ? "Ενεργό: ο συντονιστής βλέπει ζωντανή εικόνα ανταπόκρισης στο Web Admin."
              : "Ανενεργό: δεν θα υπάρχει πλήρης operational εικόνα responder lifecycle."}
          </div>
        </label>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ρόλοι που συμμετέχουν στο dispatch</div>
            <div style={hintStyle}>
              Οι ρόλοι αυτοί μπορούν να εμπλακούν στην κινητοποίηση ή να εμφανίζονται ως υποψήφιοι responders.
            </div>
          </div>
          {hasWeakRole ? <StatusPill tone="warning">Προσοχή σε γενικούς ρόλους</StatusPill> : null}
        </div>

        <div style={operationalNote}>
          Για operational dispatch προτιμήστε ρόλους που έχουν πραγματική επιχειρησιακή ευθύνη. Μην χρησιμοποιείτε γενικά WORKER/VIEWER εκτός αν το σενάριο απαιτεί broad notification.
        </div>

        <div style={roleGrid}>
          {DISPATCH_ROLES.map((role) => (
            <RoleOption
              key={role}
              role={role}
              checked={selectedRoles.has(role)}
              recommended={recommendedDispatchRoles.has(role)}
              caution={role === "WORKER" || role === "VIEWER"}
              onToggle={() => onToggleRole(role)}
            />
          ))}
        </div>
      </div>

      <div style={subSectionWrap}>
        <div style={sectionHeaderLine}>
          <div>
            <div style={subSectionTitle}>Ομάδες που μπορούν να κινητοποιηθούν</div>
            <div style={hintStyle}>
              Επιλέξτε ποιες ομάδες της μονάδας μπορούν να λάβουν κινητοποίηση για τον συγκεκριμένο τύπο συμβάντος.
            </div>
          </div>
          {usesBroadTeam ? <StatusPill tone="warning">Broad notification</StatusPill> : null}
        </div>

        <div style={operationalNote}>
          Για σενάρια πυρκαγιάς/ΣΑΕΚ συνήθως χρησιμοποιούνται FIRE_TEAM, FIRST_AID_TEAM, EVACUATION_TEAM, EMERGENCY_TEAM και HSE_TEAM. Το GENERAL_USERS να χρησιμοποιείται με προσοχή γιατί μπορεί να αυξήσει πολύ τον αριθμό ειδοποιήσεων.
        </div>

        <div style={roleGrid}>
          {DISPATCH_TEAMS.map((team) => (
            <TeamOption
              key={team}
              team={team}
              checked={selectedTeams.has(team)}
              recommended={recommendedDispatchTeams.has(team)}
              caution={team === "GENERAL_USERS" || team === "MANAGEMENT"}
              onToggle={() => onToggleTeam(team)}
            />
          ))}
        </div>
      </div>

      <div style={messagePreviewBox}>
        <div style={messagePreviewTitle}>Μηνύματα που πρέπει να βλέπει ο χρήστης στη ροή dispatch</div>
        <ul style={messageList}>
          <li>Η πολιτική κινητοποιεί συγκεκριμένες ομάδες/ρόλους για αυτόν τον τύπο συμβάντος.</li>
          {postVerifyDispatchMode === "POST_VERIFY" ? (
            <li>Η κινητοποίηση θα ξεκινήσει μόνο μετά την επιβεβαίωση του συμβάντος.</li>
          ) : null}
          {allowAutoDispatch ? <li>Το σύστημα μπορεί να δημιουργήσει αυτόματα dispatch σύμφωνα με την πολιτική.</li> : null}
          {trackingEnabled ? (
            <li>Οι ανταποκρινόμενοι πρέπει να δηλώνουν “Κατευθύνομαι”, “Έφτασα” και “Ολοκλήρωσα”, ώστε να ενημερώνεται η επιχειρησιακή εικόνα.</li>
          ) : (
            <li>Η παρακολούθηση ανταπόκρισης είναι ανενεργή, άρα το Web Admin δεν θα έχει πλήρες responder lifecycle.</li>
          )}
          {hasNoTargets && !dispatchDisabled ? <li>Δεν έχουν οριστεί αποδέκτες dispatch. Ελέγξτε ρόλους και ομάδες.</li> : null}
        </ul>
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 14,
  padding: 16,
  background: "var(--surface)",
  color: "var(--text-strong)",
};

const headerRow: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: "uppercase",
  letterSpacing: 0.8,
  color: "var(--muted)",
  marginBottom: 4,
};

const titleStyle: React.CSSProperties = {
  fontWeight: 900,
  fontSize: 16,
  color: "var(--text-strong)",
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 5,
  fontSize: 12,
  color: "var(--muted)",
  lineHeight: 1.45,
  maxWidth: 780,
};

const summaryPills: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const pillStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const helperBox: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 12,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info-strong)",
  color: "var(--info-strong)",
  fontSize: 12,
  lineHeight: 1.5,
};

const flowBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  background: "var(--surface)",
  border: "1px solid var(--border)",
};

const flowTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 8,
  color: "var(--text-strong)",
};

const flowSteps: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  fontSize: 12,
  fontWeight: 700,
};

const flowHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  color: "var(--muted)",
  lineHeight: 1.4,
};

const fieldWrap: React.CSSProperties = {
  marginTop: 14,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  color: "var(--muted)",
  marginBottom: 6,
};

const selectStyle: React.CSSProperties = {
  width: "100%",
  padding: "9px 10px",
  borderRadius: 10,
  border: "1px solid var(--border-strong)",
  background: "var(--surface)",
  color: "var(--text-strong)",
};

const modeDescriptionBox: React.CSSProperties = {
  marginTop: 8,
  padding: 10,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  lineHeight: 1.45,
};

const modeGuideBox: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
};

const modeGuideTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 13,
  marginBottom: 6,
};

const modeGuideList: React.CSSProperties = {
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.45,
  color: "var(--text)",
};

const disabledNotice: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--warning)",
  background: "var(--warning-soft)",
  color: "var(--warning-strong)",
  fontSize: 12,
  lineHeight: 1.45,
};

const dangerNotice: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--danger)",
  background: "var(--danger-soft)",
  color: "var(--danger-strong)",
  fontSize: 12,
  lineHeight: 1.45,
};

const toggleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
  gap: 10,
  marginTop: 14,
};

const toggleCard: React.CSSProperties = {
  display: "grid",
  gap: 8,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const toggleTitle: React.CSSProperties = {
  fontWeight: 850,
  lineHeight: 1.35,
  color: "var(--text-strong)",
};

const toggleDescription: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  color: "var(--muted)",
  lineHeight: 1.42,
};

const requirementStateOn: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--success-soft)",
  border: "1px solid var(--success)",
  color: "var(--success-strong)",
  fontSize: 12,
  lineHeight: 1.4,
};

const requirementStateOff: React.CSSProperties = {
  padding: 9,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 12,
  color: "var(--muted)",
  lineHeight: 1.4,
};

const subSectionWrap: React.CSSProperties = {
  marginTop: 16,
};

const sectionHeaderLine: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const subSectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 6,
  fontSize: 13,
  color: "var(--text-strong)",
};

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  color: "var(--muted)",
  marginTop: 4,
  marginBottom: 6,
  lineHeight: 1.4,
};

const operationalNote: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "var(--warning-soft)",
  border: "1px solid var(--warning)",
  color: "var(--warning-strong)",
  fontSize: 12,
  lineHeight: 1.45,
};

const roleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: 8,
  marginTop: 8,
};

const dispatchItem: React.CSSProperties = {
  display: "grid",
  gap: 6,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  cursor: "pointer",
};

const selectedItem: React.CSSProperties = {
  ...dispatchItem,
  border: "1px solid var(--success)",
  background: "var(--success-soft)",
};

const itemTopLine: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  gap: 8,
};

const labelLine: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
  lineHeight: 1.35,
};

const itemHelper: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  color: "var(--muted)",
  lineHeight: 1.35,
};

const messagePreviewBox: React.CSSProperties = {
  marginTop: 16,
  padding: 12,
  borderRadius: 12,
  background: "var(--info-soft)",
  border: "1px solid var(--info-strong)",
  color: "var(--info-strong)",
};

const messagePreviewTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 12,
  marginBottom: 6,
  color: "var(--info-strong)",
};

const messageList: React.CSSProperties = {
  margin: 0,
  paddingLeft: 18,
  display: "grid",
  gap: 5,
  fontSize: 12,
  lineHeight: 1.4,
};
