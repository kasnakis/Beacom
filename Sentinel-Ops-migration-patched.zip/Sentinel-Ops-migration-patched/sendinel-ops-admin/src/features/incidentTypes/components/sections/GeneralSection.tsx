type Props = {
  policyKey: string;
  displayName: string;
  active: boolean;
  onDisplayNameChange: (value: string) => void;
  onActiveChange: (value: boolean) => void;
};

export function GeneralSection({
  policyKey,
  displayName,
  active,
  onDisplayNameChange,
  onActiveChange,
}: Props) {
  return (
    <section style={sectionStyle}>
      <div style={sectionHeader}>
        <div style={sectionTitle}>Βασικά στοιχεία πολιτικής</div>
        <div style={sectionSubtitle}>
          Εδώ ορίζεται η ονομασία και η ενεργοποίηση της πολιτικής συμβάντος για τη συγκεκριμένη μονάδα.
        </div>
      </div>

      <div style={helperBox}>
        Η πολιτική καθορίζει ποιοι χρήστες μπορούν να δημιουργούν, να επιβεβαιώνουν, να κινητοποιούν ομάδες,
        να ενημερώνουν εξωτερικές αρχές και να κλείνουν έναν συγκεκριμένο τύπο συμβάντος.
      </div>

      <div style={grid2}>
        <div>
          <label style={labelStyle}>Κωδικός πολιτικής</label>
          <input value={policyKey} readOnly style={readOnlyInputStyle} />
          <div style={hintStyle}>Τεχνικό αναγνωριστικό. Δεν αλλάζει από την οθόνη.</div>
        </div>

        <div>
          <label style={labelStyle}>Όνομα εμφάνισης</label>
          <input
            value={displayName}
            onChange={(e) => onDisplayNameChange(e.target.value)}
            style={inputStyle}
            placeholder="Π.χ. Πυρκαγιά / Έκτακτη ανάγκη"
          />
          <div style={hintStyle}>Το όνομα που θα βλέπουν οι χρήστες στο admin.</div>
        </div>
      </div>

      <div style={checkboxRow}>
        <label style={checkboxLabel}>
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => onActiveChange(e.target.checked)}
          />
          <span>Ενεργή πολιτική</span>
        </label>
        <div style={hintStyle}>
          Όταν η πολιτική είναι ανενεργή, δεν πρέπει να χρησιμοποιείται για νέα συμβάντα.
        </div>
      </div>
    </section>
  );
}

const sectionStyle: React.CSSProperties = {
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 14,
  padding: 14,
  background: "rgba(255,255,255,0.02)",
};

const sectionHeader: React.CSSProperties = {
  marginBottom: 12,
};

const sectionTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 14,
};

const sectionSubtitle: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.7,
};

const helperBox: React.CSSProperties = {
  marginTop: 10,
  marginBottom: 12,
  padding: 10,
  borderRadius: 10,
  background: "rgba(255,255,255,0.04)",
  fontSize: 12,
  opacity: 0.86,
  lineHeight: 1.45,
};

const grid2: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: 12,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  opacity: 0.72,
  marginBottom: 6,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "8px 10px",
  borderRadius: 8,
  border: "1px solid rgba(255,255,255,0.15)",
  background: "rgba(255,255,255,0.05)",
  color: "inherit",
};

const readOnlyInputStyle: React.CSSProperties = {
  ...inputStyle,
  opacity: 0.9,
};

const checkboxRow: React.CSSProperties = {
  marginTop: 12,
};

const checkboxLabel: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  fontSize: 13,
};

const hintStyle: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.6,
  marginTop: 4,
  lineHeight: 1.4,
};
