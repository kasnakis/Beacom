import type { UserProfile } from "../../../domain/models/user";
import { RoleBadge } from "../../shared/components/RoleBadge";
import { TeamBadge } from "../../shared/components/TeamBadge";
import { StatusBadge } from "../../shared/components/StatusBadge";
import {
  translateRole,
  translateTeam,
  userLabel,
} from "../i18n/userManagementLabels";

type Props = {
  users: UserProfile[];
  selectedUid?: string | null;
  onSelect?: (uid: string) => void;
  compact?: boolean;
};

function activeTone(user: UserProfile): "success" | "danger" {
  return user.active === false ? "danger" : "success";
}

function activeLabel(user: UserProfile) {
  return user.active === false ? userLabel("inactive") : userLabel("active");
}

function trueKeys(value?: Record<string, boolean>) {
  if (!value) return [];

  return Object.entries(value)
    .filter(([, enabled]) => enabled)
    .map(([key]) => key)
    .sort();
}

function renderBadges(items: string[], kind: "role" | "team") {
  if (!items.length) {
    return <span style={{ opacity: 0.65 }}>-</span>;
  }

  return (
    <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
      {items.map((item) =>
        kind === "role" ? (
          <RoleBadge key={item} label={translateRole(item)} />
        ) : (
          <TeamBadge key={item} label={translateTeam(item)} />
        )
      )}
    </div>
  );
}

export function UsersTable({
  users,
  selectedUid,
  onSelect,
  compact = false,
}: Props) {
  if (!users.length) {
    return (
      <div
        style={{
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 16,
          padding: 18,
          background: "rgba(255,255,255,0.025)",
          opacity: 0.8,
        }}
      >
        {userLabel("emptyUsers")}
      </div>
    );
  }

  return (
    <div
      style={{
        overflowX: "auto",
        maxHeight: "calc(100vh - 260px)",
        overflowY: "auto",
        border: "1px solid rgba(255,255,255,0.1)",
        borderRadius: 16,
        background: "rgba(255,255,255,0.02)",
      }}
    >
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: compact ? 13 : 14,
        }}
      >
        <thead>
          <tr>
            <th style={th}>{userLabel("nameColumn")}</th>
            <th style={th}>{userLabel("emailColumn")}</th>
            <th style={th}>{userLabel("siteColumn")}</th>
            <th style={th}>{userLabel("statusColumn")}</th>
            <th style={th}>{userLabel("rolesColumn")}</th>
            <th style={th}>{userLabel("teamsColumn")}</th>
          </tr>
        </thead>

        <tbody>
          {users.map((user) => {
            const roles = trueKeys(user.roles);
            const teams = trueKeys(user.teams);
            const isSelected = selectedUid === user.uid;

            return (
              <tr
                key={user.uid}
                onClick={() => onSelect?.(user.uid)}
                style={{
                  cursor: onSelect ? "pointer" : "default",
                  background: isSelected
                    ? "rgba(72,126,255,0.2)"
                    : "transparent",
                  outline: isSelected
                    ? "1px solid rgba(72,126,255,0.4)"
                    : "none",
                  transition: "background 0.15s ease, outline 0.15s ease",
                }}
                onMouseEnter={(e) => {
                  if (!isSelected) {
                    e.currentTarget.style.background =
                      "rgba(255,255,255,0.045)";
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = isSelected
                    ? "rgba(72,126,255,0.2)"
                    : "transparent";
                }}
              >
                <td style={compact ? tdCompact : td}>
                  <div style={{ fontWeight: 700 }}>
                    {user.displayName || "-"}
                  </div>
                  <div
                    style={{
                      marginTop: 3,
                      fontSize: 11,
                      opacity: 0.55,
                      maxWidth: 180,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                    title={user.uid}
                  >
                    {user.uid}
                  </div>
                </td>

                <td style={compact ? tdCompact : td}>{user.email || "-"}</td>
                <td style={compact ? tdCompact : td}>{user.siteId || "-"}</td>

                <td style={compact ? tdCompact : td}>
                  <StatusBadge
                    label={activeLabel(user)}
                    tone={activeTone(user)}
                  />
                </td>

                <td style={compact ? tdCompact : td}>
                  {renderBadges(roles, "role")}
                </td>

                <td style={compact ? tdCompact : td}>
                  {renderBadges(teams, "team")}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "10px 10px",
  borderBottom: "1px solid rgba(255,255,255,0.12)",
  fontWeight: 700,
  fontSize: 12,
  opacity: 0.9,
  position: "sticky",
  top: 0,
  background: "rgba(15,23,42,0.98)",
  zIndex: 2,
};

const td: React.CSSProperties = {
  padding: "11px 10px",
  borderBottom: "1px solid rgba(255,255,255,0.08)",
  verticalAlign: "top",
};

const tdCompact: React.CSSProperties = {
  padding: "8px 10px",
  borderBottom: "1px solid rgba(255,255,255,0.08)",
  verticalAlign: "top",
};