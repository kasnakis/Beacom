import type { ReactNode } from "react";
import { userLabel } from "../i18n/userManagementLabels";

type Option = {
  value: string;
  label: string;
};

type Props = {
  search: string;
  siteId?: string;
  activeMode: string;
  roleFilter: string;
  teamFilter: string;
  availableSites?: string[];
  availableRoles: Option[];
  availableTeams: Option[];
  hideSiteFilter?: boolean;
  onSearchChange: (value: string) => void;
  onSiteChange?: (value: string) => void;
  onActiveModeChange: (value: string) => void;
  onRoleFilterChange: (value: string) => void;
  onTeamFilterChange: (value: string) => void;
  onClearFilters: () => void;
};

function SelectField({
  label,
  value,
  onChange,
  children,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: ReactNode;
}) {
  return (
    <label className="filter-panel-label">
      <div className="filter-panel-title">{label}</div>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {children}
      </select>
    </label>
  );
}

export function UsersFilters({
  search,
  siteId = "",
  activeMode,
  roleFilter,
  teamFilter,
  availableSites = [],
  availableRoles,
  availableTeams,
  hideSiteFilter = false,
  onSearchChange,
  onSiteChange,
  onActiveModeChange,
  onRoleFilterChange,
  onTeamFilterChange,
  onClearFilters,
}: Props) {
  const hasFilters =
    Boolean(search) ||
    Boolean(siteId) ||
    activeMode !== "ALL" ||
    Boolean(roleFilter) ||
    Boolean(teamFilter);

  return (
    <div className="filter-panel">
      <div
        className="filter-panel-grid"
        style={{
          gridTemplateColumns: hideSiteFilter
            ? "minmax(260px, 2fr) minmax(180px, 1fr) minmax(180px, 1fr)"
            : "minmax(260px, 2fr) repeat(4, minmax(150px, 1fr))",
        }}
      >
        <label className="filter-panel-label">
          <div className="filter-panel-title">{userLabel("searchField")}</div>
          <input
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={userLabel("searchPlaceholder")}
          />
        </label>

        {!hideSiteFilter ? (
          <SelectField
            label={userLabel("siteField")}
            value={siteId}
            onChange={(value) => onSiteChange?.(value)}
          >
            <option value="">{userLabel("allSitesOption")}</option>
            {availableSites.map((site) => (
              <option key={site} value={site}>
                {site}
              </option>
            ))}
          </SelectField>
        ) : null}

        <SelectField
          label={userLabel("statusFilterField")}
          value={activeMode}
          onChange={onActiveModeChange}
        >
          <option value="ALL">{userLabel("allUsersOption")}</option>
          <option value="ACTIVE">{userLabel("activeUsersOption")}</option>
          <option value="INACTIVE">{userLabel("inactiveUsersOption")}</option>
        </SelectField>

        <SelectField label="Ρόλος" value={roleFilter} onChange={onRoleFilterChange}>
          <option value="">Όλοι οι ρόλοι</option>
          {availableRoles.map((role) => (
            <option key={role.value} value={role.value}>
              {role.label}
            </option>
          ))}
        </SelectField>

        <SelectField label="Ομάδα" value={teamFilter} onChange={onTeamFilterChange}>
          <option value="">Όλες οι ομάδες</option>
          {availableTeams.map((team) => (
            <option key={team.value} value={team.value}>
              {team.label}
            </option>
          ))}
        </SelectField>
      </div>

      <div className="filter-panel-actions">
        <button
          type="button"
          className="filter-clear-button"
          onClick={onClearFilters}
          disabled={!hasFilters}
        >
          Καθαρισμός φίλτρων
        </button>
      </div>
    </div>
  );
}
