import { useEffect, useMemo, useRef, useState } from "react";
import type { AdminLevel, UserProfile, SiteMembership } from "../../../domain/models/user";
import { SITE_ASSET_PERMISSION_OPTIONS } from "../../../domain/models/siteAsset";
import { resolveAdminCapabilities } from "../../../domain/permissions/adminCapabilities";
import {
  ENTERPRISE_SITE_PERMISSION_OPTIONS,
  getPrimarySiteId,
} from "../../../domain/permissions/siteAccess";
import { useAuth } from "../../../hooks/useAuth";
import { useUpdateUser } from "../../../hooks/useUpdateUser";
import { StatusBadge } from "../../shared/components/StatusBadge";
import {
  useDynamicRoles,
  useDynamicTeams,
  userLabel,
} from "../i18n/userManagementLabels";
import { UserAuditHistory } from "./UserAuditHistory";

type Props = {
  user: UserProfile | null;
  availableSites: string[];
  onClose?: () => void;
};

type TabKey = "general" | "roles" | "teams" | "enterpriseAccess" | "assets" | "history";

const ADMIN_LEVEL_OPTIONS: { value: AdminLevel; label: string }[] = [
  { value: "GLOBAL_ADMIN", label: "Global Admin" },
  { value: "SITE_ADMIN", label: "Site Admin" },
  { value: "VIEW_ONLY", label: "View Only" },
];

function recordToSelectedSet(value?: Record<string, boolean>) {
  return new Set(
    Object.entries(value || {})
      .filter(([, enabled]) => enabled)
      .map(([key]) => key)
  );
}

function selectedSetToRecord(set: Set<string>) {
  return Array.from(set).reduce<Record<string, boolean>>((acc, key) => {
    acc[key] = true;
    return acc;
  }, {});
}

const ENTERPRISE_PERMISSION_KEYS = new Set(
  ENTERPRISE_SITE_PERMISSION_OPTIONS.map((option) => option.value)
);

function pickEnterprisePermissions(value?: Record<string, boolean>) {
  return Object.entries(value || {}).reduce<Record<string, boolean>>((acc, [key, enabled]) => {
    if (enabled && ENTERPRISE_PERMISSION_KEYS.has(key as any)) {
      acc[key] = true;
    }
    return acc;
  }, {});
}

function stripEnterprisePermissions(value?: Record<string, boolean>) {
  return Object.entries(value || {}).reduce<Record<string, boolean>>((acc, [key, enabled]) => {
    if (enabled && !ENTERPRISE_PERMISSION_KEYS.has(key as any)) {
      acc[key] = true;
    }
    return acc;
  }, {});
}

function enterpriseAccessFromUser(user: UserProfile | null | undefined, availableSites: string[]) {
  if (!user) return {};

  const primarySiteId = getPrimarySiteId(user);
  const siteIds = new Set<string>([...availableSites, ...Object.keys(user.siteMemberships || {})]);
  const result: Record<string, Record<string, boolean>> = {};

  siteIds.forEach((enterpriseSiteId) => {
    if (!enterpriseSiteId || enterpriseSiteId === primarySiteId) return;

    const permissions = pickEnterprisePermissions(
      user.siteMemberships?.[enterpriseSiteId]?.permissions
    );

    if (Object.keys(permissions).length) {
      result[enterpriseSiteId] = permissions;
    }
  });

  return result;
}

function recordsEqual(a: Record<string, unknown>, b: Record<string, unknown>) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function setsEqual(a: Set<string>, b: Set<string>) {
  if (a.size !== b.size) return false;
  for (const value of a) {
    if (!b.has(value)) return false;
  }
  return true;
}

function resolveDisplayedAdminLevel(user?: UserProfile | null): AdminLevel {
  if (user?.adminPermissions?.level) return user.adminPermissions.level;
  if (user?.platformRoles?.ADMIN_PORTAL) return "GLOBAL_ADMIN";
  return "VIEW_ONLY";
}

function PermissionHint({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ marginTop: 6, opacity: 0.75, fontSize: 12, color: "#f0c36a" }}>
      {children}
    </div>
  );
}

function SummaryChips({
  title,
  values,
  options,
}: {
  title: string;
  values: Set<string>;
  options: readonly { value: string; label: string }[];
}) {
  const labels = Array.from(values).map((value) => {
    const option = options.find((item) => item.value === value);
    return option?.label || value;
  });

  return (
    <div style={{ display: "grid", gap: 6 }}>
      <div style={{ fontSize: 12, opacity: 0.7 }}>{title}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {labels.length ? (
          labels.map((label) => (
            <span
              key={label}
              style={{
                padding: "4px 8px",
                borderRadius: 999,
                border: "1px solid rgba(255,255,255,0.12)",
                background: "rgba(255,255,255,0.04)",
                fontSize: 12,
              }}
            >
              {label}
            </span>
          ))
        ) : (
          <span style={{ opacity: 0.6, fontSize: 12 }}>Δεν έχει οριστεί</span>
        )}
      </div>
    </div>
  );
}

function OptionGroup({
  title,
  options,
  selected,
  disabled = false,
  disabledMessage,
  onToggle,
}: {
  title: string;
  options: readonly { value: string; label: string }[];
  selected: Set<string>;
  disabled?: boolean;
  disabledMessage?: string;
  onToggle: (key: string) => void;
}) {
  const [query, setQuery] = useState("");

  const filteredOptions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;

    return options.filter(
      (option) =>
        option.label.toLowerCase().includes(q) ||
        option.value.toLowerCase().includes(q)
    );
  }, [options, query]);

  return (
    <div
      style={{
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 12,
        padding: 12,
        opacity: disabled ? 0.75 : 1,
      }}
    >
      <div style={{ marginBottom: 10, fontWeight: 700 }}>{title}</div>

      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Αναζήτηση..."
        style={{
          width: "100%",
          boxSizing: "border-box",
          marginBottom: 12,
          padding: "10px 12px",
          borderRadius: 10,
          border: "1px solid rgba(255,255,255,0.12)",
          background: "rgba(255,255,255,0.04)",
          color: "inherit",
        }}
      />

      <div style={{ display: "grid", gap: 8 }}>
        {filteredOptions.map((option) => (
          <label
            key={option.value}
            style={{
              display: "flex",
              gap: 10,
              alignItems: "center",
              cursor: disabled ? "not-allowed" : "pointer",
            }}
          >
            <input
              type="checkbox"
              checked={selected.has(option.value)}
              disabled={disabled}
              onChange={() => onToggle(option.value)}
            />
            <span>{option.label}</span>
          </label>
        ))}
      </div>

      {disabled && disabledMessage ? (
        <PermissionHint>{disabledMessage}</PermissionHint>
      ) : null}
    </div>
  );
}

function TabButton({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        padding: "10px 14px",
        borderRadius: 10,
        border: active
          ? "1px solid rgba(72,126,255,0.55)"
          : "1px solid rgba(255,255,255,0.08)",
        background: active ? "rgba(72,126,255,0.16)" : "transparent",
        color: "inherit",
        cursor: "pointer",
        fontWeight: active ? 700 : 500,
      }}
    >
      {label}
    </button>
  );
}

export function UserDetailDrawer({ user, availableSites, onClose }: Props) {
  const { profile } = useAuth();
  const mutation = useUpdateUser();
  const detailRef = useRef<HTMLDivElement | null>(null);

  const [activeTab, setActiveTab] = useState<TabKey>("general");

  const [active, setActive] = useState(true);
  const [siteId, setSiteId] = useState("");
  const [adminPortal, setAdminPortal] = useState(false);
  const [adminLevel, setAdminLevel] = useState<AdminLevel>("VIEW_ONLY");
  const [selectedRoles, setSelectedRoles] = useState<Set<string>>(new Set());
  const [selectedTeams, setSelectedTeams] = useState<Set<string>>(new Set());
  const [selectedAssetPermissions, setSelectedAssetPermissions] = useState<Set<string>>(new Set());
  const [selectedEnterpriseSiteId, setSelectedEnterpriseSiteId] = useState("");
  const [enterpriseAccessBySite, setEnterpriseAccessBySite] = useState<Record<string, Record<string, boolean>>>({});

  const capabilities = useMemo(
    () => resolveAdminCapabilities(profile, user),
    [profile, user]
  );

const configSiteId = user?.siteId || siteId || "tpas_kardias";

const roleOptions = useDynamicRoles(configSiteId);
const teamOptions = useDynamicTeams(configSiteId);

  useEffect(() => {
    mutation.reset();

    if (!user) {
      setActiveTab("general");
      setActive(true);
      setSiteId("");
      setAdminPortal(false);
      setAdminLevel("VIEW_ONLY");
      setSelectedRoles(new Set());
      setSelectedTeams(new Set());
      setSelectedAssetPermissions(new Set());
      setSelectedEnterpriseSiteId("");
      setEnterpriseAccessBySite({});
      return;
    }

    setActiveTab("general");
    setActive(user.active !== false);
    setSiteId(user.siteId || "");
    setAdminPortal(Boolean(user.platformRoles?.ADMIN_PORTAL));
    setAdminLevel(resolveDisplayedAdminLevel(user));
    setSelectedRoles(recordToSelectedSet(user.roles));
    setSelectedTeams(recordToSelectedSet(user.teams));

    const permissionsSiteId = user.siteId || siteId || "";
    setSelectedAssetPermissions(
      recordToSelectedSet(user.siteMemberships?.[permissionsSiteId]?.permissions)
    );

    const nextEnterpriseAccess = enterpriseAccessFromUser(user, availableSites);
    const primarySiteId = getPrimarySiteId(user);
    const firstAdditionalSite = availableSites.find((site) => site !== primarySiteId) || "";
    setSelectedEnterpriseSiteId(Object.keys(nextEnterpriseAccess)[0] || firstAdditionalSite);
    setEnterpriseAccessBySite(nextEnterpriseAccess);

  }, [availableSites, user]);

  const rolesRecord = useMemo(
    () => selectedSetToRecord(selectedRoles),
    [selectedRoles]
  );

  const teamsRecord = useMemo(
    () => selectedSetToRecord(selectedTeams),
    [selectedTeams]
  );

  const initialRoles = useMemo(() => recordToSelectedSet(user?.roles), [user]);
  const initialTeams = useMemo(() => recordToSelectedSet(user?.teams), [user]);
  const initialAssetPermissions = useMemo(() => {
    const permissionsSiteId = user?.siteId || siteId || "";
    return recordToSelectedSet(user?.siteMemberships?.[permissionsSiteId]?.permissions);
  }, [siteId, user]);

  const initialEnterpriseAccessBySite = useMemo(
    () => enterpriseAccessFromUser(user, availableSites),
    [availableSites, user]
  );

  const additionalSiteOptions = useMemo(() => {
    const primarySiteId = getPrimarySiteId(user) || siteId;
    return availableSites.filter((site) => site && site !== primarySiteId);
  }, [availableSites, siteId, user]);

  const selectedEnterprisePermissions = useMemo(
    () => recordToSelectedSet(enterpriseAccessBySite[selectedEnterpriseSiteId]),
    [enterpriseAccessBySite, selectedEnterpriseSiteId]
  );

  const hasChanges = useMemo(() => {
    if (!user) return false;

    const initialActive = user.active !== false;
    const initialSiteId = user.siteId || "";
    const initialAdminPortal = Boolean(user.platformRoles?.ADMIN_PORTAL);
    const initialAdminLevel = resolveDisplayedAdminLevel(user);

    return (
      active !== initialActive ||
      siteId !== initialSiteId ||
      adminPortal !== initialAdminPortal ||
      adminLevel !== initialAdminLevel ||
      !setsEqual(selectedRoles, initialRoles) ||
      !setsEqual(selectedTeams, initialTeams) ||
      !setsEqual(selectedAssetPermissions, initialAssetPermissions) ||
      !recordsEqual(enterpriseAccessBySite, initialEnterpriseAccessBySite)
    );
  }, [
    active,
    adminPortal,
    adminLevel,
    initialRoles,
    initialTeams,
    initialAssetPermissions,
    selectedRoles,
    selectedTeams,
    selectedAssetPermissions,
    enterpriseAccessBySite,
    initialEnterpriseAccessBySite,
    siteId,
    user,
  ]);

  function toggleRole(key: string) {
    if (!capabilities.canEditRoles) return;

    setSelectedRoles((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleTeam(key: string) {
    if (!capabilities.canEditTeams) return;

    setSelectedTeams((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleAssetPermission(key: string) {
    if (!capabilities.canEditRoles) return;

    setSelectedAssetPermissions((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }


  function toggleEnterprisePermission(key: string) {
    if (!capabilities.canEditSite || !selectedEnterpriseSiteId) return;

    setEnterpriseAccessBySite((prev) => {
      const current = { ...(prev[selectedEnterpriseSiteId] || {}) };

      if (current[key]) delete current[key];
      else current[key] = true;

      const next = { ...prev };
      if (Object.keys(current).length) next[selectedEnterpriseSiteId] = current;
      else delete next[selectedEnterpriseSiteId];

      return next;
    });
  }

  async function handleSave() {
    if (!user || mutation.isPending || !hasChanges || !capabilities.canSave) {
      return;
    }

    const values: Partial<UserProfile> = {};

    if (capabilities.canEditActive) values.active = active;
    if (capabilities.canEditSite) values.siteId = siteId || "";

    if (capabilities.canEditAdminPortal) {
      values.platformRoles = {
        ...(user.platformRoles || {}),
        ADMIN_PORTAL: adminPortal,
      };

      values.adminPermissions = {
        ...(user.adminPermissions || {}),
        level: adminLevel,
      };
    }

    if (capabilities.canEditRoles) values.roles = rolesRecord;
    if (capabilities.canEditTeams) values.teams = teamsRecord;

    const membershipSiteId = siteId || user.siteId || "";
    const shouldSyncSiteMembership =
      Boolean(membershipSiteId) &&
      (capabilities.canEditRoles ||
        capabilities.canEditTeams ||
        !setsEqual(selectedAssetPermissions, initialAssetPermissions));

    if (shouldSyncSiteMembership) {
      const currentMemberships = user.siteMemberships || {};
      const currentMembership: SiteMembership = currentMemberships[membershipSiteId] || {};

      values.siteMemberships = {
        ...currentMemberships,
        [membershipSiteId]: {
          ...currentMembership,
          siteId: membershipSiteId,
          active: currentMembership.active !== false,
          roles: capabilities.canEditRoles ? rolesRecord : currentMembership.roles,
          teams: capabilities.canEditTeams ? teamsRecord : currentMembership.teams,
          permissions: selectedSetToRecord(selectedAssetPermissions),
        },
      };
    }

    if (capabilities.canEditSite && !recordsEqual(enterpriseAccessBySite, initialEnterpriseAccessBySite)) {
      const memberships = { ...(values.siteMemberships || user.siteMemberships || {}) };
      const touchedSiteIds = new Set([
        ...Object.keys(initialEnterpriseAccessBySite),
        ...Object.keys(enterpriseAccessBySite),
      ]);

      touchedSiteIds.forEach((enterpriseSiteId) => {
        if (!enterpriseSiteId || enterpriseSiteId === membershipSiteId) return;

        const currentMembership: SiteMembership = memberships[enterpriseSiteId] || {};
        const preservedPermissions = stripEnterprisePermissions(currentMembership.permissions);
        const nextPermissions = {
          ...preservedPermissions,
          ...(enterpriseAccessBySite[enterpriseSiteId] || {}),
        };

        memberships[enterpriseSiteId] = {
          ...currentMembership,
          siteId: enterpriseSiteId,
          active: currentMembership.active !== false,
          permissions: nextPermissions,
        };
      });

      values.siteMemberships = memberships;
    }

    if (!Object.keys(values).length) return;

    await mutation.mutateAsync({
      uid: user.uid,
      values,
    });
  }

  if (!user) {
    return (
      <div ref={detailRef} className="user-detail-panel">
        {userLabel("selectUserForDetails")}
      </div>
    );
  }

  return (
    <div
      ref={detailRef}
      className={`user-detail-panel${onClose ? "" : " user-detail-panel-sticky"}`}
    >
      <div className="user-detail-header">
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 12,
            marginBottom: 12,
          }}
        >
          <h3 style={{ margin: 0 }}>{userLabel("detailTitle")}</h3>

          {onClose ? (
            <button
              type="button"
              onClick={onClose}
              aria-label="Κλείσιμο στοιχείων χρήστη"
              style={{
                width: 36,
                height: 36,
                borderRadius: 999,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(255,255,255,0.06)",
                color: "inherit",
                cursor: "pointer",
                fontSize: 20,
                lineHeight: 1,
              }}
            >
              ×
            </button>
          ) : null}
        </div>

        <div style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 18 }}>
            {user.displayName || "-"}
          </div>
          <div style={{ opacity: 0.8, marginTop: 4 }}>{user.email || "-"}</div>
          <div style={{ opacity: 0.7, marginTop: 4, fontSize: 13 }}>
            {user.uid}
          </div>
        </div>

        <div style={{ marginBottom: 12 }}>
          <StatusBadge
            label={active ? userLabel("active") : userLabel("inactive")}
            tone={active ? "success" : "danger"}
          />
        </div>

        <div style={{ display: "grid", gap: 12 }}>
          <SummaryChips
            title="Ρόλοι χρήστη"
            values={selectedRoles}
            options={roleOptions}
          />
          <SummaryChips
            title="Ομάδες χρήστη"
            values={selectedTeams}
            options={teamOptions}
          />
        </div>
      </div>

      {!capabilities.canSave ? (
        <div
          style={{
            marginBottom: 16,
            padding: 10,
            borderRadius: 10,
            border: "1px solid rgba(255,193,7,0.35)",
            background: "rgba(255,193,7,0.08)",
            color: "#f0c36a",
            fontSize: 13,
          }}
        >
          Δεν έχετε δικαίωμα επεξεργασίας για αυτόν τον χρήστη.
        </div>
      ) : null}

      <div
        style={{
          display: "flex",
          gap: 8,
          flexWrap: "wrap",
          marginBottom: 16,
        }}
      >
        <TabButton
          label={userLabel("generalTab")}
          active={activeTab === "general"}
          onClick={() => setActiveTab("general")}
        />
        <TabButton
          label={userLabel("rolesTab")}
          active={activeTab === "roles"}
          onClick={() => setActiveTab("roles")}
        />
        <TabButton
          label={userLabel("teamsTab")}
          active={activeTab === "teams"}
          onClick={() => setActiveTab("teams")}
        />
        <TabButton
          label="Enterprise πρόσβαση"
          active={activeTab === "enterpriseAccess"}
          onClick={() => setActiveTab("enterpriseAccess")}
        />
        <TabButton
          label="Μέσα site"
          active={activeTab === "assets"}
          onClick={() => setActiveTab("assets")}
        />
        <TabButton
          label="Ιστορικό"
          active={activeTab === "history"}
          onClick={() => setActiveTab("history")}
        />
      </div>

      <div style={{ display: "grid", gap: 14 }}>
        {activeTab === "general" && (
          <>
            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                cursor: capabilities.canEditActive ? "pointer" : "not-allowed",
                opacity: capabilities.canEditActive ? 1 : 0.75,
              }}
            >
              <input
                type="checkbox"
                checked={active}
                disabled={!capabilities.canEditActive}
                onChange={(e) => setActive(e.target.checked)}
              />
              <span>{userLabel("activeUser")}</span>
            </label>

            {!capabilities.canEditActive ? (
              <PermissionHint>
                Δεν μπορείτε να αλλάξετε την κατάσταση ενεργού χρήστη.
              </PermissionHint>
            ) : null}

            <label style={{ display: "block" }}>
              <div style={{ marginBottom: 6 }}>{userLabel("siteField")}</div>
              <select
                value={siteId}
                disabled={!capabilities.canEditSite}
                onChange={(e) => setSiteId(e.target.value)}
                style={{
                  width: "100%",
                  padding: 10,
                  borderRadius: 10,
                  opacity: capabilities.canEditSite ? 1 : 0.75,
                  cursor: capabilities.canEditSite ? "pointer" : "not-allowed",
                }}
              >
                <option value="">{userLabel("noSiteOption")}</option>
                {availableSites.map((site) => (
                  <option key={site} value={site}>
                    {site}
                  </option>
                ))}
              </select>

              {!capabilities.canEditSite ? (
                <PermissionHint>
                  Το site assignment αλλάζει μόνο από Global Admin.
                </PermissionHint>
              ) : null}
            </label>

            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                cursor: capabilities.canEditAdminPortal
                  ? "pointer"
                  : "not-allowed",
                opacity: capabilities.canEditAdminPortal ? 1 : 0.75,
              }}
            >
              <input
                type="checkbox"
                checked={adminPortal}
                disabled={!capabilities.canEditAdminPortal}
                onChange={(e) => setAdminPortal(e.target.checked)}
              />
              <span>{userLabel("adminPortal")}</span>
            </label>

            {!capabilities.canEditAdminPortal ? (
              <PermissionHint>
                Η πρόσβαση Admin Portal αλλάζει μόνο από Global Admin.
              </PermissionHint>
            ) : null}

            <label style={{ display: "block" }}>
              <div style={{ marginBottom: 6 }}>Admin Level</div>
              <select
                value={adminLevel}
                disabled={!capabilities.canEditAdminPortal}
                onChange={(e) => setAdminLevel(e.target.value as AdminLevel)}
                style={{
                  width: "100%",
                  padding: 10,
                  borderRadius: 10,
                  opacity: capabilities.canEditAdminPortal ? 1 : 0.75,
                  cursor: capabilities.canEditAdminPortal
                    ? "pointer"
                    : "not-allowed",
                }}
              >
                {ADMIN_LEVEL_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>

              {!capabilities.canEditAdminPortal ? (
                <PermissionHint>
                  Το Admin Level αλλάζει μόνο από Global Admin.
                </PermissionHint>
              ) : (
                <PermissionHint>
                  Το Admin Level καθορίζει τι μπορεί να κάνει ο χρήστης μέσα
                  στο web admin.
                </PermissionHint>
              )}
            </label>
          </>
        )}

        {activeTab === "roles" && (
          <OptionGroup
            title={userLabel("operationalRolesGroup")}
            options={roleOptions}
            selected={selectedRoles}
            disabled={!capabilities.canEditRoles}
            disabledMessage="Δεν έχετε δικαίωμα αλλαγής επιχειρησιακών ρόλων για αυτόν τον χρήστη."
            onToggle={toggleRole}
          />
        )}

        {activeTab === "teams" && (
          <OptionGroup
            title={userLabel("teamsGroup")}
            options={teamOptions}
            selected={selectedTeams}
            disabled={!capabilities.canEditTeams}
            disabledMessage="Δεν έχετε δικαίωμα αλλαγής ομάδων για αυτόν τον χρήστη."
            onToggle={toggleTeam}
          />
        )}

        {activeTab === "enterpriseAccess" && (
          <div style={{ display: "grid", gap: 12 }}>
            <div
              style={{
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 12,
                padding: 12,
              }}
            >
              <div style={{ fontWeight: 700, marginBottom: 8 }}>
                Ρητή πρόσβαση σε επιπλέον μονάδες εργασίας
              </div>
              <div style={{ opacity: 0.72, fontSize: 13, marginBottom: 12 }}>
                Το βασικό site του χρήστη είναι {getPrimarySiteId(user) || "-"}.
                Τα παρακάτω δικαιώματα αφορούν μόνο πρόσθετη cross-site πρόσβαση.
                Το ενεργό siteMembership από μόνο του δεν πρέπει να δίνει ορατότητα ή ειδοποιήσεις.
              </div>

              {additionalSiteOptions.length ? (
                <label style={{ display: "block", marginBottom: 12 }}>
                  <div style={{ marginBottom: 6 }}>Πρόσθετη μονάδα εργασίας</div>
                  <select
                    value={selectedEnterpriseSiteId}
                    disabled={!capabilities.canEditSite}
                    onChange={(event) => setSelectedEnterpriseSiteId(event.target.value)}
                    style={{
                      width: "100%",
                      padding: 10,
                      borderRadius: 10,
                      opacity: capabilities.canEditSite ? 1 : 0.75,
                    }}
                  >
                    {additionalSiteOptions.map((site) => (
                      <option key={site} value={site}>
                        {site}
                      </option>
                    ))}
                  </select>
                </label>
              ) : (
                <div style={{ opacity: 0.7, fontSize: 13 }}>
                  Δεν υπάρχουν διαθέσιμα επιπλέον sites για ανάθεση πρόσβασης.
                </div>
              )}

              {selectedEnterpriseSiteId ? (
                <div style={{ display: "grid", gap: 10 }}>
                  {ENTERPRISE_SITE_PERMISSION_OPTIONS.map((option) => (
                    <label
                      key={option.value}
                      style={{
                        display: "grid",
                        gridTemplateColumns: "auto 1fr",
                        gap: 10,
                        cursor: capabilities.canEditSite ? "pointer" : "not-allowed",
                        opacity: capabilities.canEditSite ? 1 : 0.75,
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={selectedEnterprisePermissions.has(option.value)}
                        disabled={!capabilities.canEditSite}
                        onChange={() => toggleEnterprisePermission(option.value)}
                      />
                      <span>
                        <span style={{ fontWeight: 700 }}>{option.label}</span>
                        <br />
                        <span style={{ opacity: 0.7, fontSize: 12 }}>{option.description}</span>
                      </span>
                    </label>
                  ))}
                </div>
              ) : null}

              {!capabilities.canEditSite ? (
                <PermissionHint>
                  Η πρόσθετη cross-site πρόσβαση αλλάζει μόνο από Global Admin.
                </PermissionHint>
              ) : null}
            </div>
          </div>
        )}

        {activeTab === "assets" && (
          <div style={{ display: "grid", gap: 12 }}>
            <div
              style={{
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 12,
                padding: 12,
              }}
            >
              <div style={{ fontWeight: 700, marginBottom: 8 }}>
                Δικαιώματα διαχείρισης μέσων για site: {siteId || user.siteId || "-"}
              </div>
              <div style={{ opacity: 0.72, fontSize: 13, marginBottom: 12 }}>
                Τα δικαιώματα αποθηκεύονται στο siteMemberships του χρήστη και δεν επηρεάζουν την τρέχουσα mobile έκδοση.
              </div>

              <div style={{ display: "grid", gap: 10 }}>
                {SITE_ASSET_PERMISSION_OPTIONS.map((option) => (
                  <label
                    key={option.value}
                    style={{
                      display: "grid",
                      gridTemplateColumns: "auto 1fr",
                      gap: 10,
                      cursor: capabilities.canEditRoles ? "pointer" : "not-allowed",
                      opacity: capabilities.canEditRoles ? 1 : 0.75,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={selectedAssetPermissions.has(option.value)}
                      disabled={!capabilities.canEditRoles}
                      onChange={() => toggleAssetPermission(option.value)}
                    />
                    <span>
                      <span style={{ fontWeight: 700 }}>{option.label}</span>
                      <br />
                      <span style={{ opacity: 0.7, fontSize: 12 }}>{option.description}</span>
                    </span>
                  </label>
                ))}
              </div>

              {!capabilities.canEditRoles ? (
                <PermissionHint>
                  Τα δικαιώματα μέσων αλλάζουν από Global Admin ή από Site Admin του ίδιου site.
                </PermissionHint>
              ) : null}
            </div>
          </div>
        )}

        {activeTab === "history" && <UserAuditHistory userId={user.uid} />}
      </div>

      <div
        style={{
          marginTop: 20,
          display: "flex",
          alignItems: "center",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <button
          onClick={handleSave}
          disabled={mutation.isPending || !hasChanges || !capabilities.canSave}
          style={{
            padding: "12px 18px",
            borderRadius: 12,
            border: "none",
            cursor:
              mutation.isPending || !hasChanges || !capabilities.canSave
                ? "not-allowed"
                : "pointer",
            opacity:
              mutation.isPending || !hasChanges || !capabilities.canSave
                ? 0.65
                : 1,
          }}
        >
          {mutation.isPending ? userLabel("saving") : userLabel("save")}
        </button>

        {!hasChanges ? (
          <span style={{ opacity: 0.7, fontSize: 13 }}>
            {userLabel("noUnsavedChanges")}
          </span>
        ) : null}
      </div>

      {mutation.isSuccess ? (
        <div style={{ marginTop: 12, color: "limegreen" }}>
          {userLabel("saveSuccess")}
        </div>
      ) : null}

      {mutation.isError ? (
        <div style={{ marginTop: 12, color: "crimson" }}>
          {userLabel("saveErrorPrefix")} {String(mutation.error)}
        </div>
      ) : null}
    </div>
  );
}