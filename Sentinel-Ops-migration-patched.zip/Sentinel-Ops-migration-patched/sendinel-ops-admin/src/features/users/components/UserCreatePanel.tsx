import { useMemo, useState } from "react";
import type { Dispatch, FormEvent, ReactNode, SetStateAction } from "react";
import type { AdminLevel, UserProfile } from "../../../domain/models/user";
import { translatedRoleOptions, translatedTeamOptions } from "../i18n/userManagementLabels";
import { useCreateAdminUser } from "../../../hooks/useCreateAdminUser";

type Props = {
  currentUser: UserProfile | null;
  availableSites: string[];
};

const ADMIN_LEVEL_OPTIONS: { value: AdminLevel; label: string }[] = [
  { value: "GLOBAL_ADMIN", label: "Global Admin" },
  { value: "SITE_ADMIN", label: "Site Admin" },
  { value: "VIEW_ONLY", label: "View Only" },
];

function isGlobalAdmin(profile: UserProfile | null) {
  return profile?.adminPermissions?.level === "GLOBAL_ADMIN";
}

function selectedSetToRecord(set: Set<string>) {
  return Array.from(set).reduce<Record<string, boolean>>((acc, key) => {
    acc[key] = true;
    return acc;
  }, {});
}

function toggleInSet(setter: Dispatch<SetStateAction<Set<string>>>, key: string) {
  setter((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    return next;
  });
}

function FieldLabel({ children }: { children: ReactNode }) {
  return <div style={{ marginBottom: 6, fontWeight: 700 }}>{children}</div>;
}

function Hint({ children }: { children: ReactNode }) {
  return <div style={{ marginTop: 6, opacity: 0.7, fontSize: 12 }}>{children}</div>;
}

export function UserCreatePanel({ currentUser, availableSites }: Props) {
  const mutation = useCreateAdminUser();

  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [siteId, setSiteId] = useState("");
  const [active, setActive] = useState(true);
  const [adminPortal, setAdminPortal] = useState(false);
  const [adminLevel, setAdminLevel] = useState<AdminLevel>("VIEW_ONLY");
  const [selectedRoles, setSelectedRoles] = useState<Set<string>>(new Set());
  const [selectedTeams, setSelectedTeams] = useState<Set<string>>(new Set());
  const [createdMessage, setCreatedMessage] = useState("");

  const canCreate = isGlobalAdmin(currentUser);
  const roleOptions = useMemo(() => translatedRoleOptions(), []);
  const teamOptions = useMemo(() => translatedTeamOptions(), []);

  const normalizedEmail = email.trim().toLowerCase();
  const normalizedDisplayName = displayName.trim();
  const normalizedSiteId = siteId.trim();

  const formValid = Boolean(normalizedEmail && normalizedDisplayName && normalizedSiteId);

  function resetForm() {
    setEmail("");
    setDisplayName("");
    setSiteId("");
    setActive(true);
    setAdminPortal(false);
    setAdminLevel("VIEW_ONLY");
    setSelectedRoles(new Set());
    setSelectedTeams(new Set());
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setCreatedMessage("");

    if (!canCreate || mutation.isPending || !formValid) return;

    const result = await mutation.mutateAsync({
      email: normalizedEmail,
      displayName: normalizedDisplayName,
      siteId: normalizedSiteId,
      active,
      platformRoles: {
        ADMIN_PORTAL: adminPortal,
      },
      adminPermissions: {
        level: adminLevel,
      },
      roles: selectedSetToRecord(selectedRoles),
      teams: selectedSetToRecord(selectedTeams),
    });

    setCreatedMessage(
      `Ο χρήστης δημιουργήθηκε επιτυχώς${result?.uid ? ` (UID: ${result.uid})` : ""}. Προσωρινό password: sentinel`
    );
    resetForm();
  }

  if (!canCreate) {
    return null;
  }

  return (
    <div
      style={{
        marginBottom: 18,
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 16,
        padding: 16,
        background: "rgba(255,255,255,0.02)",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 12,
          alignItems: "center",
        }}
      >
        <div>
          <h2 style={{ margin: 0, fontSize: 18 }}>Δημιουργία χρήστη</h2>
          <div style={{ marginTop: 4, opacity: 0.72, fontSize: 13 }}>
            Δημιουργεί Firebase Auth user, RTDB profile και audit log. Προσωρινό password: <strong>sentinel</strong>.
          </div>
        </div>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          style={{
            padding: "10px 14px",
            borderRadius: 10,
            border: "1px solid rgba(72,126,255,0.55)",
            background: "rgba(72,126,255,0.16)",
            color: "inherit",
            cursor: "pointer",
            fontWeight: 700,
          }}
        >
          {open ? "Κλείσιμο" : "+ Create User"}
        </button>
      </div>

      {createdMessage ? (
        <div
          style={{
            marginTop: 14,
            padding: 10,
            borderRadius: 10,
            border: "1px solid rgba(39,174,96,0.35)",
            background: "rgba(39,174,96,0.08)",
            color: "#7ee2a8",
            fontSize: 13,
          }}
        >
          {createdMessage}
        </div>
      ) : null}

      {open ? (
        <form onSubmit={handleSubmit} style={{ marginTop: 16, display: "grid", gap: 14 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12 }}>
            <label style={{ display: "block" }}>
              <FieldLabel>Email *</FieldLabel>
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="user@company.com"
                type="email"
                required
                style={{ width: "100%", padding: 10, borderRadius: 10 }}
              />
            </label>

            <label style={{ display: "block" }}>
              <FieldLabel>Ονοματεπώνυμο *</FieldLabel>
              <input
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                placeholder="User Name"
                required
                style={{ width: "100%", padding: 10, borderRadius: 10 }}
              />
            </label>

            <label style={{ display: "block" }}>
              <FieldLabel>Site *</FieldLabel>
              <select
                value={siteId}
                onChange={(event) => setSiteId(event.target.value)}
                required
                style={{ width: "100%", padding: 10, borderRadius: 10 }}
              >
                <option value="">-- Επιλογή site --</option>
                {availableSites.map((site) => (
                  <option key={site} value={site}>
                    {site}
                  </option>
                ))}
              </select>
              <Hint>Το site γράφεται ως primary/current siteId για συμβατότητα με mobile.</Hint>
            </label>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12 }}>
            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 12,
                padding: 12,
              }}
            >
              <input
                type="checkbox"
                checked={active}
                onChange={(event) => setActive(event.target.checked)}
              />
              <span>Ενεργός χρήστης</span>
            </label>

            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 12,
                padding: 12,
              }}
            >
              <input
                type="checkbox"
                checked={adminPortal}
                onChange={(event) => setAdminPortal(event.target.checked)}
              />
              <span>Πρόσβαση Admin Portal</span>
            </label>

            <label style={{ display: "block" }}>
              <FieldLabel>Admin Level</FieldLabel>
              <select
                value={adminLevel}
                onChange={(event) => setAdminLevel(event.target.value as AdminLevel)}
                style={{ width: "100%", padding: 10, borderRadius: 10 }}
              >
                {ADMIN_LEVEL_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <Hint>Για απλό εργαζόμενο άφησέ το View Only και χωρίς Admin Portal.</Hint>
            </label>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 }}>
            <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, padding: 12 }}>
              <FieldLabel>Επιχειρησιακοί ρόλοι</FieldLabel>
              <div style={{ display: "grid", gap: 8 }}>
                {roleOptions.map((role) => (
                  <label key={role.value} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <input
                      type="checkbox"
                      checked={selectedRoles.has(role.value)}
                      onChange={() => toggleInSet(setSelectedRoles, role.value)}
                    />
                    <span>{role.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, padding: 12 }}>
              <FieldLabel>Ομάδες</FieldLabel>
              <div style={{ display: "grid", gap: 8 }}>
                {teamOptions.map((team) => (
                  <label key={team.value} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <input
                      type="checkbox"
                      checked={selectedTeams.has(team.value)}
                      onChange={() => toggleInSet(setSelectedTeams, team.value)}
                    />
                    <span>{team.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {mutation.error ? (
            <div
              style={{
                padding: 10,
                borderRadius: 10,
                border: "1px solid rgba(231,76,60,0.35)",
                background: "rgba(231,76,60,0.08)",
                color: "#ff9f9f",
                fontSize: 13,
              }}
            >
              Σφάλμα δημιουργίας χρήστη: {mutation.error.message}
            </div>
          ) : null}

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
            <button
              type="button"
              onClick={resetForm}
              disabled={mutation.isPending}
              style={{ padding: "10px 14px", borderRadius: 10, cursor: "pointer" }}
            >
              Καθαρισμός
            </button>
            <button
              type="submit"
              disabled={!formValid || mutation.isPending}
              style={{
                padding: "10px 14px",
                borderRadius: 10,
                border: "1px solid rgba(39,174,96,0.55)",
                background: "rgba(39,174,96,0.16)",
                color: "inherit",
                cursor: !formValid || mutation.isPending ? "not-allowed" : "pointer",
                fontWeight: 700,
              }}
            >
              {mutation.isPending ? "Δημιουργία..." : "Δημιουργία χρήστη"}
            </button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
