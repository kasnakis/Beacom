import { useState } from "react";
import { useUserAuditLogs } from "../../../hooks/useUserAuditLogs";

type Props = {
  userId: string;
};

function formatDate(value?: number) {
  if (!value) return "-";

  return new Date(value).toLocaleString("el-GR");
}

function formatFields(fields?: string[]) {
  if (!fields?.length) return "-";
  return fields.join(", ");
}

function exportToCSV(data: any[]) {
  if (!data.length) return;

  const rows = data.map((log) => ({
    date: formatDate(log.createdAt),
    user: log.performedBy?.email || log.performedBy?.uid || "",
    level: log.performedBy?.level || "",
    fields: formatFields(log.changedFields),
  }));

  const headers = Object.keys(rows[0]).join(",");
  const csv = [
    headers,
    ...rows.map((r) => Object.values(r).join(",")),
  ].join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", "audit_logs.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function UserAuditHistory({ userId }: Props) {
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");

  const filters = {
    fromDate: fromDate ? new Date(fromDate).getTime() : null,
    toDate: toDate ? new Date(toDate).getTime() : null,
  };

  const { data = [], isLoading, error } = useUserAuditLogs(
    userId,
    filters
  );

  if (isLoading) return <div>Φόρτωση...</div>;
  if (error) return <div>Σφάλμα</div>;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* FILTERS */}
      <div
        style={{
          display: "flex",
          gap: 10,
          flexWrap: "wrap",
          alignItems: "center",
        }}
      >
        <input
          type="date"
          value={fromDate}
          onChange={(e) => setFromDate(e.target.value)}
        />

        <input
          type="date"
          value={toDate}
          onChange={(e) => setToDate(e.target.value)}
        />

        <button onClick={() => exportToCSV(data)}>
          Export CSV
        </button>
      </div>

      {/* DATA */}
      {!data.length && (
        <div style={{ opacity: 0.7 }}>Δεν υπάρχουν δεδομένα</div>
      )}

      {data.map((log) => (
        <div
          key={log.id}
          style={{
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 12,
            padding: 12,
          }}
        >
          <div style={{ fontWeight: 700 }}>
            {formatFields(log.changedFields)}
          </div>

          <div style={{ fontSize: 12, opacity: 0.7 }}>
            {formatDate(log.createdAt)}
          </div>

          <div style={{ marginTop: 6 }}>
            {log.performedBy?.email}
          </div>

          <details style={{ marginTop: 8 }}>
            <summary>Δες αλλαγές</summary>
            <pre style={{ fontSize: 12 }}>
              {JSON.stringify(log.changes, null, 2)}
            </pre>
          </details>
        </div>
      ))}
    </div>
  );
}