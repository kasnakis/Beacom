import { useEffect, useState } from "react";
import { getDatabase, ref, get } from "firebase/database";

type Option = { value: string; label: string };

const FALLBACK_ROLES: Option[] = [
  { value: "WORKER", label: "Εργαζόμενος" },
  { value: "SUPERVISOR", label: "Επόπτης / Προϊστάμενος" },
  { value: "SITE_MANAGER", label: "Διοίκηση μονάδας" },
  { value: "DIRECTOR", label: "Διευθυντής / Επικεφαλής" },
  { value: "CONTROL_ROOM", label: "Κέντρο Ελέγχου" },
  { value: "SECURITY_OFFICER", label: "Φύλαξη / Ασφάλεια χώρου" },
  { value: "VIEWER", label: "Μόνο προβολή" },
  { value: "HSE_MANAGER", label: "Υπεύθυνος Υγείας & Ασφάλειας" },
  { value: "HSE_RESPONDER", label: "Ανταποκριτής Υ&Α" },
  { value: "ENVIRONMENTAL_OFFICER", label: "Υπεύθυνος Περιβάλλοντος" },
  { value: "ENVIRONMENT_RESPONDER", label: "Ανταποκριτής Περιβάλλοντος" },
  { value: "EMERGENCY_COMMANDER", label: "Συντονιστής έκτακτης ανάγκης" },
  { value: "COMMUNICATIONS_OFFICER", label: "Υπεύθυνος επικοινωνιών" },
  { value: "FIRE_SAFETY_COORDINATOR", label: "Συντονιστής πυρασφάλειας" },
  { value: "FIRST_AID_COORDINATOR", label: "Συντονιστής Α’ Βοηθειών" },
  { value: "PERSONNEL_COORDINATOR", label: "Συντονιστής προσωπικού" },
  { value: "FIRE_TEAM_MEMBER", label: "Μέλος ομάδας πυρασφάλειας" },
  { value: "FIRST_AID_RESPONDER", label: "Μέλος Α’ Βοηθειών" },
  { value: "EVACUATION_WARDEN", label: "Υπεύθυνος εκκένωσης" },
  { value: "TECHNICIAN", label: "Τεχνικός" },
];

const FALLBACK_TEAMS: Option[] = [
  { value: "GENERAL_USERS", label: "Γενικοί Χρήστες" },
  { value: "MANAGEMENT", label: "Διοίκηση" },
  { value: "HSE_TEAM", label: "Ομάδα Υγείας & Ασφάλειας" },
  { value: "ENVIRONMENT_TEAM", label: "Περιβαλλοντική ομάδα" },
  { value: "EMERGENCY_TEAM", label: "Ομάδα έκτακτης ανάγκης" },
  { value: "FIRE_TEAM", label: "Ομάδα πυρασφάλειας" },
  { value: "FIRST_AID_TEAM", label: "Ομάδα Α’ Βοηθειών" },
  { value: "EVACUATION_TEAM", label: "Ομάδα εκκένωσης" },
  { value: "SECURITY_TEAM", label: "Ομάδα φύλαξης / ασφάλειας" },
  { value: "CONTROL_ROOM_TEAM", label: "Κέντρο Ελέγχου / Φυλάκη" },
  { value: "READ_ONLY_USERS", label: "Χρήστες μόνο προβολής" },
  { value: "ENVIRONMENTAL_TEAM", label: "Περιβαλλοντική ομάδα" },
  { value: "RESPONSE_TEAM", label: "Ομάδα απόκρισης" },
];

function optionFromConfigEntry(key: string, value: any): Option {
  const optionValue = value?.id || key;
  return {
    value: optionValue,
    label: value?.labelEl || value?.labelEn || value?.name || optionValue,
  };
}

function mergeOptions(primary: Option[], extra: Option[]): Option[] {
  const merged = new Map<string, Option>();

  primary.forEach((item) => {
    if (item.value) merged.set(item.value, item);
  });

  extra.forEach((item) => {
    if (!item.value) return;

    const existing = merged.get(item.value);
    merged.set(item.value, {
      value: item.value,
      label: existing?.label || item.label || item.value,
    });
  });

  return Array.from(merged.values());
}

function normalizeOptionsFromConfig(data: unknown, fallback: Option[]): Option[] {
  if (!data || typeof data !== "object") return fallback;

  const configOptions = Object.entries(data as Record<string, any>)
    .map(([key, value]) => optionFromConfigEntry(key, value))
    .filter((item) => Boolean(item.value));

  // Enterprise rule: every site must expose the full canonical role/team catalog.
  // Site config may add custom labels/options, but it must not hide canonical options.
  return mergeOptions(fallback, configOptions);
}

export function useDynamicRoles(siteId: string) {
  const [roles, setRoles] = useState<Option[]>(FALLBACK_ROLES);

  useEffect(() => {
    if (!siteId) {
      setRoles(FALLBACK_ROLES);
      return;
    }

    const db = getDatabase();

    get(ref(db, `site_config_data/${siteId}/roles`))
      .then((snap) => {
        if (!snap.exists()) {
          setRoles(FALLBACK_ROLES);
          return;
        }

        setRoles(normalizeOptionsFromConfig(snap.val(), FALLBACK_ROLES));
      })
      .catch(() => {
        setRoles(FALLBACK_ROLES);
      });
  }, [siteId]);

  return roles;
}

export function useDynamicTeams(siteId: string) {
  const [teams, setTeams] = useState<Option[]>(FALLBACK_TEAMS);

  useEffect(() => {
    if (!siteId) {
      setTeams(FALLBACK_TEAMS);
      return;
    }

    const db = getDatabase();

    get(ref(db, `site_config_data/${siteId}/teams`))
      .then((snap) => {
        if (!snap.exists()) {
          setTeams(FALLBACK_TEAMS);
          return;
        }

        setTeams(normalizeOptionsFromConfig(snap.val(), FALLBACK_TEAMS));
      })
      .catch(() => {
        setTeams(FALLBACK_TEAMS);
      });
  }, [siteId]);

  return teams;
}

export function translatedRoleOptions() {
  return FALLBACK_ROLES;
}

export function translatedTeamOptions() {
  return FALLBACK_TEAMS;
}

export function translateRole(role: string) {
  return FALLBACK_ROLES.find((item) => item.value === role)?.label || role;
}

export function translateTeam(team: string) {
  return FALLBACK_TEAMS.find((item) => item.value === team)?.label || team;
}

export function userLabel(key: string, ...args: Array<string | number>) {
  const labels: Record<string, string> = {
  title: "Χρήστες",
  pageTitle: "Χρήστες",
  usersCount: `Χρήστες: ${args[0] ?? 0} / ${args[1] ?? 0}`,

  loadingUsers: "Φόρτωση χρηστών...",
  loadingUsersError: "Σφάλμα φόρτωσης χρηστών",
  emptyUsers: "Δεν βρέθηκαν χρήστες",

  searchField: "Αναζήτηση",
  searchPlaceholder: "Όνομα, email, ρόλος, ομάδα, site...",
  siteField: "Site",
  allSitesOption: "Όλα τα sites",
  statusFilterField: "Κατάσταση",
  allUsersOption: "Όλοι οι χρήστες",
  activeUsersOption: "Ενεργοί",
  inactiveUsersOption: "Ανενεργοί",

  nameColumn: "Ονοματεπώνυμο",
  emailColumn: "Email",
  siteColumn: "Site",
  statusColumn: "Κατάσταση",
  platformRolesColumn: "Platform Roles",
  rolesColumn: "Ρόλοι",
  teamsColumn: "Ομάδες",

  detailTitle: "Στοιχεία Χρήστη",
  generalTab: "Γενικά",
  rolesTab: "Ρόλοι",
  teamsTab: "Ομάδες",
  active: "Ενεργός",
  inactive: "Ανενεργός",
  save: "Αποθήκευση",
  saving: "Αποθήκευση...",
  saveSuccess: "Αποθηκεύτηκε επιτυχώς",
  saveErrorPrefix: "Σφάλμα:",
  noUnsavedChanges: "Δεν υπάρχουν αλλαγές",
  selectUserForDetails: "Επιλέξτε χρήστη",
  activeUser: "Ενεργός χρήστης",
  noSiteOption: "Χωρίς site",
  adminPortal: "Admin Portal",
  operationalRolesGroup: "Επιχειρησιακοί Ρόλοι",
  teamsGroup: "Ομάδες",
};

  return labels[key] || key;
}