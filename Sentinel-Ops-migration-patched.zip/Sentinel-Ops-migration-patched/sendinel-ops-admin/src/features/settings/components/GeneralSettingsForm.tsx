import type { AppConfig } from "../../../domain/models/appConfig";

export function GeneralSettingsForm({ value }: { value: AppConfig | null }) {
  return (
    <div className="card form-grid">
      <label>
        <span>Default language</span>
        <input value={value?.defaultLanguage ?? ""} readOnly />
      </label>
      <label>
        <span>Default timezone</span>
        <input value={value?.defaultTimezone ?? ""} readOnly />
      </label>
      <label>
        <span>Notification mode</span>
        <input value={value?.notificationMode ?? ""} readOnly />
      </label>
      <label>
        <span>Policy mode</span>
        <input value={value?.policyMode ?? ""} readOnly />
      </label>
    </div>
  );
}
