import { useEffect, useState } from "react";
import type { SiteAdminRow } from "../../../domain/models/site";
import { useUpdateSite } from "../../../hooks/useUpdateSite";
import { StatusBadge } from "../../shared/components/StatusBadge";

type Props = {
  site: SiteAdminRow | null;
};

export function SiteEditPanel({ site }: Props) {
  const mutation = useUpdateSite();

  const [name, setName] = useState("");
  const [active, setActive] = useState(true);

  useEffect(() => {
    if (!site) return;
    setName(site.name || "");
    setActive(site.active !== false);
  }, [site]);

  if (!site) {
    return <p>Δεν βρέθηκε site</p>;
  }

  async function handleSave() {
  if (!site) return;

  await mutation.mutateAsync({
    siteId: site.id,
    values: {
      name,
      active,
    },
  });
}

  return (
    <div
      style={{
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 16,
        padding: 16,
        background: "rgba(255,255,255,0.02)",
      }}
    >
      <h3 style={{ marginTop: 0 }}>Site Edit</h3>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 18 }}>{site.name || site.id}</div>
        <div style={{ opacity: 0.75, marginTop: 4 }}>{site.id}</div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <StatusBadge
          label={active ? "Ενεργό" : "Ανενεργό"}
          tone={active ? "success" : "danger"}
        />
      </div>

      <div style={{ display: "grid", gap: 14, maxWidth: 520 }}>
        <label style={{ display: "block" }}>
          <div style={{ marginBottom: 6 }}>Site Name</div>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ width: "100%", padding: 10, borderRadius: 10 }}
          />
        </label>

        <label style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
          />
          <span>Active</span>
        </label>
      </div>

      <div style={{ marginTop: 20 }}>
        <button
          onClick={handleSave}
          disabled={mutation.isPending}
          style={{
            padding: "12px 18px",
            borderRadius: 12,
            border: "none",
            cursor: "pointer",
          }}
        >
          {mutation.isPending ? "Αποθήκευση..." : "Αποθήκευση"}
        </button>
      </div>

      {mutation.isSuccess ? (
        <div style={{ marginTop: 12, color: "limegreen" }}>Οι αλλαγές αποθηκεύτηκαν</div>
      ) : null}

      {mutation.isError ? (
        <div style={{ marginTop: 12, color: "crimson" }}>
          Σφάλμα αποθήκευσης: {String(mutation.error)}
        </div>
      ) : null}
    </div>
  );
}