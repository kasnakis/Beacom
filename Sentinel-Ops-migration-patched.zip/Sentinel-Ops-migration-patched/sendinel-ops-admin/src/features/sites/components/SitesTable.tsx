import { Link } from "react-router-dom";
import type { SiteAdminRow } from "../../../domain/models/site";
import { StatusBadge } from "../../shared/components/StatusBadge";

type Props = {
  items: SiteAdminRow[];
};

function activeTone(item: SiteAdminRow): "success" | "danger" {
  return item.active === false ? "danger" : "success";
}

function activeLabel(item: SiteAdminRow) {
  return item.active === false ? "Ανενεργό" : "Ενεργό";
}

export function SitesTable({ items }: Props) {
  if (!items.length) {
    return <p>Δεν βρέθηκαν sites</p>;
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: 12,
        }}
      >
        <thead>
          <tr>
            <th style={th}>Site ID</th>
            <th style={th}>Όνομα</th>
            <th style={th}>Κατάσταση</th>
            <th style={th}>Χρήστες</th>
            <th style={th}>Open Dispatches</th>
            <th style={th}>Pending External</th>
            <th style={th}>Detail</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td style={td}>{item.id}</td>
              <td style={td}>{item.name || "-"}</td>
              <td style={td}>
                <StatusBadge label={activeLabel(item)} tone={activeTone(item)} />
              </td>
              <td style={td}>{item.usersCount}</td>
              <td style={td}>{item.openDispatchesCount}</td>
              <td style={td}>{item.pendingExternalCount}</td>
              <td style={td}>
                <Link to={`/app/sites/${item.id}`}>Άνοιγμα</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "12px 10px",
  borderBottom: "1px solid rgba(255,255,255,0.12)",
  fontWeight: 600,
};

const td: React.CSSProperties = {
  padding: "10px",
  borderBottom: "1px solid rgba(255,255,255,0.08)",
  verticalAlign: "top",
};