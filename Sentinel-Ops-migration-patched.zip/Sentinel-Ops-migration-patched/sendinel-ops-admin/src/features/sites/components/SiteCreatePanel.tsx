import { useMemo, useState } from "react";
import type { CreateSitePayload, SiteAdminRow, SiteCloneOptions } from "../../../domain/models/site";
import type { UserProfile } from "../../../domain/models/user";
import { useCreateSite } from "../../../hooks/useCreateSite";

const DEFAULT_OPTIONS: SiteCloneOptions = {
  cloneIncidentPolicies: true,
  cloneExternalAuthorities: false,
  cloneSiteConfigDefaults: true,
  cloneAssetCatalogs: false,
  cloneLookupSettings: false,
};

type Props = {
  sites: SiteAdminRow[];
  currentProfile: UserProfile | null;
};

function resolveAdminLevel(profile: UserProfile | null): string {
  return profile?.adminPermissions?.level || (profile?.platformRoles?.ADMIN_PORTAL ? "GLOBAL_ADMIN" : "VIEW_ONLY");
}

function normalizeSiteId(input: string): string {
  return input.trim().toLowerCase().replace(/\s+/g, "_");
}

export function SiteCreatePanel({ sites, currentProfile }: Props) {
  const mutation = useCreateSite(currentProfile);
  const adminLevel = resolveAdminLevel(currentProfile);
  const canCreate = adminLevel === "GLOBAL_ADMIN";

  const [mode, setMode] = useState<"EMPTY" | "CLONE">("EMPTY");
  const [siteId, setSiteId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [active, setActive] = useState(true);
  const [sourceSiteId, setSourceSiteId] = useState("");
  const [cloneOptions, setCloneOptions] = useState<SiteCloneOptions>(DEFAULT_OPTIONS);

  const normalizedSiteId = useMemo(() => normalizeSiteId(siteId), [siteId]);

  function setOption(key: keyof SiteCloneOptions, value: boolean) {
    setCloneOptions((prev) => ({ ...prev, [key]: value }));
  }

  async function handleCreate() {
    const payload: CreateSitePayload = {
      siteId: normalizedSiteId,
      name,
      description,
      active,
      sourceSiteId: mode === "CLONE" ? sourceSiteId : undefined,
      cloneOptions: mode === "CLONE"
        ? cloneOptions
        : {
            cloneIncidentPolicies: false,
            cloneExternalAuthorities: false,
            cloneSiteConfigDefaults: false,
            cloneAssetCatalogs: false,
            cloneLookupSettings: false,
          },
    };

    await mutation.mutateAsync(payload);

    setSiteId("");
    setName("");
    setDescription("");
    setActive(true);
    setSourceSiteId("");
    setMode("EMPTY");
    setCloneOptions(DEFAULT_OPTIONS);
  }

  return (
    <div style={panelStyle}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start" }}>
        <div>
          <h2 style={{ marginTop: 0, marginBottom: 6 }}>Δημιουργία Site</h2>
          <div style={{ opacity: 0.72 }}>
            Μόνο GLOBAL_ADMIN. Δημιουργεί καθαρό site ή αντιγράφει επιλεγμένα configuration δεδομένα.
          </div>
        </div>
        <div style={{ fontSize: 12, opacity: 0.75 }}>Admin level: {adminLevel}</div>
      </div>

      {!canCreate ? (
        <div style={warningStyle}>Δεν έχεις δικαίωμα δημιουργίας site. Απαιτείται GLOBAL_ADMIN.</div>
      ) : null}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14, marginTop: 18 }}>
        <label style={labelStyle}>
          <span>Site ID *</span>
          <input
            value={siteId}
            onChange={(e) => setSiteId(e.target.value)}
            placeholder="π.χ. polyfytos"
            disabled={!canCreate || mutation.isPending}
            style={inputStyle}
          />
          <small style={{ opacity: 0.65 }}>Θα αποθηκευτεί ως: {normalizedSiteId || "-"}</small>
        </label>

        <label style={labelStyle}>
          <span>Όνομα site *</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="π.χ. ΥΗΣ Πολυφύτου"
            disabled={!canCreate || mutation.isPending}
            style={inputStyle}
          />
        </label>

        <label style={labelStyle}>
          <span>Περιγραφή / metadata</span>
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="σύντομη περιγραφή"
            disabled={!canCreate || mutation.isPending}
            style={inputStyle}
          />
        </label>

        <label style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 24 }}>
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
            disabled={!canCreate || mutation.isPending}
          />
          <span>Ενεργό site</span>
        </label>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 18 }}>
        <button type="button" onClick={() => setMode("EMPTY")} disabled={!canCreate || mutation.isPending} style={mode === "EMPTY" ? activeButtonStyle : buttonStyle}>
          Κενό site
        </button>
        <button type="button" onClick={() => setMode("CLONE")} disabled={!canCreate || mutation.isPending} style={mode === "CLONE" ? activeButtonStyle : buttonStyle}>
          Αντιγραφή ρυθμίσεων
        </button>
      </div>

      {mode === "CLONE" ? (
        <div style={{ ...panelStyle, marginTop: 16, background: "rgba(255,255,255,0.015)" }}>
          <label style={labelStyle}>
            <span>Source site *</span>
            <select
              value={sourceSiteId}
              onChange={(e) => setSourceSiteId(e.target.value)}
              disabled={!canCreate || mutation.isPending}
              style={inputStyle}
            >
              <option value="">Επίλεξε site</option>
              {sites.map((site) => (
                <option key={site.id} value={site.id}>
                  {site.name || site.id} ({site.id})
                </option>
              ))}
            </select>
          </label>

          <div style={{ display: "grid", gap: 10, marginTop: 14 }}>
            <CloneOption label="Incident policies / ροές πολιτικών" checked={cloneOptions.cloneIncidentPolicies} onChange={(v) => setOption("cloneIncidentPolicies", v)} />
            <CloneOption label="External authorities templates" checked={cloneOptions.cloneExternalAuthorities} onChange={(v) => setOption("cloneExternalAuthorities", v)} />
            <CloneOption label="Site configuration defaults" checked={cloneOptions.cloneSiteConfigDefaults} onChange={(v) => setOption("cloneSiteConfigDefaults", v)} />
            <CloneOption label="Asset catalogs" checked={cloneOptions.cloneAssetCatalogs} onChange={(v) => setOption("cloneAssetCatalogs", v)} />
            <CloneOption label="Lookup settings" checked={cloneOptions.cloneLookupSettings} onChange={(v) => setOption("cloneLookupSettings", v)} />
          </div>

          <div style={{ marginTop: 12, fontSize: 13, opacity: 0.72 }}>
            Δεν αντιγράφονται users, incidents, dispatch state, audit logs, notifications ή responder runtime δεδομένα.
          </div>
        </div>
      ) : null}

      <div style={{ marginTop: 18 }}>
        <button onClick={handleCreate} disabled={!canCreate || mutation.isPending} style={primaryButtonStyle}>
          {mutation.isPending ? "Δημιουργία..." : "Δημιουργία site"}
        </button>
      </div>

      {mutation.isSuccess ? <div style={successStyle}>Το site δημιουργήθηκε.</div> : null}
      {mutation.isError ? <div style={errorStyle}>Σφάλμα: {String(mutation.error)}</div> : null}
    </div>
  );
}

function CloneOption({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <label style={{ display: "flex", gap: 10, alignItems: "center" }}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  );
}

const panelStyle: React.CSSProperties = {
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 16,
  padding: 16,
  background: "rgba(255,255,255,0.02)",
};

const labelStyle: React.CSSProperties = {
  display: "grid",
  gap: 6,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: 10,
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.16)",
};

const buttonStyle: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.14)",
  background: "rgba(255,255,255,0.03)",
  color: "inherit",
  cursor: "pointer",
};

const activeButtonStyle: React.CSSProperties = {
  ...buttonStyle,
  border: "1px solid rgba(72,126,255,0.75)",
  background: "rgba(72,126,255,0.14)",
};

const primaryButtonStyle: React.CSSProperties = {
  padding: "12px 18px",
  borderRadius: 12,
  border: "none",
  cursor: "pointer",
};

const warningStyle: React.CSSProperties = {
  marginTop: 14,
  padding: 12,
  borderRadius: 12,
  border: "1px solid rgba(255,193,7,0.35)",
  background: "rgba(255,193,7,0.08)",
};

const successStyle: React.CSSProperties = {
  marginTop: 12,
  color: "limegreen",
};

const errorStyle: React.CSSProperties = {
  marginTop: 12,
  color: "crimson",
};
