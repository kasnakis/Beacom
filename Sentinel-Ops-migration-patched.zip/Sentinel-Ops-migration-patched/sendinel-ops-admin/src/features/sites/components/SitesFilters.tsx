type Props = {
  search: string;
  activeMode: string;
  onSearchChange: (value: string) => void;
  onActiveModeChange: (value: string) => void;
};

export function SitesFilters({
  search,
  activeMode,
  onSearchChange,
  onActiveModeChange,
}: Props) {
  return (
    <div className="filter-panel" style={{ marginTop: 12, marginBottom: 16 }}>
      <div
        className="filter-panel-grid"
        style={{ gridTemplateColumns: "minmax(0, 2fr) minmax(0, 1fr)" }}
      >
        <label>
          <div className="filter-panel-title">Αναζήτηση</div>
          <input
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Όνομα ή site id..."
          />
        </label>

        <label>
          <div className="filter-panel-title">Κατάσταση</div>
          <select
            value={activeMode}
            onChange={(e) => onActiveModeChange(e.target.value)}
          >
            <option value="ALL">Όλα</option>
            <option value="ACTIVE">Ενεργά</option>
            <option value="INACTIVE">Ανενεργά</option>
          </select>
        </label>
      </div>
    </div>
  );
}
