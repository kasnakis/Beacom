import type { ExternalAuthority } from "../../../domain/models/externalAuthority";

type Props = {
  items: ExternalAuthority[];
};

export function ExternalAuthoritiesTable({ items }: Props) {
  if (!items.length) {
    return <p>Δεν βρέθηκαν εξωτερικές αρχές</p>;
  }

  return (
    <div style={{ overflowX: "auto", marginTop: 12 }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th style={th}>ID</th>
            <th style={th}>Όνομα</th>
            <th style={th}>Τύπος</th>
            <th style={th}>Κανάλι</th>
            <th style={th}>Τηλέφωνο</th>
            <th style={th}>Email</th>
            <th style={th}>Ενεργό</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td style={td}>{item.id}</td>
              <td style={td}>{item.name || "-"}</td>
              <td style={td}>{item.type || "-"}</td>
              <td style={td}>{item.channel || "-"}</td>
              <td style={td}>{item.phone || "-"}</td>
              <td style={td}>{item.email || "-"}</td>
              <td style={td}>{item.active ? "Ναι" : "Όχι"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "12px 10px",
  borderBottom: "1px solid rgba(255,255,255,0.12)",
  fontWeight: 600,
};

const td: React.CSSProperties = {
  padding: "10px",
  borderBottom: "1px solid rgba(255,255,255,0.08)",
  verticalAlign: "top",
};