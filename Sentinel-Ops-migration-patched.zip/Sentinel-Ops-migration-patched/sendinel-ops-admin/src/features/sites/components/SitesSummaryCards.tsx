import { MetricCard } from "../../shared/components/MetricCard";

type Props = {
  totalSites: number;
  activeSites: number;
  totalUsers: number;
  openDispatches: number;
};

export function SitesSummaryCards({
  totalSites,
  activeSites,
  totalUsers,
  openDispatches,
}: Props) {
  return (
    <div
      style={{
        display: "grid",
        gap: 16,
        gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
        marginBottom: 24,
      }}
    >
      <MetricCard label="Σύνολο Sites" value={totalSites} />
      <MetricCard label="Ενεργά Sites" value={activeSites} />
      <MetricCard label="Χρήστες" value={totalUsers} />
      <MetricCard label="Open Dispatches" value={openDispatches} />
    </div>
  );
}