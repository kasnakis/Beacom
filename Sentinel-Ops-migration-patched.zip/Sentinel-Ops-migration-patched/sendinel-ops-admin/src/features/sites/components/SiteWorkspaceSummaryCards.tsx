import { MetricCard } from "../../shared/components/MetricCard";

type Props = {
  usersCount: number;
  activeUsersCount: number;
  openDispatchesCount: number;
  pendingExternalCount: number;
  authoritiesCount: number;
  policiesCount: number;
};

export function SiteWorkspaceSummaryCards({
  usersCount,
  activeUsersCount,
  openDispatchesCount,
  pendingExternalCount,
  authoritiesCount,
  policiesCount,
}: Props) {
  return (
    <div
      style={{
        display: "grid",
        gap: 16,
        gridTemplateColumns: "repeat(6, minmax(0, 1fr))",
        marginBottom: 24,
      }}
    >
      <MetricCard label="Χρήστες" value={usersCount} />
      <MetricCard label="Ενεργοί χρήστες" value={activeUsersCount} />
      <MetricCard label="Ανοικτά dispatch" value={openDispatchesCount} />
      <MetricCard label="Εκκρεμείς εξωτερικές" value={pendingExternalCount} />
      <MetricCard label="Εξωτερικές αρχές" value={authoritiesCount} />
      <MetricCard label="Πολιτικές" value={policiesCount} />
    </div>
  );
}
