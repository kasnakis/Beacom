import { MetricCard } from "../../shared/components/MetricCard";

type Props = {
  activeIncidentsCount: number;
  openDispatchesCount: number;
  respondingCount: number;
  pendingExternalCount: number;
};

export function LiveSummaryCards({
  activeIncidentsCount,
  openDispatchesCount,
  respondingCount,
  pendingExternalCount,
}: Props) {
  return (
    <div
      style={{
        display: "grid",
        gap: 16,
        gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
        marginBottom: 24,
      }}
    >
<MetricCard
  label="Ενεργά Συμβάντα"
  value={activeIncidentsCount}
/>

<MetricCard
  label="Ενεργές Κινητοποιήσεις"
  value={openDispatchesCount}
/>

<MetricCard
  label="Ανταποκρινόμενοι"
  value={respondingCount}
/>

<MetricCard
  label="Εκκρεμείς Εξωτερικές Ειδοποιήσεις"
  value={pendingExternalCount}
/>
    </div>
  );
}