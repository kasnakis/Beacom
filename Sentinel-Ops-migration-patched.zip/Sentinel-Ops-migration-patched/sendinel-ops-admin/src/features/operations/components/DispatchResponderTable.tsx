import type { DispatchResponder } from "../../../domain/models/dispatch";

type Props = {
  responders?: Record<string, DispatchResponder>;
};

export function DispatchResponderTable({ responders }: Props) {
  const rows = responders ? Object.values(responders) : [];

  if (!rows.length) {
    return <p>Δεν υπάρχουν responders</p>;
  }

  return (
    <div style={{ overflowX: "auto", marginTop: 12 }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th style={th}>User</th>
            <th style={th}>Role</th>
            <th style={th}>Team</th>
            <th style={th}>Status</th>
            <th style={th}>Distance</th>
            <th style={th}>Source</th>
            <th style={th}>Last Update</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.userId}>
              <td style={td}>{row.displayName || row.userId}</td>
              <td style={td}>{row.role || "-"}</td>
              <td style={td}>{row.team || "-"}</td>
              <td style={td}>{row.status || "-"}</td>
              <td style={td}>{row.distanceMeters ?? "-"}</td>
              <td style={td}>{row.source || "-"}</td>
              <td style={td}>
                {row.lastUpdatedAt ? new Date(row.lastUpdatedAt).toLocaleString("el-GR") : "-"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "12px 10px",
  borderBottom: "1px solid var(--border)",
  fontWeight: 600,
};

const td: React.CSSProperties = {
  padding: "10px",
  borderBottom: "1px solid var(--border)",
  verticalAlign: "top",
};