type Props = {
  siteId: string;
  incidentId: string;
  eventType: string;
  availableSites: string[];
  availableEventTypes: string[];
  onSiteChange: (value: string) => void;
  onIncidentChange: (value: string) => void;
  onEventTypeChange: (value: string) => void;
};

export function TimelineFilters({
  siteId,
  incidentId,
  eventType,
  availableSites,
  availableEventTypes,
  onSiteChange,
  onIncidentChange,
  onEventTypeChange,
}: Props) {
  return (
    <div className="filter-panel" style={{ marginTop: 12, marginBottom: 16 }}>
      <div className="filter-panel-grid" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
        <label>
          <div className="filter-panel-title">Site</div>
          <select value={siteId} onChange={(e) => onSiteChange(e.target.value)}>
            <option value="">Όλα</option>
            {availableSites.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Incident ID</div>
          <input
            value={incidentId}
            onChange={(e) => onIncidentChange(e.target.value)}
            placeholder="π.χ. -OqFOws4..."
          />
        </label>

        <label>
          <div className="filter-panel-title">Event Type</div>
          <select value={eventType} onChange={(e) => onEventTypeChange(e.target.value)}>
            <option value="">Όλα</option>
            {availableEventTypes.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}
