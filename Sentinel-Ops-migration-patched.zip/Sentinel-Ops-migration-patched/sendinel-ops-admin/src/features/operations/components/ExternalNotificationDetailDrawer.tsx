import { useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { ExternalNotificationRecord } from "../../../domain/models/externalNotification";
import { externalNotificationsRepository } from "../../../services/repositories/externalNotificationsRepository";
import { useAuth } from "../../../hooks/useAuth";

type Props = {
  item: ExternalNotificationRecord | null;
};

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function formatRoles(roles?: Record<string, boolean>) {
  if (!roles) return "-";
  const active = Object.entries(roles)
    .filter(([, v]) => v)
    .map(([k]) => k);

  return active.length ? active.join(", ") : "-";
}

function formatText(value?: string) {
  if (!value || !value.trim()) return "-";
  return value;
}

function canApprove(item: ExternalNotificationRecord | null) {
  if (!item) return false;
  if (item.approval?.required === false) return false;
  return item.status === "REQUESTED";
}

function canReject(item: ExternalNotificationRecord | null) {
  if (!item) return false;
  if (item.approval?.required === false) return false;
  return item.status === "REQUESTED" || item.status === "APPROVED";
}

function canMarkSent(item: ExternalNotificationRecord | null) {
  if (!item) return false;

  const approvalRequired = item.approval?.required === true;

  if (approvalRequired) {
    return item.status === "APPROVED";
  }

  return item.status === "REQUESTED" || item.status === "APPROVED";
}

function canAcknowledge(item: ExternalNotificationRecord | null) {
  if (!item) return false;
  return item.status === "SENT";
}

function approvalInfoText(item: ExternalNotificationRecord | null) {
  if (!item) return "";

  if (item.approval?.required === false) {
    if (item.approval?.status === "APPROVED") {
      return "Δεν απαιτείται έγκριση. Το record θεωρείται εγκεκριμένο από την πολιτική ή το backend flow.";
    }
    return "Δεν απαιτείται έγκριση από πολιτική.";
  }

  if (item.approval?.required === true) {
    return "Απαιτείται έγκριση πριν από την εκτέλεση.";
  }

  return "Δεν υπάρχει διαθέσιμη πληροφορία απαίτησης έγκρισης.";
}

function badgeStyle(status?: string): React.CSSProperties {
  switch (status) {
    case "REQUESTED":
      return {
        background: "rgba(245, 158, 11, 0.18)",
        border: "1px solid rgba(245, 158, 11, 0.35)",
        color: "#fbbf24",
      };
    case "APPROVED":
      return {
        background: "rgba(59, 130, 246, 0.18)",
        border: "1px solid rgba(59, 130, 246, 0.35)",
        color: "var(--accent-strong)",
      };
    case "SENT":
      return {
        background: "rgba(16, 185, 129, 0.18)",
        border: "1px solid rgba(16, 185, 129, 0.35)",
        color: "#a7f3d0",
      };
    case "ACKNOWLEDGED":
      return {
        background: "rgba(20, 184, 166, 0.18)",
        border: "1px solid rgba(20, 184, 166, 0.35)",
        color: "#99f6e4",
      };
    case "REJECTED":
    case "FAILED":
    case "CANCELLED":
      return {
        background: "rgba(239, 68, 68, 0.18)",
        border: "1px solid rgba(239, 68, 68, 0.35)",
        color: "#fecaca",
      };
    case "CLOSED":
      return {
        background: "rgba(99, 102, 241, 0.18)",
        border: "1px solid rgba(99, 102, 241, 0.35)",
        color: "#c7d2fe",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "#e5e7eb",
      };
  }
}

function kindStyle(kind?: string): React.CSSProperties {
  if (kind === "CANONICAL") {
    return {
      background: "rgba(16,185,129,0.16)",
      border: "1px solid rgba(16,185,129,0.30)",
      color: "#86efac",
    };
  }

  return {
    background: "rgba(245,158,11,0.16)",
    border: "1px solid rgba(245,158,11,0.30)",
    color: "#fcd34d",
  };
}

function Badge({ label, style }: { label: string; style?: React.CSSProperties }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "4px 10px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {label}
    </span>
  );
}

function InfoRow({
  label,
  value,
  mono = false,
}: {
  label: string;
  value: React.ReactNode;
  mono?: boolean;
}) {
  return (
    <div style={infoRow}>
      <div style={infoLabel}>{label}</div>
      <div
        style={{
          ...infoValue,
          ...(mono
            ? {
                fontFamily:
                  "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                fontSize: 12,
              }
            : null),
        }}
      >
        {value}
      </div>
    </div>
  );
}

export function ExternalNotificationDetailDrawer({ item }: Props) {
  const { firebaseUser, profile } = useAuth();
  const queryClient = useQueryClient();

  const [decisionNotes, setDecisionNotes] = useState("");
  const [executionNotes, setExecutionNotes] = useState("");
  const [ackNotes, setAckNotes] = useState("");
  const [actionError, setActionError] = useState("");

  const actor = useMemo(
    () => ({
      userId: firebaseUser?.uid || "admin-portal",
      name:
        profile?.displayName ||
        firebaseUser?.displayName ||
        firebaseUser?.email ||
        "Admin Portal",
      role: profile?.roles
        ? Object.keys(profile.roles).find((key) => profile.roles?.[key]) || "ADMIN_PORTAL"
        : "ADMIN_PORTAL",
      siteId: profile?.siteId || "",
    }),
    [firebaseUser, profile]
  );

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["externalNotificationsMonitor"] });
    await queryClient.invalidateQueries({ queryKey: ["externalNotifications"] });
  };

  const approveMutation = useMutation({
    mutationFn: async () => {
      if (!item) return;
      setActionError("");
      await externalNotificationsRepository.approve(item, actor);
    },
    onSuccess: refresh,
    onError: (error: any) => {
      setActionError(error?.message || "Σφάλμα έγκρισης");
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async () => {
      if (!item) return;
      setActionError("");
      await externalNotificationsRepository.reject(item, actor, decisionNotes);
    },
    onSuccess: async () => {
      setDecisionNotes("");
      await refresh();
    },
    onError: (error: any) => {
      setActionError(error?.message || "Σφάλμα απόρριψης");
    },
  });

  const sentMutation = useMutation({
    mutationFn: async () => {
      if (!item) return;
      setActionError("");
      await externalNotificationsRepository.markSent(item, actor, executionNotes);
    },
    onSuccess: async () => {
      setExecutionNotes("");
      await refresh();
    },
    onError: (error: any) => {
      setActionError(error?.message || "Σφάλμα ενημέρωσης αποστολής");
    },
  });

  const ackMutation = useMutation({
    mutationFn: async () => {
      if (!item) return;
      setActionError("");
      await externalNotificationsRepository.acknowledge(item, actor.name, ackNotes, actor);
    },
    onSuccess: async () => {
      setAckNotes("");
      await refresh();
    },
    onError: (error: any) => {
      setActionError(error?.message || "Σφάλμα acknowledgement");
    },
  });

  if (!item) {
    return (
      <div style={emptyState}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>Detail</div>
        <div style={{ fontSize: 13, opacity: 0.8 }}>
          Επίλεξε record από τον πίνακα για να δεις lifecycle, policy context και διαθέσιμες ενέργειες.
        </div>
      </div>
    );
  }

  const busy =
    approveMutation.isPending ||
    rejectMutation.isPending ||
    sentMutation.isPending ||
    ackMutation.isPending;

  const approvalRequired = item.approval?.required === true;
  const approvalNotRequired = item.approval?.required === false;
  const isCanonical = item.recordKind === "CANONICAL";
  const showAllowedRoles = !isCanonical;

  return (
    <div style={wrapper}>
      <div style={header}>
        <div>
          <h3 style={{ margin: 0 }}>External Notification Detail</h3>
          <div style={subtleText}>
            Αναλυτική προβολή operational record με lifecycle και admin actions.
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Badge label={item.recordKind || "-"} style={kindStyle(item.recordKind)} />
          <Badge label={item.status || "-"} style={badgeStyle(item.status)} />
        </div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Core</div>
        <InfoRow label="ID" value={item.id} mono />
        <InfoRow label="Path" value={item.dataPath || "-"} mono />
        <InfoRow label="Incident" value={item.incidentId || "-"} mono />
        <InfoRow label="Site" value={item.siteId || "-"} />
        <InfoRow label="Authority" value={item.authorityName || item.authorityType || "-"} />
        <InfoRow label="Authority type" value={item.authorityType || "-"} />
        <InfoRow label="Authority ID" value={item.authorityId || "-"} mono />
        <InfoRow label="Category" value={item.category || "-"} />
        <InfoRow label="Channel" value={item.channel || "-"} />
        <InfoRow label="Mode" value={item.mode || "-"} />
        <InfoRow label="Source" value={item.source || "-"} />
        <InfoRow label="Trigger" value={item.trigger || "-"} />
        <InfoRow label="Created" value={formatDate(item.createdAt)} />
        <InfoRow label="Updated" value={formatDate(item.updatedAt)} />
        <InfoRow label="Legacy request" value={item.legacyRequestId || "-"} mono />
      </div>

      <div style={section}>
        <div style={sectionTitle}>Playbook Context</div>
        <InfoRow label="Playbook ID" value={item.playbookId || "-"} mono />
        <InfoRow label="Playbook" value={item.playbookTitle || "-"} />
        <InfoRow label="Step ID" value={item.stepId || "-"} mono />
        <InfoRow label="Step" value={item.stepTitle || "-"} />
      </div>

      <div style={section}>
        <div style={sectionTitle}>Approval</div>
        <InfoRow label="Required" value={item.approval?.required ? "Ναι" : "Όχι"} />
        <InfoRow
          label="Status"
          value={
            <Badge
              label={item.approval?.status || "-"}
              style={badgeStyle(item.approval?.status)}
            />
          }
        />
        <InfoRow label="Approved by" value={item.approval?.approvedByName || "-"} />
        <InfoRow label="Approved role" value={item.approval?.approvedByRole || "-"} />
        <InfoRow label="Approved at" value={formatDate(item.approval?.approvedAt)} />
        <InfoRow label="Decision at" value={formatDate(item.approval?.decisionAt)} />
        <InfoRow label="Decision by" value={item.approval?.decisionByName || "-"} />
        <InfoRow label="Decision role" value={item.approval?.decisionByRole || "-"} />

        <div
          style={{
            marginTop: 10,
            padding: 10,
            borderRadius: 10,
            background: approvalNotRequired
              ? "rgba(16,185,129,0.10)"
              : "rgba(59,130,246,0.10)",
            border: approvalNotRequired
              ? "1px solid rgba(16,185,129,0.22)"
              : "1px solid rgba(59,130,246,0.22)",
            color: approvalNotRequired ? "#a7f3d0" : "var(--accent-strong)",
            fontSize: 13,
          }}
        >
          {approvalInfoText(item)}
        </div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Execution</div>
        <InfoRow
          label="Status"
          value={
            <Badge
              label={item.execution?.status || "-"}
              style={badgeStyle(item.execution?.status)}
            />
          }
        />
        <InfoRow label="Executed by" value={item.execution?.executedByName || "-"} />
        <InfoRow label="Executed at" value={formatDate(item.execution?.executedAt)} />
        <InfoRow label="Result notes" value={formatText(item.execution?.resultNotes)} />
      </div>

      <div style={section}>
        <div style={sectionTitle}>Acknowledgement</div>
        <InfoRow
          label="Status"
          value={
            <Badge
              label={item.acknowledgement?.status || "-"}
              style={badgeStyle(item.acknowledgement?.status)}
            />
          }
        />
        <InfoRow label="Received by" value={item.acknowledgement?.receivedBy || "-"} />
        <InfoRow label="Received at" value={formatDate(item.acknowledgement?.receivedAt)} />
        <InfoRow label="Notes" value={formatText(item.acknowledgement?.notes)} />
      </div>

      {(item.contacts?.primary || item.contacts?.secondary) && (
        <div style={section}>
          <div style={sectionTitle}>Contacts</div>

          {item.contacts?.primary ? (
            <div style={contactBlock}>
              <div style={contactTitle}>Primary</div>
              <InfoRow label="Phone" value={item.contacts.primary.phone || "-"} />
              <InfoRow label="Email" value={item.contacts.primary.email || "-"} />
              <InfoRow label="Address" value={item.contacts.primary.address || "-"} />
              <InfoRow label="Notes" value={formatText(item.contacts.primary.notes)} />
            </div>
          ) : null}

          {item.contacts?.secondary ? (
            <div style={contactBlock}>
              <div style={contactTitle}>Secondary</div>
              <InfoRow label="Phone" value={item.contacts.secondary.phone || "-"} />
              <InfoRow label="Email" value={item.contacts.secondary.email || "-"} />
              <InfoRow label="Address" value={item.contacts.secondary.address || "-"} />
              <InfoRow label="Notes" value={formatText(item.contacts.secondary.notes)} />
            </div>
          ) : null}
        </div>
      )}

      {showAllowedRoles ? (
        <div style={section}>
          <div style={sectionTitle}>Allowed Roles</div>
          <InfoRow label="Approvers" value={formatRoles(item.allowedApproverRoles)} />
          <InfoRow label="Executors" value={formatRoles(item.allowedExecutorRoles)} />
          <InfoRow label="Requesters" value={formatRoles(item.allowedRequesterRoles)} />
        </div>
      ) : (
        <div style={section}>
          <div style={sectionTitle}>Policy / Access Context</div>
          <div style={contextNotice}>
            Τα permissions και οι επιτρεπόμενες μεταβάσεις αυτού του record
            καθορίζονται από το canonical backend flow. Το admin εδώ λειτουργεί
            ως operational surface πάνω στο source-of-truth queue.
          </div>
        </div>
      )}

      <div style={section}>
        <div style={sectionTitle}>Notes / Summary</div>
        <div style={summaryBox}>{formatText(item.notes)}</div>
      </div>

      <div style={section}>
        <div style={sectionTitle}>Actions</div>

        {actionError ? (
          <div style={errorBox}>{actionError}</div>
        ) : null}

        <div style={actionsGrid}>
          <div style={actionBlock}>
            <div style={actionHeader}>Approval decision</div>

            {approvalNotRequired ? (
              <div style={noticeSuccess}>
                Δεν απαιτείται έγκριση για αυτό το record. Η έγκριση γίνεται αυτόματα από την πολιτική.
              </div>
            ) : (
              <>
                <textarea
                  value={decisionNotes}
                  onChange={(e) => setDecisionNotes(e.target.value)}
                  placeholder="Σημειώσεις έγκρισης / απόρριψης"
                  rows={3}
                  style={textareaStyle}
                  disabled={busy}
                />
                <div style={actionsRow}>
                  <button
                    type="button"
                    disabled={!canApprove(item) || busy}
                    onClick={() => approveMutation.mutate()}
                    style={primaryButton}
                  >
                    Έγκριση
                  </button>
                  <button
                    type="button"
                    disabled={!canReject(item) || busy}
                    onClick={() => rejectMutation.mutate()}
                    style={dangerButton}
                  >
                    Απόρριψη
                  </button>
                </div>
                {approvalRequired && item.status !== "REQUESTED" ? (
                  <div style={hintText}>
                    Η έγκριση είναι διαθέσιμη μόνο όταν το record είναι σε κατάσταση REQUESTED.
                  </div>
                ) : null}
              </>
            )}
          </div>

          <div style={actionBlock}>
            <div style={actionHeader}>Execution update</div>
            <textarea
              value={executionNotes}
              onChange={(e) => setExecutionNotes(e.target.value)}
              placeholder="Σημειώσεις αποστολής / εκτέλεσης"
              rows={3}
              style={textareaStyle}
              disabled={busy}
            />
            <div style={actionsRow}>
              <button
                type="button"
                disabled={!canMarkSent(item) || busy}
                onClick={() => sentMutation.mutate()}
                style={primaryButton}
              >
                Mark Sent
              </button>
            </div>
            {!canMarkSent(item) ? (
              <div style={hintText}>
                {approvalRequired
                  ? "Απαιτείται πρώτα έγκριση για να γίνει αποστολή."
                  : "Η αποστολή είναι διαθέσιμη μόνο όταν το record είναι σε REQUESTED ή APPROVED κατάσταση."}
              </div>
            ) : null}
          </div>

          <div style={actionBlock}>
            <div style={actionHeader}>Acknowledgement</div>
            <textarea
              value={ackNotes}
              onChange={(e) => setAckNotes(e.target.value)}
              placeholder="Σημειώσεις acknowledgement"
              rows={3}
              style={textareaStyle}
              disabled={busy}
            />
            <div style={actionsRow}>
              <button
                type="button"
                disabled={!canAcknowledge(item) || busy}
                onClick={() => ackMutation.mutate()}
                style={primaryButton}
              >
                Acknowledge
              </button>
            </div>
            {!canAcknowledge(item) ? (
              <div style={hintText}>
                Το acknowledgement είναι διαθέσιμο μόνο όταν το record είναι σε κατάσταση SENT.
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

const wrapper: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 16,
  padding: 16,
  background: "var(--surface)",
  display: "grid",
  gap: 14,
};

const header: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const subtleText: React.CSSProperties = {
  marginTop: 6,
  fontSize: 13,
  opacity: 0.78,
};

const section: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 12,
  padding: 12,
  background: "var(--surface)",
};

const sectionTitle: React.CSSProperties = {
  fontWeight: 800,
  marginBottom: 10,
  fontSize: 14,
};

const infoRow: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "150px 1fr",
  gap: 10,
  alignItems: "start",
  padding: "6px 0",
  borderBottom: "1px solid var(--border)",
};

const infoLabel: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
};

const infoValue: React.CSSProperties = {
  fontSize: 13,
  lineHeight: 1.45,
  wordBreak: "break-word",
};

const contextNotice: React.CSSProperties = {
  padding: 12,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 13,
  opacity: 0.9,
};

const summaryBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  fontSize: 13,
  lineHeight: 1.5,
};

const contactBlock: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 10,
  padding: 10,
  background: "var(--surface)",
  marginBottom: 10,
};

const contactTitle: React.CSSProperties = {
  fontWeight: 700,
  marginBottom: 8,
  fontSize: 13,
};

const errorBox: React.CSSProperties = {
  marginBottom: 12,
  padding: 10,
  borderRadius: 10,
  background: "rgba(239,68,68,0.14)",
  border: "1px solid rgba(239,68,68,0.28)",
  color: "#fecaca",
};

const actionsGrid: React.CSSProperties = {
  display: "grid",
  gap: 12,
};

const actionBlock: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 12,
  padding: 12,
  background: "var(--surface)",
};

const actionHeader: React.CSSProperties = {
  fontWeight: 700,
  marginBottom: 8,
};

const actionsRow: React.CSSProperties = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  marginTop: 8,
};

const textareaStyle: React.CSSProperties = {
  width: "100%",
  borderRadius: 10,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  color: "inherit",
  padding: 10,
  resize: "vertical",
};

const hintText: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.8,
};

const noticeSuccess: React.CSSProperties = {
  padding: 12,
  borderRadius: 10,
  background: "rgba(16,185,129,0.10)",
  border: "1px solid rgba(16,185,129,0.22)",
  color: "#a7f3d0",
  fontSize: 13,
};

const primaryButton: React.CSSProperties = {
  border: "1px solid rgba(59,130,246,0.35)",
  background: "rgba(59,130,246,0.18)",
  color: "var(--accent-strong)",
  borderRadius: 10,
  padding: "8px 12px",
  cursor: "pointer",
};

const dangerButton: React.CSSProperties = {
  border: "1px solid rgba(239,68,68,0.35)",
  background: "rgba(239,68,68,0.18)",
  color: "#fecaca",
  borderRadius: 10,
  padding: "8px 12px",
  cursor: "pointer",
};

const emptyState: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 16,
  padding: 16,
  background: "var(--surface)",
};