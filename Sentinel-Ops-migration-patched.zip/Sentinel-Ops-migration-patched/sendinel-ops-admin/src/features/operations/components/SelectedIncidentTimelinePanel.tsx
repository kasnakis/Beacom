import { useIncidentTimelineByIncident } from "../../../hooks/useIncidentTimelineByIncident";

type Props = {
  incidentId: string | null;
};

function formatDate(value?: number) {
  if (!value) return "-";

  try {
    return new Date(value).toLocaleString("el-GR");
  } catch {
    return "-";
  }
}

function eventTypeLabel(value?: string) {
  const labels: Record<string, string> = {
    INCIDENT_CREATED: "Δημιουργία συμβάντος",
    INCIDENT_UPDATED: "Ενημέρωση συμβάντος",
    INCIDENT_VERIFIED: "Επιβεβαίωση συμβάντος",
    INCIDENT_CLOSED: "Ολοκλήρωση συμβάντος",
    INCIDENT_DEACTIVATED: "Απενεργοποίηση συμβάντος",
    EMERGENCY_ACTIVATED: "Ενεργοποίηση έκτακτης ανάγκης",
    EMERGENCY_UNDER_CONTROL: "Το συμβάν τέθηκε υπό έλεγχο",
    RESPONDER_DECLARED: "Δήλωση ανταπόκρισης",
    RESPONDER_LOCATION_UPDATED: "Ενημέρωση θέσης ανταποκρινόμενου",
    RESPONDER_ARRIVED: "Άφιξη στο συμβάν",
    RESPONDER_COMPLETED: "Ολοκλήρωση ενέργειας ανταποκρινόμενου",
    PLAYBOOK_ACTIVATED: "Ενεργοποίηση επιχειρησιακής ροής",
    PLAYBOOK_STEP_STARTED: "Έναρξη βήματος ΣΑΕΚ",
    PLAYBOOK_STEP_COMPLETED: "Ολοκλήρωση βήματος ΣΑΕΚ",
    PLAYBOOK_STEP_CLOSED: "Κλείσιμο βήματος ΣΑΕΚ",
    EXTERNAL_NOTIFICATION_REQUESTED: "Αίτημα εξωτερικής ειδοποίησης",
    EXTERNAL_NOTIFICATION_APPROVED: "Έγκριση εξωτερικής ειδοποίησης",
    EXTERNAL_NOTIFICATION_SENT: "Εκτέλεση εξωτερικής ειδοποίησης",
    EXTERNAL_NOTIFICATION_ACK: "Επιβεβαίωση λήψης εξωτερικής ειδοποίησης",
    EXTERNAL_NOTIFICATION_REJECTED: "Απόρριψη εξωτερικής ειδοποίησης",
    EXTERNAL_NOTIFICATION_CANCELLED: "Ακύρωση εξωτερικής ειδοποίησης",
  };

  return labels[value || ""] || value || "-";
}

export function SelectedIncidentTimelinePanel({ incidentId }: Props) {
  const {
    data = [],
    isLoading,
    error,
  } = useIncidentTimelineByIncident(incidentId || "");

  if (!incidentId) {
    return (
      <p>
        Επιλέξτε συμβάν για προβολή επιχειρησιακού
        χρονολογίου.
      </p>
    );
  }

  if (isLoading) {
    return <p>Φόρτωση επιχειρησιακού χρονολογίου...</p>;
  }

  if (error) {
    return (
      <p>
        Σφάλμα φόρτωσης επιχειρησιακού χρονολογίου.
      </p>
    );
  }

  if (!data.length) {
    return (
      <p>
        Δεν υπάρχουν πρόσφατα επιχειρησιακά γεγονότα
        για αυτό το συμβάν.
      </p>
    );
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      {data.map((item) => (
        <div
          key={item.id}
          style={{
            border: "1px solid var(--border)",
            borderRadius: 12,
            padding: 12,
            background: "var(--surface)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
              alignItems: "flex-start",
            }}
          >
            <div>
              <strong>
                {eventTypeLabel(item.eventType)}
              </strong>

              <div
                style={{
                  marginTop: 3,
                  fontSize: 11,
                  opacity: 0.62,
                }}
              >
                {item.eventType || "-"}
              </div>
            </div>

            <span
              style={{
                opacity: 0.75,
                fontSize: 12,
                whiteSpace: "nowrap",
              }}
            >
              {formatDate(item.createdAt)}
            </span>
          </div>

          <div
            style={{
              marginTop: 8,
              fontSize: 14,
              opacity: 0.85,
              lineHeight: 1.45,
            }}
          >
            Χρήστης: {item.userName || item.userId || "-"}
            {" "}
            | Πηγή: {item.source || "-"}
          </div>
        </div>
      ))}
    </div>
  );
}