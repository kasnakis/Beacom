import { Fragment, useMemo, useState } from "react";
import type { ExternalNotificationRecord } from "../../../domain/models/externalNotification";
import {
  getBadgeStyle,
  getModeBadgeSpec,
  getRecordKindBadgeSpec,
  getStatusBadgeSpec,
} from "../utils/statusBadge";

type Props = {
  items: ExternalNotificationRecord[];
  selectedId?: string | null;
  onSelect: (id: string) => void;
  grouped?: boolean;
};

type NotificationGroup = {
  key: string;
  incidentId: string;
  authorityLabel: string;
  siteId: string;
  category: string;
  trigger: string;
  primary: ExternalNotificationRecord;
  canonicalItems: ExternalNotificationRecord[];
  legacyItems: ExternalNotificationRecord[];
  allItems: ExternalNotificationRecord[];
};

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function Chip({
  label,
  style,
}: {
  label: string;
  style?: React.CSSProperties;
}) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 11,
        fontWeight: 700,
        whiteSpace: "nowrap",
        lineHeight: 1.1,
        ...style,
      }}
    >
      {label}
    </span>
  );
}

function safeTime(item: ExternalNotificationRecord) {
  return item.updatedAt ?? item.createdAt ?? 0;
}

function buildGroups(items: ExternalNotificationRecord[]): NotificationGroup[] {
  const map = new Map<string, ExternalNotificationRecord[]>();

  for (const item of items) {
    const authorityKey =
      item.authorityId || item.authorityType || item.authorityName || "-";
    const key = `${item.incidentId || "-"}__${authorityKey}`;

    if (!map.has(key)) {
      map.set(key, []);
    }

    map.get(key)!.push(item);
  }

  const groups: NotificationGroup[] = [];

  for (const [key, groupItems] of map.entries()) {
    const sorted = [...groupItems].sort((a, b) => {
      const aCanonical = a.recordKind === "CANONICAL" ? 1 : 0;
      const bCanonical = b.recordKind === "CANONICAL" ? 1 : 0;

      if (aCanonical !== bCanonical) {
        return bCanonical - aCanonical;
      }

      return safeTime(b) - safeTime(a);
    });

    const canonicalItems = sorted.filter((x) => x.recordKind === "CANONICAL");
    const legacyItems = sorted.filter((x) => x.recordKind === "LEGACY");
    const primary = canonicalItems[0] || sorted[0];

    groups.push({
      key,
      incidentId: primary.incidentId || "-",
      authorityLabel: primary.authorityName || primary.authorityType || "-",
      siteId: primary.siteId || "-",
      category: primary.category || "-",
      trigger: primary.trigger || "-",
      primary,
      canonicalItems,
      legacyItems,
      allItems: sorted,
    });
  }

  groups.sort((a, b) => safeTime(b.primary) - safeTime(a.primary));

  return groups;
}

function renderModeSource(item: ExternalNotificationRecord) {
  const modeSpec = getModeBadgeSpec(item.mode);

  return (
    <div style={stackCell}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <Chip label={modeSpec.label} style={getBadgeStyle(modeSpec.tone)} />
        {item.source ? <div style={subtleMeta}>{item.source}</div> : null}
      </div>
      {item.playbookTitle || item.stepTitle ? (
        <div style={subtleMeta}>
          {item.playbookTitle || item.playbookId || "-"}
          {item.stepTitle ? ` · ${item.stepTitle}` : ""}
        </div>
      ) : null}
    </div>
  );
}

function renderLifecycle(
  item: ExternalNotificationRecord,
  type: "approval" | "execution" | "ack"
) {
  if (type === "approval") {
    const spec = getStatusBadgeSpec(item.approval?.status);

    return (
      <div style={stackCell}>
        <Chip label={spec.label} style={getBadgeStyle(spec.tone)} />
        <div style={subtleMeta}>
          {formatDate(item.approval?.approvedAt || item.approval?.decisionAt)}
        </div>
      </div>
    );
  }

  if (type === "execution") {
    const spec = getStatusBadgeSpec(item.execution?.status);

    return (
      <div style={stackCell}>
        <Chip label={spec.label} style={getBadgeStyle(spec.tone)} />
        <div style={subtleMeta}>{formatDate(item.execution?.executedAt)}</div>
      </div>
    );
  }

  const spec = getStatusBadgeSpec(item.acknowledgement?.status);

  return (
    <div style={stackCell}>
      <Chip label={spec.label} style={getBadgeStyle(spec.tone)} />
      <div style={subtleMeta}>
        {formatDate(
          item.acknowledgement?.receivedAt || item.acknowledgement?.acknowledgedAt
        )}
      </div>
    </div>
  );
}

export function ExternalNotificationsTable({
  items,
  selectedId,
  onSelect,
  grouped = true,
}: Props) {
  const groups = useMemo(() => buildGroups(items), [items]);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  if (!items.length) {
    return <p>Δεν υπάρχουν external notification records</p>;
  }

  const toggleGroup = (key: string) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  if (!grouped) {
    return (
      <div style={{ overflowX: "auto" }}>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={th}>Kind</th>
              <th style={th}>Incident</th>
              <th style={th}>Site</th>
              <th style={th}>Authority</th>
              <th style={th}>Mode / Source</th>
              <th style={th}>Trigger</th>
              <th style={th}>Category</th>
              <th style={th}>Status</th>
              <th style={th}>Approval</th>
              <th style={th}>Execution</th>
              <th style={th}>Ack</th>
              <th style={th}>Updated</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const isSelected = selectedId === item.id;
              const kindSpec = getRecordKindBadgeSpec(item.recordKind);
              const statusSpec = getStatusBadgeSpec(item.status);

              return (
                <tr
                  key={item.id}
                  onClick={() => onSelect(item.id)}
                  style={{
                    cursor: "pointer",
                    background: isSelected
                      ? "var(--accent-soft)"
                      : item.recordKind === "LEGACY"
                        ? "var(--surface)"
                        : "transparent",
                    opacity: item.recordKind === "LEGACY" ? 0.8 : 1,
                  }}
                >
                  <td style={td}>
                    <Chip
                      label={kindSpec.label}
                      style={getBadgeStyle(kindSpec.tone)}
                    />
                  </td>
                  <td style={tdMono}>{item.incidentId || "-"}</td>
                  <td style={td}>{item.siteId || "-"}</td>
                  <td style={tdStrong}>{item.authorityName || item.authorityType || "-"}</td>
                  <td style={td}>{renderModeSource(item)}</td>
                  <td style={td}>{item.trigger || "-"}</td>
                  <td style={td}>{item.category || "-"}</td>
                  <td style={td}>
                    <Chip
                      label={statusSpec.label}
                      style={getBadgeStyle(statusSpec.tone)}
                    />
                  </td>
                  <td style={td}>{renderLifecycle(item, "approval")}</td>
                  <td style={td}>{renderLifecycle(item, "execution")}</td>
                  <td style={td}>{renderLifecycle(item, "ack")}</td>
                  <td style={td}>{formatDate(safeTime(item))}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={th}>Group</th>
            <th style={th}>Incident</th>
            <th style={th}>Site</th>
            <th style={th}>Authority</th>
            <th style={th}>Mode / Source</th>
            <th style={th}>Trigger</th>
            <th style={th}>Category</th>
            <th style={th}>Status</th>
            <th style={th}>Approval</th>
            <th style={th}>Execution</th>
            <th style={th}>Ack</th>
            <th style={th}>Updated</th>
          </tr>
        </thead>
        <tbody>
          {groups.map((group) => {
            const expanded = !!expandedGroups[group.key];
            const primary = group.primary;
            const isSelected = selectedId === primary.id;
            const kindSpec = getRecordKindBadgeSpec(primary.recordKind);
            const statusSpec = getStatusBadgeSpec(primary.status);

            return (
              <Fragment key={group.key}>
                <tr
                  onClick={() => onSelect(primary.id)}
                  style={{
                    cursor: "pointer",
                    background: isSelected ? "var(--accent-soft)" : "transparent",
                  }}
                >
                  <td style={td}>
                    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleGroup(group.key);
                          }}
                          style={toggleButton}
                        >
                          {expanded ? "−" : "+"}
                        </button>

                        <Chip
                          label={kindSpec.label}
                          style={getBadgeStyle(kindSpec.tone)}
                        />
                      </div>

                      <div style={subtleMeta}>
                        canonical: {group.canonicalItems.length} · legacy: {group.legacyItems.length}
                      </div>
                    </div>
                  </td>

                  <td style={tdMono}>{group.incidentId}</td>
                  <td style={td}>{group.siteId}</td>
                  <td style={tdStrong}>{group.authorityLabel}</td>
                  <td style={td}>{renderModeSource(primary)}</td>
                  <td style={td}>{group.trigger}</td>
                  <td style={td}>{group.category}</td>
                  <td style={td}>
                    <Chip
                      label={statusSpec.label}
                      style={getBadgeStyle(statusSpec.tone)}
                    />
                  </td>
                  <td style={td}>{renderLifecycle(primary, "approval")}</td>
                  <td style={td}>{renderLifecycle(primary, "execution")}</td>
                  <td style={td}>{renderLifecycle(primary, "ack")}</td>
                  <td style={td}>{formatDate(safeTime(primary))}</td>
                </tr>

                {expanded &&
                  group.allItems.map((item) => {
                    const isSubSelected = selectedId === item.id;
                    const itemKindSpec = getRecordKindBadgeSpec(item.recordKind);
                    const itemStatusSpec = getStatusBadgeSpec(item.status);

                    return (
                      <tr
                        key={item.id}
                        onClick={() => onSelect(item.id)}
                        style={{
                          cursor: "pointer",
                          background: isSubSelected
                            ? "var(--accent-soft)"
                            : "var(--surface)",
                          opacity: item.recordKind === "LEGACY" ? 0.8 : 1,
                        }}
                      >
                        <td style={tdIndented}>
                          <Chip
                            label={itemKindSpec.label}
                            style={getBadgeStyle(itemKindSpec.tone)}
                          />
                        </td>
                        <td style={tdMono}>{item.incidentId || "-"}</td>
                        <td style={td}>{item.siteId || "-"}</td>
                        <td style={tdStrong}>{item.authorityName || item.authorityType || "-"}</td>
                        <td style={td}>{renderModeSource(item)}</td>
                        <td style={td}>{item.trigger || "-"}</td>
                        <td style={td}>{item.category || "-"}</td>
                        <td style={td}>
                          <Chip
                            label={itemStatusSpec.label}
                            style={getBadgeStyle(itemStatusSpec.tone)}
                          />
                        </td>
                        <td style={td}>{renderLifecycle(item, "approval")}</td>
                        <td style={td}>{renderLifecycle(item, "execution")}</td>
                        <td style={td}>{renderLifecycle(item, "ack")}</td>
                        <td style={td}>{formatDate(safeTime(item))}</td>
                      </tr>
                    );
                  })}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const tableStyle: React.CSSProperties = {
  width: "100%",
  borderCollapse: "collapse",
  marginTop: 12,
  minWidth: 1180,
};

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "12px 10px",
  borderBottom: "1px solid var(--border)",
  color: "var(--text-strong)",
  fontWeight: 600,
  whiteSpace: "nowrap",
  fontSize: 13,
};

const td: React.CSSProperties = {
  padding: "10px",
  borderBottom: "1px solid var(--border)",
  verticalAlign: "top",
};

const tdIndented: React.CSSProperties = {
  ...td,
  paddingLeft: 28,
};

const tdMono: React.CSSProperties = {
  ...td,
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
  fontSize: 12,
};

const tdStrong: React.CSSProperties = {
  ...td,
  fontWeight: 600,
  color: "var(--text-strong)",
};

const stackCell: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: 6,
};

const subtleMeta: React.CSSProperties = {
  fontSize: 12,
  color: "var(--muted)",
};

const toggleButton: React.CSSProperties = {
  width: 24,
  height: 24,
  borderRadius: 6,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "var(--text)",
  cursor: "pointer",
};