import type { DispatchState } from "../../../domain/models/dispatch";

type Props = {
  items: DispatchState[];
  selectedId?: string | null;
  onSelect?: (incidentId: string) => void;
};

function formatStatus(status?: string) {
  if (!status) return "-";
  return status;
}

function formatTeams(teams?: Record<string, boolean>) {
  if (!teams) return "-";

  const activeTeams = Object.entries(teams)
    .filter(([, value]) => value)
    .map(([key]) => key);

  return activeTeams.length ? activeTeams.join(", ") : "-";
}

export function DispatchTable({ items, selectedId, onSelect }: Props) {
  if (!items.length) {
    return <p>Δεν υπάρχουν dispatch records</p>;
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: 12,
        }}
      >
        <thead>
          <tr>
            <th style={th}>Incident</th>
            <th style={th}>Site</th>
            <th style={th}>Category</th>
            <th style={th}>Status</th>
            <th style={th}>Requested</th>
            <th style={th}>Responding</th>
            <th style={th}>Arrived</th>
            <th style={th}>Closest</th>
            <th style={th}>Teams</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const isSelected = selectedId === item.incidentId;

            return (
              <tr
                key={item.incidentId}
                onClick={() => onSelect?.(item.incidentId)}
                style={{
                  cursor: onSelect ? "pointer" : "default",
                  background: isSelected ? "rgba(72,126,255,0.12)" : "transparent",
                }}
              >
                <td style={td}>{item.incidentId}</td>
                <td style={td}>{item.siteId || "-"}</td>
                <td style={td}>{item.category || "-"}</td>
                <td style={td}>{formatStatus(item.status)}</td>
                <td style={td}>{item.requestedResponders || 0}</td>
                <td style={td}>{item.respondingResponders || 0}</td>
                <td style={td}>{item.arrivedResponders || 0}</td>
                <td style={td}>
                  {item.closestResponderId
                    ? `${item.closestResponderId} (${item.closestDistanceMeters ?? "-"}m)`
                    : "-"}
                </td>
                <td style={td}>{formatTeams(item.requestedTeams)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "12px 10px",
  borderBottom: "1px solid var(--border)",
  fontWeight: 600,
};

const td: React.CSSProperties = {
  padding: "10px",
  borderBottom: "1px solid var(--border)",
  verticalAlign: "top",
};