import { useEffect, useMemo, useState } from "react";
import { getDownloadURL, ref as storageRef } from "firebase/storage";
import { httpsCallable } from "firebase/functions";
import type { IncidentRecord } from "../../../domain/models/incident";
import type { DispatchResponder, DispatchState } from "../../../domain/models/dispatch";
import type { ExternalNotificationRecord } from "../../../domain/models/externalNotification";
import { functions } from "../../../services/firebase/firebaseFunctions";
import { storage } from "../../../services/firebase/firebaseStorage";
import { useAuth } from "../../../hooks/useAuth";

type SelectedIncidentOverviewMode = "full" | "summary" | "closure" | "dispatch" | "external";

type Props = {
  incident: IncidentRecord | null;
  dispatch?: DispatchState | null;
  externalNotifications?: ExternalNotificationRecord[];
  mode?: SelectedIncidentOverviewMode;
};

type ExternalAuthorityGroup = {
  key: string;
  authorityLabel: string;
  authorityType?: string;
  authorityId?: string;
  channel?: string;
  mode?: string;
  latestStatus?: string;
  latestUpdatedAt?: number;
  latestApprovedAt?: number;
  latestExecutedAt?: number;
  latestAcknowledgedAt?: number;
  latestNotes?: string;
  canonicalItems: ExternalNotificationRecord[];
  legacyItems: ExternalNotificationRecord[];
  allItems: ExternalNotificationRecord[];
};

type LifecyclePresentation = {
  title: string;
  text: string;
  tone: "info" | "warning" | "success" | "danger" | "neutral";
};

type ClosureFailureReason = {
  code?: string;
  message?: string;
  count?: number;
};

type ClosureAttemptResult = {
  tone: "success" | "danger" | "warning" | "info";
  title: string;
  message: string;
  reasons?: ClosureFailureReason[];
};


function formatDate(value?: number | null) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function pickString(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return undefined;
}

function pickNumber(...values: unknown[]): number | undefined {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
  }
  return undefined;
}

function getNestedRecord(value: unknown): Record<string, unknown> | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  return value as Record<string, unknown>;
}

function getFirstRecordFromCollection(value: unknown): Record<string, unknown> | undefined {
  if (!value || typeof value !== "object") return undefined;

  if (Array.isArray(value)) {
    return value.map(getNestedRecord).find(Boolean);
  }

  const record = value as Record<string, unknown>;
  return Object.values(record).map(getNestedRecord).find(Boolean);
}

function isUsableImageUrl(value?: string) {
  if (!value) return false;
  const lower = value.toLowerCase();
  return lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("data:image/");
}

function normalizeStoragePath(value?: string) {
  if (!value) return undefined;
  const trimmed = value.trim();
  if (!trimmed) return undefined;

  if (trimmed.startsWith("gs://")) {
    const withoutProtocol = trimmed.slice(5);
    const slashIndex = withoutProtocol.indexOf("/");
    return slashIndex >= 0 ? withoutProtocol.slice(slashIndex + 1) : undefined;
  }

  if (trimmed.startsWith("/")) return trimmed.slice(1);
  return trimmed;
}

function extractIncidentPhoto(incident: IncidentRecord) {
  const raw = getIncidentObject(incident);
  const media = getNestedRecord(raw.media);
  const photo = getNestedRecord(raw.photo);
  const image = getNestedRecord(raw.image);
  const firstPhoto = getFirstRecordFromCollection(raw.photos);
  const firstMedia = getFirstRecordFromCollection(raw.mediaItems);
  const firstAttachment = getFirstRecordFromCollection(raw.attachments);

  const url = pickString(
    raw.photoUrl,
    raw.imageUrl,
    raw.mediaUrl,
    raw.attachmentUrl,
    raw.photoDownloadUrl,
    raw.imageDownloadUrl,
    raw.downloadUrl,
    media?.photoUrl,
    media?.imageUrl,
    media?.url,
    media?.downloadUrl,
    photo?.url,
    photo?.downloadUrl,
    image?.url,
    image?.downloadUrl,
    firstPhoto?.url,
    firstPhoto?.downloadUrl,
    firstPhoto?.photoUrl,
    firstMedia?.url,
    firstMedia?.downloadUrl,
    firstAttachment?.url,
    firstAttachment?.downloadUrl
  );

  const path = normalizeStoragePath(pickString(
    raw.photoPath,
    raw.imagePath,
    raw.mediaPath,
    raw.attachmentPath,
    raw.storagePath,
    media?.photoPath,
    media?.imagePath,
    media?.path,
    media?.storagePath,
    photo?.path,
    photo?.storagePath,
    image?.path,
    image?.storagePath,
    firstPhoto?.path,
    firstPhoto?.storagePath,
    firstMedia?.path,
    firstMedia?.storagePath,
    firstAttachment?.path,
    firstAttachment?.storagePath
  ));

  const capturedAt = pickNumber(
    raw.photoCapturedAt,
    raw.imageCapturedAt,
    raw.mediaCapturedAt,
    raw.photoUploadedAt,
    raw.imageUploadedAt,
    raw.mediaUploadedAt,
    media?.capturedAt,
    media?.uploadedAt,
    photo?.capturedAt,
    photo?.uploadedAt,
    image?.capturedAt,
    image?.uploadedAt,
    firstPhoto?.capturedAt,
    firstPhoto?.uploadedAt,
    firstMedia?.capturedAt,
    firstMedia?.uploadedAt,
    firstAttachment?.createdAt,
    firstAttachment?.uploadedAt
  );

  const caption = pickString(
    raw.photoCaption,
    raw.imageCaption,
    raw.mediaCaption,
    raw.photoDescription,
    raw.imageDescription,
    media?.caption,
    media?.description,
    photo?.caption,
    photo?.description,
    image?.caption,
    image?.description,
    firstPhoto?.caption,
    firstPhoto?.description,
    firstMedia?.caption,
    firstMedia?.description,
    firstAttachment?.caption,
    firstAttachment?.description
  );

  return { url, path, capturedAt, caption };
}

function normalizeKey(value?: string) {
  return (value || "").trim().toUpperCase();
}

function formatMeters(value?: number | null) {
  if (typeof value !== "number" || !Number.isFinite(value)) return "-";
  if (Math.abs(value) >= 1000) return `${(value / 1000).toFixed(1)} km`;
  return `${Math.round(value)} m`;
}

function formatLabel(value?: string | null) {
  const key = normalizeKey(value || undefined);

  const dictionary: Record<string, string> = {
    EMERGENCY_ACTIVATION: "Ενεργοποίηση έκτακτης ανάγκης",
    HSE_ACCIDENT: "Ατύχημα Υγείας & Ασφάλειας",
    ENVIRONMENTAL_INCIDENT: "Περιβαλλοντικό συμβάν",
    NEAR_MISS: "Παρ’ ολίγον συμβάν",
    UNSAFE_ACTION: "Μη ασφαλής ενέργεια",
    UNSAFE_CONDITION: "Μη ασφαλής κατάσταση",
    FIRE: "Πυρκαγιά",
    MEDICAL: "Ιατρικό συμβάν",
    EVACUATION: "Εκκένωση",

    LOW: "Χαμηλή",
    MEDIUM: "Μέτρια",
    HIGH: "Υψηλή",
    CRITICAL: "Κρίσιμη",

    CREATED: "Δημιουργήθηκε",
    NEW: "Νέο",
    OPEN: "Ανοικτό",
    CONFIRMED: "Επιβεβαιωμένο",
    VERIFIED: "Επιβεβαιωμένο",
    AUTO_VERIFIED: "Αυτόματα επιβεβαιωμένο",
    REJECTED: "Απορρίφθηκε",
    ACTIVE: "Ενεργό",
    ACTIVE_RESPONSE: "Ενεργή αντιμετώπιση",
    UNDER_CONTROL: "Υπό έλεγχο",
    RECOVERY: "Αποκατάσταση",
    CLOSED: "Ολοκληρωμένο",
    DEACTIVATED: "Απενεργοποιημένο",
    CANCELLED: "Ακυρώθηκε",
    PENDING: "Εκκρεμεί",
    REQUESTED: "Ζητήθηκε",
    RESPONDING: "Ανταποκρίνεται",
    ARRIVED: "Έφτασε",
    COMPLETED: "Ολοκληρώθηκε",
    IN_PROGRESS: "Σε εξέλιξη",
    SENT: "Στάλθηκε",
    ACKNOWLEDGED: "Επιβεβαιώθηκε λήψη",
    APPROVED: "Εγκρίθηκε",
    FAILED: "Απέτυχε",
    NOT_REQUIRED: "Δεν απαιτείται",
    NONE: "Καμία ενέργεια",

    GENERAL_USERS: "Γενικοί χρήστες",
    MANAGEMENT: "Διοίκηση",
    HSE_TEAM: "Ομάδα ΥΑΕ",
    EMERGENCY_TEAM: "Ομάδα έκτακτης ανάγκης",
    FIRST_AID_TEAM: "Ομάδα Α’ Βοηθειών",
    FIRE_TEAM: "Ομάδα Πυρασφάλειας",
    EVACUATION_TEAM: "Ομάδα Εκκένωσης",
    SECURITY_TEAM: "Ομάδα Ασφάλειας",
    CONTROL_ROOM_TEAM: "Ομάδα Control Room",
    ENVIRONMENT_TEAM: "Περιβαλλοντική ομάδα",
    ENVIRONMENTAL_TEAM: "Περιβαλλοντική ομάδα",
    RESPONSE_TEAM: "Ομάδα ανταπόκρισης",

    WORKER: "Εργαζόμενος",
    SUPERVISOR: "Supervisor / Επιβλέπων",
    SITE_MANAGER: "Υπεύθυνος μονάδας",
    HSE_MANAGER: "Υπεύθυνος ΥΑΕ",
    EMERGENCY_COMMANDER: "Συντονιστής έκτακτης ανάγκης",
    FIRE_SAFETY_COORDINATOR: "Συντονιστής πυρασφάλειας",
    FIRE_TEAM_MEMBER: "Μέλος ομάδας πυρασφάλειας",
    FIRST_AID_COORDINATOR: "Συντονιστής Α’ Βοηθειών",
    FIRST_AID_RESPONDER: "Ανταποκριτής Α’ Βοηθειών",
    EVACUATION_WARDEN: "Υπεύθυνος εκκένωσης",
    COMMUNICATIONS_OFFICER: "Υπεύθυνος επικοινωνιών",
    SECURITY_OFFICER: "Υπεύθυνος ασφάλειας",
    ENVIRONMENTAL_OFFICER: "Περιβαλλοντικός υπεύθυνος",
    ENVIRONMENT_RESPONDER: "Περιβαλλοντικός ανταποκριτής",
    PERSONNEL_COORDINATOR: "Συντονιστής προσωπικού",
    CONTROL_ROOM: "Control Room",
    DIRECTOR: "Διευθυντής",
    VIEWER: "Χρήστης προβολής",
    TECHNICIAN: "Τεχνικός",

    CIVIL_PROTECTION: "Πολιτική Προστασία / 112",
    EMS: "ΕΚΑΒ",
    FIRE_BRIGADE: "Πυροσβεστική Υπηρεσία",
    FIRE_SERVICE: "Πυροσβεστική Υπηρεσία",
    POLICE: "Αστυνομία",
    ENVIRONMENTAL_AUTHORITY: "Περιβαλλοντική αρχή",

    PHONE: "Τηλέφωνο",
    EMAIL: "Email",
    SMS: "SMS",
    RADIO: "Ασύρματος",
    AUTO: "Αυτόματα",
    MANUAL: "Χειροκίνητα",
    PLAYBOOK_DRIVEN: "Μέσω playbook",
    CANONICAL: "Canonical εγγραφή",
    LEGACY: "Legacy εγγραφή",
    READY: "Έτοιμο",
    WARNING: "Προσοχή",
    BLOCKER: "Blocker",
    INFO: "Πληροφορία",
  };

  return dictionary[key] || value || "-";
}

function getDispatchObject(dispatch?: DispatchState | null): Record<string, unknown> {
  if (!dispatch) return {};
  return dispatch as unknown as Record<string, unknown>;
}

function getDispatchLastUpdate(dispatch?: DispatchState | null): number | undefined {
  const raw = getDispatchObject(dispatch);

  return pickNumber(
    raw.lastDispatchUpdate,
    raw.updatedAt,
    raw.lastUpdatedAt,
    raw.timestamp
  );
}

function getIncidentObject(incident: IncidentRecord): Record<string, unknown> {
  return incident as unknown as Record<string, unknown>;
}

function safeTime(item: ExternalNotificationRecord) {
  return (
    item.updatedAt ??
    item.acknowledgedAt ??
    item.executedAt ??
    item.approvedAt ??
    item.createdAt ??
    0
  );
}

function chip(label: string, value?: string, helper?: string) {
  return (
    <div style={chipCard}>
      <div style={chipLabel}>{label}</div>
      <div style={chipValue}>{value || "-"}</div>
      {helper ? <div style={chipHelper}>{helper}</div> : null}
    </div>
  );
}

function toneStyle(tone: LifecyclePresentation["tone"]): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "rgba(16,185,129,0.13)",
        border: "1px solid rgba(16,185,129,0.32)",
        color: "#bbf7d0",
      };
    case "warning":
      return {
        background: "rgba(245,158,11,0.13)",
        border: "1px solid rgba(245,158,11,0.32)",
        color: "#fde68a",
      };
    case "danger":
      return {
        background: "rgba(239,68,68,0.13)",
        border: "1px solid rgba(239,68,68,0.32)",
        color: "#fecaca",
      };
    case "info":
      return {
        background: "rgba(59,130,246,0.13)",
        border: "1px solid rgba(59,130,246,0.32)",
        color: "var(--accent-strong)",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "#e5e7eb",
      };
  }
}

function statusBadgeStyle(status?: string): React.CSSProperties {
  switch (normalizeKey(status)) {
    case "REQUESTED":
    case "PENDING":
    case "IN_PROGRESS":
      return toneStyle("warning");
    case "APPROVED":
    case "SENT":
    case "ACKNOWLEDGED":
    case "ARRIVED":
    case "COMPLETED":
      return toneStyle("success");
    case "REJECTED":
    case "FAILED":
    case "CANCELLED":
      return toneStyle("danger");
    case "CLOSED":
      return toneStyle("info");
    default:
      return toneStyle("neutral");
  }
}

function kindBadgeStyle(kind?: string): React.CSSProperties {
  if (kind === "CANONICAL") return toneStyle("success");
  return toneStyle("warning");
}

function Pill({
  label,
  style,
}: {
  label: string;
  style?: React.CSSProperties;
}) {
  return (
    <span style={{ ...pillBase, ...style }}>
      {label}
    </span>
  );
}

function buildAuthorityGroups(
  externalNotifications: ExternalNotificationRecord[]
): ExternalAuthorityGroup[] {
  const map = new Map<string, ExternalNotificationRecord[]>();

  for (const item of externalNotifications) {
    const key =
      item.authorityId ||
      item.authorityType ||
      item.authorityName ||
      item.legacyRequestId ||
      item.id;

    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(item);
  }

  const groups: ExternalAuthorityGroup[] = [];

  for (const [key, groupItems] of map.entries()) {
    const sorted = [...groupItems].sort((a, b) => {
      const aCanonical = a.recordKind === "CANONICAL" ? 1 : 0;
      const bCanonical = b.recordKind === "CANONICAL" ? 1 : 0;
      if (aCanonical !== bCanonical) return bCanonical - aCanonical;
      return safeTime(b) - safeTime(a);
    });

    const latest = sorted[0];
    const canonicalItems = sorted.filter((item) => item.recordKind === "CANONICAL");
    const legacyItems = sorted.filter((item) => item.recordKind === "LEGACY");

    groups.push({
      key,
      authorityLabel: formatLabel(latest.authorityName || latest.authorityType || "Άγνωστη αρχή"),
      authorityType: latest.authorityType,
      authorityId: latest.authorityId,
      channel: latest.channel,
      mode: latest.mode,
      latestStatus: latest.status,
      latestUpdatedAt: latest.updatedAt,
      latestApprovedAt:
        latest.approvedAt ?? latest.approval?.approvedAt ?? latest.approval?.decisionAt,
      latestExecutedAt: latest.executedAt ?? latest.execution?.executedAt,
      latestAcknowledgedAt:
        latest.acknowledgedAt ??
        latest.acknowledgement?.receivedAt ??
        latest.acknowledgement?.acknowledgedAt,
      latestNotes: pickString(
        latest.notes,
        latest.resultNotes,
        latest.execution?.resultNotes,
        latest.acknowledgement?.notes,
        latest.approval?.rejectionReason
      ),
      canonicalItems,
      legacyItems,
      allItems: sorted,
    });
  }

  groups.sort((a, b) => (b.latestUpdatedAt || 0) - (a.latestUpdatedAt || 0));
  return groups;
}

function countByStatus(externalNotifications: ExternalNotificationRecord[], status: string) {
  return externalNotifications.filter((item) => item.status === status).length;
}

function getLifecyclePresentation(incident: IncidentRecord): LifecyclePresentation {
  const status = normalizeKey(incident.status);

  if (status === "CLOSED") {
    return {
      title: "Το συμβάν έχει ολοκληρωθεί",
      text: "Η επιχειρησιακή ροή έχει κλείσει και το συμβάν παραμένει διαθέσιμο στο ιστορικό για έλεγχο, τεκμηρίωση και lessons learned.",
      tone: "success",
    };
  }

  if (status === "UNDER_CONTROL") {
    return {
      title: "Το συμβάν έχει τεθεί υπό έλεγχο",
      text: "Η άμεση φάση κινδύνου έχει σταθεροποιηθεί. Το συμβάν παραμένει ανοικτό μέχρι να ολοκληρωθούν οι απαιτούμενες ενέργειες, η διερεύνηση και το formal closure.",
      tone: "warning",
    };
  }

  if (status === "DEACTIVATED") {
    return {
      title: "Απενεργοποιημένο ΣΑΕΚ — εκκρεμεί οριστικό κλείσιμο",
      text: "Η απενεργοποίηση σταμάτησε την επιχειρησιακή emergency φάση και ακύρωσε/τερμάτισε τις ενεργές ροές. Το συμβάν δεν θεωρείται οριστικά κλειστό μέχρι να ολοκληρωθεί το formal closure.",
      tone: "info",
    };
  }

  if (status === "RECOVERY") {
    return {
      title: "Το συμβάν βρίσκεται σε φάση αποκατάστασης",
      text: "Ελέγχονται οι συνθήκες ασφαλούς επιστροφής στην κανονική λειτουργία και η ολοκλήρωση των εκκρεμών ενεργειών.",
      tone: "info",
    };
  }

  if (status === "REJECTED" || status === "CANCELLED") {
    return {
      title: "Το συμβάν δεν συνεχίζει σε ενεργή αντιμετώπιση",
      text: "Το συμβάν απορρίφθηκε ή ακυρώθηκε. Ελέγξτε το ιστορικό για αιτιολογία και χρήστη που έκανε την ενέργεια.",
      tone: "danger",
    };
  }

  return {
    title: "Το συμβάν βρίσκεται σε ενεργή επιχειρησιακή ροή",
    text: "Παρακολουθήστε ανταποκρινόμενους, ομάδες, εξωτερικές αρχές και ανοικτές ενέργειες μέχρι να τεθεί υπό έλεγχο και να προχωρήσει προς ολοκλήρωση.",
    tone: "warning",
  };
}

function getClosureGuidance(incident: IncidentRecord, dispatch?: DispatchState | null) {
  const raw = getIncidentObject(incident);
  const dispatchRaw = getDispatchObject(dispatch);
  const messages: string[] = [];

  const verificationStatus = normalizeKey(incident.verificationStatus);
  const status = normalizeKey(incident.status);
  const activeResponders = pickNumber(dispatchRaw.activeResponders, dispatchRaw.effectiveResponders) || 0;
  const pendingResponders = pickNumber(dispatchRaw.pendingRequestedResponders) || 0;
  const hasOpenDispatch = activeResponders > 0 || pendingResponders > 0;

  if (!verificationStatus || verificationStatus === "PENDING" || verificationStatus === "REQUESTED") {
    messages.push("Αν η πολιτική απαιτεί επιβεβαίωση πριν το κλείσιμο, πρέπει πρώτα να ολοκληρωθεί το verification του συμβάντος.");
  }

  if (status !== "UNDER_CONTROL" && status !== "DEACTIVATED" && status !== "RECOVERY" && status !== "CLOSED") {
    messages.push("Πριν από formal closure προτείνεται να δηλωθεί ότι το συμβάν τέθηκε υπό έλεγχο ή ότι η emergency φάση έχει απενεργοποιηθεί.");
  }

  if (hasOpenDispatch) {
    messages.push("Υπάρχουν ακόμη ανταποκρινόμενοι ή εκκρεμείς ζητήσεις κινητοποίησης. Ελέγξτε τις ομάδες πριν το κλείσιμο.");
  }

  const investigationStatus = pickString(
    raw.investigationStatus,
    (raw.investigation as Record<string, unknown> | undefined)?.status
  );

  if (!investigationStatus || normalizeKey(investigationStatus) !== "COMPLETED") {
    messages.push("Αν η πολιτική απαιτεί ολοκληρωμένη διερεύνηση, συμπληρώστε και κλείστε τη διερεύνηση πριν επιχειρήσετε closure.");
  }

  if (!messages.length) {
    messages.push("Οι βασικές ενδείξεις δείχνουν ότι το συμβάν είναι κοντά σε formal closure. Ελέγξτε τα policy requirements πριν την τελική ενέργεια.");
  }

  return messages;
}


type ResponderRow = DispatchResponder & {
  userId: string;
  statusKey: string;
  displayLabel: string;
};

type LifecycleStep = {
  key: string;
  label: string;
  helper: string;
  state: "done" | "current" | "pending" | "blocked";
};

function getResponders(dispatch?: DispatchState | null): ResponderRow[] {
  const responders = dispatch?.responders || {};

  return Object.entries(responders)
    .map(([userId, responder]) => {
      const statusKey = normalizeKey(responder.status) || "UNKNOWN";
      return {
        ...responder,
        userId: responder.userId || userId,
        statusKey,
        displayLabel: responder.displayName || responder.userId || userId,
      };
    })
    .sort((a, b) => {
      const weight: Record<string, number> = {
        RESPONDING: 1,
        ARRIVED: 2,
        REQUESTED: 3,
        COMPLETED: 4,
        CANCELLED: 5,
      };
      const aWeight = weight[a.statusKey] ?? 9;
      const bWeight = weight[b.statusKey] ?? 9;
      if (aWeight !== bWeight) return aWeight - bWeight;
      return (b.lastUpdatedAt || 0) - (a.lastUpdatedAt || 0);
    });
}

function countRespondersByStatus(responders: ResponderRow[]) {
  return responders.reduce<Record<string, number>>((acc, item) => {
    acc[item.statusKey] = (acc[item.statusKey] || 0) + 1;
    return acc;
  }, {});
}


type DispatchLifecycleStage = {
  key: string;
  label: string;
  count: number;
  helper: string;
  timestamp?: number;
  state: LifecycleStep["state"];
};

function latestNumber(values: Array<number | undefined>) {
  const clean = values.filter((value): value is number => typeof value === "number" && Number.isFinite(value) && value > 0);
  if (!clean.length) return undefined;
  return Math.max(...clean);
}

function getResponderLifecycleTime(responders: ResponderRow[], statusKey: string) {
  return latestNumber(
    responders
      .filter((item) => item.statusKey === statusKey)
      .flatMap((item) => [item.statusUpdatedAt, item.lastUpdatedAt, item.requestedAt, item.initialRequestedAt, item.arrivedAt, item.completedAt, item.cancelledAt])
  );
}

function getDispatchLifecycleStages(
  dispatch: DispatchState | null | undefined,
  responders: ResponderRow[],
  respondersByStatus: Record<string, number>
): DispatchLifecycleStage[] {
  const dispatchStatus = normalizeKey(dispatch?.status);
  const terminal = dispatchStatus === "CLOSED" || dispatchStatus === "CANCELLED" || dispatchStatus === "COMPLETED";
  const requested = dispatch?.requestedResponders ?? responders.length;
  const pending = dispatch?.pendingRequestedResponders ?? respondersByStatus.REQUESTED ?? 0;
  const responding = dispatch?.respondingResponders ?? respondersByStatus.RESPONDING ?? 0;
  const arrived = dispatch?.arrivedResponders ?? respondersByStatus.ARRIVED ?? 0;
  const completed = dispatch?.completedResponders ?? respondersByStatus.COMPLETED ?? 0;
  const cancelled = dispatch?.cancelledResponders ?? respondersByStatus.CANCELLED ?? 0;

  const requestedAt = latestNumber(responders.flatMap((item) => [item.requestedAt, item.initialRequestedAt]));
  const respondingAt = getResponderLifecycleTime(responders, "RESPONDING");
  const arrivedAt = latestNumber(responders.flatMap((item) => [item.arrivedAt, item.statusKey === "ARRIVED" ? item.statusUpdatedAt : undefined, item.statusKey === "ARRIVED" ? item.lastUpdatedAt : undefined]));
  const completedAt = latestNumber(responders.flatMap((item) => [item.completedAt, item.statusKey === "COMPLETED" ? item.statusUpdatedAt : undefined, item.statusKey === "COMPLETED" ? item.lastUpdatedAt : undefined]));
  const cancelledAt = latestNumber(responders.flatMap((item) => [item.cancelledAt, item.statusKey === "CANCELLED" ? item.statusUpdatedAt : undefined, item.statusKey === "CANCELLED" ? item.lastUpdatedAt : undefined]));

  return [
    {
      key: "requested",
      label: "Ζητήθηκε",
      count: requested,
      helper: requested > 0 ? "Η πολιτική/playbook στοχοποίησε responders" : "Δεν υπάρχει καταγεγραμμένη ζήτηση",
      timestamp: requestedAt,
      state: requested > 0 ? "done" : "pending",
    },
    {
      key: "pending",
      label: "Εκκρεμεί",
      count: pending,
      helper: pending > 0 ? "Χρήστες που δεν έχουν δηλώσει ανταπόκριση" : "Δεν υπάρχει ανοικτή εκκρεμότητα REQUESTED",
      timestamp: requestedAt,
      state: pending > 0 && !terminal ? "current" : pending > 0 ? "blocked" : "done",
    },
    {
      key: "responding",
      label: "Καθ’ οδόν",
      count: responding,
      helper: responding > 0 ? "Χρήστες που δήλωσαν ότι κατευθύνονται" : "Δεν υπάρχουν ενεργοί responders καθ’ οδόν",
      timestamp: respondingAt,
      state: responding > 0 ? "current" : arrived > 0 || completed > 0 ? "done" : "pending",
    },
    {
      key: "arrived",
      label: "Άφιξη",
      count: arrived,
      helper: arrived > 0 ? "Υπάρχει φυσική παρουσία στο σημείο" : "Δεν έχει καταγραφεί άφιξη",
      timestamp: arrivedAt,
      state: arrived > 0 || completed > 0 ? "done" : responding > 0 ? "current" : "pending",
    },
    {
      key: "completed",
      label: "Ολοκλήρωση",
      count: completed,
      helper: completed > 0 ? "Responders ή ενέργειες ολοκληρώθηκαν" : "Δεν έχει δηλωθεί completed",
      timestamp: completedAt,
      state: completed > 0 || terminal ? "done" : "pending",
    },
    {
      key: "cancelled",
      label: "Ακύρωση",
      count: cancelled,
      helper: cancelled > 0 ? "Responders ακυρώθηκαν/καθαρίστηκαν από lifecycle" : "Χωρίς ακυρωμένους responders",
      timestamp: cancelledAt,
      state: cancelled > 0 ? "blocked" : "pending",
    },
  ];
}

function dispatchLifecycleCardStyle(state: LifecycleStep["state"]): React.CSSProperties {
  return {
    ...miniBox,
    ...lifecycleStepStyle(state),
    minHeight: 108,
    position: "relative",
    overflow: "hidden",
  };
}

function getOpenExternalCount(externalNotifications: ExternalNotificationRecord[]) {
  return externalNotifications.filter((item) => {
    const status = normalizeKey(item.status);
    return status === "REQUESTED" || status === "APPROVED" || status === "SENT";
  }).length;
}


type ExternalExecutionColumn = {
  key: string;
  title: string;
  helper: string;
  statusForTone: string;
  items: ExternalAuthorityGroup[];
};

function getExternalAuthorityStage(group: ExternalAuthorityGroup) {
  const latest = group.allItems[0];
  const status = normalizeKey(group.latestStatus);
  const approvalStatus = normalizeKey(latest?.approval?.status);
  const executionStatus = normalizeKey(latest?.execution?.status);
  const acknowledgementStatus = normalizeKey(latest?.acknowledgement?.status);

  if (status === "ACKNOWLEDGED" || acknowledgementStatus === "ACKNOWLEDGED") return "acknowledged";
  if (status === "REJECTED" || status === "FAILED" || status === "CANCELLED") return "closed";
  if (status === "SENT" || executionStatus === "SENT") return "sent";
  if (status === "APPROVED" || approvalStatus === "APPROVED") return "approved";
  return "requested";
}

function buildExternalExecutionBoard(groups: ExternalAuthorityGroup[]): ExternalExecutionColumn[] {
  const columns: ExternalExecutionColumn[] = [
    {
      key: "requested",
      title: "Ζητήθηκε / αναμονή",
      helper: "Νέα αιτήματα ή αιτήματα που θέλουν απόφαση",
      statusForTone: "REQUESTED",
      items: [],
    },
    {
      key: "approved",
      title: "Εγκρίθηκε",
      helper: "Εγκρίθηκε και πρέπει να εκτελεστεί/καταγραφεί",
      statusForTone: "APPROVED",
      items: [],
    },
    {
      key: "sent",
      title: "Εκτελέστηκε",
      helper: "Έγινε επικοινωνία, αναμένεται επιβεβαίωση/αποτέλεσμα",
      statusForTone: "SENT",
      items: [],
    },
    {
      key: "acknowledged",
      title: "Επιβεβαιώθηκε",
      helper: "Υπάρχει καταγεγραμμένη επιβεβαίωση/λήψη",
      statusForTone: "ACKNOWLEDGED",
      items: [],
    },
    {
      key: "closed",
      title: "Απορρίφθηκε / έκλεισε",
      helper: "Δεν απαιτήθηκε, απέτυχε ή ακυρώθηκε",
      statusForTone: "REJECTED",
      items: [],
    },
  ];

  const byKey = new Map(columns.map((column) => [column.key, column]));

  for (const group of groups) {
    const stage = getExternalAuthorityStage(group);
    byKey.get(stage)?.items.push(group);
  }

  return columns;
}

function getAuthorityContactLabel(group: ExternalAuthorityGroup) {
  const latest = group.allItems[0];
  const contact = latest?.contact || latest?.contacts?.primary;
  const parts = [
    contact?.phone ? `Τηλ. ${contact.phone}` : "",
    contact?.email ? `Email ${contact.email}` : "",
  ].filter(Boolean);

  return parts.length ? parts.join(" · ") : "Χωρίς στοιχεία επικοινωνίας";
}

function getAuthorityActionHint(group: ExternalAuthorityGroup) {
  const latest = group.allItems[0];
  const status = normalizeKey(group.latestStatus);
  const approvalStatus = normalizeKey(latest?.approval?.status);
  const executionStatus = normalizeKey(latest?.execution?.status);
  const acknowledgementStatus = normalizeKey(latest?.acknowledgement?.status);

  if (status === "ACKNOWLEDGED" || acknowledgementStatus === "ACKNOWLEDGED") {
    return "Ολοκληρωμένη καταγραφή. Ελέγξτε μόνο αν χρειάζεται τελική σημείωση στο closure.";
  }

  if (status === "SENT" || executionStatus === "SENT") {
    return "Χρειάζεται επιβεβαίωση λήψης ή αποτέλεσμα επικοινωνίας.";
  }

  if (status === "APPROVED" || approvalStatus === "APPROVED") {
    return "Χρειάζεται καταγραφή εκτέλεσης της επικοινωνίας.";
  }

  if (status === "REJECTED") {
    return "Δεν απαιτήθηκε περαιτέρω ενέργεια. Ελέγξτε την αιτιολογία απόρριψης.";
  }

  if (status === "FAILED") {
    return "Απέτυχε η ενέργεια. Χρειάζεται χειροκίνητος έλεγχος/επανάληψη.";
  }

  return "Χρειάζεται απόφαση: εκτέλεση, έγκριση ή απόρριψη σύμφωνα με το policy.";
}

function isTerminalIncidentStatus(status?: string) {
  const key = normalizeKey(status);
  return key === "CLOSED" || key === "DEACTIVATED" || key === "CANCELLED" || key === "REJECTED";
}

function isOpenDispatchStatus(status?: string) {
  const key = normalizeKey(status);
  return !!key && key !== "CLOSED" && key !== "CANCELLED" && key !== "COMPLETED";
}

function getOperationalAlerts(
  incident: IncidentRecord,
  dispatch: DispatchState | null | undefined,
  externalNotifications: ExternalNotificationRecord[],
  responders: ResponderRow[]
) {
  const dispatchRaw = getDispatchObject(dispatch);
  const status = normalizeKey(incident.status);
  const dispatchStatus = normalizeKey(dispatch?.status);
  const pendingResponders = pickNumber(dispatchRaw.pendingRequestedResponders) || 0;
  const activeResponders = pickNumber(dispatchRaw.activeResponders, dispatchRaw.effectiveResponders) || 0;
  const requestedFromRows = responders.filter((item) => item.statusKey === "REQUESTED").length;
  const openExternal = getOpenExternalCount(externalNotifications);
  const alerts: { title: string; text: string; tone: LifecyclePresentation["tone"] }[] = [];

  if (isTerminalIncidentStatus(status) && (isOpenDispatchStatus(dispatchStatus) || pendingResponders > 0 || activeResponders > 0 || requestedFromRows > 0)) {
    alerts.push({
      title: "Πιθανή ασυνέπεια lifecycle",
      text: "Το συμβάν φαίνεται κλειστό/απενεργοποιημένο, αλλά η κινητοποίηση έχει ακόμη ανοικτή κατάσταση ή εκκρεμείς responders. Το cleanup πρέπει να μηδενίζει τους ενεργούς/εκκρεμείς responders και να ακυρώνει τα dispatch requests κατά την απενεργοποίηση.",
      tone: "warning",
    });
  }

  if (openExternal > 0 && (status === "DEACTIVATED" || status === "CLOSED")) {
    alerts.push({
      title: "Εκκρεμείς εξωτερικές αρχές",
      text: "Υπάρχουν ακόμη αιτήματα εξωτερικών αρχών σε REQUESTED / APPROVED / SENT. Πριν το closure πρέπει να επιβεβαιωθεί αν εκτελέστηκαν, απορρίφθηκαν ή δεν απαιτούνται.",
      tone: "warning",
    });
  }

  if (!dispatch && !externalNotifications.length) {
    alerts.push({
      title: "Περιορισμένη επιχειρησιακή εικόνα",
      text: "Δεν βρέθηκε dispatch_state ή εξωτερικές ειδοποιήσεις για το συμβάν. Αν η πολιτική του συμβάντος απαιτεί κινητοποίηση, χρειάζεται έλεγχος policy/playbook execution.",
      tone: "info",
    });
  }

  return alerts;
}


type ClosureCheck = {
  key: string;
  title: string;
  description: string;
  status: "READY" | "WARNING" | "BLOCKER" | "INFO";
  value?: string;
};

function closureCheckTone(status: ClosureCheck["status"]): LifecyclePresentation["tone"] {
  if (status === "READY") return "success";
  if (status === "BLOCKER") return "danger";
  if (status === "WARNING") return "warning";
  return "info";
}

function buildClosureReadiness(
  incident: IncidentRecord,
  dispatch: DispatchState | null | undefined,
  externalNotifications: ExternalNotificationRecord[],
  responders: ResponderRow[]
) {
  const raw = getIncidentObject(incident);
  const dispatchRaw = getDispatchObject(dispatch);
  const incidentStatus = normalizeKey(incident.status);
  const dispatchStatus = normalizeKey(dispatch?.status);
  const verificationStatus = normalizeKey(incident.verificationStatus);
  const pendingResponders = pickNumber(dispatchRaw.pendingRequestedResponders) || responders.filter((item) => item.statusKey === "REQUESTED").length;
  const activeResponders = pickNumber(dispatchRaw.activeResponders, dispatchRaw.effectiveResponders) || responders.filter((item) => item.statusKey === "RESPONDING" || item.statusKey === "ARRIVED").length;
  const openExternal = getOpenExternalCount(externalNotifications);
  const investigationStatus = normalizeKey(
    pickString(raw.investigationStatus, (raw.investigation as Record<string, unknown> | undefined)?.status)
  );

  const checks: ClosureCheck[] = [
    {
      key: "incident_status",
      title: "Κατάσταση συμβάντος",
      description: "Το συμβάν πρέπει να είναι τουλάχιστον υπό έλεγχο, σε αποκατάσταση ή απενεργοποιημένο πριν από formal closure.",
      status:
        incidentStatus === "CLOSED"
          ? "READY"
          : incidentStatus === "UNDER_CONTROL" || incidentStatus === "RECOVERY" || incidentStatus === "DEACTIVATED"
            ? "READY"
            : "WARNING",
      value: formatLabel(incident.status),
    },
    {
      key: "dispatch_state",
      title: "Κινητοποίηση / dispatch",
      description: "Δεν πρέπει να μένουν REQUESTED ή ενεργοί responders όταν το συμβάν προχωρά προς κλείσιμο.",
      status:
        pendingResponders > 0 || activeResponders > 0
          ? incidentStatus === "DEACTIVATED" || incidentStatus === "CLOSED"
            ? "BLOCKER"
            : "WARNING"
          : dispatchStatus === "CLOSED" || dispatchStatus === "CANCELLED" || dispatchStatus === "COMPLETED"
            ? "READY"
            : dispatch
              ? "INFO"
              : "READY",
      value: `${formatLabel(dispatch?.status)} · εκκρεμείς ${pendingResponders} · ενεργοί ${activeResponders}`,
    },
    {
      key: "external_authorities",
      title: "Εξωτερικές αρχές",
      description: "Τα αιτήματα προς 112/ΕΚΑΒ/Πυροσβεστική/Αστυνομία πρέπει να έχουν εκτελεστεί, επιβεβαιωθεί ή απορριφθεί τεκμηριωμένα.",
      status: openExternal > 0 ? "WARNING" : externalNotifications.length > 0 ? "READY" : "INFO",
      value: openExternal > 0 ? `${openExternal} ανοικτές ενέργειες` : "Χωρίς ανοικτές ενέργειες",
    },
    {
      key: "verification",
      title: "Verification / αξιολόγηση",
      description: "Για non-emergency ή policy-driven συμβάντα χρειάζεται σαφής απόφαση επιβεβαίωσης/απόρριψης πριν το κλείσιμο.",
      status:
        !verificationStatus || verificationStatus === "PENDING" || verificationStatus === "REQUESTED"
          ? incident.category === "EMERGENCY_ACTIVATION"
            ? "INFO"
            : "WARNING"
          : verificationStatus === "REJECTED"
            ? "BLOCKER"
            : "READY",
      value: formatLabel(incident.verificationStatus),
    },
    {
      key: "investigation",
      title: "Διερεύνηση / τεκμηρίωση",
      description: "Αν απαιτείται από την πολιτική, πρέπει να έχει συμπληρωθεί διερεύνηση, αιτία, ενέργειες και τελικές σημειώσεις.",
      status: investigationStatus === "COMPLETED" || investigationStatus === "CLOSED" ? "READY" : "INFO",
      value: investigationStatus ? formatLabel(investigationStatus) : "Δεν έχει καταγραφεί κατάσταση διερεύνησης",
    },
  ];

  const blockers = checks.filter((item) => item.status === "BLOCKER").length;
  const warnings = checks.filter((item) => item.status === "WARNING").length;
  const ready = checks.filter((item) => item.status === "READY").length;
  const score = Math.round((ready / checks.length) * 100);

  const summary = blockers > 0
    ? "Δεν προτείνεται closure πριν λυθούν τα κόκκινα σημεία."
    : warnings > 0
      ? "Το συμβάν μπορεί να προχωρήσει προς closure μόνο μετά από επιβεβαίωση των κίτρινων σημείων."
      : "Οι βασικές ενδείξεις είναι καθαρές για formal closure.";

  return { checks, blockers, warnings, ready, score, summary };
}

function getLifecycleSteps(
  incident: IncidentRecord,
  dispatch: DispatchState | null | undefined,
  externalNotifications: ExternalNotificationRecord[],
  responders: ResponderRow[]
): LifecycleStep[] {
  const incidentStatus = normalizeKey(incident.status);
  const verificationStatus = normalizeKey(incident.verificationStatus);
  const dispatchStatus = normalizeKey(dispatch?.status);
  const openExternal = getOpenExternalCount(externalNotifications);
  const hasArrived = responders.some((item) => item.statusKey === "ARRIVED" || item.statusKey === "COMPLETED");
  const hasResponders = responders.length > 0 || !!dispatch;
  const terminal = isTerminalIncidentStatus(incidentStatus);

  return [
    {
      key: "created",
      label: "Καταχώρηση",
      helper: formatDate(incident.createdAt),
      state: incident.createdAt ? "done" : "pending",
    },
    {
      key: "verification",
      label: "Επιβεβαίωση",
      helper: verificationStatus ? formatLabel(verificationStatus) : "Δεν απαιτείται ή δεν έχει καταγραφεί",
      state:
        verificationStatus === "REJECTED"
          ? "blocked"
          : verificationStatus && verificationStatus !== "PENDING" && verificationStatus !== "REQUESTED"
            ? "done"
            : incident.category === "EMERGENCY_ACTIVATION"
              ? "done"
              : "current",
    },
    {
      key: "dispatch",
      label: "Κινητοποίηση",
      helper: dispatchStatus ? formatLabel(dispatchStatus) : "Δεν υπάρχει dispatch_state",
      state: !hasResponders ? "pending" : isOpenDispatchStatus(dispatchStatus) ? "current" : "done",
    },
    {
      key: "response",
      label: "Ανταπόκριση",
      helper: hasArrived ? "Υπάρχει άφιξη στο σημείο" : "Αναμονή ανταπόκρισης / άφιξης",
      state: hasArrived ? "done" : hasResponders ? "current" : "pending",
    },
    {
      key: "external",
      label: "Εξωτερικές αρχές",
      helper: openExternal > 0 ? `${openExternal} εκκρεμείς ενέργειες` : "Χωρίς ανοικτή εκκρεμότητα",
      state: openExternal > 0 ? "current" : externalNotifications.length ? "done" : "pending",
    },
    {
      key: "closure",
      label: "Οριστικό κλείσιμο",
      helper: incidentStatus === "DEACTIVATED" ? "Εκκρεμεί formal closure" : formatLabel(incidentStatus),
      state: incidentStatus === "CLOSED" ? "done" : terminal ? "current" : "pending",
    },
  ];
}

function lifecycleStepStyle(state: LifecycleStep["state"]): React.CSSProperties {
  if (state === "done") return toneStyle("success");
  if (state === "current") return toneStyle("warning");
  if (state === "blocked") return toneStyle("danger");
  return toneStyle("neutral");
}

function responderStatusDotStyle(statusKey: string): React.CSSProperties {
  const background =
    statusKey === "ARRIVED" || statusKey === "COMPLETED"
      ? "#10b981"
      : statusKey === "RESPONDING"
        ? "#3b82f6"
        : statusKey === "REQUESTED"
          ? "#f59e0b"
          : statusKey === "CANCELLED"
            ? "#ef4444"
            : "#94a3b8";

  return {
    width: 9,
    height: 9,
    borderRadius: 999,
    background,
    boxShadow: `0 0 0 4px ${background}22`,
    flex: "0 0 auto",
  };
}

function renderBoolMap(value?: Record<string, boolean>) {
  const keys = Object.entries(value || {})
    .filter(([, enabled]) => enabled)
    .map(([key]) => key);

  if (!keys.length) return "-";
  return keys.map(formatLabel).join(", ");
}

function enabledKeys(value?: Record<string, boolean>): string[] {
  return Object.entries(value || {})
    .filter(([, enabled]) => enabled === true)
    .map(([key]) => key);
}

function extractClosureFailure(error: unknown): ClosureAttemptResult {
  const raw = error as any;
  const details = raw?.details || raw?.customData?.details || raw?._details || null;
  const reasons = Array.isArray(details?.reasons)
    ? details.reasons
        .map((item: any) => ({
          code: typeof item?.code === "string" ? item.code : undefined,
          message: typeof item?.message === "string" ? item.message : undefined,
          count: typeof item?.count === "number" ? item.count : undefined,
        }))
        .filter((item: ClosureFailureReason) => item.message || item.code)
    : [];

  const fallbackMessage =
    typeof raw?.message === "string" && raw.message.trim()
      ? raw.message.trim()
      : "Το συμβάν δεν μπορεί να κλείσει ακόμη.";

  return {
    tone: "danger",
    title: "Το κλείσιμο μπλοκαρίστηκε",
    message: reasons.length
      ? "Το backend closure validator δεν επέτρεψε το κλείσιμο. Δες τις αιτίες παρακάτω."
      : fallbackMessage,
    reasons,
  };
}

export function SelectedIncidentOverview({
  incident,
  dispatch,
  externalNotifications = [],
  mode = "full",
}: Props) {
  const [expandedAuthorityKey, setExpandedAuthorityKey] = useState<string | null>(null);
  const [showAllResponders, setShowAllResponders] = useState(false);
  const [closureNotes, setClosureNotes] = useState("");
  const [closureSubmitting, setClosureSubmitting] = useState(false);
  const [closureAttemptResult, setClosureAttemptResult] = useState<ClosureAttemptResult | null>(null);
  const [resolvedIncidentPhotoUrl, setResolvedIncidentPhotoUrl] = useState<string | null>(null);
  const [incidentPhotoError, setIncidentPhotoError] = useState<string | null>(null);
  const { profile } = useAuth();

  const responders = useMemo(() => getResponders(dispatch), [dispatch]);
  const respondersByStatus = useMemo(() => countRespondersByStatus(responders), [responders]);
  const dispatchLifecycleStages = useMemo(
    () => getDispatchLifecycleStages(dispatch, responders, respondersByStatus),
    [dispatch, responders, respondersByStatus]
  );

  const authorityGroups = useMemo(
    () => buildAuthorityGroups(externalNotifications),
    [externalNotifications]
  );

  const externalExecutionBoard = useMemo(
    () => buildExternalExecutionBoard(authorityGroups),
    [authorityGroups]
  );

  const externalStats = useMemo(() => {
    return {
      total: externalNotifications.length,
      authorities: authorityGroups.length,
      requested: countByStatus(externalNotifications, "REQUESTED"),
      approved: countByStatus(externalNotifications, "APPROVED"),
      sent: countByStatus(externalNotifications, "SENT"),
      acknowledged: countByStatus(externalNotifications, "ACKNOWLEDGED"),
      open: getOpenExternalCount(externalNotifications),
      failed:
        countByStatus(externalNotifications, "FAILED") +
        countByStatus(externalNotifications, "REJECTED") +
        countByStatus(externalNotifications, "CANCELLED"),
      canonical: externalNotifications.filter((item) => item.recordKind === "CANONICAL").length,
      legacy: externalNotifications.filter((item) => item.recordKind === "LEGACY").length,
    };
  }, [externalNotifications, authorityGroups]);

  const incidentPhoto = useMemo(() => (incident ? extractIncidentPhoto(incident) : null), [incident]);

  useEffect(() => {
    let cancelled = false;

    setIncidentPhotoError(null);

    if (!incidentPhoto) {
      setResolvedIncidentPhotoUrl(null);
      return;
    }

    if (isUsableImageUrl(incidentPhoto.url)) {
      setResolvedIncidentPhotoUrl(incidentPhoto.url || null);
      return;
    }

    if (!incidentPhoto.path) {
      setResolvedIncidentPhotoUrl(null);
      return;
    }

    setResolvedIncidentPhotoUrl(null);

    getDownloadURL(storageRef(storage, incidentPhoto.path))
      .then((url) => {
        if (!cancelled) setResolvedIncidentPhotoUrl(url);
      })
      .catch(() => {
        if (!cancelled) {
          setIncidentPhotoError("Δεν ήταν δυνατή η φόρτωση της φωτογραφίας από το Storage.");
        }
      });

    return () => {
      cancelled = true;
    };
  }, [incidentPhoto]);

  if (!incident) {
    return (
      <div style={emptyState}>
        Επίλεξε συμβάν από τη λίστα ή τον χάρτη για να εμφανιστεί η επιχειρησιακή του εικόνα.
      </div>
    );
  }

  const lifecycle = getLifecyclePresentation(incident);
  const closureGuidance = getClosureGuidance(incident, dispatch);
  const lifecycleSteps = getLifecycleSteps(incident, dispatch, externalNotifications, responders);
  const operationalAlerts = getOperationalAlerts(incident, dispatch, externalNotifications, responders);
  const closureReadiness = buildClosureReadiness(incident, dispatch, externalNotifications, responders);
  const dispatchRaw = getDispatchObject(dispatch);
  const visibleResponders = showAllResponders ? responders : responders.slice(0, 8);
  const requestedTeamsLabel = renderBoolMap(dispatch?.requestedTeams);
  const activeResponders = pickNumber(dispatchRaw.activeResponders, dispatchRaw.effectiveResponders) || 0;
  const showSummary = mode === "full" || mode === "summary";
  const showClosure = mode === "full" || mode === "closure";
  const showDispatch = mode === "full" || mode === "dispatch";
  const showExternal = mode === "full" || mode === "external";
  const pendingResponders = pickNumber(dispatchRaw.pendingRequestedResponders) || 0;

  async function handleFormalClosure() {
    if (!incident?.id || closureSubmitting) return;

    setClosureSubmitting(true);
    setClosureAttemptResult(null);

    try {
      const closeIncident = httpsCallable(functions, "closeIncident");
      await closeIncident({
        incidentId: incident.id,
        closureNotes: closureNotes.trim(),
        actor: {
          userId: profile?.uid,
          displayName: profile?.displayName || profile?.email,
          siteId: profile?.siteId || incident.siteId,
          roles: enabledKeys(profile?.roles),
          sessionType: "WEB_ADMIN",
        },
      });

      setClosureAttemptResult({
        tone: "success",
        title: "Το συμβάν έκλεισε",
        message: "Το backend closure validator επέτρεψε το formal closure και το συμβάν ενημερώθηκε επιτυχώς.",
      });
      setClosureNotes("");
    } catch (error) {
      setClosureAttemptResult(extractClosureFailure(error));
    } finally {
      setClosureSubmitting(false);
    }
  }

  return (
    <div style={panel}>
      {showSummary ? (
        <>
          <div style={{ ...banner, ...toneStyle(lifecycle.tone) }}>
            <div style={bannerTitle}>{lifecycle.title}</div>
            <div style={bannerText}>{lifecycle.text}</div>
          </div>

          {operationalAlerts.length ? (
            <div style={{ display: "grid", gap: 10 }}>
              {operationalAlerts.map((alert) => (
                <div key={alert.title} style={{ ...banner, ...toneStyle(alert.tone) }}>
                  <div style={bannerTitle}>{alert.title}</div>
                  <div style={bannerText}>{alert.text}</div>
                </div>
              ))}
            </div>
          ) : null}

          <div>
            <h3 style={title}>Επιχειρησιακή εικόνα συμβάντος</h3>
        <div style={sectionHint}>
          Συνοπτική εικόνα κατάστασης, κινητοποίησης, εξωτερικών αρχών και οδηγιών πριν από ολοκλήρωση.
        </div>

        <div style={{ marginTop: 14, marginBottom: 14 }}>
          <div style={incidentTitle}>{incident.title || formatLabel(incident.category) || incident.id}</div>
          <div style={idText}>{incident.id}</div>
        </div>

        <div style={mainGrid}>
          {chip("Μονάδα", incident.siteId)}
          {chip("Κατηγορία", formatLabel(incident.category))}
          {chip("Σοβαρότητα", formatLabel(incident.severity))}
          {chip("Κατάσταση", formatLabel(incident.status))}
          {chip("Επιβεβαίωση", formatLabel(incident.verificationStatus))}
          {chip(
            "Τύπος / Υποτύπος",
            [formatLabel(incident.type), formatLabel(incident.subtype)].filter((v) => v && v !== "-").join(" / ")
          )}
        </div>

        <div style={detailGrid}>
          <div><strong>Δημιουργήθηκε:</strong> {formatDate(incident.createdAt)}</div>
          <div><strong>Τελευταία ενημέρωση:</strong> {formatDate(incident.updatedAt)}</div>
          <div><strong>Καταχώρηση από:</strong> {incident.createdByName || incident.createdByUserId || "-"}</div>
          <div>
            <strong>Υπεύθυνος συντονισμού:</strong> {incident.commandOwnerName || "-"}{" "}
            {incident.commandOwnerRole ? `(${formatLabel(incident.commandOwnerRole)})` : ""}
          </div>
        </div>

        {incidentPhoto ? (
          <div style={incidentPhotoPanel}>
            <div style={incidentPhotoHeader}>
              <div>
                <div style={sectionTitle}>Φωτογραφία ενεργοποίησης</div>
                <div style={sectionHint}>
                  Εικόνα που ανέβασε ο χρήστης κατά την καταχώρηση/ενεργοποίηση του συμβάντος.
                </div>
              </div>
              {incidentPhoto.capturedAt ? (
                <Pill label={formatDate(incidentPhoto.capturedAt)} style={toneStyle("info")} />
              ) : null}
            </div>

            {resolvedIncidentPhotoUrl ? (
              <a href={resolvedIncidentPhotoUrl} target="_blank" rel="noreferrer" style={incidentPhotoLink}>
                <img
                  src={resolvedIncidentPhotoUrl}
                  alt={`Φωτογραφία συμβάντος ${incident.id}`}
                  style={incidentPhotoImage}
                />
              </a>
            ) : incidentPhotoError ? (
              <div style={{ ...emptyState, marginTop: 12 }}>{incidentPhotoError}</div>
            ) : incidentPhoto.path ? (
              <div style={{ ...emptyState, marginTop: 12 }}>Φόρτωση φωτογραφίας...</div>
            ) : null}

            {incidentPhoto.caption ? (
              <div style={incidentPhotoCaption}>{incidentPhoto.caption}</div>
            ) : null}

            {incidentPhoto.path ? (
              <div style={incidentPhotoPath}>Storage path: {incidentPhoto.path}</div>
            ) : null}
          </div>
        ) : null}

        {incident.description ? (
              <div style={descriptionBox}>
                <strong>Περιγραφή συμβάντος</strong>
                <div style={descriptionText}>{incident.description}</div>
              </div>
            ) : null}
          </div>
        </>
      ) : null}

      {showSummary || showClosure ? (
      <div>
        <div style={sectionTitle}>Lifecycle συμβάντος</div>
        <div style={sectionHint}>
          Γρήγορη οπτική αποτύπωση της επιχειρησιακής ροής από καταχώρηση μέχρι ολοκλήρωση.
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10, marginTop: 12 }}>
          {lifecycleSteps.map((step, index) => (
            <div key={step.key} style={{ ...miniBox, ...lifecycleStepStyle(step.state) }}>
              <div style={{ fontSize: 11, opacity: 0.76 }}>Βήμα {index + 1}</div>
              <div style={{ marginTop: 4, fontWeight: 900 }}>{step.label}</div>
              <div style={{ marginTop: 5, fontSize: 12, lineHeight: 1.35 }}>{step.helper}</div>
            </div>
          ))}
        </div>
      </div>
      ) : null}

      {showClosure ? (
      <div style={guidanceBox}>
        <div style={sectionTitle}>Οδηγίες πριν από ολοκλήρωση</div>
        <div style={sectionHint}>
          Τα παρακάτω βοηθούν τον χρήστη να καταλάβει τι πρέπει να ελεγχθεί πριν από formal closure.
        </div>
        <ul style={guidanceList}>
          {closureGuidance.map((message) => (
            <li key={message}>{message}</li>
          ))}
        </ul>
      </div>
      ) : null}

      {showClosure ? (
      <div style={closurePanel}>
        <div style={sectionHeader}>
          <div>
            <div style={sectionTitle}>Incident closure workflow</div>
            <div style={sectionHint}>
              Readiness check για ασφαλές κλείσιμο συμβάντος, χωρίς να μένουν ανοικτά dispatch, responders ή εξωτερικές αρχές.
            </div>
          </div>
          <Pill
            label={`${closureReadiness.score}% readiness`}
            style={toneStyle(closureReadiness.blockers > 0 ? "danger" : closureReadiness.warnings > 0 ? "warning" : "success")}
          />
        </div>

        <div style={closureSummaryGrid}>
          {chip("Έτοιμα", String(closureReadiness.ready), "Πράσινοι έλεγχοι")}
          {chip("Προσοχή", String(closureReadiness.warnings), "Χρειάζεται επιβεβαίωση")}
          {chip("Blockers", String(closureReadiness.blockers), "Δεν προτείνεται closure")}
        </div>

        <div style={{ ...banner, ...toneStyle(closureReadiness.blockers > 0 ? "danger" : closureReadiness.warnings > 0 ? "warning" : "success"), marginTop: 12 }}>
          <div style={bannerTitle}>Σύσταση closure</div>
          <div style={bannerText}>{closureReadiness.summary}</div>
        </div>

        <div style={closureChecklistGrid}>
          {closureReadiness.checks.map((check, index) => (
            <div key={check.key} style={{ ...closureCheckCard, ...toneStyle(closureCheckTone(check.status)) }}>
              <div style={closureCheckTop}>
                <div style={closureCheckIndex}>{index + 1}</div>
                <Pill label={formatLabel(check.status)} style={toneStyle(closureCheckTone(check.status))} />
              </div>
              <div style={closureCheckTitle}>{check.title}</div>
              <div style={closureCheckValue}>{check.value || "-"}</div>
              <div style={closureCheckDescription}>{check.description}</div>
            </div>
          ))}
        </div>

        <div style={closureActionBox}>
          <strong>Πρακτική οδηγία:</strong> πριν ο χρήστης πατήσει τελικό κλείσιμο, πρέπει να έχει ελεγχθεί ότι η emergency φάση σταμάτησε, το dispatch καθάρισε, οι εξωτερικές αρχές έχουν τεκμηριωμένη κατάληξη και υπάρχουν τελικές σημειώσεις/διερεύνηση όπου απαιτείται.

          <div style={closureForm}>
            <label style={closureFormLabel} htmlFor={`closure-notes-${incident.id}`}>
              Σημείωση κλεισίματος / αιτιολόγηση
            </label>
            <textarea
              id={`closure-notes-${incident.id}`}
              value={closureNotes}
              onChange={(event) => setClosureNotes(event.target.value)}
              placeholder="Π.χ. Ολοκληρώθηκε ο έλεγχος, οι ανταποκρινόμενοι αποδεσμεύτηκαν και οι εξωτερικές αρχές τεκμηριώθηκαν."
              style={closureTextArea}
              rows={3}
            />
            <button
              type="button"
              style={{ ...primaryButton, opacity: closureSubmitting ? 0.68 : 1 }}
              onClick={handleFormalClosure}
              disabled={closureSubmitting || normalizeKey(incident.status) === "CLOSED"}
            >
              {closureSubmitting ? "Έλεγχος closure..." : "Κλείσιμο συμβάντος"}
            </button>
          </div>

          {closureAttemptResult ? (
            <div style={{ ...closureResultBox, ...toneStyle(closureAttemptResult.tone) }}>
              <div style={bannerTitle}>{closureAttemptResult.title}</div>
              <div style={bannerText}>{closureAttemptResult.message}</div>
              {closureAttemptResult.reasons?.length ? (
                <ul style={closureResultList}>
                  {closureAttemptResult.reasons.map((reason, index) => (
                    <li key={`${reason.code || "reason"}-${index}`}>
                      {reason.message || formatLabel(reason.code)}
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
      ) : null}

      {showDispatch ? (
      <div>
        <div style={sectionHeader}>
          <div>
            <div style={sectionTitle}>Κινητοποίηση και ανταπόκριση</div>
            <div style={sectionHint}>
              Σύνοψη ομάδων και χρηστών που ζητήθηκαν, ανταποκρίθηκαν ή έφτασαν στο σημείο.
            </div>
          </div>
          <Pill label={formatLabel(dispatch?.status)} style={statusBadgeStyle(dispatch?.status)} />
        </div>

        <div style={mainGridFour}>
          {chip("Ζητήθηκαν", String(dispatch?.requestedResponders ?? responders.length), "Συνολικοί χρήστες που στοχοποιήθηκαν")}
          {chip("Ενεργοί", String(activeResponders), "Responding + arrived σύμφωνα με dispatch_state")}
          {chip("Ανταποκρίνονται", String(dispatch?.respondingResponders ?? respondersByStatus.RESPONDING ?? 0), "Χρήστες καθ’ οδόν")}
          {chip("Έφτασαν", String(dispatch?.arrivedResponders ?? respondersByStatus.ARRIVED ?? 0), "Χρήστες που δήλωσαν άφιξη")}
          {chip("Εκκρεμείς", String(pendingResponders || respondersByStatus.REQUESTED || 0), "Δεν έχουν απαντήσει ακόμη")}
          {chip("Ολοκληρώθηκαν", String((dispatchRaw.completedResponders as number) ?? respondersByStatus.COMPLETED ?? 0), "Χρήστες/ενέργειες με completed status")}
        </div>

        <div style={detailGrid}>
          <div><strong>Στοχευμένες ομάδες:</strong> {requestedTeamsLabel}</div>
          <div><strong>Κοντινότερος ανταποκρινόμενος:</strong> {dispatch?.closestResponderId || "-"}</div>
          <div><strong>Κοντινότερη απόσταση:</strong> {formatMeters(dispatch?.closestDistanceMeters)}</div>
          <div><strong>Τελευταία ενημέρωση κινητοποίησης:</strong> {formatDate(getDispatchLastUpdate(dispatch))}</div>
        </div>

        <div style={dispatchLifecyclePanel}>
          <div style={sectionHeader}>
            <div>
              <div style={sectionTitle}>Dispatch lifecycle</div>
              <div style={sectionHint}>
                Οπτική διαδρομή της κινητοποίησης από το REQUESTED μέχρι το COMPLETED/CANCELLED. Βοηθά να φαίνονται αμέσως οι εκκρεμότητες πριν το κλείσιμο.
              </div>
            </div>
            <Pill
              label={pendingResponders > 0 ? `${pendingResponders} εκκρεμείς` : "Χωρίς εκκρεμείς"}
              style={statusBadgeStyle(pendingResponders > 0 ? "REQUESTED" : "COMPLETED")}
            />
          </div>

          <div style={dispatchLifecycleGrid}>
            {dispatchLifecycleStages.map((stage, index) => (
              <div key={stage.key} style={dispatchLifecycleCardStyle(stage.state)}>
                <div style={dispatchStageIndex}>{index + 1}</div>
                <div style={dispatchStageTitle}>{stage.label}</div>
                <div style={dispatchStageCount}>{stage.count}</div>
                <div style={dispatchStageHelper}>{stage.helper}</div>
                <div style={dispatchStageTime}>{stage.timestamp ? formatDate(stage.timestamp) : "-"}</div>
              </div>
            ))}
          </div>

          <div style={dispatchLifecycleNote}>
            <strong>Έλεγχος lifecycle:</strong> όταν το συμβάν απενεργοποιείται ή κλείνει, οι εκκρεμείς REQUESTED responders πρέπει να μηδενίζονται ή να γίνονται CANCELLED/COMPLETED από το cleanup flow.
          </div>
        </div>

        {responders.length === 0 ? (
          <div style={{ ...emptyState, marginTop: 12 }}>
            Δεν υπάρχουν responders στο dispatch_state για αυτό το συμβάν.
          </div>
        ) : (
          <div style={{ marginTop: 14 }}>
            <div style={sectionHeader}>
              <div>
                <div style={sectionTitle}>Responders</div>
                <div style={sectionHint}>
                  Αναλυτική εικόνα κατάστασης χρηστών. Εμφανίζονται πρώτα όσοι είναι καθ’ οδόν ή έχουν φτάσει.
                </div>
              </div>
              {responders.length > 8 ? (
                <button type="button" style={toggleButton} onClick={() => setShowAllResponders((value) => !value)}>
                  {showAllResponders ? "Λιγότεροι" : `Όλοι (${responders.length})`}
                </button>
              ) : null}
            </div>

            <div style={{ display: "grid", gap: 8 }}>
              {visibleResponders.map((responder) => (
                <div key={responder.userId} style={recordRow}>
                  <div style={recordRowTop}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                      <span style={responderStatusDotStyle(responder.statusKey)} />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 900, wordBreak: "break-word" }}>{responder.displayLabel}</div>
                        <div style={{ marginTop: 3, fontSize: 12, opacity: 0.72 }}>
                          {formatLabel(responder.role)} · {formatLabel(responder.team)}
                        </div>
                      </div>
                    </div>
                    <Pill label={formatLabel(responder.status)} style={statusBadgeStyle(responder.status)} />
                  </div>

                  <div style={recordDetailsGrid}>
                    <div style={recordDetailBox}>
                      <div style={recordMetaLabel}>Απόσταση</div>
                      <div style={recordMetaValue}>{formatMeters(responder.distanceMeters)}</div>
                    </div>
                    <div style={recordDetailBox}>
                      <div style={recordMetaLabel}>Τελευταία ενημέρωση</div>
                      <div style={recordMetaValue}>{formatDate(responder.lastUpdatedAt)}</div>
                    </div>
                    <div style={recordDetailBox}>
                      <div style={recordMetaLabel}>Πηγή</div>
                      <div style={recordMetaValue}>{formatLabel(responder.source)}</div>
                    </div>
                    <div style={recordDetailBox}>
                      <div style={recordMetaLabel}>Playbook / βήμα</div>
                      <div style={recordMetaValue}>{responder.sourcePlaybookId || "-"}{responder.sourceStepId ? ` · ${responder.sourceStepId}` : ""}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      ) : null}

      {showExternal ? (
      <div>
        <div style={sectionHeader}>
          <div>
            <div style={sectionTitle}>External Authorities execution board</div>
            <div style={sectionHint}>
              Επιχειρησιακό board για το τι ζητήθηκε, τι εγκρίθηκε, τι εκτελέστηκε και τι επιβεβαιώθηκε για κάθε εξωτερική αρχή.
            </div>
          </div>
          <Pill label={externalStats.open > 0 ? `${externalStats.open} ανοικτές ενέργειες` : "Χωρίς ανοικτές ενέργειες"} style={statusBadgeStyle(externalStats.open > 0 ? "REQUESTED" : "COMPLETED")} />
        </div>

        {authorityGroups.length === 0 ? (
          <div style={emptyState}>
            Δεν υπάρχουν ενέργειες εξωτερικών αρχών για το επιλεγμένο συμβάν.
          </div>
        ) : (
          <div style={externalBoardGrid}>
            {externalExecutionBoard.map((column) => (
              <div key={column.key} style={externalBoardColumn}>
                <div style={externalBoardColumnHeader}>
                  <div>
                    <div style={externalBoardColumnTitle}>{column.title}</div>
                    <div style={externalBoardColumnHint}>{column.helper}</div>
                  </div>
                  <Pill label={String(column.items.length)} style={statusBadgeStyle(column.statusForTone)} />
                </div>

                {column.items.length === 0 ? (
                  <div style={externalBoardEmpty}>Καμία εγγραφή</div>
                ) : (
                  <div style={{ display: "grid", gap: 10 }}>
                    {column.items.map((group) => (
                      <button
                        key={`${column.key}-${group.key}`}
                        type="button"
                        style={externalBoardCard}
                        onClick={() => setExpandedAuthorityKey(group.key)}
                      >
                        <div style={externalBoardCardTop}>
                          <div style={externalBoardCardTitle}>{group.authorityLabel}</div>
                          <Pill label={formatLabel(group.latestStatus)} style={statusBadgeStyle(group.latestStatus)} />
                        </div>
                        <div style={externalBoardMeta}>
                          {formatLabel(group.authorityType)}{group.channel ? ` · ${formatLabel(group.channel)}` : ""}
                        </div>
                        <div style={externalBoardMeta}>{getAuthorityContactLabel(group)}</div>
                        <div style={externalBoardActionHint}>{getAuthorityActionHint(group)}</div>
                        <div style={externalBoardFooter}>
                          <span>{formatDate(group.latestUpdatedAt || group.latestExecutedAt || group.latestApprovedAt)}</span>
                          <span>{group.canonicalItems.length ? "canonical" : "legacy"}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      ) : null}

      {showExternal ? (
      <div>
        <div style={sectionHeader}>
          <div>
            <div style={sectionTitle}>Εξωτερικές αρχές - αναλυτικές εγγραφές</div>
            <div style={sectionHint}>
              Συνοπτική εικόνα ειδοποιήσεων προς ΕΚΑΒ, Πυροσβεστική, Αστυνομία, Πολιτική Προστασία ή άλλη αρμόδια αρχή.
            </div>
          </div>
          <Pill label={externalStats.open > 0 ? `${externalStats.open} ανοικτές` : "Χωρίς ανοικτές"} style={statusBadgeStyle(externalStats.open > 0 ? "REQUESTED" : "COMPLETED")} />
        </div>

        <div style={mainGridFour}>
          {chip("Αρχές", String(externalStats.authorities))}
          {chip("Αιτήματα", String(externalStats.requested))}
          {chip("Εγκρίθηκαν / στάλθηκαν", String(externalStats.approved + externalStats.sent))}
          {chip("Επιβεβαιώθηκαν", String(externalStats.acknowledged))}
        </div>

        <div style={mainGridFour}>
          {chip("Σύνολο εγγραφών", String(externalStats.total))}
          {chip("Canonical", String(externalStats.canonical), "Κύρια εγγραφή workflow")}
          {chip("Legacy", String(externalStats.legacy), "Συμβατότητα με παλαιότερη δομή")}
          {chip("Απέτυχαν / απορρίφθηκαν", String(externalStats.failed))}
        </div>

        {authorityGroups.length === 0 ? (
          <div style={emptyState}>
            Δεν υπάρχουν εγγραφές εξωτερικών αρχών για αυτό το συμβάν. Αν η πολιτική απαιτεί external authorities, ελέγξτε το policy και τα flags του συμβάντος.
          </div>
        ) : (
          <div style={{ display: "grid", gap: 12 }}>
            {authorityGroups.map((group) => {
              const expanded = expandedAuthorityKey === group.key;

              return (
                <div key={group.key} style={authorityCard}>
                  <div style={authorityHeader}>
                    <div style={{ minWidth: 0 }}>
                      <div style={authorityTitleRow}>
                        <div style={authorityTitle}>{group.authorityLabel}</div>
                        <Pill label={formatLabel(group.latestStatus)} style={statusBadgeStyle(group.latestStatus)} />
                      </div>

                      <div style={authorityMeta}>
                        {formatLabel(group.authorityType)}
                        {group.authorityId ? ` · ${group.authorityId}` : ""}
                        {group.channel ? ` · ${formatLabel(group.channel)}` : ""}
                        {group.mode ? ` · ${formatLabel(group.mode)}` : ""}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setExpandedAuthorityKey(expanded ? null : group.key)}
                      style={toggleButton}
                    >
                      {expanded ? "Απόκρυψη λεπτομερειών" : "Προβολή λεπτομερειών"}
                    </button>
                  </div>

                  <div style={mainGridFourCompact}>
                    <div style={miniBox}><div style={miniLabel}>Canonical</div><div style={miniValue}>{group.canonicalItems.length}</div></div>
                    <div style={miniBox}><div style={miniLabel}>Legacy</div><div style={miniValue}>{group.legacyItems.length}</div></div>
                    <div style={miniBox}><div style={miniLabel}>Ενημερώθηκε</div><div style={miniValueSmall}>{formatDate(group.latestUpdatedAt)}</div></div>
                    <div style={miniBox}><div style={miniLabel}>Επιβεβαίωση λήψης</div><div style={miniValueSmall}>{formatDate(group.latestAcknowledgedAt)}</div></div>
                  </div>

                  <div style={threeGrid}>
                    <div style={infoPanel}><div style={infoPanelLabel}>Έγκριση</div><div style={infoPanelValue}>{formatDate(group.latestApprovedAt)}</div></div>
                    <div style={infoPanel}><div style={infoPanelLabel}>Εκτέλεση ειδοποίησης</div><div style={infoPanelValue}>{formatDate(group.latestExecutedAt)}</div></div>
                    <div style={infoPanel}><div style={infoPanelLabel}>Τελευταία σημείωση</div><div style={infoPanelValue}>{group.latestNotes || "-"}</div></div>
                  </div>

                  {expanded ? (
                    <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
                      {group.allItems.map((item) => (
                        <div key={item.id} style={recordRow}>
                          <div style={recordRowTop}>
                            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                              <Pill label={formatLabel(item.recordKind)} style={kindBadgeStyle(item.recordKind)} />
                              <Pill label={formatLabel(item.status)} style={statusBadgeStyle(item.status)} />
                            </div>
                            <div style={recordDate}>{formatDate(safeTime(item))}</div>
                          </div>

                          <div style={recordMetaGrid}>
                            <div style={recordMetaItem}>
                              <div style={recordMetaLabel}>ID εγγραφής</div>
                              <div style={recordMetaValueMono}>{item.id}</div>
                            </div>
                            <div style={recordMetaItem}>
                              <div style={recordMetaLabel}>Διαδρομή δεδομένων</div>
                              <div style={recordMetaValueMono}>{item.dataPath || "-"}</div>
                            </div>
                            <div style={recordMetaItem}>
                              <div style={recordMetaLabel}>Playbook / βήμα</div>
                              <div style={recordMetaValue}>
                                {item.playbookTitle || item.playbookId || "-"}
                                {item.stepTitle ? ` · ${item.stepTitle}` : ""}
                              </div>
                            </div>
                            <div style={recordMetaItem}>
                              <div style={recordMetaLabel}>Κανάλι / τρόπος</div>
                              <div style={recordMetaValue}>
                                {formatLabel(item.channel)}
                                {item.mode ? ` · ${formatLabel(item.mode)}` : ""}
                              </div>
                            </div>
                          </div>

                          <div style={recordDetailsGrid}>
                            <div style={recordDetailBox}>
                              <div style={recordMetaLabel}>Έγκριση</div>
                              <div style={recordMetaValue}>
                                {formatLabel(item.approval?.status)} · {formatDate(item.approvedAt ?? item.approval?.approvedAt ?? item.approval?.decisionAt)}
                              </div>
                            </div>
                            <div style={recordDetailBox}>
                              <div style={recordMetaLabel}>Εκτέλεση</div>
                              <div style={recordMetaValue}>
                                {formatLabel(item.execution?.status)} · {formatDate(item.executedAt ?? item.execution?.executedAt)}
                              </div>
                            </div>
                            <div style={recordDetailBox}>
                              <div style={recordMetaLabel}>Επιβεβαίωση λήψης</div>
                              <div style={recordMetaValue}>
                                {formatLabel(item.acknowledgement?.status)} · {formatDate(item.acknowledgedAt ?? item.acknowledgement?.receivedAt ?? item.acknowledgement?.acknowledgedAt)}
                              </div>
                            </div>
                          </div>

                          {(item.notes || item.resultNotes || item.execution?.resultNotes || item.acknowledgement?.notes || item.approval?.rejectionReason) ? (
                            <div style={recordNotes}>
                              <strong>Σημείωση:</strong>{" "}
                              {pickString(
                                item.notes,
                                item.resultNotes,
                                item.execution?.resultNotes,
                                item.acknowledgement?.notes,
                                item.approval?.rejectionReason
                              )}
                            </div>
                          ) : null}
                        </div>
                      ))}
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </div>
      ) : null}
    </div>
  );
}

const panel: React.CSSProperties = {
  border: "1px solid var(--border)",
  borderRadius: 16,
  padding: 16,
  background: "var(--surface)",
  display: "grid",
  gap: 16,
};

const banner: React.CSSProperties = {
  borderRadius: 14,
  padding: 14,
};

const bannerTitle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 900,
  marginBottom: 5,
};

const bannerText: React.CSSProperties = {
  fontSize: 13,
  lineHeight: 1.45,
};

const title: React.CSSProperties = {
  marginTop: 0,
  marginBottom: 4,
  fontSize: 18,
};

const incidentTitle: React.CSSProperties = {
  fontWeight: 800,
  fontSize: 18,
  lineHeight: 1.35,
};

const idText: React.CSSProperties = {
  marginTop: 4,
  opacity: 0.72,
  wordBreak: "break-word",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
  fontSize: 12,
};

const chipCard: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 12,
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
};

const chipLabel: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
};

const chipValue: React.CSSProperties = {
  marginTop: 4,
  fontWeight: 800,
  lineHeight: 1.35,
  wordBreak: "break-word",
};

const chipHelper: React.CSSProperties = {
  marginTop: 5,
  fontSize: 11,
  opacity: 0.62,
  lineHeight: 1.35,
};

const mainGrid: React.CSSProperties = {
  display: "grid",
  gap: 12,
  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
};

const mainGridFour: React.CSSProperties = {
  display: "grid",
  gap: 12,
  gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
  marginTop: 12,
  marginBottom: 14,
};

const mainGridFourCompact: React.CSSProperties = {
  display: "grid",
  gap: 10,
  gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
  marginTop: 12,
};

const threeGrid: React.CSSProperties = {
  display: "grid",
  gap: 10,
  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
  marginTop: 12,
};

const detailGrid: React.CSSProperties = {
  marginTop: 16,
  display: "grid",
  gap: 6,
  fontSize: 13,
  lineHeight: 1.45,
};

const descriptionBox: React.CSSProperties = {
  marginTop: 16,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
};

const descriptionText: React.CSSProperties = {
  marginTop: 6,
  opacity: 0.88,
  lineHeight: 1.5,
};

const guidanceBox: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid rgba(59,130,246,0.25)",
  background: "rgba(59,130,246,0.08)",
  padding: 14,
};

const guidanceList: React.CSSProperties = {
  margin: "10px 0 0",
  paddingLeft: 20,
  display: "grid",
  gap: 6,
  fontSize: 13,
  lineHeight: 1.45,
};

const closurePanel: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid rgba(16,185,129,0.18)",
  background: "rgba(16,185,129,0.045)",
  padding: 14,
};

const closureSummaryGrid: React.CSSProperties = {
  display: "grid",
  gap: 10,
  gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
  marginTop: 12,
};

const closureChecklistGrid: React.CSSProperties = {
  display: "grid",
  gap: 10,
  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
  marginTop: 12,
};

const closureCheckCard: React.CSSProperties = {
  borderRadius: 14,
  padding: 12,
  minHeight: 150,
};

const closureCheckTop: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 10,
};

const closureCheckIndex: React.CSSProperties = {
  width: 24,
  height: 24,
  borderRadius: 999,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  background: "rgba(0,0,0,0.18)",
  fontSize: 12,
  fontWeight: 900,
};

const closureCheckTitle: React.CSSProperties = {
  marginTop: 10,
  fontWeight: 950,
  lineHeight: 1.3,
};

const closureCheckValue: React.CSSProperties = {
  marginTop: 6,
  fontSize: 12,
  fontWeight: 800,
  lineHeight: 1.35,
};

const closureCheckDescription: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  lineHeight: 1.42,
  opacity: 0.86,
};

const closureActionBox: React.CSSProperties = {
  marginTop: 12,
  padding: 10,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 12,
  lineHeight: 1.45,
};

const closureForm: React.CSSProperties = {
  marginTop: 12,
  display: "grid",
  gap: 8,
};

const closureFormLabel: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 900,
};

const closureTextArea: React.CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: 10,
  font: "inherit",
  resize: "vertical",
};

const primaryButton: React.CSSProperties = {
  justifySelf: "start",
  borderRadius: 12,
  border: "1px solid #0f766e",
  background: "#0f766e",
  color: "#fff",
  padding: "9px 14px",
  cursor: "pointer",
  fontWeight: 900,
};

const closureResultBox: React.CSSProperties = {
  marginTop: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  padding: 12,
};

const closureResultList: React.CSSProperties = {
  margin: "8px 0 0 18px",
  padding: 0,
  lineHeight: 1.5,
};

const dispatchLifecyclePanel: React.CSSProperties = {
  marginTop: 14,
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 14,
};

const dispatchLifecycleGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(135px, 1fr))",
  gap: 10,
  marginTop: 12,
};

const dispatchStageIndex: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.7,
};

const dispatchStageTitle: React.CSSProperties = {
  marginTop: 4,
  fontSize: 13,
  fontWeight: 900,
};

const dispatchStageCount: React.CSSProperties = {
  marginTop: 8,
  fontSize: 28,
  lineHeight: 1,
  fontWeight: 950,
};

const dispatchStageHelper: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  lineHeight: 1.35,
  opacity: 0.86,
};

const dispatchStageTime: React.CSSProperties = {
  marginTop: 8,
  fontSize: 11,
  opacity: 0.7,
};

const dispatchLifecycleNote: React.CSSProperties = {
  marginTop: 12,
  padding: 10,
  borderRadius: 12,
  border: "1px solid rgba(59,130,246,0.22)",
  background: "rgba(59,130,246,0.08)",
  fontSize: 12,
  lineHeight: 1.45,
};

const sectionTitle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 900,
  marginBottom: 4,
};

const sectionHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  marginBottom: 10,
  flexWrap: "wrap",
};

const sectionHint: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
  lineHeight: 1.4,
};

const emptyState: React.CSSProperties = {
  padding: 14,
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 13,
  opacity: 0.82,
};


const externalBoardGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
  gap: 12,
  alignItems: "stretch",
};

const externalBoardColumn: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 12,
  minHeight: 150,
};

const externalBoardColumnHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 10,
  alignItems: "flex-start",
  marginBottom: 12,
};

const externalBoardColumnTitle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 900,
  lineHeight: 1.25,
};

const externalBoardColumnHint: React.CSSProperties = {
  marginTop: 4,
  fontSize: 11,
  lineHeight: 1.35,
  opacity: 0.68,
};

const externalBoardCard: React.CSSProperties = {
  width: "100%",
  textAlign: "left",
  color: "inherit",
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 10,
  cursor: "pointer",
};

const externalBoardCardTop: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 8,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const externalBoardCardTitle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 900,
  lineHeight: 1.3,
};

const externalBoardMeta: React.CSSProperties = {
  marginTop: 6,
  fontSize: 11,
  lineHeight: 1.35,
  opacity: 0.7,
  wordBreak: "break-word",
};

const externalBoardActionHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  lineHeight: 1.4,
  opacity: 0.9,
};

const externalBoardFooter: React.CSSProperties = {
  marginTop: 10,
  paddingTop: 8,
  borderTop: "1px solid var(--border)",
  display: "flex",
  justifyContent: "space-between",
  gap: 8,
  fontSize: 11,
  opacity: 0.65,
};

const externalBoardEmpty: React.CSSProperties = {
  borderRadius: 12,
  border: "1px dashed var(--border)",
  padding: 12,
  fontSize: 12,
  opacity: 0.6,
};

const authorityCard: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 14,
};

const authorityHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const authorityTitleRow: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  flexWrap: "wrap",
};

const authorityTitle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 900,
};

const authorityMeta: React.CSSProperties = {
  marginTop: 6,
  fontSize: 12,
  opacity: 0.72,
  wordBreak: "break-word",
};

const toggleButton: React.CSSProperties = {
  borderRadius: 10,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 12px",
  cursor: "pointer",
};

const miniBox: React.CSSProperties = {
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 10,
};

const miniLabel: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.68,
  marginBottom: 4,
};

const miniValue: React.CSSProperties = {
  fontSize: 20,
  fontWeight: 900,
};

const miniValueSmall: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  lineHeight: 1.4,
};

const infoPanel: React.CSSProperties = {
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 10,
};

const infoPanelLabel: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.68,
  marginBottom: 4,
};

const infoPanelValue: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.45,
  wordBreak: "break-word",
};

const recordRow: React.CSSProperties = {
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 12,
  display: "grid",
  gap: 10,
};

const recordRowTop: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 12,
  flexWrap: "wrap",
};

const recordDate: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
};

const recordMetaGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
  gap: 10,
};

const recordMetaItem: React.CSSProperties = {
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  padding: 10,
};

const recordMetaLabel: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.68,
  marginBottom: 4,
};

const recordMetaValue: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.45,
  wordBreak: "break-word",
};

const recordMetaValueMono: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.45,
  wordBreak: "break-word",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
};

const recordDetailsGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
  gap: 10,
};

const recordDetailBox: React.CSSProperties = {
  borderRadius: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
  padding: 10,
};

const recordNotes: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.5,
  opacity: 0.88,
};


const incidentPhotoPanel: React.CSSProperties = {
  borderRadius: 16,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 14,
  display: "grid",
  gap: 12,
};

const incidentPhotoHeader: React.CSSProperties = {
  display: "flex",
  alignItems: "flex-start",
  justifyContent: "space-between",
  gap: 12,
  flexWrap: "wrap",
};

const incidentPhotoLink: React.CSSProperties = {
  display: "block",
  borderRadius: 14,
  overflow: "hidden",
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
};

const incidentPhotoImage: React.CSSProperties = {
  display: "block",
  width: "100%",
  maxHeight: 420,
  objectFit: "contain",
  background: "#020617",
};

const incidentPhotoCaption: React.CSSProperties = {
  fontSize: 13,
  lineHeight: 1.5,
  opacity: 0.86,
};

const incidentPhotoPath: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.52,
  wordBreak: "break-word",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
};

const pillBase: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};
