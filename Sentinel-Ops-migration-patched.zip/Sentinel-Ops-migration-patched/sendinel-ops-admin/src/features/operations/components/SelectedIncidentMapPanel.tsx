import { Fragment, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import {
  CircleMarker,
  LayersControl,
  MapContainer,
  Marker,
  Polyline,
  Popup,
  TileLayer,
  Tooltip,
} from "react-leaflet";
import L from "leaflet";
import type { IncidentRecord } from "../../../domain/models/incident";
import type { DispatchState, DispatchResponder } from "../../../domain/models/dispatch";

type Props = {
  incident: IncidentRecord | null;
  dispatch?: DispatchState | null;
};

type ResponderMapFilter = "ACTIVE" | "ALL" | "STALE";

const STALE_AFTER_MS = 5 * 60 * 1000;

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function normalizeStatus(status?: string) {
  return (status || "").toUpperCase();
}

function formatMeters(value?: number) {
  if (typeof value !== "number" || Number.isNaN(value)) return "-";
  if (value >= 1000) return `${(value / 1000).toFixed(1)} km`;
  return `${Math.round(value)} m`;
}

function isStale(responder: DispatchResponder) {
  if (!responder.lastUpdatedAt) return false;
  return Date.now() - responder.lastUpdatedAt > STALE_AFTER_MS;
}

function responderColor(status?: string, stale?: boolean) {
  if (stale) return "#64748b";

  switch (normalizeStatus(status)) {
    case "RESPONDING":
      return "#2563eb";
    case "ARRIVED":
      return "#16a34a";
    case "COMPLETED":
      return "#0f766e";
    case "CANCELLED":
      return "#dc2626";
    case "REQUESTED":
      return "#7c3aed";
    default:
      return "#7c3aed";
  }
}

function statusLabel(status?: string) {
  switch (normalizeStatus(status)) {
    case "REQUESTED":
      return "Ζητήθηκε";
    case "RESPONDING":
      return "Κατευθύνεται";
    case "ARRIVED":
      return "Έφτασε";
    case "COMPLETED":
      return "Ολοκληρώθηκε";
    case "CANCELLED":
      return "Ακυρώθηκε";
    default:
      return status || "-";
  }
}

function statusBadgeStyle(status?: string, stale?: boolean): CSSProperties {
  return {
    display: "inline-block",
    padding: "4px 8px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 700,
    color: "#fff",
    background: responderColor(status, stale),
  };
}

function incidentIcon(status?: string) {
  const normalized = normalizeStatus(status);
  const color = normalized === "CLOSED" || normalized === "DEACTIVATED" ? "#64748b" : "#f59e0b";

  return L.divIcon({
    className: "",
    html: `
      <div style="
        width:24px;
        height:24px;
        border-radius:50%;
        background:${color};
        border:3px solid #fff;
        box-shadow:0 0 0 2px rgba(0,0,0,0.35), 0 0 22px rgba(245,158,11,0.5);
      "></div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
}

function responderIcon(status?: string, isClosest?: boolean, stale?: boolean) {
  const color = responderColor(status, stale);
  const size = isClosest ? 24 : 18;
  const border = isClosest ? 3 : 2;
  const opacity = stale ? 0.72 : 1;

  return L.divIcon({
    className: "",
    html: `
      <div style="
        width:${size}px;
        height:${size}px;
        border-radius:50%;
        background:${color};
        opacity:${opacity};
        border:${border}px solid #fff;
        box-shadow:0 0 0 2px rgba(0,0,0,0.25);
      "></div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

function getResponders(dispatch?: DispatchState | null): DispatchResponder[] {
  if (!dispatch?.responders) return [];

  return Object.entries(dispatch.responders).map(([userId, value]) => ({
    ...value,
    userId: value.userId || userId,
  }));
}

function hasCoords(lat?: number, lng?: number) {
  return typeof lat === "number" && typeof lng === "number";
}

function isOperationallyActive(status?: string) {
  const s = normalizeStatus(status);
  return s === "RESPONDING" || s === "ARRIVED";
}

function countByStatus(responders: DispatchResponder[]) {
  return responders.reduce<Record<string, number>>((acc, responder) => {
    const key = normalizeStatus(responder.status) || "UNKNOWN";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
}

function countByTeam(responders: DispatchResponder[]) {
  return responders.reduce<Record<string, number>>((acc, responder) => {
    const key = responder.team || "Χωρίς ομάδα";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
}

function sortResponders(responders: DispatchResponder[]) {
  return [...responders].sort((a, b) => {
    const staleA = isStale(a) ? 1 : 0;
    const staleB = isStale(b) ? 1 : 0;
    if (staleA !== staleB) return staleA - staleB;

    const distanceA = typeof a.distanceMeters === "number" ? a.distanceMeters : Number.MAX_SAFE_INTEGER;
    const distanceB = typeof b.distanceMeters === "number" ? b.distanceMeters : Number.MAX_SAFE_INTEGER;
    return distanceA - distanceB;
  });
}

export function SelectedIncidentMapPanel({ incident, dispatch }: Props) {
  const [responderFilter, setResponderFilter] = useState<ResponderMapFilter>("ACTIVE");
  const [showResponderLines, setShowResponderLines] = useState(true);
  const [showOperationalRadius, setShowOperationalRadius] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState("");

  const incidentLat = incident?.latitude;
  const incidentLng = incident?.longitude;
  const closestResponderId = dispatch?.closestResponderId || null;

  const allRespondersWithCoords = useMemo(() => {
    return getResponders(dispatch).filter((item) => hasCoords(item.latitude, item.longitude));
  }, [dispatch]);

  const availableTeams = useMemo(() => {
    return [...new Set(allRespondersWithCoords.map((item) => item.team).filter(Boolean) as string[])].sort();
  }, [allRespondersWithCoords]);

  const responders = useMemo(() => {
    const teamFiltered = selectedTeam
      ? allRespondersWithCoords.filter((item) => item.team === selectedTeam)
      : allRespondersWithCoords;

    const statusFiltered = teamFiltered.filter((item) => {
      if (responderFilter === "ALL") return true;
      if (responderFilter === "STALE") return isStale(item);
      return isOperationallyActive(item.status);
    });

    return sortResponders(statusFiltered);
  }, [allRespondersWithCoords, responderFilter, selectedTeam]);

  const statusCounts = useMemo(() => countByStatus(allRespondersWithCoords), [allRespondersWithCoords]);
  const teamCounts = useMemo(() => countByTeam(allRespondersWithCoords), [allRespondersWithCoords]);
  const staleCount = useMemo(() => allRespondersWithCoords.filter(isStale).length, [allRespondersWithCoords]);

  if (!incident) {
    return <p>Επίλεξε incident για χάρτη</p>;
  }

  if (!hasCoords(incidentLat, incidentLng)) {
    return <p>Το επιλεγμένο incident δεν έχει συντεταγμένες</p>;
  }

  return (
    <div
      style={{
        border: "1px solid var(--border)",
        borderRadius: 16,
        overflow: "hidden",
        background: "var(--surface)",
      }}
    >
      <div style={{ padding: 14, borderBottom: "1px solid var(--border)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start" }}>
          <div>
            <div style={{ fontWeight: 700 }}>Incident Map Overlays</div>
            <div style={{ marginTop: 4, fontSize: 13, opacity: 0.75 }}>
              Επιχειρησιακός χάρτης με incident, responders, αποστάσεις, teams και stale ένδειξη.
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <span style={statusBadgeStyle("REQUESTED")}>Ζητήθηκαν {statusCounts.REQUESTED || 0}</span>
            <span style={statusBadgeStyle("RESPONDING")}>Κατευθύνονται {statusCounts.RESPONDING || 0}</span>
            <span style={statusBadgeStyle("ARRIVED")}>Έφτασαν {statusCounts.ARRIVED || 0}</span>
            <span style={statusBadgeStyle("COMPLETED")}>Ολοκληρώθηκαν {statusCounts.COMPLETED || 0}</span>
            {staleCount > 0 ? <span style={statusBadgeStyle("", true)}>Stale {staleCount}</span> : null}
          </div>
        </div>

        <div
          style={{
            marginTop: 12,
            display: "grid",
            gap: 10,
            gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          }}
        >
          <div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Incident</div>
            <div style={{ fontWeight: 600 }}>{incident.id}</div>
          </div>
          <div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Κατηγορία</div>
            <div style={{ fontWeight: 600 }}>{incident.category || "-"}</div>
          </div>
          <div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Κατάσταση</div>
            <div style={{ fontWeight: 600 }}>{incident.status || "-"}</div>
          </div>
          <div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Responders στον χάρτη</div>
            <div style={{ fontWeight: 600 }}>{responders.length}</div>
          </div>
        </div>

        <div
          style={{
            marginTop: 12,
            display: "flex",
            gap: 10,
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <label style={{ display: "grid", gap: 4, fontSize: 13 }}>
            Προβολή responders
            <select
              value={responderFilter}
              onChange={(event) => setResponderFilter(event.target.value as ResponderMapFilter)}
              style={{ minWidth: 180, padding: 8, borderRadius: 10 }}
            >
              <option value="ACTIVE">Μόνο ενεργοί</option>
              <option value="ALL">Όλοι με θέση</option>
              <option value="STALE">Μόνο stale</option>
            </select>
          </label>

          <label style={{ display: "grid", gap: 4, fontSize: 13 }}>
            Ομάδα
            <select
              value={selectedTeam}
              onChange={(event) => setSelectedTeam(event.target.value)}
              style={{ minWidth: 190, padding: 8, borderRadius: 10 }}
            >
              <option value="">Όλες οι ομάδες</option>
              {availableTeams.map((team) => (
                <option key={team} value={team}>
                  {team} ({teamCounts[team] || 0})
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 18, fontSize: 14 }}>
            <input
              type="checkbox"
              checked={showResponderLines}
              onChange={(event) => setShowResponderLines(event.target.checked)}
            />
            Γραμμές προς συμβάν
          </label>

          <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 18, fontSize: 14 }}>
            <input
              type="checkbox"
              checked={showOperationalRadius}
              onChange={(event) => setShowOperationalRadius(event.target.checked)}
            />
            Επιχειρησιακή ακτίνα
          </label>
        </div>
      </div>

      <div style={{ height: 500, position: "relative" }}>
        <MapContainer
          center={[incidentLat!, incidentLng!]}
          zoom={15}
          style={{ height: "100%", width: "100%" }}
          scrollWheelZoom={true}
        >
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="OpenStreetMap">
              <TileLayer
                attribution="&copy; OpenStreetMap contributors"
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
            </LayersControl.BaseLayer>

            <LayersControl.BaseLayer name="Esri Satellite">
              <TileLayer
                attribution="Tiles &copy; Esri"
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              />
            </LayersControl.BaseLayer>
          </LayersControl>

          {showOperationalRadius ? (
            <>
              <CircleMarker
                center={[incidentLat!, incidentLng!]}
                radius={36}
                pathOptions={{
                  color: "#f59e0b",
                  weight: 2,
                  fillColor: "#f59e0b",
                  fillOpacity: 0.08,
                }}
              >
                <Tooltip direction="top">Ζώνη άμεσης προσοχής</Tooltip>
              </CircleMarker>
              <CircleMarker
                center={[incidentLat!, incidentLng!]}
                radius={72}
                pathOptions={{
                  color: "#f59e0b",
                  weight: 1,
                  dashArray: "6 6",
                  fillColor: "#f59e0b",
                  fillOpacity: 0.035,
                }}
              >
                <Tooltip direction="top">Ευρύτερη επιχειρησιακή ζώνη</Tooltip>
              </CircleMarker>
            </>
          ) : null}

          <Marker position={[incidentLat!, incidentLng!]} icon={incidentIcon(incident.status)}>
            <Popup>
              <div>
                <strong>Incident</strong>
                <div>ID: {incident.id}</div>
                <div>Category: {incident.category || "-"}</div>
                <div>Status: {incident.status || "-"}</div>
                <div>Severity: {incident.severity || "-"}</div>
                <div>Site: {incident.siteId || "-"}</div>
              </div>
            </Popup>
            <Tooltip direction="top" offset={[0, -12]} permanent>
              {incident.category || "Incident"}
            </Tooltip>
          </Marker>

          {responders.map((responder) => {
            const stale = isStale(responder);
            const isClosest = responder.userId === closestResponderId;
            const lineColor = responderColor(responder.status, stale);

            return (
              <Fragment key={responder.userId}>
                {showResponderLines ? (
                  <Polyline
                    positions={[
                      [incidentLat!, incidentLng!],
                      [responder.latitude!, responder.longitude!],
                    ]}
                    pathOptions={{
                      color: lineColor,
                      weight: isClosest ? 3 : 2,
                      opacity: stale ? 0.35 : 0.58,
                      dashArray: normalizeStatus(responder.status) === "ARRIVED" ? undefined : "6 8",
                    }}
                  />
                ) : null}

                <Marker
                  position={[responder.latitude!, responder.longitude!]}
                  icon={responderIcon(responder.status, isClosest, stale)}
                >
                  <Popup>
                    <div style={{ minWidth: 240 }}>
                      <div style={{ fontWeight: 700 }}>{responder.displayName || responder.userId}</div>

                      <div style={{ marginTop: 8 }}>
                        <span style={statusBadgeStyle(responder.status, stale)}>
                          {stale ? "Stale" : statusLabel(responder.status)}
                        </span>
                        {isClosest ? (
                          <span
                            style={{
                              marginLeft: 8,
                              display: "inline-block",
                              padding: "4px 8px",
                              borderRadius: 999,
                              fontSize: 12,
                              fontWeight: 700,
                              background: "#f59e0b",
                              color: "#111827",
                            }}
                          >
                            Πλησιέστερος
                          </span>
                        ) : null}
                      </div>

                      <div style={{ marginTop: 10, fontSize: 14 }}>
                        <div>
                          <strong>Role:</strong> {responder.role || "-"}
                        </div>
                        <div>
                          <strong>Team:</strong> {responder.team || "-"}
                        </div>
                        <div>
                          <strong>Distance:</strong> {formatMeters(responder.distanceMeters)}
                        </div>
                        <div>
                          <strong>Source:</strong> {responder.source || "-"}
                        </div>
                        <div>
                          <strong>Updated:</strong> {formatDate(responder.lastUpdatedAt)}
                        </div>
                      </div>
                    </div>
                  </Popup>
                  <Tooltip direction="top" offset={[0, -10]}>
                    {responder.displayName || responder.userId} · {statusLabel(responder.status)}
                  </Tooltip>
                </Marker>
              </Fragment>
            );
          })}
        </MapContainer>
      </div>

      <div style={{ padding: 14, borderTop: "1px solid var(--border)" }}>
        <div style={{ fontSize: 13, opacity: 0.85, display: "flex", gap: 16, flexWrap: "wrap" }}>
          <span>
            <strong>Legend:</strong>
          </span>
          <span style={{ color: "#f59e0b" }}>● Incident</span>
          <span style={{ color: "#7c3aed" }}>● Ζητήθηκε</span>
          <span style={{ color: "#2563eb" }}>● Κατευθύνεται</span>
          <span style={{ color: "#16a34a" }}>● Έφτασε</span>
          <span style={{ color: "#0f766e" }}>● Ολοκληρώθηκε</span>
          <span style={{ color: "#dc2626" }}>● Ακυρώθηκε</span>
          <span style={{ color: "#64748b" }}>● Stale</span>
          <span style={{ color: "#f59e0b" }}>● Πλησιέστερος responder</span>
        </div>
      </div>
    </div>
  );
}
