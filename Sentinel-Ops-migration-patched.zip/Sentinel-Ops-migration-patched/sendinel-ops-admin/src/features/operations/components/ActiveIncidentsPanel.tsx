type Props = {
  items: any[];
  selectedId: string | null;
  onSelect: (id: string) => void;
};

function formatDate(value?: number) {
  if (!value) return "-";

  try {
    return new Date(value).toLocaleString("el-GR");
  } catch {
    return "-";
  }
}

function badgeStyle(color: string): React.CSSProperties {
  return {
    padding: "4px 8px",
    borderRadius: 999,
    background: color,
    color: "white",
    fontSize: 11,
    fontWeight: 700,
    display: "inline-flex",
    alignItems: "center",
  };
}

export function ActiveIncidentsPanel({
  items,
  selectedId,
  onSelect,
}: Props) {
  if (!items.length) {
    return (
      <p>
        Δεν υπάρχουν ενεργά συμβάντα για τα
        επιλεγμένα φίλτρα.
      </p>
    );
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {items.map((item: any) => {
        const selected = item.id === selectedId;
        const status = String(item.status || "").toUpperCase();
        const pendingClosure = status === "DEACTIVATED";

        return (
          <button
            key={item.id}
            onClick={() => onSelect(item.id)}
            style={{
              textAlign: "left",
              padding: 16,
              borderRadius: 16,
              border: selected
                ? "1px solid rgba(72,126,255,0.7)"
                : "1px solid var(--border)",
              background: selected
                ? "rgba(72,126,255,0.12)"
                : "var(--surface)",
              cursor: "pointer",
              color: "inherit",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                gap: 12,
              }}
            >
              <div>
                <div
                  style={{
                    fontWeight: 800,
                    fontSize: 15,
                  }}
                >
                  {item.title ||
                    item.category ||
                    item.id}
                </div>

                <div
                  style={{
                    marginTop: 4,
                    fontSize: 12,
                    opacity: 0.7,
                  }}
                >
                  Incident ID: {item.id}
                </div>
              </div>

              <div
                style={{
                  textAlign: "right",
                  fontSize: 12,
                  opacity: 0.75,
                }}
              >
                {formatDate(item.createdAt)}
              </div>
            </div>

            <div
              style={{
                marginTop: 12,
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
              }}
            >
              <span style={badgeStyle("#1f4b99")}>
                {item.siteId || "-"}
              </span>

              <span style={badgeStyle("#7b3fe4")}>
                {item.category || "-"}
              </span>

              <span style={badgeStyle("#b26b00")}>
                Κατάσταση:
                {" "}
                {pendingClosure ? "Προς οριστικό κλείσιμο" : item.status || "-"}
              </span>

              <span style={badgeStyle("#0f766e")}>
                Verification:
                {" "}
                {item.verificationStatus || "-"}
              </span>
            </div>

            <div
              style={{
                marginTop: 10,
                fontSize: 12,
                opacity: 0.72,
                lineHeight: 1.45,
              }}
            >
              {pendingClosure
                ? "Το ΣΑΕΚ έχει απενεργοποιηθεί και το συμβάν παραμένει εδώ μέχρι το formal closure."
                : "Ζωντανή επιχειρησιακή εικόνα συμβάντος, responders, timeline, εξωτερικών ειδοποιήσεων και κατάστασης αντιμετώπισης."}
            </div>
          </button>
        );
      })}
    </div>
  );
}