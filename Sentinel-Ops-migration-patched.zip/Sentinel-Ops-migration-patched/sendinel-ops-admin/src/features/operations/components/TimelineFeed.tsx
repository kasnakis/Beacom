import { getBadgeStyle } from "../utils/statusBadge";
import type { IncidentEventRecord } from "../../../domain/models/incidentEvent";

type Props = {
  items: IncidentEventRecord[];
};

type Tone = {
  badge: React.CSSProperties;
  border: string;
  glow: string;
  label: string;
};

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function asRecord(value: unknown): Record<string, unknown> {
  if (value && typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return {};
}

function getEventObject(item: IncidentEventRecord): Record<string, unknown> {
  return item as unknown as Record<string, unknown>;
}

function getPayload(item: IncidentEventRecord): Record<string, unknown> {
  const raw = getEventObject(item);

  return asRecord(
    raw.payload ??
      raw.extra ??
      raw.data ??
      raw.details ??
      raw.metadata ??
      raw.context ??
      raw.eventData
  );
}

function pickString(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return undefined;
}

function pickNumber(...values: unknown[]): number | undefined {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
  }
  return undefined;
}

function normalizeKey(value?: string) {
  return (value || "").trim().toUpperCase();
}

function formatMeters(value?: number) {
  if (value === undefined) return undefined;
  if (Math.abs(value) >= 1000) {
    return `${(value / 1000).toFixed(1)} km`;
  }
  return `${Math.round(value)} m`;
}

function formatBoolean(value: unknown) {
  if (typeof value !== "boolean") return undefined;
  return value ? "Ναι" : "Όχι";
}

function formatLabel(value?: string) {
  const key = normalizeKey(value);

  const dictionary: Record<string, string> = {
    // Incident categories / types
    EMERGENCY_ACTIVATION: "Ενεργοποίηση έκτακτης ανάγκης",
    HSE_ACCIDENT: "Ατύχημα Υγείας & Ασφάλειας",
    ENVIRONMENTAL_INCIDENT: "Περιβαλλοντικό συμβάν",
    NEAR_MISS: "Παρ’ ολίγον συμβάν",
    UNSAFE_ACTION: "Μη ασφαλής ενέργεια",
    UNSAFE_CONDITION: "Μη ασφαλής κατάσταση",
    FIRE: "Πυρκαγιά",
    MEDICAL: "Ιατρικό συμβάν",
    EVACUATION: "Εκκένωση",

    // Severity / risk
    LOW: "Χαμηλή",
    MEDIUM: "Μέτρια",
    HIGH: "Υψηλή",
    CRITICAL: "Κρίσιμη",

    // Incident / responder status
    CREATED: "Δημιουργήθηκε",
    NEW: "Νέο",
    OPEN: "Ανοικτό",
    CONFIRMED: "Επιβεβαιωμένο",
    VERIFIED: "Επιβεβαιωμένο",
    AUTO_VERIFIED: "Αυτόματα επιβεβαιωμένο",
    REJECTED: "Απορρίφθηκε",
    ACTIVE: "Ενεργό",
    ACTIVE_RESPONSE: "Ενεργή αντιμετώπιση",
    UNDER_CONTROL: "Υπό έλεγχο",
    RECOVERY: "Αποκατάσταση",
    CLOSED: "Ολοκληρωμένο",
    DEACTIVATED: "Απενεργοποιημένο",
    CANCELLED: "Ακυρώθηκε",
    PENDING: "Εκκρεμεί",
    REQUESTED: "Ζητήθηκε",
    RESPONDING: "Ανταποκρίνεται",
    ARRIVED: "Έφτασε",
    COMPLETED: "Ολοκληρώθηκε",
    IN_PROGRESS: "Σε εξέλιξη",
    PREPARING: "Σε προετοιμασία",
    SENT: "Στάλθηκε",
    ACKNOWLEDGED: "Επιβεβαιώθηκε λήψη",
    APPROVED: "Εγκρίθηκε",
    FAILED: "Απέτυχε",
    NOT_REQUIRED: "Δεν απαιτείται",
    NONE: "Καμία ενέργεια",

    // Teams
    GENERAL_USERS: "Γενικοί χρήστες",
    MANAGEMENT: "Διοίκηση",
    HSE_TEAM: "Ομάδα ΥΑΕ",
    EMERGENCY_TEAM: "Ομάδα έκτακτης ανάγκης",
    FIRST_AID_TEAM: "Ομάδα Α’ Βοηθειών",
    FIRE_TEAM: "Ομάδα Πυρασφάλειας",
    EVACUATION_TEAM: "Ομάδα Εκκένωσης",
    SECURITY_TEAM: "Ομάδα Ασφάλειας",
    CONTROL_ROOM_TEAM: "Ομάδα Control Room",
    ENVIRONMENT_TEAM: "Περιβαλλοντική ομάδα",
    ENVIRONMENTAL_TEAM: "Περιβαλλοντική ομάδα",
    RESPONSE_TEAM: "Ομάδα ανταπόκρισης",
    READ_ONLY_USERS: "Χρήστες προβολής",

    // Roles
    WORKER: "Εργαζόμενος",
    SUPERVISOR: "Supervisor / Επιβλέπων",
    SITE_MANAGER: "Υπεύθυνος μονάδας",
    HSE_MANAGER: "Υπεύθυνος ΥΑΕ",
    EMERGENCY_COMMANDER: "Συντονιστής έκτακτης ανάγκης",
    FIRE_SAFETY_COORDINATOR: "Συντονιστής πυρασφάλειας",
    FIRE_TEAM_MEMBER: "Μέλος ομάδας πυρασφάλειας",
    FIRST_AID_COORDINATOR: "Συντονιστής Α’ Βοηθειών",
    FIRST_AID_RESPONDER: "Ανταποκριτής Α’ Βοηθειών",
    EVACUATION_WARDEN: "Υπεύθυνος εκκένωσης",
    COMMUNICATIONS_OFFICER: "Υπεύθυνος επικοινωνιών",
    SECURITY_OFFICER: "Υπεύθυνος ασφάλειας",
    ENVIRONMENTAL_OFFICER: "Περιβαλλοντικός υπεύθυνος",
    ENVIRONMENT_RESPONDER: "Περιβαλλοντικός ανταποκριτής",
    PERSONNEL_COORDINATOR: "Συντονιστής προσωπικού",
    CONTROL_ROOM: "Control Room",
    DIRECTOR: "Διευθυντής",
    VIEWER: "Χρήστης προβολής",
    TECHNICIAN: "Τεχνικός",

    // External authorities
    CIVIL_PROTECTION: "Πολιτική Προστασία / 112",
    EMS: "ΕΚΑΒ",
    FIRE_BRIGADE: "Πυροσβεστική Υπηρεσία",
    FIRE_SERVICE: "Πυροσβεστική Υπηρεσία",
    POLICE: "Αστυνομία",
    ENVIRONMENTAL_AUTHORITY: "Περιβαλλοντική αρχή",

    // Channels / modes
    PHONE: "Τηλέφωνο",
    EMAIL: "Email",
    SMS: "SMS",
    RADIO: "Ασύρματος",
    AUTO: "Αυτόματα",
    MANUAL: "Χειροκίνητα",
    PLAYBOOK_DRIVEN: "Μέσω playbook",
    POLICY_ENGINE: "Μηχανισμός πολιτικών",
    MOBILE: "Mobile εφαρμογή",
    FUNCTION: "Cloud Function",
  };

  return dictionary[key] || value || "-";
}

function formatValue(value?: string) {
  return formatLabel(value);
}

function getActor(item: IncidentEventRecord, payload: Record<string, unknown>) {
  return pickString(
    payload.actorName,
    payload.userName,
    payload.displayName,
    payload.requestedByName,
    payload.approvedByName,
    payload.executedByName,
    payload.receivedBy,
    item.userName,
    item.userId
  );
}

function getResponderName(item: IncidentEventRecord, payload: Record<string, unknown>) {
  return pickString(
    payload.responderName,
    payload.displayName,
    payload.userName,
    item.userName,
    payload.responderUserId,
    item.userId
  );
}

function getAuthority(payload: Record<string, unknown>) {
  return pickString(
    payload.authorityName,
    payload.authorityType,
    payload.targetAuthorityName,
    payload.targetAuthorityType,
    payload.authorityId
  );
}

function getTeam(payload: Record<string, unknown>) {
  return pickString(
    payload.teamName,
    payload.team,
    payload.teamKey,
    payload.requestedTeam,
    payload.targetTeam
  );
}

function getStatus(payload: Record<string, unknown>) {
  return pickString(
    payload.status,
    payload.newStatus,
    payload.executionStatus,
    payload.approvalStatus,
    payload.acknowledgementStatus,
    payload.responderStatus
  );
}

function getEventTone(eventType?: string): Tone {
  const type = eventType || "UNKNOWN";

  if (
    type === "INCIDENT_CREATED" ||
    type === "INCIDENT_VERIFIED" ||
    type === "INCIDENT_REJECTED" ||
    type === "INCIDENT_CLOSED" ||
    type === "INCIDENT_UPDATED" ||
    type === "EMERGENCY_ACTIVATED" ||
    type === "EMERGENCY_UNDER_CONTROL" ||
    type === "EMERGENCY_DEACTIVATED" ||
    type === "EMERGENCY_COMMAND_ASSIGNED" ||
    type === "EMERGENCY_COMMAND_TRANSFERRED" ||
    type === "INVESTIGATION_STARTED" ||
    type === "INVESTIGATION_COMPLETED"
  ) {
    return {
      badge: getBadgeStyle("info"),
      border: "var(--info)",
      glow: "var(--info-soft)",
      label: "Κύκλος συμβάντος",
    };
  }

  if (
    type === "RISK_ASSESSMENT_COMPUTED" ||
    type === "PLAYBOOK_ACTIVATED" ||
    type === "PLAYBOOK_STEP_STARTED" ||
    type === "PLAYBOOK_STEP_COMPLETED" ||
    type === "PLAYBOOK_STEP_CLOSED" ||
    type === "PLAYBOOK_EXECUTION_CLOSED"
  ) {
    return {
      badge: getBadgeStyle("accent"),
      border: "var(--accent)",
      glow: "var(--accent-soft)",
      label: "Ροή ΣΑΕΚ",
    };
  }

  if (
    type === "PLAYBOOK_DISPATCH_REQUESTED" ||
    type === "PLAYBOOK_DISPATCH_MATERIALIZED" ||
    type === "PLAYBOOK_DISPATCH_CLOSED" ||
    type === "RESPONDER_DECLARED" ||
    type === "RESPONDER_LOCATION_UPDATED" ||
    type === "RESPONDER_ARRIVED" ||
    type === "RESPONDER_COMPLETED" ||
    type === "RESPONDER_CANCELLED"
  ) {
    return {
      badge: getBadgeStyle("warning"),
      border: "var(--warning)",
      glow: "var(--warning-soft)",
      label: "Κινητοποίηση",
    };
  }

  if (
    type === "EVACUATION_STARTED" ||
    type === "EVACUATION_PREPARED" ||
    type === "EVACUATION_COMPLETED" ||
    type === "EVACUATION_CLOSED"
  ) {
    return {
      badge: getBadgeStyle("warning"),
      border: "var(--warning)",
      glow: "var(--warning-soft)",
      label: "Εκκένωση",
    };
  }

  if (
    type === "EXTERNAL_NOTIFICATION_REQUESTED" ||
    type === "EXTERNAL_NOTIFICATION_APPROVED" ||
    type === "EXTERNAL_NOTIFICATION_SENT" ||
    type === "EXTERNAL_NOTIFICATION_ACK" ||
    type === "EXTERNAL_NOTIFICATION_CANCELLED" ||
    type === "EXTERNAL_NOTIFICATION_REJECTED" ||
    type === "EXTERNAL_NOTIFICATION_FAILED" ||
    type === "EXTERNAL_NOTIFICATION_CLOSED"
  ) {
    return {
      badge: getBadgeStyle("success"),
      border: "var(--success)",
      glow: "var(--success-soft)",
      label: "Εξωτερικές αρχές",
    };
  }

  return {
    badge: getBadgeStyle("neutral"),
    border: "var(--border)",
    glow: "var(--surface-2)",
    label: "Καταγραφή",
  };
}

function getEventTitle(item: IncidentEventRecord) {
  const payload = getPayload(item);
  const eventType = item.eventType || "UNKNOWN";
  const authority = getAuthority(payload);
  const playbook = pickString(payload.playbookTitle, payload.playbookId);
  const step = pickString(payload.stepTitle, payload.stepId);
  const team = getTeam(payload);
  const responder = getResponderName(item, payload);

  switch (eventType) {
    case "INCIDENT_CREATED":
      return "Δημιουργήθηκε νέο συμβάν";
    case "INCIDENT_UPDATED":
      return "Ενημερώθηκαν στοιχεία συμβάντος";
    case "INCIDENT_VERIFIED":
      return "Το συμβάν επιβεβαιώθηκε";
    case "INCIDENT_REJECTED":
      return "Το συμβάν απορρίφθηκε";
    case "INCIDENT_CLOSED":
      return "Το συμβάν ολοκληρώθηκε";
    case "EMERGENCY_ACTIVATED":
      return "Ενεργοποιήθηκε ροή έκτακτης ανάγκης";
    case "EMERGENCY_UNDER_CONTROL":
      return "Το συμβάν τέθηκε υπό έλεγχο";
    case "EMERGENCY_DEACTIVATED":
      return "Απενεργοποιήθηκε η έκτακτη φάση";
    case "EMERGENCY_COMMAND_ASSIGNED":
      return "Ορίστηκε υπεύθυνος συντονισμού";
    case "EMERGENCY_COMMAND_TRANSFERRED":
      return "Μεταβιβάστηκε ο συντονισμός του συμβάντος";
    case "INVESTIGATION_STARTED":
      return "Ξεκίνησε διερεύνηση συμβάντος";
    case "INVESTIGATION_COMPLETED":
      return "Ολοκληρώθηκε η διερεύνηση συμβάντος";

    case "RISK_ASSESSMENT_COMPUTED":
      return "Υπολογίστηκε επιχειρησιακός κίνδυνος";
    case "PLAYBOOK_ACTIVATED":
      return `Ενεργοποιήθηκε επιχειρησιακή ροή${playbook ? ` · ${playbook}` : ""}`;
    case "PLAYBOOK_STEP_STARTED":
      return `Ξεκίνησε ενέργεια ΣΑΕΚ${step ? ` · ${step}` : ""}`;
    case "PLAYBOOK_STEP_COMPLETED":
      return `Ολοκληρώθηκε ενέργεια ΣΑΕΚ${step ? ` · ${step}` : ""}`;
    case "PLAYBOOK_STEP_CLOSED":
      return `Έκλεισε βήμα ΣΑΕΚ${step ? ` · ${step}` : ""}`;
    case "PLAYBOOK_EXECUTION_CLOSED":
      return "Έκλεισε η εκτέλεση των playbooks";

    case "PLAYBOOK_DISPATCH_REQUESTED":
      return `Ζητήθηκε κινητοποίηση ομάδας${team ? ` · ${formatValue(team)}` : ""}`;
    case "PLAYBOOK_DISPATCH_MATERIALIZED":
      return `Δημιουργήθηκαν εγγραφές ανταπόκρισης${team ? ` · ${formatValue(team)}` : ""}`;
    case "PLAYBOOK_DISPATCH_CLOSED":
      return "Έκλεισε αίτημα κινητοποίησης";
    case "RESPONDER_DECLARED":
      return responder
        ? `Ο χρήστης ${responder} δήλωσε ανταπόκριση`
        : "Δηλώθηκε ανταπόκριση χρήστη";
    case "RESPONDER_LOCATION_UPDATED":
      return responder
        ? `Ενημερώθηκε η θέση του χρήστη ${responder}`
        : "Ενημερώθηκε θέση ανταποκρινόμενου";
    case "RESPONDER_ARRIVED":
      return responder
        ? `Ο χρήστης ${responder} έφτασε στο συμβάν`
        : "Καταγράφηκε άφιξη στο συμβάν";
    case "RESPONDER_COMPLETED":
      return responder
        ? `Ο χρήστης ${responder} ολοκλήρωσε την ενέργειά του`
        : "Ολοκληρώθηκε ενέργεια ανταποκρινόμενου";
    case "RESPONDER_CANCELLED":
      return responder
        ? `Ο χρήστης ${responder} ακύρωσε την ανταπόκριση`
        : "Ακυρώθηκε ανταπόκριση χρήστη";

    case "EVACUATION_STARTED":
      return "Ξεκίνησε διαδικασία εκκένωσης";
    case "EVACUATION_PREPARED":
      return "Προετοιμάστηκε διαδικασία εκκένωσης";
    case "EVACUATION_COMPLETED":
      return "Ολοκληρώθηκε διαδικασία εκκένωσης";
    case "EVACUATION_CLOSED":
      return "Έκλεισε η φάση εκκένωσης";

    case "EXTERNAL_NOTIFICATION_REQUESTED":
      return `Δημιουργήθηκε αίτημα ειδοποίησης${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_APPROVED":
      return `Εγκρίθηκε ειδοποίηση εξωτερικής αρχής${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_SENT":
      return `Εκτελέστηκε ειδοποίηση εξωτερικής αρχής${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_ACK":
      return `Καταγράφηκε επιβεβαίωση λήψης${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_CANCELLED":
      return `Ακυρώθηκε ειδοποίηση εξωτερικής αρχής${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_REJECTED":
      return `Απορρίφθηκε ειδοποίηση εξωτερικής αρχής${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_FAILED":
      return `Απέτυχε ειδοποίηση εξωτερικής αρχής${authority ? ` · ${formatValue(authority)}` : ""}`;
    case "EXTERNAL_NOTIFICATION_CLOSED":
      return `Έκλεισε ο κύκλος ειδοποίησης${authority ? ` · ${formatValue(authority)}` : ""}`;

    default:
      return eventType;
  }
}

function getEventSummary(item: IncidentEventRecord) {
  const payload = getPayload(item);
  const eventType = item.eventType || "UNKNOWN";

  const authority = getAuthority(payload);
  const playbook = pickString(payload.playbookTitle, payload.playbookId);
  const step = pickString(payload.stepTitle, payload.stepId);
  const team = getTeam(payload);
  const actor = getActor(item, payload);
  const status = getStatus(payload);
  const notes = pickString(
    payload.resultNotes,
    payload.rejectionReason,
    payload.notes,
    payload.reason,
    payload.summary,
    payload.description
  );
  const mode = pickString(payload.mode, payload.executionMode, payload.navigationMode);
  const level = pickString(payload.level, payload.activationLevel);
  const severity = pickString(payload.severity, payload.overallRisk, payload.newOverallRisk);
  const responders = pickNumber(
    payload.materializedCount,
    payload.requestedResponders,
    payload.responderCount
  );
  const distance = formatMeters(pickNumber(payload.distanceMeters, payload.closestDistanceMeters));

  switch (eventType) {
    case "INCIDENT_CREATED": {
      const category = pickString(payload.category);
      const subtype = pickString(payload.subtype, payload.type);
      return [
        category ? `Κατηγορία: ${formatValue(category)}` : undefined,
        subtype ? `Τύπος: ${formatValue(subtype)}` : undefined,
        severity ? `Σοβαρότητα: ${formatValue(severity)}` : undefined,
        actor ? `Καταχώρηση από: ${actor}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ");
    }

    case "RISK_ASSESSMENT_COMPUTED": {
      const score = pickNumber(payload.score, payload.newScore);
      return [
        severity ? `Επίπεδο: ${formatValue(severity)}` : undefined,
        score !== undefined ? `Βαθμολογία: ${score}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Υπολογίστηκε ο επιχειρησιακός κίνδυνος του συμβάντος.";
    }

    case "EMERGENCY_ACTIVATED":
      return [
        level ? `Επίπεδο ενεργοποίησης: ${formatValue(level)}` : undefined,
        formatBoolean(payload.evacuationRequired) !== undefined
          ? `Εκκένωση: ${formatBoolean(payload.evacuationRequired)}`
          : undefined,
        formatBoolean(payload.externalAuthoritiesRequired) !== undefined
          ? `Εξωτερικές αρχές: ${formatBoolean(payload.externalAuthoritiesRequired)}`
          : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ξεκίνησε η επιχειρησιακή ροή έκτακτης ανάγκης.";

    case "EMERGENCY_UNDER_CONTROL":
      return "Το συμβάν έχει σταθεροποιηθεί. Παραμένει ανοικτό μέχρι να ολοκληρωθούν οι απαιτούμενες ενέργειες και η διερεύνηση.";

    case "EMERGENCY_DEACTIVATED":
      return "Έληξε η ενεργή φάση έκτακτης ανάγκης. Αυτό δεν σημαίνει απαραίτητα ότι έχει ολοκληρωθεί το formal closure του συμβάντος.";

    case "INCIDENT_CLOSED":
      return "Το συμβάν ολοκληρώθηκε σύμφωνα με την πολιτική κλεισίματος και καταγράφηκε στο ιστορικό.";

    case "INCIDENT_VERIFIED":
      return actor ? `Επιβεβαιώθηκε από ${actor}.` : "Το συμβάν επιβεβαιώθηκε σύμφωνα με την πολιτική verification.";

    case "INCIDENT_REJECTED":
      return notes ? `Αιτιολογία: ${notes}` : "Το συμβάν απορρίφθηκε και δεν συνεχίζει σε πλήρη επιχειρησιακή ροή.";

    case "EMERGENCY_COMMAND_ASSIGNED":
    case "EMERGENCY_COMMAND_TRANSFERRED": {
      const owner = pickString(payload.newOwnerName, payload.ownerName, payload.toUserName);
      const ownerRole = pickString(payload.newOwnerRole, payload.ownerRole);
      return [
        owner ? `Υπεύθυνος: ${owner}` : undefined,
        ownerRole ? `Ρόλος: ${formatValue(ownerRole)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ενημερώθηκε ο επιχειρησιακός συντονισμός του συμβάντος.";
    }

    case "INVESTIGATION_STARTED":
      return actor ? `Η διερεύνηση ξεκίνησε από ${actor}.` : "Ξεκίνησε η διερεύνηση του συμβάντος.";

    case "INVESTIGATION_COMPLETED":
      return actor ? `Η διερεύνηση ολοκληρώθηκε από ${actor}.` : "Ολοκληρώθηκε η διερεύνηση του συμβάντος.";

    case "PLAYBOOK_ACTIVATED":
      return [
        playbook ? `Ροή: ${playbook}` : undefined,
        severity ? `Κίνδυνος: ${formatValue(severity)}` : undefined,
        pickNumber(payload.stepCount) !== undefined ? `Βήματα: ${pickNumber(payload.stepCount)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ενεργοποιήθηκε επιχειρησιακό playbook.";

    case "PLAYBOOK_STEP_STARTED":
      return [
        playbook ? `Ροή: ${playbook}` : undefined,
        step ? `Ενέργεια: ${step}` : undefined,
        status ? `Κατάσταση: ${formatValue(status)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ξεκίνησε επιχειρησιακή ενέργεια από playbook.";

    case "PLAYBOOK_STEP_COMPLETED":
      return [
        playbook ? `Ροή: ${playbook}` : undefined,
        step ? `Ενέργεια: ${step}` : undefined,
        "Η ενέργεια ολοκληρώθηκε αυτόματα ή από τη ροή του συστήματος.",
      ]
        .filter(Boolean)
        .join(" · ");

    case "PLAYBOOK_STEP_CLOSED":
      return [
        playbook ? `Ροή: ${playbook}` : undefined,
        step ? `Βήμα: ${step}` : undefined,
        status ? `Νέα κατάσταση: ${formatValue(status)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Έκλεισε ανοικτό βήμα playbook στο πλαίσιο cleanup της ροής.";

    case "PLAYBOOK_EXECUTION_CLOSED":
      return "Το σύστημα έκλεισε την εκτέλεση των ανοικτών playbooks μετά την αλλαγή κατάστασης του συμβάντος.";

    case "PLAYBOOK_DISPATCH_REQUESTED":
      return [
        team ? `Ομάδα: ${formatValue(team)}` : undefined,
        playbook ? `Ροή: ${playbook}` : undefined,
        step ? `Ενέργεια: ${step}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ζητήθηκε κινητοποίηση ομάδας από playbook.";

    case "PLAYBOOK_DISPATCH_MATERIALIZED":
      return [
        team ? `Ομάδα: ${formatValue(team)}` : undefined,
        responders !== undefined ? `Χρήστες που στοχοποιήθηκαν: ${responders}` : undefined,
        playbook ? `Ροή: ${playbook}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Δημιουργήθηκαν εγγραφές ανταπόκρισης για τους χρήστες της ομάδας.";

    case "PLAYBOOK_DISPATCH_CLOSED":
      return [
        status ? `Νέα κατάσταση: ${formatValue(status)}` : undefined,
        pickString(payload.dispatchRequestId) ? `Dispatch: ${pickString(payload.dispatchRequestId)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Έκλεισε αίτημα κινητοποίησης.";

    case "RESPONDER_DECLARED": {
      const responder = getResponderName(item, payload);
      return [
        responder ? `Χρήστης: ${responder}` : undefined,
        status ? `Κατάσταση: ${formatValue(status)}` : undefined,
        mode ? `Πλοήγηση: ${formatValue(mode)}` : undefined,
        distance ? `Απόσταση: ${distance}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ο χρήστης δήλωσε ότι ανταποκρίνεται στο συμβάν.";
    }

    case "RESPONDER_LOCATION_UPDATED": {
      const responder = getResponderName(item, payload);
      return [
        responder ? `Χρήστης: ${responder}` : undefined,
        status ? `Κατάσταση: ${formatValue(status)}` : undefined,
        distance ? `Απόσταση: ${distance}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ενημερώθηκε η θέση ανταποκρινόμενου χρήστη.";
    }

    case "RESPONDER_ARRIVED": {
      const responder = getResponderName(item, payload);
      return responder
        ? `Η άφιξη του χρήστη ${responder} στο συμβάν καταγράφηκε επιτυχώς.`
        : "Η άφιξη στο συμβάν καταγράφηκε επιτυχώς.";
    }

    case "RESPONDER_COMPLETED": {
      const responder = getResponderName(item, payload);
      return responder
        ? `Ο χρήστης ${responder} ολοκλήρωσε την επιχειρησιακή του ενέργεια.`
        : "Ολοκληρώθηκε επιχειρησιακή ενέργεια ανταποκρινόμενου.";
    }

    case "RESPONDER_CANCELLED": {
      const responder = getResponderName(item, payload);
      return responder
        ? `Ο χρήστης ${responder} ακύρωσε την ανταπόκριση.`
        : "Ακυρώθηκε ανταπόκριση χρήστη.";
    }

    case "EVACUATION_STARTED":
      return [
        mode ? `Τύπος: ${formatValue(mode)}` : undefined,
        step ? `Ενέργεια: ${step}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Ξεκίνησε διαδικασία εκκένωσης σύμφωνα με τη ροή ΣΑΕΚ.";

    case "EVACUATION_PREPARED":
      return [
        mode ? `Τύπος: ${formatValue(mode)}` : undefined,
        step ? `Ενέργεια: ${step}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Προετοιμάστηκαν ενέργειες εκκένωσης ή σημεία συγκέντρωσης.";

    case "EVACUATION_COMPLETED":
      return "Η διαδικασία εκκένωσης ολοκληρώθηκε.";

    case "EVACUATION_CLOSED":
      return "Η φάση εκκένωσης έκλεισε από το σύστημα.";

    case "EXTERNAL_NOTIFICATION_REQUESTED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        mode ? `Τρόπος: ${formatValue(mode)}` : undefined,
        pickString(payload.channel) ? `Κανάλι: ${formatValue(pickString(payload.channel))}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Δημιουργήθηκε αίτημα ειδοποίησης εξωτερικής αρχής.";

    case "EXTERNAL_NOTIFICATION_APPROVED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        actor ? `Έγκριση από: ${actor}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Εγκρίθηκε η ειδοποίηση εξωτερικής αρχής.";

    case "EXTERNAL_NOTIFICATION_SENT":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        actor ? `Εκτέλεση από: ${actor}` : undefined,
        notes ? `Σημείωση: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Καταγράφηκε η πραγματική ειδοποίηση προς εξωτερική αρχή.";

    case "EXTERNAL_NOTIFICATION_ACK":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        actor ? `Επιβεβαίωση: ${actor}` : undefined,
        notes ? `Σημείωση: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Καταγράφηκε επιβεβαίωση λήψης από την εξωτερική αρχή.";

    case "EXTERNAL_NOTIFICATION_REJECTED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        actor ? `Απόφαση από: ${actor}` : undefined,
        notes ? `Αιτιολογία: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Η ειδοποίηση εξωτερικής αρχής απορρίφθηκε ως μη απαιτούμενη.";

    case "EXTERNAL_NOTIFICATION_CANCELLED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        notes ? `Σημείωση: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Η ειδοποίηση εξωτερικής αρχής ακυρώθηκε.";

    case "EXTERNAL_NOTIFICATION_FAILED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        notes ? `Σφάλμα/σημείωση: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Η ειδοποίηση εξωτερικής αρχής απέτυχε.";

    case "EXTERNAL_NOTIFICATION_CLOSED":
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        status ? `Κατάσταση: ${formatValue(status)}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Έκλεισε ο κύκλος ειδοποίησης εξωτερικής αρχής.";

    default:
      return [
        authority ? `Αρχή: ${formatValue(authority)}` : undefined,
        playbook ? `Ροή: ${playbook}` : undefined,
        step ? `Βήμα: ${step}` : undefined,
        actor ? `Χρήστης: ${actor}` : undefined,
        status ? `Κατάσταση: ${formatValue(status)}` : undefined,
        notes ? `Σημείωση: ${notes}` : undefined,
      ]
        .filter(Boolean)
        .join(" · ") || "Καταγράφηκε επιχειρησιακό γεγονός στο ιστορικό.";
  }
}

function getMetaRows(item: IncidentEventRecord) {
  const payload = getPayload(item);

  const rows: Array<{ label: string; value: string }> = [];

  const incidentId = pickString(item.incidentId);
  const siteId = pickString(item.siteId);
  const authority = getAuthority(payload);
  const playbook = pickString(payload.playbookTitle, payload.playbookId);
  const step = pickString(payload.stepTitle, payload.stepId);
  const team = getTeam(payload);
  const actor = getActor(item, payload);
  const responder = getResponderName(item, payload);
  const status = getStatus(payload);
  const mode = pickString(payload.mode, payload.executionMode, payload.navigationMode);
  const notificationId = pickString(
    payload.notificationId,
    payload.canonicalNotificationId,
    payload.legacyRequestId
  );
  const dispatchRequestId = pickString(payload.dispatchRequestId, payload.sourceDispatchRequestId);
  const distance = formatMeters(pickNumber(payload.distanceMeters, payload.closestDistanceMeters));

  if (incidentId) rows.push({ label: "Συμβάν", value: incidentId });
  if (siteId) rows.push({ label: "Μονάδα", value: siteId });
  if (authority) rows.push({ label: "Εξωτερική αρχή", value: formatValue(authority) });
  if (playbook) rows.push({ label: "Ροή", value: playbook });
  if (step) rows.push({ label: "Βήμα / ενέργεια", value: step });
  if (team) rows.push({ label: "Ομάδα", value: formatValue(team) });
  if (responder) rows.push({ label: "Ανταποκρινόμενος", value: responder });
  if (actor) rows.push({ label: "Χρήστης", value: actor });
  if (status) rows.push({ label: "Κατάσταση", value: formatValue(status) });
  if (mode) rows.push({ label: "Τρόπος", value: formatValue(mode) });
  if (distance) rows.push({ label: "Απόσταση", value: distance });
  if (notificationId) rows.push({ label: "Ειδοποίηση", value: notificationId });
  if (dispatchRequestId) rows.push({ label: "Αίτημα κινητοποίησης", value: dispatchRequestId });

  return rows;
}

function getPayloadPreview(item: IncidentEventRecord) {
  const payload = getPayload(item);
  const keys = Object.keys(payload);

  if (!keys.length) return "";

  const hiddenKeys = new Set([
    "latitude",
    "longitude",
    "responderUserId",
    "userId",
    "canonicalRequestId",
    "canonicalNotificationId",
    "legacyRequestId",
    "dedupeKey",
    "resolverReasonCodes",
  ]);

  const previewKeys = keys.filter((key) => !hiddenKeys.has(key)).slice(0, 6);
  const preview = previewKeys
    .map((key) => {
      const value = payload[key];
      const label = technicalKeyToGreek(key);

      if (typeof value === "string") {
        return `${label}: ${formatValue(value)}`;
      }
      if (typeof value === "number" || typeof value === "boolean") {
        return `${label}: ${String(formatBoolean(value) ?? value)}`;
      }
      if (value && typeof value === "object") {
        return `${label}: {...}`;
      }
      return `${label}: -`;
    })
    .join(" · ");

  return preview;
}

function technicalKeyToGreek(key: string) {
  const dictionary: Record<string, string> = {
    category: "Κατηγορία",
    subtype: "Τύπος",
    severity: "Σοβαρότητα",
    status: "Κατάσταση",
    newStatus: "Νέα κατάσταση",
    previousStatus: "Προηγούμενη κατάσταση",
    activationLevel: "Επίπεδο ενεργοποίησης",
    evacuationRequired: "Απαιτείται εκκένωση",
    externalAuthoritiesRequired: "Απαιτούνται εξωτερικές αρχές",
    requiresVerification: "Απαιτείται επιβεβαίωση",
    playbookId: "Playbook",
    playbookTitle: "Ροή",
    stepId: "Βήμα",
    stepTitle: "Ενέργεια",
    stepType: "Τύπος ενέργειας",
    team: "Ομάδα",
    authorityId: "Αρχή",
    authorityName: "Εξωτερική αρχή",
    authorityType: "Τύπος αρχής",
    channel: "Κανάλι",
    mode: "Τρόπος",
    resultNotes: "Σημείωση",
    rejectionReason: "Αιτιολογία απόρριψης",
    executionMode: "Τρόπος εκτέλεσης",
  };

  return dictionary[key] || key;
}

function groupByDay(items: IncidentEventRecord[]) {
  const map = new Map<string, IncidentEventRecord[]>();

  for (const item of items) {
    const date = new Date(item.createdAt || 0);
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
      date.getDate()
    ).padStart(2, "0")}`;

    if (!map.has(key)) {
      map.set(key, []);
    }

    map.get(key)!.push(item);
  }

  return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
}

export function TimelineFeed({ items }: Props) {
  if (!items.length) {
    return (
      <div style={emptyState}>
        Δεν υπάρχουν γεγονότα για τα τρέχοντα φίλτρα. Δοκίμασε να αλλάξεις τύπο γεγονότος,
        χρονικό εύρος ή συμβάν.
      </div>
    );
  }

  const dayGroups = groupByDay(items);

  return (
    <div style={feedWrapper}>
      {dayGroups.map(([day, dayItems]) => (
        <div key={day} style={daySection}>
          <div style={dayHeader}>
            <div>
              <div style={dayTitle}>{day}</div>
              <div style={daySubtitle}>Χρονολογική καταγραφή επιχειρησιακών ενεργειών</div>
            </div>
            <div style={dayCount}>{dayItems.length} γεγονότα</div>
          </div>

          <div style={itemsStack}>
            {dayItems.map((item, index) => {
              const tone = getEventTone(item.eventType);
              const title = getEventTitle(item);
              const summary = getEventSummary(item);
              const metaRows = getMetaRows(item);
              const payloadPreview = getPayloadPreview(item);
              const isLast = index === dayItems.length - 1;

              return (
                <div
                  key={item.id || `${item.incidentId}-${item.eventType}-${item.createdAt}-${index}`}
                  style={eventRow}
                >
                  <div style={timelineRail}>
                    <div
                      style={{
                        ...dot,
                        background: tone.badge.background,
                        border: tone.badge.border,
                        boxShadow: `0 0 0 6px ${tone.glow}`,
                      }}
                    />
                    {!isLast ? <div style={line} /> : null}
                  </div>

                  <div
                    style={{
                      ...eventCard,
                      border: `1px solid ${tone.border}`,
                      background: "var(--surface)",
                    }}
                  >
                    <div style={eventHeader}>
                      <div>
                        <div style={eventTitle}>{title}</div>
                        <div style={eventSummary}>{summary}</div>
                      </div>

                      <div style={eventHeaderRight}>
                        <span style={{ ...pill, ...tone.badge }}>{tone.label}</span>
                        <span style={typePill}>{item.eventType || "UNKNOWN"}</span>
                        <div style={eventTime}>{formatDate(item.createdAt)}</div>
                      </div>
                    </div>

                    {metaRows.length ? (
                      <div style={metaGrid}>
                        {metaRows.map((row) => (
                          <div key={`${row.label}-${row.value}`} style={metaItem}>
                            <div style={metaLabel}>{row.label}</div>
                            <div style={metaValue}>{row.value}</div>
                          </div>
                        ))}
                      </div>
                    ) : null}

                    {payloadPreview ? (
                      <div style={payloadBox}>
                        <div style={payloadLabel}>Σύνοψη τεχνικών δεδομένων</div>
                        <div style={payloadText}>{payloadPreview}</div>
                      </div>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

const feedWrapper: React.CSSProperties = {
  display: "grid",
  gap: 18,
};

const daySection: React.CSSProperties = {
  display: "grid",
  gap: 10,
};

const dayHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 12,
  flexWrap: "wrap",
};

const dayTitle: React.CSSProperties = {
  fontSize: 14,
  fontWeight: 800,
  color: "var(--text-strong)",
};

const daySubtitle: React.CSSProperties = {
  marginTop: 2,
  fontSize: 12,
  color: "var(--muted)",
};

const dayCount: React.CSSProperties = {
  fontSize: 12,
  color: "var(--muted)",
};

const itemsStack: React.CSSProperties = {
  display: "grid",
  gap: 12,
};

const eventRow: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "28px 1fr",
  gap: 12,
  alignItems: "stretch",
};

const timelineRail: React.CSSProperties = {
  display: "grid",
  gridTemplateRows: "20px 1fr",
  justifyItems: "center",
};

const dot: React.CSSProperties = {
  width: 12,
  height: 12,
  borderRadius: 999,
  marginTop: 6,
};

const line: React.CSSProperties = {
  width: 2,
  height: "100%",
  background: "var(--border)",
  borderRadius: 999,
};

const eventCard: React.CSSProperties = {
  borderRadius: 16,
  padding: 14,
  display: "grid",
  gap: 12,
};

const eventHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  alignItems: "flex-start",
  flexWrap: "wrap",
};

const eventHeaderRight: React.CSSProperties = {
  display: "flex",
  gap: 8,
  alignItems: "center",
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const eventTitle: React.CSSProperties = {
  fontSize: 15,
  fontWeight: 800,
  lineHeight: 1.35,
  color: "var(--text-strong)",
};

const eventSummary: React.CSSProperties = {
  marginTop: 4,
  fontSize: 13,
  color: "var(--text)",
  lineHeight: 1.45,
};

const eventTime: React.CSSProperties = {
  fontSize: 12,
  color: "var(--muted)",
  whiteSpace: "nowrap",
};

const pill: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const typePill: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 8px",
  borderRadius: 999,
  fontSize: 11,
  fontWeight: 700,
  whiteSpace: "nowrap",
  background: "var(--surface-2)",
  border: "1px solid var(--border)",
  color: "var(--text)",
};

const metaGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
  gap: 10,
};

const metaItem: React.CSSProperties = {
  borderRadius: 12,
  padding: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
};

const metaLabel: React.CSSProperties = {
  fontSize: 11,
  color: "var(--muted)",
  marginBottom: 4,
};

const metaValue: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.4,
  wordBreak: "break-word",
  color: "var(--text)",
};

const payloadBox: React.CSSProperties = {
  borderRadius: 12,
  padding: 10,
  background: "var(--surface)",
  border: "1px solid var(--border)",
};

const payloadLabel: React.CSSProperties = {
  fontSize: 11,
  color: "var(--muted)",
  marginBottom: 6,
};

const payloadText: React.CSSProperties = {
  fontSize: 12,
  lineHeight: 1.45,
  color: "var(--text)",
  wordBreak: "break-word",
};

const emptyState: React.CSSProperties = {
  padding: 14,
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 13,
  color: "var(--text)",
};
