type Props = {
  siteId: string;
  status: string;
  incidentSearch: string;
  availableSites: string[];
  onSiteChange: (v: string) => void;
  onStatusChange: (v: string) => void;
  onIncidentSearchChange: (v: string) => void;
};

export function DispatchFilters({
  siteId,
  status,
  incidentSearch,
  availableSites,
  onSiteChange,
  onStatusChange,
  onIncidentSearchChange,
}: Props) {
  return (
    <div className="filter-panel" style={{ marginTop: 12, marginBottom: 16 }}>
      <div className="filter-panel-grid" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
        <label>
          <div className="filter-panel-title">Site</div>
          <select value={siteId} onChange={(e) => onSiteChange(e.target.value)}>
            <option value="">Όλα</option>
            {availableSites.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Status</div>
          <select value={status} onChange={(e) => onStatusChange(e.target.value)}>
            <option value="ALL">Όλα</option>
            <option value="OPEN">Ανοιχτά</option>
            <option value="CLOSED">Κλειστά</option>
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Incident</div>
          <input
            value={incidentSearch}
            onChange={(e) => onIncidentSearchChange(e.target.value)}
            placeholder="Search ID..."
          />
        </label>
      </div>
    </div>
  );
}
