type Props = {
  siteId: string;
  status: string;
  authority: string;
  incidentSearch: string;
  availableSites: string[];
  availableAuthorities: string[];
  onSiteChange: (value: string) => void;
  onStatusChange: (value: string) => void;
  onAuthorityChange: (value: string) => void;
  onIncidentSearchChange: (value: string) => void;
};

export function ExternalNotificationsFilters({
  siteId,
  status,
  authority,
  incidentSearch,
  availableSites,
  availableAuthorities,
  onSiteChange,
  onStatusChange,
  onAuthorityChange,
  onIncidentSearchChange,
}: Props) {
  return (
    <div className="filter-panel" style={{ marginTop: 12, marginBottom: 16 }}>
      <div className="filter-panel-grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))" }}>
        <label>
          <div className="filter-panel-title">Site</div>
          <select value={siteId} onChange={(e) => onSiteChange(e.target.value)}>
            <option value="">Όλα</option>
            {availableSites.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Status</div>
          <select value={status} onChange={(e) => onStatusChange(e.target.value)}>
            <option value="ALL">Όλα</option>
            <option value="REQUESTED">REQUESTED</option>
            <option value="APPROVED">APPROVED</option>
            <option value="SENT">SENT</option>
            <option value="ACKNOWLEDGED">ACKNOWLEDGED</option>
            <option value="REJECTED">REJECTED</option>
            <option value="CLOSED">CLOSED</option>
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Authority</div>
          <select value={authority} onChange={(e) => onAuthorityChange(e.target.value)}>
            <option value="">Όλες</option>
            {availableAuthorities.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">Incident</div>
          <input
            value={incidentSearch}
            onChange={(e) => onIncidentSearchChange(e.target.value)}
            placeholder="Search incident..."
          />
        </label>
      </div>
    </div>
  );
}
