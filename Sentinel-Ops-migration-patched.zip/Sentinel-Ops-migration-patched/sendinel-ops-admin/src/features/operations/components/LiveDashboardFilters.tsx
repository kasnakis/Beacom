type Props = {
  siteId: string;
  category: string;
  severity: string;
  availableSites: string[];
  availableCategories: string[];
  availableSeverities: string[];
  onSiteChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onSeverityChange: (value: string) => void;
};

export function LiveDashboardFilters({
  siteId,
  category,
  severity,
  availableSites,
  availableCategories,
  availableSeverities,
  onSiteChange,
  onCategoryChange,
  onSeverityChange,
}: Props) {
  return (
    <div
      className="filter-panel"
      style={{ marginTop: 12, marginBottom: 16 }}
    >
      <div
        style={{
          marginBottom: 10,
          fontSize: 12,
          opacity: 0.75,
          lineHeight: 1.45,
        }}
      >
        Φιλτράρετε τη ζωντανή επιχειρησιακή εικόνα ανά
        μονάδα, κατηγορία συμβάντος και επίπεδο
        σοβαρότητας.
      </div>

      <div
        className="filter-panel-grid"
        style={{
          gridTemplateColumns:
            "repeat(3, minmax(0, 1fr))",
        }}
      >
        <label>
          <div className="filter-panel-title">
            Μονάδα Εργασίας
          </div>

          <select
            value={siteId}
            onChange={(e) =>
              onSiteChange(e.target.value)
            }
          >
            <option value="">Όλες</option>

            {availableSites.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">
            Κατηγορία Συμβάντος
          </div>

          <select
            value={category}
            onChange={(e) =>
              onCategoryChange(e.target.value)
            }
          >
            <option value="">Όλες</option>

            {availableCategories.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>

        <label>
          <div className="filter-panel-title">
            Σοβαρότητα
          </div>

          <select
            value={severity}
            onChange={(e) =>
              onSeverityChange(e.target.value)
            }
          >
            <option value="">Όλες</option>

            {availableSeverities.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}