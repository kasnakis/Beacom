export type BadgeTone =
  | "neutral"
  | "info"
  | "success"
  | "warning"
  | "danger"
  | "accent";

export type BadgeSpec = {
  label: string;
  tone: BadgeTone;
};

function normalize(value?: string) {
  return (value || "").trim().toUpperCase();
}

export function getStatusBadgeSpec(status?: string): BadgeSpec {
  const s = normalize(status);

  switch (s) {
    case "REQUESTED":
      return { label: "REQUESTED", tone: "warning" };

    case "APPROVED":
      return { label: "APPROVED", tone: "info" };

    case "SENT":
      return { label: "SENT", tone: "success" };

    case "ACKNOWLEDGED":
    case "CONFIRMED":
      return { label: s || "ACKNOWLEDGED", tone: "success" };

    case "REJECTED":
    case "FAILED":
    case "CANCELLED":
      return { label: s, tone: "danger" };

    case "CLOSED":
      return { label: "CLOSED", tone: "accent" };

    case "PENDING":
      return { label: "PENDING", tone: "neutral" };

    case "NONE":
      return { label: "NONE", tone: "neutral" };

    case "NOT_REQUIRED":
      return { label: "NOT_REQUIRED", tone: "neutral" };

    default:
      return { label: s || "-", tone: "neutral" };
  }
}

export function getRecordKindBadgeSpec(kind?: string): BadgeSpec {
  const k = normalize(kind);

  switch (k) {
    case "CANONICAL":
      return { label: "CANONICAL", tone: "success" };
    case "LEGACY":
      return { label: "LEGACY", tone: "warning" };
    default:
      return { label: k || "-", tone: "neutral" };
  }
}

export function getModeBadgeSpec(mode?: string): BadgeSpec {
  const m = normalize(mode);

  switch (m) {
    case "AUTO":
      return { label: "AUTO", tone: "success" };
    case "MANUAL":
      return { label: "MANUAL", tone: "warning" };
    case "MANUAL_LOGGED":
      return { label: "MANUAL_LOGGED", tone: "warning" };
    case "PLAYBOOK_DRIVEN":
      return { label: "PLAYBOOK_DRIVEN", tone: "info" };
    case "NONE":
      return { label: "NONE", tone: "neutral" };
    default:
      return { label: m || "-", tone: "neutral" };
  }
}

export function getBadgeStyle(tone: BadgeTone): React.CSSProperties {
  switch (tone) {
    case "info":
      return {
        background: "var(--info-soft)",
        border: "1px solid var(--info)",
        color: "var(--info-strong)",
      };

    case "success":
      return {
        background: "var(--success-soft)",
        border: "1px solid var(--success)",
        color: "var(--success-strong)",
      };

    case "warning":
      return {
        background: "var(--warning-soft)",
        border: "1px solid var(--warning)",
        color: "var(--warning-strong)",
      };

    case "danger":
      return {
        background: "var(--danger-soft)",
        border: "1px solid var(--danger)",
        color: "var(--danger-strong)",
      };

    case "accent":
      return {
        background: "var(--accent-soft)",
        border: "1px solid var(--accent)",
        color: "var(--accent-strong)",
      };

    case "neutral":
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border-strong)",
        color: "var(--text)",
      };
  }
}