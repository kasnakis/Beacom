type Props = {
  label: string;
};

export function TeamBadge({ label }: Props) {
  return (
    <span
      style={{
        display: "inline-block",
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        background: "rgba(22,163,74,0.16)",
        border: "1px solid rgba(22,163,74,0.35)",
        color: "inherit",
      }}
    >
      {label}
    </span>
  );
}