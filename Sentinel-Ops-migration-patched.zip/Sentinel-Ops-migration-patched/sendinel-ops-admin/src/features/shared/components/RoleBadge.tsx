type Props = {
  label: string;
};

export function RoleBadge({ label }: Props) {
  return (
    <span
      style={{
        display: "inline-block",
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        background: "rgba(72,126,255,0.16)",
        border: "1px solid rgba(72,126,255,0.35)",
        color: "inherit",
      }}
    >
      {label}
    </span>
  );
}