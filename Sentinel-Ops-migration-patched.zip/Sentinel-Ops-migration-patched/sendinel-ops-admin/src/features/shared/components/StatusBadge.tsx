type Props = {
  label: string;
  tone?: "neutral" | "success" | "warning" | "danger";
};

function toneStyle(tone: Props["tone"]): React.CSSProperties {
  switch (tone) {
    case "success":
      return {
        background: "rgba(22,163,74,0.16)",
        border: "1px solid rgba(22,163,74,0.35)",
      };
    case "warning":
      return {
        background: "rgba(245,158,11,0.16)",
        border: "1px solid rgba(245,158,11,0.35)",
      };
    case "danger":
      return {
        background: "rgba(220,38,38,0.16)",
        border: "1px solid rgba(220,38,38,0.35)",
      };
    default:
      return {
        background: "rgba(255,255,255,0.08)",
        border: "1px solid rgba(255,255,255,0.14)",
      };
  }
}

export function StatusBadge({ label, tone = "neutral" }: Props) {
  return (
    <span
      style={{
        display: "inline-block",
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        color: "inherit",
        ...toneStyle(tone),
      }}
    >
      {label}
    </span>
  );
}