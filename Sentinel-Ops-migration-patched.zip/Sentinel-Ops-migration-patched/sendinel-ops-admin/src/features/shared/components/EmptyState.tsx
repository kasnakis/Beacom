export function EmptyState({ title }: { title: string }) {
  return <div className="state-card">{title}</div>;
}
