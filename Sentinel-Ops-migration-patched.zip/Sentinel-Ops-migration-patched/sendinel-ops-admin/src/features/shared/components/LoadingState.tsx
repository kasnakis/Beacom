export function LoadingState({ label = "Φόρτωση..." }: { label?: string }) {
  return <div className="state-card">{label}</div>;
}
