export function ErrorState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="state-card error-state">
      <strong>{title}</strong>
      {description ? <div>{description}</div> : null}
    </div>
  );
}
