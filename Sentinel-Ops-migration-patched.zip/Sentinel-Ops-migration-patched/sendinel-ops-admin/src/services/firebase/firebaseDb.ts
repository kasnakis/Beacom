import { getDatabase } from "firebase/database";
import { firebaseApp } from "./firebaseApp";

export const db = getDatabase(firebaseApp);