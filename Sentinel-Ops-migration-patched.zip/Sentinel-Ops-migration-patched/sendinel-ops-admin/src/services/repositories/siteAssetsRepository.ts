import { get, push, ref, remove, update } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type {
  SiteAsset,
  SiteAssetCategory,
  SiteAssetCollectionKey,
  SiteAssetInput,
} from "../../domain/models/siteAsset";
import {
  assetRequiresInspection,
  categoryForCollectionKey,
  collectionKeyForCategory,
} from "../../domain/models/siteAsset";

type AuditContext = {
  performedBy?: {
    uid?: string;
    email?: string;
    level?: string;
  };
};

const COLLECTION_KEYS: SiteAssetCollectionKey[] = ["aed", "fire_assets", "assembly_points"];

function normalizeText(value: unknown): string {
  return String(value ?? "").trim();
}

function toNumberOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeAssetId(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 96);
}

function removeUndefinedDeep<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => removeUndefinedDeep(item)) as T;
  }

  if (value && typeof value === "object") {
    const cleaned: Record<string, unknown> = {};
    Object.entries(value as Record<string, unknown>).forEach(([key, item]) => {
      if (item !== undefined) cleaned[key] = removeUndefinedDeep(item);
    });
    return cleaned as T;
  }

  return value;
}

function normalizeAssetForWrite(
  siteId: string,
  input: SiteAssetInput,
  auditCtx?: AuditContext
): SiteAsset {
  const now = Date.now();
  const category = input.category;
  const collectionKey = input.collectionKey || collectionKeyForCategory(category);
  const generatedPrefix =
    category === "AED" ? "aed" : category === "FIRE_ASSET" ? "fire" : "assembly";
  const id = normalizeAssetId(input.id || `${generatedPrefix}_${now}`);
  const name = normalizeText(input.name || input.title);

  if (!siteId) throw new Error("Το site είναι υποχρεωτικό.");
  if (!id) throw new Error("Το ID είναι υποχρεωτικό.");
  if (!name) throw new Error("Το όνομα είναι υποχρεωτικό.");

  const latitude = toNumberOrNull(input.latitude);
  const longitude = toNumberOrNull(input.longitude);

  if (latitude === null || longitude === null) {
    throw new Error("Οι συντεταγμένες latitude/longitude είναι υποχρεωτικές.");
  }

  const base: SiteAsset = {
    id,
    siteId,
    category,
    collectionKey,
    // Current mobile APK requires `name`.
    name,
    title: normalizeText(input.title || name),
    description: normalizeText(input.description),
    type: normalizeText(input.type),
    status: input.status || "ACTIVE",
    active: input.active !== false,
    latitude,
    longitude,
    building: normalizeText(input.building),
    floor: normalizeText(input.floor),
    zone: normalizeText(input.zone),
    locationNotes: normalizeText(input.locationNotes),
    serialNumber: normalizeText(input.serialNumber),
    manufacturer: normalizeText(input.manufacturer),
    model: normalizeText(input.model),
    photoUrl: normalizeText(input.photoUrl),
    photoPath: normalizeText(input.photoPath),
    photoUpdatedAt: toNumberOrNull(input.photoUpdatedAt),
    createdAt: input.createdAt || now,
    updatedAt: now,
    createdBy: input.createdBy || auditCtx?.performedBy?.uid || "unknown",
    updatedBy: auditCtx?.performedBy?.uid || "unknown",
  };

  if (assetRequiresInspection(category)) {
    base.inspection = {
      required: input.inspection?.required !== false,
      frequencyDays: toNumberOrNull(input.inspection?.frequencyDays),
      lastInspectionAt: toNumberOrNull(input.inspection?.lastInspectionAt),
      nextInspectionAt: toNumberOrNull(input.inspection?.nextInspectionAt),
      lastInspectionBy: normalizeText(input.inspection?.lastInspectionBy),
      notes: normalizeText(input.inspection?.notes),
    };
  }

  return removeUndefinedDeep(base);
}

function mapCollection(
  siteId: string,
  collectionKey: SiteAssetCollectionKey,
  value: Record<string, Omit<SiteAsset, "id" | "collectionKey"> | null> | null
): SiteAsset[] {
  if (!value) return [];
  const category = categoryForCollectionKey(collectionKey);

  return Object.entries(value)
    .filter(([, asset]) => Boolean(asset))
    .map(([id, raw]) => {
      const item = raw || ({} as Omit<SiteAsset, "id" | "collectionKey">);
      return {
        ...item,
        id: (item as SiteAsset).id || id,
        siteId: (item as SiteAsset).siteId || siteId,
        category: (item as SiteAsset).category || category,
        collectionKey,
        name: (item as SiteAsset).name || (item as SiteAsset).title || id,
        title: (item as SiteAsset).title || (item as SiteAsset).name || id,
      } as SiteAsset;
    });
}

async function listBySite(siteId: string): Promise<SiteAsset[]> {
  if (!siteId) return [];

  const snapshot = await get(ref(db, `site_assets/${siteId}`));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Partial<
    Record<SiteAssetCollectionKey, Record<string, Omit<SiteAsset, "id" | "collectionKey"> | null>>
  >;

  return COLLECTION_KEYS.flatMap((collectionKey) =>
    mapCollection(siteId, collectionKey, value[collectionKey] || null)
  ).sort((a, b) => (a.name || "").localeCompare(b.name || "", "el"));
}

async function saveAsset(siteId: string, input: SiteAssetInput, auditCtx?: AuditContext): Promise<void> {
  const asset = normalizeAssetForWrite(siteId, input, auditCtx);
  const collectionKey = asset.collectionKey || collectionKeyForCategory(asset.category);
  const updates: Record<string, unknown> = {};

  updates[`site_assets/${siteId}/${collectionKey}/${asset.id}`] = asset;

  const auditRef = push(ref(db, "site_asset_audit_logs"));
  updates[`site_asset_audit_logs/${auditRef.key}`] = {
    action: "SITE_ASSET_SAVED",
    siteId,
    assetId: asset.id,
    category: asset.category,
    collectionKey,
    createdAt: Date.now(),
    source: "WEB_ADMIN",
    performedBy: {
      uid: auditCtx?.performedBy?.uid || "unknown",
      email: auditCtx?.performedBy?.email || "",
      level: auditCtx?.performedBy?.level || "UNKNOWN",
    },
  };

  await update(ref(db), updates);
}

async function deleteAsset(
  siteId: string,
  category: SiteAssetCategory,
  id: string,
  auditCtx?: AuditContext
): Promise<void> {
  const collectionKey = collectionKeyForCategory(category);
  await remove(ref(db, `site_assets/${siteId}/${collectionKey}/${id}`));

  const auditRef = push(ref(db, "site_asset_audit_logs"));
  await update(ref(db), {
    [`site_asset_audit_logs/${auditRef.key}`]: {
      action: "SITE_ASSET_DELETED",
      siteId,
      assetId: id,
      category,
      collectionKey,
      createdAt: Date.now(),
      source: "WEB_ADMIN",
      performedBy: {
        uid: auditCtx?.performedBy?.uid || "unknown",
        email: auditCtx?.performedBy?.email || "",
        level: auditCtx?.performedBy?.level || "UNKNOWN",
      },
    },
  });
}

async function importAssets(siteId: string, inputs: SiteAssetInput[], auditCtx?: AuditContext): Promise<number> {
  const updates: Record<string, unknown> = {};
  const now = Date.now();

  inputs.forEach((input) => {
    const asset = normalizeAssetForWrite(siteId, input, auditCtx);
    const collectionKey = asset.collectionKey || collectionKeyForCategory(asset.category);
    updates[`site_assets/${siteId}/${collectionKey}/${asset.id}`] = {
      ...asset,
      updatedAt: now,
    };
  });

  const auditRef = push(ref(db, "site_asset_audit_logs"));
  updates[`site_asset_audit_logs/${auditRef.key}`] = {
    action: "SITE_ASSETS_IMPORTED",
    siteId,
    importedCount: inputs.length,
    createdAt: now,
    source: "WEB_ADMIN",
    performedBy: {
      uid: auditCtx?.performedBy?.uid || "unknown",
      email: auditCtx?.performedBy?.email || "",
      level: auditCtx?.performedBy?.level || "UNKNOWN",
    },
  };

  await update(ref(db), updates);
  return inputs.length;
}

export const siteAssetsRepository = {
  listBySite,
  saveAsset,
  deleteAsset,
  importAssets,
};
