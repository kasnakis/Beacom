import { get, ref } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { AppConfig } from "../../domain/models/appConfig";

async function getAppConfig(): Promise<AppConfig | null> {
  const snapshot = await get(ref(db, "app_config"));
  if (!snapshot.exists()) return null;

  return snapshot.val() as AppConfig;
}

export const appConfigRepository = {
  getAppConfig,
};