import { get, ref } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { ExternalAuthority } from "../../domain/models/externalAuthority";

async function listBySite(siteId: string): Promise<ExternalAuthority[]> {
  const snapshot = await get(ref(db, `site_config_data/${siteId}/external_authorities`));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<ExternalAuthority, "id">>;

  return Object.entries(value).map(([id, item]) => ({
    id,
    ...item,
  }));
}

export const externalAuthoritiesRepository = {
  listBySite,
};