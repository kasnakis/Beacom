import { get, ref, query, orderByChild, limitToLast, endAt } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { IncidentEventRecord } from "../../domain/models/incidentEvent";

const PAGE_SIZE = 50;

async function listLatest(): Promise<IncidentEventRecord[]> {
  const q = query(
    ref(db, "incident_events"),
    orderByChild("createdAt"),
    limitToLast(PAGE_SIZE)
  );

  const snapshot = await get(q);
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<IncidentEventRecord, "id">>;

  return Object.entries(value)
    .map(([id, item]) => ({ id, ...item }))
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

async function listBefore(lastCreatedAt: number): Promise<IncidentEventRecord[]> {
  const q = query(
    ref(db, "incident_events"),
    orderByChild("createdAt"),
    endAt(lastCreatedAt - 1),
    limitToLast(PAGE_SIZE)
  );

  const snapshot = await get(q);
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<IncidentEventRecord, "id">>;

  return Object.entries(value)
    .map(([id, item]) => ({ id, ...item }))
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

export const incidentEventsRepository = {
  listLatest,
  listBefore,
};