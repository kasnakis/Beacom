import { get, ref, update } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { IncidentPolicy } from "../../domain/models/incidentPolicy";

function asRecord(value: unknown): Record<string, any> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, any>;
  }
  return {};
}

function isPlainObject(value: unknown): value is Record<string, any> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function deepMerge<T extends Record<string, any>>(
  base: T,
  patch: Record<string, any>
): T {
  const result: Record<string, any> = { ...base };

  Object.entries(patch).forEach(([key, value]) => {
    if (value === undefined) return;

    const previous = result[key];

    if (isPlainObject(previous) && isPlainObject(value)) {
      result[key] = deepMerge(previous, value);
      return;
    }

    result[key] = value;
  });

  return result as T;
}

function normalizePolicy(rawInput: unknown, key: string): IncidentPolicy {
  const raw = asRecord(rawInput);

  const verification = asRecord(raw.verification);
  const dispatch = asRecord(raw.dispatch);
  const notifications = asRecord(raw.notifications);
  const externalAuthorities = asRecord(raw.externalAuthorities);
  const closure = asRecord(raw.closure);
  const playbooks = asRecord(raw.playbooks);

  return {
    ...raw,
    key,

    active: raw.active ?? raw.enabled ?? true,
    displayName: raw.displayName ?? key,
    description: raw.description,

    category: raw.category,
    type: raw.type,
    subtype: raw.subtype,
    siteId: raw.siteId,

    // --------------------------
    // flat fields (existing UI)
    // --------------------------
    requiresVerification:
      raw.requiresVerification ??
      verification.required ??
      raw.workflow?.requiresVerification ??
      false,

    verificationRoles:
      raw.verificationRoles ??
      verification.roles ??
      verification.allowedRoles ??
      {},

    minimumApprovals:
      raw.minimumApprovals ??
      verification.minimumApprovals ??
      1,

    postVerifyDispatchMode:
      raw.postVerifyDispatchMode ??
      dispatch.mode ??
      "NONE",

    allowAutoDispatch:
      raw.allowAutoDispatch ??
      dispatch.allowAutoDispatch ??
      raw.workflow?.autoDispatchOnCreate ??
      false,

    dispatchRoles:
      raw.dispatchRoles ??
      dispatch.roles ??
      dispatch.responderRoles ??
      {},

    dispatchTeams:
      raw.dispatchTeams ??
      dispatch.teams ??
      dispatch.responseTeams ??
      {},

    trackingEnabled:
      raw.trackingEnabled ??
      dispatch.trackingEnabled ??
      false,

    notificationMode:
      raw.notificationMode ??
      notifications.mode ??
      "NONE",

    notificationTargets:
      raw.notificationTargets ??
      notifications.targets ??
      {},

    externalEnabled:
      raw.externalEnabled ??
      externalAuthorities.enabled ??
      raw.externalNotificationPolicy?.enabled ??
      false,

    externalAuthorityTypes:
      raw.externalAuthorityTypes ??
      externalAuthorities.authorityTypes ??
      externalAuthorities.authorities ??
      raw.externalNotificationPolicy?.authorityTypes ??
      raw.externalNotificationPolicy?.authorityIds ??
      {},

    externalMode:
      raw.externalMode ??
      externalAuthorities.mode ??
      raw.externalNotificationPolicy?.mode ??
      "NONE",

    closureRoles:
      raw.closureRoles ??
      closure.closureRoles ??
      closure.allowedRoles ??
      {},

    requiresVerifiedIncident:
      raw.requiresVerifiedIncident ??
      closure.requiresVerifiedIncident ??
      false,

    closureMode:
      raw.closureMode ??
      closure.mode ??
      "MANUAL",

    // --------------------------
    // structured fields
    // Keep the original nested policy object and only add editor-friendly aliases.
    // This avoids hiding production fields such as allowedRoles, finalAuthorityRoles,
    // workflowExtensions, reviewMatrix, dimensionConfig, etc.
    // --------------------------
    verification: {
      ...verification,
      required:
        verification.required ??
        raw.requiresVerification ??
        raw.workflow?.requiresVerification ??
        false,
      roles:
        verification.roles ??
        raw.verificationRoles ??
        verification.allowedRoles ??
        {},
      minimumApprovals:
        verification.minimumApprovals ??
        raw.minimumApprovals ??
        1,
    },

    dispatch: {
      ...dispatch,
      mode:
        dispatch.mode ??
        raw.postVerifyDispatchMode ??
        "NONE",
      allowAutoDispatch:
        dispatch.allowAutoDispatch ??
        raw.allowAutoDispatch ??
        raw.workflow?.autoDispatchOnCreate ??
        false,
      roles:
        dispatch.roles ??
        raw.dispatchRoles ??
        dispatch.responderRoles ??
        {},
      teams:
        dispatch.teams ??
        raw.dispatchTeams ??
        dispatch.responseTeams ??
        {},
      trackingEnabled:
        dispatch.trackingEnabled ??
        raw.trackingEnabled ??
        false,
    },

    notifications: {
      ...notifications,
      mode:
        notifications.mode ??
        raw.notificationMode ??
        "NONE",
      targets:
        notifications.targets ??
        raw.notificationTargets ??
        {},
    },

    externalAuthorities: {
      ...externalAuthorities,
      enabled:
        externalAuthorities.enabled ??
        raw.externalEnabled ??
        raw.externalNotificationPolicy?.enabled ??
        false,
      mode:
        externalAuthorities.mode ??
        raw.externalMode ??
        raw.externalNotificationPolicy?.mode ??
        "NONE",
      authorities:
        externalAuthorities.authorities ??
        raw.externalAuthorityTypes ??
        raw.externalNotificationPolicy?.authorityIds ??
        raw.externalNotificationPolicy?.authorityTypes ??
        {},
      authorityTypes:
        externalAuthorities.authorityTypes ??
        raw.externalAuthorityTypes ??
        raw.externalNotificationPolicy?.authorityTypes ??
        raw.externalNotificationPolicy?.authorityIds ??
        {},
    },

    closure: {
      ...closure,
      mode:
        closure.mode ??
        raw.closureMode ??
        "MANUAL",
      allowedRoles:
        closure.allowedRoles ??
        raw.closureRoles ??
        {},
      closureRoles:
        closure.closureRoles ??
        raw.closureRoles ??
        closure.allowedRoles ??
        {},
      requiresVerifiedIncident:
        closure.requiresVerifiedIncident ??
        raw.requiresVerifiedIncident ??
        false,
    },

    playbooks: {
      ...playbooks,
      triggers: Array.isArray(playbooks.triggers) ? playbooks.triggers : playbooks.triggers,
    },

    metadata: raw.metadata,
    tags: raw.tags,
    triggers: raw.triggers,
  };
}

async function listBySite(siteId: string): Promise<IncidentPolicy[]> {
  const snapshot = await get(ref(db, `site_config_data/${siteId}/incident_policies`));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, unknown>;

  return Object.entries(value).map(([key, item]) => normalizePolicy(item, key));
}

async function getBySiteAndKey(siteId: string, key: string): Promise<IncidentPolicy | null> {
  const snapshot = await get(ref(db, `site_config_data/${siteId}/incident_policies/${key}`));
  if (!snapshot.exists()) return null;

  return normalizePolicy(snapshot.val(), key);
}

type IncidentPolicyEditableFields = {
  active?: boolean;
  displayName?: string;

  requiresVerification?: boolean;
  verificationRoles?: Record<string, boolean>;
  minimumApprovals?: number;

  postVerifyDispatchMode?: string;
  allowAutoDispatch?: boolean;
  dispatchRoles?: Record<string, boolean>;
  dispatchTeams?: Record<string, boolean>;
  trackingEnabled?: boolean;

  notificationMode?: string;
  notificationTargets?: Record<string, boolean>;

  externalEnabled?: boolean;
  externalAuthorityTypes?: Record<string, boolean>;
  externalMode?: string;

  allowedRequesterRoles?: Record<string, boolean>;
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
  approvalRequired?: boolean;
  acknowledgementRequired?: boolean;
  externalChannels?: Record<string, boolean>;

  closureRoles?: Record<string, boolean>;
  requiresVerifiedIncident?: boolean;
  requiresActionsCompleted?: boolean;
  requiresInvestigationCompleted?: boolean;
  overrideRoles?: Record<string, boolean>;
  overrideRequiresNotes?: boolean;

  // structured optional sections
  verification?: IncidentPolicy["verification"];
  dispatch?: IncidentPolicy["dispatch"];
  notifications?: IncidentPolicy["notifications"];
  externalAuthorities?: IncidentPolicy["externalAuthorities"];
  closure?: IncidentPolicy["closure"];
  playbooks?: IncidentPolicy["playbooks"];
};

function buildPolicyPatch(
  existingPolicy: Record<string, any>,
  payload: IncidentPolicyEditableFields
): Record<string, unknown> {
  const patch: Record<string, unknown> = {
    ...payload,
  };

  delete patch.verification;
  delete patch.dispatch;
  delete patch.notifications;
  delete patch.externalAuthorities;
  delete patch.closure;
  delete patch.playbooks;

  const existingVerification = asRecord(existingPolicy.verification);
  if (
    payload.requiresVerification !== undefined ||
    payload.verificationRoles ||
    payload.minimumApprovals !== undefined ||
    payload.verification
  ) {
    const verificationPatch: Record<string, unknown> = {};

    if (payload.requiresVerification !== undefined) {
      verificationPatch.required = payload.requiresVerification;
    }
    if (payload.verificationRoles) {
      verificationPatch.roles = payload.verificationRoles;

      // Preserve existing production schema style. Many current RTDB policies use
      // verification.allowedRoles instead of verification.roles.
      if (existingVerification.allowedRoles !== undefined) {
        verificationPatch.allowedRoles = payload.verificationRoles;
      }
    }
    if (payload.minimumApprovals !== undefined) {
      verificationPatch.minimumApprovals = payload.minimumApprovals;
    }

    patch.verification = deepMerge(
      existingVerification,
      deepMerge(verificationPatch, asRecord(payload.verification))
    );
  }

  const existingDispatch = asRecord(existingPolicy.dispatch);
  if (
    payload.postVerifyDispatchMode !== undefined ||
    payload.allowAutoDispatch !== undefined ||
    payload.dispatchRoles ||
    payload.dispatchTeams ||
    payload.trackingEnabled !== undefined ||
    payload.dispatch
  ) {
    const dispatchPatch: Record<string, unknown> = {};

    if (payload.postVerifyDispatchMode !== undefined) {
      dispatchPatch.mode = payload.postVerifyDispatchMode;
    }
    if (payload.allowAutoDispatch !== undefined) {
      dispatchPatch.allowAutoDispatch = payload.allowAutoDispatch;
    }
    if (payload.dispatchRoles) {
      dispatchPatch.roles = payload.dispatchRoles;

      if (existingDispatch.responderRoles !== undefined) {
        dispatchPatch.responderRoles = payload.dispatchRoles;
      }
    }
    if (payload.dispatchTeams) {
      dispatchPatch.teams = payload.dispatchTeams;

      if (existingDispatch.responseTeams !== undefined) {
        dispatchPatch.responseTeams = payload.dispatchTeams;
      }
    }
    if (payload.trackingEnabled !== undefined) {
      dispatchPatch.trackingEnabled = payload.trackingEnabled;
    }

    patch.dispatch = deepMerge(
      existingDispatch,
      deepMerge(dispatchPatch, asRecord(payload.dispatch))
    );
  }

  const existingNotifications = asRecord(existingPolicy.notifications);
  if (
    payload.notificationMode !== undefined ||
    payload.notificationTargets ||
    payload.notifications
  ) {
    const notificationPatch: Record<string, unknown> = {};

    if (payload.notificationMode !== undefined) {
      notificationPatch.mode = payload.notificationMode;
    }
    if (payload.notificationTargets) {
      notificationPatch.targets = payload.notificationTargets;
    }

    patch.notifications = deepMerge(
      existingNotifications,
      deepMerge(notificationPatch, asRecord(payload.notifications))
    );
  }

  const existingExternalAuthorities = asRecord(existingPolicy.externalAuthorities);
  if (
    payload.externalEnabled !== undefined ||
    payload.externalAuthorityTypes ||
    payload.externalMode !== undefined ||
    payload.allowedRequesterRoles ||
    payload.allowedApproverRoles ||
    payload.allowedExecutorRoles ||
    payload.approvalRequired !== undefined ||
    payload.acknowledgementRequired !== undefined ||
    payload.externalChannels ||
    payload.externalAuthorities
  ) {
    const externalPatch: Record<string, unknown> = {};

    if (payload.externalEnabled !== undefined) {
      externalPatch.enabled = payload.externalEnabled;
    }
    if (payload.externalMode !== undefined) {
      externalPatch.mode = payload.externalMode;
    }
    if (payload.externalAuthorityTypes) {
      externalPatch.authorities = payload.externalAuthorityTypes;
      externalPatch.authorityTypes = payload.externalAuthorityTypes;
    }
    if (payload.allowedRequesterRoles) {
      externalPatch.allowedRequesterRoles = payload.allowedRequesterRoles;
    }
    if (payload.allowedApproverRoles) {
      externalPatch.allowedApproverRoles = payload.allowedApproverRoles;
    }
    if (payload.allowedExecutorRoles) {
      externalPatch.allowedExecutorRoles = payload.allowedExecutorRoles;
    }
    if (payload.approvalRequired !== undefined) {
      externalPatch.approvalRequired = payload.approvalRequired;
    }
    if (payload.acknowledgementRequired !== undefined) {
      externalPatch.requireAcknowledgement = payload.acknowledgementRequired;
    }
    if (payload.externalChannels) {
      externalPatch.channels = payload.externalChannels;
    }

    patch.externalAuthorities = deepMerge(
      existingExternalAuthorities,
      deepMerge(externalPatch, asRecord(payload.externalAuthorities))
    );
  }

  const existingClosure = asRecord(existingPolicy.closure);
  if (
    payload.closureRoles ||
    payload.requiresVerifiedIncident !== undefined ||
    payload.requiresActionsCompleted !== undefined ||
    payload.requiresInvestigationCompleted !== undefined ||
    payload.overrideRoles ||
    payload.overrideRequiresNotes !== undefined ||
    payload.closure
  ) {
    const closurePatch: Record<string, unknown> = {};

    if (payload.closureRoles) {
      closurePatch.allowedRoles = payload.closureRoles;
      closurePatch.closureRoles = payload.closureRoles;
    }
    if (payload.requiresVerifiedIncident !== undefined) {
      closurePatch.requiresVerifiedIncident = payload.requiresVerifiedIncident;
    }
    if (payload.requiresActionsCompleted !== undefined) {
      closurePatch.requiresActionsCompleted = payload.requiresActionsCompleted;
    }
    if (payload.requiresInvestigationCompleted !== undefined) {
      closurePatch.requiresInvestigationCompleted = payload.requiresInvestigationCompleted;
    }
    if (payload.overrideRoles) {
      closurePatch.overrideRoles = payload.overrideRoles;
    }
    if (payload.overrideRequiresNotes !== undefined) {
      closurePatch.overrideRequiresNotes = payload.overrideRequiresNotes;
    }

    patch.closure = deepMerge(
      existingClosure,
      deepMerge(closurePatch, asRecord(payload.closure))
    );
  }

  if (payload.playbooks) {
    patch.playbooks = deepMerge(asRecord(existingPolicy.playbooks), asRecord(payload.playbooks));
  }

  return patch;
}

async function updateBasicFields(
  siteId: string,
  key: string,
  payload: IncidentPolicyEditableFields
): Promise<void> {
  const policyRef = ref(db, `site_config_data/${siteId}/incident_policies/${key}`);
  const snapshot = await get(policyRef);
  const existingPolicy = snapshot.exists() ? asRecord(snapshot.val()) : {};
  const patch = buildPolicyPatch(existingPolicy, payload);

  await update(policyRef, patch);
}

export const incidentPoliciesRepository = {
  listBySite,
  getBySiteAndKey,
  updateBasicFields,
};

export {
  listBySite,
  getBySiteAndKey,
  updateBasicFields,
};
