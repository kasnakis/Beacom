import { get, ref } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { DispatchState } from "../../domain/models/dispatch";

async function list(): Promise<DispatchState[]> {
  const snapshot = await get(ref(db, "dispatch_state"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<DispatchState, "incidentId">>;

  return Object.entries(value).map(([incidentId, item]) => ({
    incidentId,
    ...item,
  }));
}

export const dispatchRepository = { list };