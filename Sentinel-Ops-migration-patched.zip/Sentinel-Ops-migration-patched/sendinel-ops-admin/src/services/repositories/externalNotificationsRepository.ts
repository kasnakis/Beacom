import { get, ref, update } from "firebase/database";
import { httpsCallable } from "firebase/functions";
import { db } from "../firebase/firebaseDb";
import { functions } from "../firebase/firebaseFunctions";
import type { ExternalNotificationRecord } from "../../domain/models/externalNotification";

type AdminActor = {
  userId: string;
  name: string;
  role?: string;
  siteId?: string;
};

type RawRecord = Record<string, any>;

function asRecord(value: unknown): RawRecord {
  if (value && typeof value === "object") {
    return value as RawRecord;
  }
  return {};
}

function normalizeStatus(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value.trim().toUpperCase();
  return normalized || undefined;
}

function pickNumber(...values: unknown[]): number | undefined {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
  }
  return undefined;
}

function pickString(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) {
      return value;
    }
  }
  return undefined;
}

function normalizeApproval(item: RawRecord) {
  const approval = asRecord(item.approval);

  return {
    ...approval,
    required:
      typeof approval.required === "boolean"
        ? approval.required
        : typeof item.approvalRequired === "boolean"
          ? item.approvalRequired
          : undefined,
    status: normalizeStatus(approval.status),
    approvedByUserId: pickString(approval.approvedByUserId),
    approvedByName: pickString(approval.approvedByName, approval.decisionByName),
    approvedByRole: pickString(approval.approvedByRole, approval.decisionByRole),
    approvedAt: pickNumber(approval.approvedAt, approval.decisionAt),
    decisionAt: pickNumber(approval.decisionAt, approval.approvedAt),
    decisionByName: pickString(approval.decisionByName, approval.approvedByName),
    decisionByRole: pickString(approval.decisionByRole, approval.approvedByRole),
  };
}

function normalizeExecution(item: RawRecord) {
  const execution = asRecord(item.execution);

  return {
    ...execution,
    status: normalizeStatus(execution.status),
    executedByUserId: pickString(execution.executedByUserId),
    executedByName: pickString(execution.executedByName),
    executedAt: pickNumber(execution.executedAt),
    resultNotes: pickString(execution.resultNotes, item.resultNotes, item.notes),
  };
}

function normalizeAcknowledgement(item: RawRecord) {
  const acknowledgement = asRecord(item.acknowledgement);

  const receivedBy = pickString(
    acknowledgement.receivedBy,
    acknowledgement.acknowledgedBy
  );
  const receivedAt = pickNumber(
    acknowledgement.receivedAt,
    acknowledgement.acknowledgedAt
  );

  return {
    ...acknowledgement,
    status: normalizeStatus(acknowledgement.status),
    receivedBy,
    receivedAt,
    notes: pickString(acknowledgement.notes),
  };
}

function normalizeContacts(item: RawRecord) {
  if (item.contacts && typeof item.contacts === "object") {
    return item.contacts;
  }

  const primary = item.contact && typeof item.contact === "object" ? item.contact : undefined;
  const secondary =
    item.contactSecondary && typeof item.contactSecondary === "object"
      ? item.contactSecondary
      : undefined;

  if (!primary && !secondary) {
    return undefined;
  }

  return {
    primary,
    secondary,
  };
}

function deriveNotes(item: RawRecord): string {
  return (
    pickString(
      item.notes,
      item.resultNotes,
      asRecord(item.execution).resultNotes,
      asRecord(item.acknowledgement).notes
    ) || ""
  );
}

function deriveUpdatedAt(item: RawRecord): number | undefined {
  return pickNumber(
    item.updatedAt,
    item.lastUpdatedAt,
    asRecord(item.execution).executedAt,
    asRecord(item.acknowledgement).receivedAt,
    asRecord(item.acknowledgement).acknowledgedAt,
    asRecord(item.approval).approvedAt,
    asRecord(item.approval).decisionAt,
    item.createdAt
  );
}

function mapCanonicalRecord(id: string, item: RawRecord): ExternalNotificationRecord {
  return {
    id,
    incidentId: pickString(item.incidentId) || "",
    siteId: pickString(item.siteId),
    category: pickString(item.category),

    authorityId: pickString(item.authorityId),
    authorityName: pickString(item.authorityName),
    authorityType: pickString(item.authorityType),

    channel: pickString(item.channel),
    status: normalizeStatus(item.status),
    mode: pickString(item.mode),
    source: pickString(item.source),
    trigger: pickString(item.trigger),

    playbookId: pickString(item.playbookId),
    playbookTitle: pickString(item.playbookTitle),
    stepId: pickString(item.stepId),
    stepTitle: pickString(item.stepTitle),

    approval: normalizeApproval(item),
    execution: normalizeExecution(item),
    acknowledgement: normalizeAcknowledgement(item),

    contacts: normalizeContacts(item),

    notes: deriveNotes(item),
    legacyRequestId: pickString(item.legacyRequestId),

    createdAt: pickNumber(item.createdAt),
    updatedAt: deriveUpdatedAt(item),

    recordKind: "CANONICAL",
    dataPath: `external_notifications/${id}`,
  };
}

function mapLegacyRecord(id: string, item: RawRecord): ExternalNotificationRecord {
  return {
    id,
    incidentId: pickString(item.incidentId) || "",
    siteId: pickString(item.siteId),
    category: pickString(item.category),

    authorityId: pickString(item.authorityId),
    authorityName: pickString(item.authorityName),
    authorityType: pickString(item.authorityType),

    channel: pickString(item.channel),
    status: normalizeStatus(item.status),
    mode: pickString(item.mode),
    source: pickString(item.source),
    trigger: pickString(item.trigger),

    playbookId: pickString(item.playbookId),
    playbookTitle: pickString(item.playbookTitle),
    stepId: pickString(item.stepId),
    stepTitle: pickString(item.stepTitle),

    allowedApproverRoles:
      item.allowedApproverRoles && typeof item.allowedApproverRoles === "object"
        ? item.allowedApproverRoles
        : undefined,
    allowedExecutorRoles:
      item.allowedExecutorRoles && typeof item.allowedExecutorRoles === "object"
        ? item.allowedExecutorRoles
        : undefined,
    allowedRequesterRoles:
      item.allowedRequesterRoles && typeof item.allowedRequesterRoles === "object"
        ? item.allowedRequesterRoles
        : undefined,

    approval: normalizeApproval(item),
    execution: normalizeExecution(item),
    acknowledgement: normalizeAcknowledgement(item),

    contacts: normalizeContacts(item),

    notes: deriveNotes(item),
    legacyRequestId: pickString(item.legacyRequestId) || id,

    createdAt: pickNumber(item.createdAt),
    updatedAt: deriveUpdatedAt(item),

    recordKind: "LEGACY",
    dataPath: `external_notification_requests/${id}`,
  };
}

function dedupeRecords(
  canonicalItems: ExternalNotificationRecord[],
  legacyItems: ExternalNotificationRecord[]
): ExternalNotificationRecord[] {
  const result: ExternalNotificationRecord[] = [];
  const coveredLegacyIds = new Set<string>();

  for (const item of canonicalItems) {
    result.push(item);

    if (item.legacyRequestId) {
      coveredLegacyIds.add(item.legacyRequestId);
    }
  }

  for (const item of legacyItems) {
    if (coveredLegacyIds.has(item.id)) {
      continue;
    }
    result.push(item);
  }

  return result;
}

async function list(): Promise<ExternalNotificationRecord[]> {
  const [canonicalSnapshot, legacySnapshot] = await Promise.all([
    get(ref(db, "external_notifications")),
    get(ref(db, "external_notification_requests")),
  ]);

  const canonicalItems: ExternalNotificationRecord[] = canonicalSnapshot.exists()
    ? Object.entries(asRecord(canonicalSnapshot.val())).map(([id, raw]) =>
        mapCanonicalRecord(id, asRecord(raw))
      )
    : [];

  const legacyItems: ExternalNotificationRecord[] = legacySnapshot.exists()
    ? Object.entries(asRecord(legacySnapshot.val())).map(([id, raw]) =>
        mapLegacyRecord(id, asRecord(raw))
      )
    : [];

  return dedupeRecords(canonicalItems, legacyItems);
}

function toFunctionActor(actor: AdminActor, item: ExternalNotificationRecord) {
  return {
    userId: actor.userId,
    displayName: actor.name,
    siteId: actor.siteId || item.siteId || "",
    roles: actor.role ? [actor.role] : ["ADMIN_PORTAL"],
    sessionType: "REAL_SESSION" as const,
  };
}

// ============================================
// CANONICAL -> direct update on canonical node
// LEGACY    -> existing callable compatibility
// ============================================

async function approve(item: ExternalNotificationRecord, actor: AdminActor) {
  if (item.recordKind === "LEGACY") {
    const fn = httpsCallable(functions, "approveExternalNotification");
    await fn({
      notificationId: item.id,
      actor: toFunctionActor(actor, item),
      notes: "",
    });
    return;
  }

  if (!item.dataPath) {
    throw new Error("Missing dataPath");
  }

  const now = Date.now();

  await update(ref(db, item.dataPath), {
    status: "APPROVED",
    updatedAt: now,
    approval: {
      ...(item.approval ?? {}),
      required: item.approval?.required ?? false,
      status: "APPROVED",
      approvedByUserId: actor.userId,
      approvedByName: actor.name,
      approvedByRole: actor.role ?? "",
      approvedAt: now,
      decisionAt: now,
      decisionByName: actor.name,
      decisionByRole: actor.role ?? "",
    },
  });
}

async function reject(
  item: ExternalNotificationRecord,
  actor: AdminActor,
  reason: string
) {
  if (item.recordKind === "LEGACY") {
    const fn = httpsCallable(functions, "rejectExternalNotification");
    await fn({
      notificationId: item.id,
      actor: toFunctionActor(actor, item),
      reason,
      notes: reason,
    });
    return;
  }

  if (!item.dataPath) {
    throw new Error("Missing dataPath");
  }

  const now = Date.now();

  await update(ref(db, item.dataPath), {
    status: "REJECTED",
    updatedAt: now,
    notes: reason || item.notes || "",
    approval: {
      ...(item.approval ?? {}),
      required: item.approval?.required ?? false,
      status: "REJECTED",
      decisionAt: now,
      decisionByName: actor.name,
      decisionByRole: actor.role ?? "",
      rejectionReason: reason || "",
    },
  });
}

async function markSent(
  item: ExternalNotificationRecord,
  actor: AdminActor,
  resultNotes: string
) {
  if (item.recordKind === "LEGACY") {
    const fn = httpsCallable(functions, "markExternalNotificationSent");
    await fn({
      notificationId: item.id,
      actor: toFunctionActor(actor, item),
      resultNotes,
      notes: resultNotes,
    });
    return;
  }

  if (!item.dataPath) {
    throw new Error("Missing dataPath");
  }

  const now = Date.now();

  await update(ref(db, item.dataPath), {
    status: "SENT",
    updatedAt: now,
    execution: {
      ...(item.execution ?? {}),
      status: "SENT",
      executedByUserId: actor.userId,
      executedByName: actor.name,
      executedAt: now,
      resultNotes: resultNotes || item.execution?.resultNotes || "",
    },
  });
}

async function acknowledge(
  item: ExternalNotificationRecord,
  actorName: string,
  ackNotes: string,
  actor?: AdminActor
) {
  if (item.recordKind === "LEGACY") {
    const fn = httpsCallable(functions, "acknowledgeExternalNotification");
    await fn({
      notificationId: item.id,
      actor: toFunctionActor(
        actor || {
          userId: "admin-portal",
          name: actorName,
          role: "ADMIN_PORTAL",
          siteId: item.siteId,
        },
        item
      ),
      receivedBy: actorName,
      notes: ackNotes,
    });
    return;
  }

  if (!item.dataPath) {
    throw new Error("Missing dataPath");
  }

  const now = Date.now();

  await update(ref(db, item.dataPath), {
    status: "ACKNOWLEDGED",
    updatedAt: now,
    acknowledgement: {
      ...(item.acknowledgement ?? {}),
      status: "ACKNOWLEDGED",
      receivedBy: actorName,
      receivedAt: now,
      notes: ackNotes || item.acknowledgement?.notes || "",
    },
  });
}

export const externalNotificationsRepository = {
  list,
  approve,
  reject,
  markSent,
  acknowledge,
};