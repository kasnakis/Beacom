import {
  equalTo,
  get,
  limitToLast,
  orderByChild,
  push,
  query,
  ref,
  update,
} from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { AdminPermissions, SiteMembership, UserProfile } from "../../domain/models/user";

export type UserAuditLog = {
  id: string;
  targetUserId?: string;
  changedFields?: string[];
  changes?: Record<string, unknown>;
  createdAt?: number;
  source?: string;
  performedBy?: {
    uid?: string;
    email?: string;
    level?: string;
  };
};

async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const snapshot = await get(ref(db, `users/${uid}`));
  if (!snapshot.exists()) return null;

  const value = snapshot.val() as Omit<UserProfile, "uid">;
  return {
    uid,
    ...value,
  };
}

async function listUsers(): Promise<UserProfile[]> {
  const snapshot = await get(ref(db, "users"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<UserProfile, "uid">>;
  return Object.entries(value).map(([uid, user]) => ({
    uid,
    ...user,
  }));
}

async function listUserAuditLogs(
  targetUserId: string,
  limit = 30
): Promise<UserAuditLog[]> {
  const auditQuery = query(
    ref(db, "user_audit_logs"),
    orderByChild("targetUserId"),
    equalTo(targetUserId),
    limitToLast(limit)
  );

  const snapshot = await get(auditQuery);
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<UserAuditLog, "id">>;

  return Object.entries(value)
    .map(([id, log]) => ({
      id,
      ...log,
    }))
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

async function listAuditLogs(limit = 100): Promise<UserAuditLog[]> {
  const snapshot = await get(ref(db, "user_audit_logs"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<UserAuditLog, "id">>;

  return Object.entries(value)
    .map(([id, log]) => ({
      id,
      ...log,
    }))
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
    .slice(0, limit);
}

type UserEditableFields = {
  active?: boolean;
  siteId?: string;
  platformRoles?: Record<string, boolean>;
  roles?: Record<string, boolean>;
  teams?: Record<string, boolean>;
  adminPermissions?: AdminPermissions;
  siteMemberships?: Record<string, SiteMembership>;
};

type AuditContext = {
  performedBy?: {
    uid?: string;
    email?: string;
    level?: string;
  };
};

function buildDiff(
  before: any,
  after: any
): { changedFields: string[]; diff: Record<string, any> } {
  const changedFields: string[] = [];
  const diff: Record<string, any> = {};

  Object.keys(after).forEach((key) => {
    const beforeVal = before?.[key];
    const afterVal = after[key];

    if (JSON.stringify(beforeVal) !== JSON.stringify(afterVal)) {
      changedFields.push(key);
      diff[key] = {
        before: beforeVal ?? null,
        after: afterVal ?? null,
      };
    }
  });

  return { changedFields, diff };
}

async function updateBasicFields(
  uid: string,
  payload: UserEditableFields,
  auditCtx?: AuditContext
): Promise<void> {
  const updates: Record<string, unknown> = {};

  const currentUser = await getUserProfile(uid);
  const { changedFields, diff } = buildDiff(currentUser || {}, payload);

  if (!changedFields.length) {
    return;
  }

  Object.entries(payload).forEach(([key, value]) => {
    updates[`users/${uid}/${key}`] = value;
  });

  const auditRef = push(ref(db, "user_audit_logs"));

  updates[`user_audit_logs/${auditRef.key}`] = {
    targetUserId: uid,
    changedFields,
    changes: diff,
    createdAt: Date.now(),
    source: "WEB_ADMIN",
    performedBy: {
      uid: auditCtx?.performedBy?.uid || "unknown",
      email: auditCtx?.performedBy?.email || "",
      level: auditCtx?.performedBy?.level || "UNKNOWN",
    },
  };

  await update(ref(db), updates);
}

export const usersRepository = {
  getUserProfile,
  listUsers,
  listUserAuditLogs,
  listAuditLogs,
  updateBasicFields,
};

export { getUserProfile, listUsers, listUserAuditLogs, listAuditLogs };