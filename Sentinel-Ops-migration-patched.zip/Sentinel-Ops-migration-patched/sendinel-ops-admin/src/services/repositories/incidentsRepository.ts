import { get, ref } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { IncidentRecord } from "../../domain/models/incident";

async function list(): Promise<IncidentRecord[]> {
  const snapshot = await get(ref(db, "incidents"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<IncidentRecord, "id">>;

  return Object.entries(value).map(([id, item]) => ({
    id,
    ...item,
  }));
}

export const incidentsRepository = {
  list,
};