import { get, ref } from "firebase/database";
import { db } from "../firebase/firebaseDb";
import type { OperationalNotificationRequest } from "../../domain/models/operationalNotification";

type RawRecord = Record<string, any>;

function asMap(value: unknown): Record<string, boolean> | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  return value as Record<string, boolean>;
}

function pickString(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value;
  }
  return undefined;
}

function pickNumber(...values: unknown[]): number | undefined {
  for (const value of values) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
  }
  return undefined;
}

function normalizeStatus(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value.trim().toUpperCase();
  return normalized || undefined;
}

function countTokens(value: unknown): number {
  if (!value) return 0;
  if (Array.isArray(value)) return value.length;
  if (typeof value === "object") return Object.keys(value as Record<string, unknown>).length;
  return 0;
}

function mapRecord(id: string, item: RawRecord): OperationalNotificationRequest {
  const deliveryResults =
    item.deliveryResults && typeof item.deliveryResults === "object"
      ? item.deliveryResults
      : undefined;

  const invalidTokens = item.invalidTokens;
  const failedTokens = item.failedTokens;
  const retryableFailedTokens = item.retryableFailedTokens;

  return {
    id,
    dataPath: `notification_requests/${id}`,
    incidentId: pickString(item.incidentId, item.context?.incidentId),
    siteId: pickString(item.siteId, item.targetSiteId, item.context?.siteId),
    category: pickString(item.category, item.incidentCategory, item.context?.category),
    type: pickString(item.type, item.notificationType, item.context?.type),
    trigger: pickString(item.trigger, item.reason, item.context?.trigger),
    status: normalizeStatus(item.status),
    priority: pickString(item.priority),
    source: pickString(item.source, item.createdBy, item.requestedBy),
    title: pickString(item.title, item.notification?.title, item.message?.title),
    body: pickString(item.body, item.notification?.body, item.message?.body),
    targetRoles: asMap(item.targetRoles),
    targetTeams: asMap(item.targetTeams),
    targetUsers: asMap(item.targetUsers),
    createdAt: pickNumber(item.createdAt, item.requestedAt),
    updatedAt: pickNumber(item.updatedAt, item.lastUpdatedAt, item.processedAt, item.sentAt),
    processedAt: pickNumber(item.processedAt),
    sentAt: pickNumber(item.sentAt),
    nextRetryAt: pickNumber(item.nextRetryAt, item.retry?.nextRetryAt),
    retryCount: pickNumber(item.retryCount, item.retry?.attempt, item.attempt),
    maxRetries: pickNumber(item.maxRetries, item.retry?.maxRetries),
    recipientCount: pickNumber(item.recipientCount, item.targetCount, item.resolvedRecipientCount),
    successCount: pickNumber(item.successCount, item.sentCount, item.deliveredCount),
    failureCount: pickNumber(item.failureCount, item.failedCount),
    invalidTokenCount: pickNumber(item.invalidTokenCount) ?? countTokens(invalidTokens),
    retryableFailureCount: pickNumber(item.retryableFailureCount) ?? countTokens(retryableFailedTokens),
    deliveryResults,
    invalidTokens,
    failedTokens,
    retryableFailedTokens,
    error: pickString(item.error, item.errorMessage),
    lastError: pickString(item.lastError, item.retry?.lastError),
    notes: pickString(item.notes),
  };
}

async function list(): Promise<OperationalNotificationRequest[]> {
  const snapshot = await get(ref(db, "notification_requests"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, RawRecord>;
  return Object.entries(value).map(([id, item]) => mapRecord(id, item));
}

export const operationalNotificationsRepository = {
  list,
};
