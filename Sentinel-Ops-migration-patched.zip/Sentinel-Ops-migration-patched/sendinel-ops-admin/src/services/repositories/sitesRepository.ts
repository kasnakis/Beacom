import { get, push, ref, update } from "firebase/database";
import { getDownloadURL, ref as storageRef, uploadBytes } from "firebase/storage";
import { db } from "../firebase/firebaseDb";
import { storage } from "../firebase/firebaseStorage";
import type { CreateSitePayload, SiteCloneOptions, SiteSummary } from "../../domain/models/site";

type AuditContext = {
  performedBy?: {
    uid?: string;
    email?: string;
    level?: string;
  };
};

type SiteEditableFields = {
  name?: string;
  description?: string;
  active?: boolean;
  metadata?: Record<string, unknown>;
};

const DEFAULT_CLONE_OPTIONS: SiteCloneOptions = {
  cloneIncidentPolicies: false,
  cloneExternalAuthorities: false,
  cloneSiteConfigDefaults: false,
  cloneAssetCatalogs: false,
  cloneLookupSettings: false,
};

async function list(): Promise<SiteSummary[]> {
  const snapshot = await get(ref(db, "sites"));
  if (!snapshot.exists()) return [];

  const value = snapshot.val() as Record<string, Omit<SiteSummary, "id">>;
  return Object.entries(value).map(([id, item]) => ({
    id,
    ...item,
  }));
}

function normalizeSiteId(input: string): string {
  return input.trim().toLowerCase().replace(/\s+/g, "_");
}

function isValidSiteId(siteId: string): boolean {
  return /^[a-z0-9_-]{2,64}$/.test(siteId);
}

function safeCloneOptions(options?: Partial<SiteCloneOptions>): SiteCloneOptions {
  return {
    ...DEFAULT_CLONE_OPTIONS,
    ...(options || {}),
  };
}

function stripRuntimeFieldsFromSiteConfig(value: Record<string, unknown>): Record<string, unknown> {
  const forbiddenKeys = new Set([
    "users",
    "incidents",
    "dispatch_state",
    "notification_requests",
    "external_notifications",
    "external_notification_requests",
    "responder_states",
    "audit_logs",
    "user_audit_logs",
    "site_audit_logs",
  ]);

  return Object.fromEntries(
    Object.entries(value).filter(([key]) => !forbiddenKeys.has(key))
  );
}

async function maybeRead(path: string): Promise<unknown | null> {
  const snapshot = await get(ref(db, path));
  return snapshot.exists() ? snapshot.val() : null;
}

async function updateBasicFields(siteId: string, payload: SiteEditableFields): Promise<void> {
  await update(ref(db, `sites/${siteId}`), payload);
}

async function createSite(payload: CreateSitePayload, auditCtx?: AuditContext): Promise<void> {
  const siteId = normalizeSiteId(payload.siteId);
  const name = payload.name.trim();
  const description = payload.description?.trim() || "";
  const cloneOptions = safeCloneOptions(payload.cloneOptions);
  const sourceSiteId = payload.sourceSiteId?.trim() || "";

  if (!isValidSiteId(siteId)) {
    throw new Error("Μη έγκυρο Site ID. Χρησιμοποίησε 2-64 λατινικούς χαρακτήρες, αριθμούς, _ ή -.");
  }

  if (!name) {
    throw new Error("Το όνομα site είναι υποχρεωτικό.");
  }

  const existing = await get(ref(db, `sites/${siteId}`));
  if (existing.exists()) {
    throw new Error(`Υπάρχει ήδη site με Site ID '${siteId}'.`);
  }

  if (Object.values(cloneOptions).some(Boolean) && !sourceSiteId) {
    throw new Error("Επίλεξε source site για αντιγραφή ρυθμίσεων.");
  }

  const now = Date.now();
  const updates: Record<string, unknown> = {};

  updates[`sites/${siteId}`] = {
    name,
    description,
    active: payload.active,
    metadata: {
      createdAt: now,
      updatedAt: now,
      createdBy: auditCtx?.performedBy?.uid || "unknown",
      createdByEmail: auditCtx?.performedBy?.email || "",
      clonedFromSiteId: sourceSiteId || null,
      cloneOptions,
    },
  };

  if (sourceSiteId) {
    const siteConfigClone: Record<string, unknown> = {};

    if (cloneOptions.cloneIncidentPolicies) {
      const policies = await maybeRead(`site_config_data/${sourceSiteId}/incident_policies`);
      if (policies) siteConfigClone.incident_policies = policies;
    }

    if (cloneOptions.cloneExternalAuthorities) {
      const authorities = await maybeRead(`site_config_data/${sourceSiteId}/external_authorities`);
      if (authorities) siteConfigClone.external_authorities = authorities;
    }

    if (cloneOptions.cloneLookupSettings) {
      const lookups = await maybeRead(`site_config_data/${sourceSiteId}/lookups`);
      if (lookups) siteConfigClone.lookups = lookups;
    }

    if (cloneOptions.cloneSiteConfigDefaults) {
      const config = await maybeRead(`site_config_data/${sourceSiteId}`);
      if (config && typeof config === "object") {
        const cleaned = stripRuntimeFieldsFromSiteConfig(config as Record<string, unknown>);

        // These sections are handled explicitly above based on selected checkboxes.
        // This avoids accidentally cloning sections the user did not select.
        delete cleaned.incident_policies;
        delete cleaned.external_authorities;
        delete cleaned.lookups;

        Object.assign(siteConfigClone, cleaned);
      }
    }

    if (Object.keys(siteConfigClone).length > 0) {
      // Firebase RTDB rejects one update() call that contains both a parent path
      // and one of its child paths. Therefore site_config_data/{siteId} is written once.
      updates[`site_config_data/${siteId}`] = siteConfigClone;
    }

    if (cloneOptions.cloneAssetCatalogs) {
      const assetCatalogs = await maybeRead(`site_asset_catalogs/${sourceSiteId}`);
      if (assetCatalogs) updates[`site_asset_catalogs/${siteId}`] = assetCatalogs;
    }
  }

  const auditRef = push(ref(db, "site_audit_logs"));
  updates[`site_audit_logs/${auditRef.key}`] = {
    action: "SITE_CREATED",
    targetSiteId: siteId,
    changedFields: ["site"],
    changes: {
      before: null,
      after: {
        siteId,
        name,
        description,
        active: payload.active,
        sourceSiteId: sourceSiteId || null,
        cloneOptions,
      },
    },
    createdAt: now,
    source: "WEB_ADMIN",
    performedBy: {
      uid: auditCtx?.performedBy?.uid || "unknown",
      email: auditCtx?.performedBy?.email || "",
      level: auditCtx?.performedBy?.level || "UNKNOWN",
    },
  };

  await update(ref(db), updates);
}

export const sitesRepository = {
  list,
  updateBasicFields,
  createSite,
};

async function uploadSiteCoverImage(
  siteId: string,
  file: File
): Promise<string> {
  const fileRef = storageRef(
    storage,
    `site_images/${siteId}/cover.jpg`
  );

  await uploadBytes(fileRef, file);

  const downloadUrl = await getDownloadURL(fileRef);

  await update(ref(db, `sites/${siteId}`), {
    coverImageUrl: downloadUrl,
  });

  return downloadUrl;
}

export {
  list,
  createSite,
  updateBasicFields,
  uploadSiteCoverImage,
};