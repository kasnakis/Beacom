import type { UserProfile } from "../models/user";

export type EnterpriseSitePermissionKey =
  | "VIEW_SITE_INCIDENTS"
  | "RECEIVE_SITE_NOTIFICATIONS"
  | "PARTICIPATE_IN_SITE_RESPONSE";

export const ENTERPRISE_SITE_PERMISSION_OPTIONS: readonly {
  value: EnterpriseSitePermissionKey;
  label: string;
  description: string;
}[] = [
  {
    value: "VIEW_SITE_INCIDENTS",
    label: "Προβολή συμβάντων site",
    description:
      "Επιτρέπει στον χρήστη να βλέπει επιχειρησιακά συμβάντα άλλης μονάδας εργασίας στο web admin.",
  },
  {
    value: "RECEIVE_SITE_NOTIFICATIONS",
    label: "Λήψη ειδοποιήσεων site",
    description:
      "Επιτρέπει στο notification targeting να θεωρήσει τον χρήστη ρητό παραλήπτη για τη συγκεκριμένη μονάδα.",
  },
  {
    value: "PARTICIPATE_IN_SITE_RESPONSE",
    label: "Συμμετοχή σε ανταπόκριση site",
    description:
      "Επιτρέπει στον χρήστη να συμμετέχει επιχειρησιακά σε απόκριση/κινητοποίηση άλλης μονάδας, όταν το υποστηρίζει το backend/mobile flow.",
  },
];

export type SiteAccessSnapshot = {
  primarySiteId: string;
  viewableSiteIds: string[];
  notificationSiteIds: string[];
  responseSiteIds: string[];
};

function uniqSorted(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b, "el"));
}

export function getPrimarySiteId(user?: UserProfile | null): string {
  return user?.primarySiteId || user?.siteId || "";
}

export function isPrimarySite(user: UserProfile | null | undefined, siteId?: string): boolean {
  const primarySiteId = getPrimarySiteId(user);
  return Boolean(primarySiteId && siteId && primarySiteId === siteId);
}

export function hasExplicitSitePermission(
  user: UserProfile | null | undefined,
  siteId: string | undefined,
  permission: EnterpriseSitePermissionKey
): boolean {
  if (!user || !siteId) return false;

  // Enterprise rule: cross-site access is granted only by explicit permission.
  // Do NOT infer access from siteMemberships[siteId].active.
  return Boolean(user.siteMemberships?.[siteId]?.permissions?.[permission]);
}

export function canViewSiteIncidents(
  user: UserProfile | null | undefined,
  siteId: string | undefined
): boolean {
  if (!user || !siteId) return false;
  if (isPrimarySite(user, siteId)) return true;
  return hasExplicitSitePermission(user, siteId, "VIEW_SITE_INCIDENTS");
}

export function canReceiveSiteNotifications(
  user: UserProfile | null | undefined,
  siteId: string | undefined
): boolean {
  if (!user || !siteId) return false;
  if (isPrimarySite(user, siteId)) return true;
  return hasExplicitSitePermission(user, siteId, "RECEIVE_SITE_NOTIFICATIONS");
}

export function canParticipateInSiteResponse(
  user: UserProfile | null | undefined,
  siteId: string | undefined
): boolean {
  if (!user || !siteId) return false;
  if (isPrimarySite(user, siteId)) return true;
  return hasExplicitSitePermission(user, siteId, "PARTICIPATE_IN_SITE_RESPONSE");
}

export function resolveSiteAccessSnapshot(user?: UserProfile | null): SiteAccessSnapshot {
  const primarySiteId = getPrimarySiteId(user);
  const membershipSiteIds = Object.keys(user?.siteMemberships || {});

  return {
    primarySiteId,
    viewableSiteIds: uniqSorted([
      primarySiteId,
      ...membershipSiteIds.filter((siteId) => hasExplicitSitePermission(user, siteId, "VIEW_SITE_INCIDENTS")),
    ]),
    notificationSiteIds: uniqSorted([
      primarySiteId,
      ...membershipSiteIds.filter((siteId) => hasExplicitSitePermission(user, siteId, "RECEIVE_SITE_NOTIFICATIONS")),
    ]),
    responseSiteIds: uniqSorted([
      primarySiteId,
      ...membershipSiteIds.filter((siteId) => hasExplicitSitePermission(user, siteId, "PARTICIPATE_IN_SITE_RESPONSE")),
    ]),
  };
}

export function filterByIncidentVisibility<T extends { siteId?: string }>(
  user: UserProfile | null | undefined,
  items: T[]
): T[] {
  return items.filter((item) => canViewSiteIncidents(user, item.siteId));
}

export function filterByNotificationEligibility<T extends { siteId?: string }>(
  user: UserProfile | null | undefined,
  items: T[]
): T[] {
  return items.filter((item) => canReceiveSiteNotifications(user, item.siteId));
}

export function filterByResponseEligibility<T extends { siteId?: string }>(
  user: UserProfile | null | undefined,
  items: T[]
): T[] {
  return items.filter((item) => canParticipateInSiteResponse(user, item.siteId));
}
