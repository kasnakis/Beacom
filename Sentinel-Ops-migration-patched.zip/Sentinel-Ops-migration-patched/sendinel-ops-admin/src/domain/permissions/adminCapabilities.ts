import type { UserProfile, AdminLevel } from "../models/user";
import { getPrimarySiteId } from "./siteAccess";

export type AdminCapabilities = {
  canViewUser: boolean;

  canEditActive: boolean;
  canEditSite: boolean;
  canEditAdminPortal: boolean;
  canEditRoles: boolean;
  canEditTeams: boolean;

  canSave: boolean;
};

function resolveAdminLevel(user: UserProfile | null): AdminLevel {
  if (!user) return "VIEW_ONLY";

  // 🔹 explicit adminPermissions
  if (user.adminPermissions?.level) {
    return user.adminPermissions.level;
  }

  // 🔹 fallback (current behavior)
  if (user.platformRoles?.ADMIN_PORTAL) {
    return "GLOBAL_ADMIN";
  }

  return "VIEW_ONLY";
}

export function resolveAdminCapabilities(
  currentUser: UserProfile | null,
  targetUser: UserProfile | null
): AdminCapabilities {
  const level = resolveAdminLevel(currentUser);

  const currentPrimarySiteId = getPrimarySiteId(currentUser);
  const targetPrimarySiteId = getPrimarySiteId(targetUser);

  const sameSite =
    currentPrimarySiteId &&
    targetPrimarySiteId &&
    currentPrimarySiteId === targetPrimarySiteId;

  // 🔹 default deny
  let caps: AdminCapabilities = {
    canViewUser: false,

    canEditActive: false,
    canEditSite: false,
    canEditAdminPortal: false,
    canEditRoles: false,
    canEditTeams: false,

    canSave: false,
  };

  if (!targetUser) return caps;

  // =========================
  // GLOBAL ADMIN
  // =========================
  if (level === "GLOBAL_ADMIN") {
    return {
      canViewUser: true,

      canEditActive: true,
      canEditSite: true,
      canEditAdminPortal: true,
      canEditRoles: true,
      canEditTeams: true,

      canSave: true,
    };
  }

  // =========================
  // SITE ADMIN
  // =========================
  if (level === "SITE_ADMIN") {
    if (!sameSite) {
      return caps;
    }

    return {
      canViewUser: true,

      canEditActive: true,
      canEditSite: false,          // ❗ δεν αλλάζει site
      canEditAdminPortal: false,   // ❗ δεν δίνει admin portal
      canEditRoles: true,
      canEditTeams: true,

      canSave: true,
    };
  }

  // =========================
  // VIEW ONLY
  // =========================
  if (level === "VIEW_ONLY") {
    if (!sameSite) return caps;

    return {
      canViewUser: true,

      canEditActive: false,
      canEditSite: false,
      canEditAdminPortal: false,
      canEditRoles: false,
      canEditTeams: false,

      canSave: false,
    };
  }

  return caps;
}