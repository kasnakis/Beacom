export const TEAM_OPTIONS = [
  "GENERAL_USERS",
  "MANAGEMENT",
  "HSE_TEAM",
  "ENVIRONMENT_TEAM",
  "EMERGENCY_TEAM",
  "FIRE_TEAM",
  "FIRST_AID_TEAM",
  "EVACUATION_TEAM",
  "SECURITY_TEAM",
  "CONTROL_ROOM_TEAM",
  "READ_ONLY_USERS",

  // Existing legacy/team aliases kept for backward compatibility.
  "ENVIRONMENTAL_TEAM",
  "RESPONSE_TEAM",
] as const;

export type TeamOption = (typeof TEAM_OPTIONS)[number];
