export const ROLE_OPTIONS = [
  // General / management layer
  "WORKER",
  "SUPERVISOR",
  "SITE_MANAGER",
  "DIRECTOR",
  "CONTROL_ROOM",
  "SECURITY_OFFICER",
  "VIEWER",

  // HSE / environment layer
  "HSE_MANAGER",
  "HSE_RESPONDER",
  "ENVIRONMENTAL_OFFICER",
  "ENVIRONMENT_RESPONDER",

  // SAEK command layer
  "EMERGENCY_COMMANDER",
  "COMMUNICATIONS_OFFICER",
  "FIRE_SAFETY_COORDINATOR",
  "FIRST_AID_COORDINATOR",
  "PERSONNEL_COORDINATOR",

  // SAEK response layer
  "FIRE_TEAM_MEMBER",
  "FIRST_AID_RESPONDER",
  "EVACUATION_WARDEN",

  // Existing technical/support role kept for backward compatibility
  "TECHNICIAN",
] as const;

export type RoleOption = (typeof ROLE_OPTIONS)[number];
