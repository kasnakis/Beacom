export type SiteMetadata = {
  description?: string;
  createdAt?: number;
  updatedAt?: number;
  createdBy?: string;
  createdByEmail?: string;
  clonedFromSiteId?: string;
  cloneOptions?: SiteCloneOptions;
  [key: string]: unknown;
};

export type SiteCloneOptions = {
  cloneIncidentPolicies: boolean;
  cloneExternalAuthorities: boolean;
  cloneSiteConfigDefaults: boolean;
  cloneAssetCatalogs: boolean;
  cloneLookupSettings: boolean;
};

export type SiteSummary = {
  id: string;
  name?: string;
  description?: string;
  active?: boolean;
  metadata?: SiteMetadata;
};

export type SiteAdminRow = SiteSummary & {
  usersCount: number;
  openDispatchesCount: number;
  pendingExternalCount: number;
};

export type CreateSitePayload = {
  siteId: string;
  name: string;
  description?: string;
  active: boolean;
  sourceSiteId?: string;
  cloneOptions: SiteCloneOptions;
};

export type SiteMedia = {
  coverImageUrl?: string;
};