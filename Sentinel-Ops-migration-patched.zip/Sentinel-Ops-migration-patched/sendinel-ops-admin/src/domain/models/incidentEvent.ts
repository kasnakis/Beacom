export type IncidentEventRecord = {
  id: string;
  incidentId: string;
  siteId?: string;
  eventType: string;
  source?: string;
  userId?: string;
  userName?: string;
  incidentStatus?: string;
  createdAt: number;
  extra?: Record<string, unknown>;
};