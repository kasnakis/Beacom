export type SiteAssetCategory = "AED" | "FIRE_ASSET" | "ASSEMBLY_POINT";

export type SiteAssetCollectionKey = "aed" | "fire_assets" | "assembly_points";

export type SiteAssetStatus = "ACTIVE" | "INACTIVE" | "OUT_OF_SERVICE";

export type SiteAssetInspection = {
  required?: boolean;
  frequencyDays?: number | null;
  lastInspectionAt?: number | null;
  nextInspectionAt?: number | null;
  lastInspectionBy?: string;
  notes?: string;
};

export type SiteAsset = {
  id: string;
  siteId: string;
  category: SiteAssetCategory;
  collectionKey: SiteAssetCollectionKey;

  // Kept for current mobile compatibility. Current APK reads `name`.
  name: string;
  title?: string;
  description?: string;

  type?: string;
  status?: SiteAssetStatus | string;
  active?: boolean;

  latitude?: number | null;
  longitude?: number | null;

  building?: string;
  floor?: string;
  zone?: string;
  locationNotes?: string;

  serialNumber?: string;
  manufacturer?: string;
  model?: string;

  inspection?: SiteAssetInspection;

  photoUrl?: string;
  photoPath?: string;
  photoUpdatedAt?: number | null;

  createdAt?: number;
  updatedAt?: number;
  createdBy?: string;
  updatedBy?: string;
};

export type SiteAssetInput = Omit<SiteAsset, "collectionKey"> & {
  collectionKey?: SiteAssetCollectionKey;
};

export type SiteAssetPermissionKey =
  | "MANAGE_AED"
  | "MANAGE_FIRE_ASSETS"
  | "MANAGE_ASSEMBLY_POINTS"
  | "SITE_ASSET_MANAGER";

export const SITE_ASSET_PERMISSION_OPTIONS: {
  value: SiteAssetPermissionKey;
  label: string;
  description: string;
}[] = [
  {
    value: "SITE_ASSET_MANAGER",
    label: "Διαχειριστής μέσων site",
    description: "Πλήρης διαχείριση όλων των απινιδωτών, πυροσβεστικών μέσων και χώρων συγκέντρωσης του site.",
  },
  {
    value: "MANAGE_AED",
    label: "Διαχείριση απινιδωτών",
    description: "Καταχώρηση, επεξεργασία και διαγραφή AED.",
  },
  {
    value: "MANAGE_FIRE_ASSETS",
    label: "Διαχείριση πυροσβεστικών μέσων",
    description: "Καταχώρηση, επεξεργασία και διαγραφή πυροσβεστικών μέσων.",
  },
  {
    value: "MANAGE_ASSEMBLY_POINTS",
    label: "Διαχείριση χώρων συγκέντρωσης",
    description: "Καταχώρηση, επεξεργασία και διαγραφή χώρων συγκέντρωσης.",
  },
];

export function collectionKeyForCategory(category: SiteAssetCategory): SiteAssetCollectionKey {
  if (category === "AED") return "aed";
  if (category === "FIRE_ASSET") return "fire_assets";
  return "assembly_points";
}

export function categoryForCollectionKey(collectionKey: SiteAssetCollectionKey): SiteAssetCategory {
  if (collectionKey === "aed") return "AED";
  if (collectionKey === "fire_assets") return "FIRE_ASSET";
  return "ASSEMBLY_POINT";
}

export function labelForAssetCategory(category: SiteAssetCategory): string {
  if (category === "AED") return "Απινιδωτές";
  if (category === "FIRE_ASSET") return "Πυροσβεστικά μέσα";
  return "Χώροι συγκέντρωσης";
}

export function assetRequiresInspection(category: SiteAssetCategory): boolean {
  return category === "AED" || category === "FIRE_ASSET";
}
