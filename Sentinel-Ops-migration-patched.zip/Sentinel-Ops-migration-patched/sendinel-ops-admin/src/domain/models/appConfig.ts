export type AppConfig = {
  defaultLanguage: string;
  defaultTimezone: string;
  multiSiteEnabled: boolean;
  notificationMode: string;
  policyMode: string;
};
