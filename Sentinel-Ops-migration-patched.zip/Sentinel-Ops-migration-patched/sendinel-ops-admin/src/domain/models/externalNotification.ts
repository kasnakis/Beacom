export type ExternalNotificationStatus =
  | "REQUESTED"
  | "APPROVED"
  | "REJECTED"
  | "SENT"
  | "ACKNOWLEDGED"
  | "CANCELLED"
  | "FAILED"
  | "CLOSED";

export type ExternalNotificationChannel =
  | "PHONE"
  | "EMAIL"
  | "SMS"
  | "SYSTEM"
  | string;

export type ExternalNotificationMode =
  | "MANUAL"
  | "MANUAL_LOGGED"
  | "AUTO"
  | string;

export type ExternalNotificationRecordKind =
  | "CANONICAL"
  | "LEGACY";

export interface ExternalNotificationApproval {
  required?: boolean;
  status?: "PENDING" | "APPROVED" | "REJECTED" | string;
  approvedByUserId?: string;
  approvedByName?: string;
  approvedByRole?: string;
  approvedAt?: number;
  rejectedAt?: number;
  notes?: string;

  // compatibility / audit fields
  decisionAt?: number;
  decisionByName?: string;
  decisionByRole?: string;
  rejectionReason?: string;
}

export interface ExternalNotificationExecution {
  status?: "PENDING" | "SENT" | "FAILED" | string;
  executedByUserId?: string;
  executedByName?: string;
  executedByRole?: string;
  executedAt?: number;
  resultNotes?: string;
}

export interface ExternalNotificationAcknowledgement {
  status?: "PENDING" | "ACKNOWLEDGED" | string;
  acknowledgedBy?: string;
  acknowledgedByUserId?: string;
  acknowledgedAt?: number;
  receivedBy?: string;
  receivedAt?: number;
  notes?: string;
}

export interface ExternalNotificationContact {
  name?: string;
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
}

export interface ExternalNotificationContacts {
  primary?: ExternalNotificationContact;
  secondary?: ExternalNotificationContact;
}

export interface ExternalNotificationRecord {
  // identity
  id: string;
  dataPath?: string;
  recordKind?: ExternalNotificationRecordKind;

  // incident linkage
  incidentId: string;
  siteId?: string;

  // authority
  authorityType?: string;
  authorityId?: string;
  authorityName?: string;

  // classification
  category?: string;
  channel?: ExternalNotificationChannel;
  mode?: ExternalNotificationMode;
  status?: ExternalNotificationStatus | string;

  // source / trigger
  source?: string;
  trigger?: string;

  // playbook linkage
  playbookId?: string;
  playbookTitle?: string;
  stepId?: string;
  stepTitle?: string;

  // compatibility
  legacyRequestId?: string;

  // lifecycle
  createdAt?: number;
  updatedAt?: number;
  closedAt?: number | null;
  closedBy?: string;

  // request metadata
  requestedByUserId?: string;
  requestedByName?: string;
  requestedByRole?: string;

  // policy/role context
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
  allowedRequesterRoles?: Record<string, boolean>;

  // contacts
  contacts?: ExternalNotificationContacts;
  contact?: ExternalNotificationContact;
  contactSecondary?: ExternalNotificationContact;

  // lifecycle blocks
  approval?: ExternalNotificationApproval;
  execution?: ExternalNotificationExecution;
  acknowledgement?: ExternalNotificationAcknowledgement;

  // convenience timestamps
  approvedAt?: number;
  executedAt?: number;
  acknowledgedAt?: number;

  // notes / results
  notes?: string;
  resultNotes?: string;

  // target info
  targets?: Record<string, boolean>;

  // operational flags
  serverOwned?: boolean;
  lastUpdatedAt?: number;
}

// optional alias για μελλοντική ευκρίνεια χωρίς να σπάσει τίποτα
export type ExternalNotification = ExternalNotificationRecord;