export type ExternalAuthority = {
  id: string;
  name?: string;
  type?: string;
  channel?: string;
  active?: boolean;
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
  secondaryPhone?: string;
  secondaryEmail?: string;
  secondaryAddress?: string;
  secondaryNotes?: string;
  [key: string]: unknown;
};