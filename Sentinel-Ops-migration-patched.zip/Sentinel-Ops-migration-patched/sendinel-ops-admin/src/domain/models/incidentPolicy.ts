export type RoleMap = Record<string, boolean>;

export type ApprovalMode =
  | "NONE"
  | "OPTIONAL"
  | "REQUIRED"
  | string;

export type DispatchMode =
  | "NONE"
  | "AUTO"
  | "MANUAL"
  | "POST_VERIFY"
  | string;

export type NotificationMode =
  | "NONE"
  | "AUTO"
  | "MANUAL"
  | "POST_VERIFY"
  | string;

export type ClosureMode =
  | "MANUAL"
  | "AUTO"
  | "POST_ACTIONS"
  | string;

export type ExternalAuthorityMode =
  | "NONE"
  | "MANUAL"
  | "AUTO"
  | "PLAYBOOK_DRIVEN"
  | string;

export type PolicyTriggerMode =
  | "AUTO"
  | "MANUAL"
  | "POST_VERIFY"
  | string;

export type IncidentPolicyVerification = {
  required?: boolean;
  roles?: RoleMap;
  allowedRoles?: RoleMap;
  finalAuthorityRoles?: RoleMap;
  rejectOverrides?: boolean;
  approvalMode?: ApprovalMode;
  minimumApprovals?: number;
  allowMultipleReviews?: boolean;
  requireAllRoles?: boolean;
  expandedDimensionsEnabled?: boolean;
  [key: string]: unknown;
};

export type IncidentPolicyDispatch = {
  mode?: DispatchMode;
  allowAutoDispatch?: boolean;
  roles?: RoleMap;
  teams?: RoleMap;
  responderRoles?: RoleMap;
  responseTeams?: RoleMap;
  enabled?: boolean;
  trackingEnabled?: boolean;
  requireVerificationFirst?: boolean;
  createDispatchState?: boolean;
  [key: string]: unknown;
};

export type IncidentPolicyNotifications = {
  mode?: NotificationMode;
  roles?: RoleMap;
  teams?: RoleMap;
  targets?: RoleMap;
  notifyOnCreate?: boolean;
  notifyOnVerify?: boolean;
  notifyOnClose?: boolean;
  [key: string]: unknown;
};

export type IncidentPolicyExternalAuthorities = {
  enabled?: boolean;
  mode?: ExternalAuthorityMode;
  authorities?: RoleMap;
  authorityTypes?: RoleMap;
  channels?: RoleMap;
  allowedRequesterRoles?: RoleMap;
  allowedApproverRoles?: RoleMap;
  allowedExecutorRoles?: RoleMap;
  approvalRequired?: boolean;
  requireAcknowledgement?: boolean;
  [key: string]: unknown;
};

export type IncidentPolicyClosure = {
  mode?: ClosureMode;
  allowedRoles?: RoleMap;
  closureRoles?: RoleMap;
  requiresVerifiedIncident?: boolean;
  requiresInvestigationCompleted?: boolean;
  requiresActionsCompleted?: boolean;
  overrideRoles?: RoleMap;
  overrideRequiresNotes?: boolean;
  [key: string]: unknown;
};

export type IncidentPolicyPlaybookTrigger = {
  playbookId?: string;
  playbookTitle?: string;
  enabled?: boolean;
  triggerMode?: PolicyTriggerMode;
  conditions?: Record<string, unknown>;
};

export type IncidentPolicyPlaybooks = {
  enabled?: boolean;
  autoActivate?: boolean;
  triggers?: IncidentPolicyPlaybookTrigger[];
};

export type IncidentPolicy = {
  key: string;
  active?: boolean;
  displayName?: string;
  description?: string;

  category?: string;
  type?: string;
  subtype?: string;
  siteId?: string;

  // --------------------------------------------------
  // Existing flat fields used by current editor/hooks
  // --------------------------------------------------
  requiresVerification?: boolean;
  verificationRoles?: RoleMap;
  minimumApprovals?: number;

  postVerifyDispatchMode?: string;
  allowAutoDispatch?: boolean;
  dispatchRoles?: RoleMap;
  dispatchTeams?: RoleMap;
  trackingEnabled?: boolean;

  notificationMode?: string;
  notificationTargets?: RoleMap;

  externalEnabled?: boolean;
  externalAuthorityTypes?: RoleMap;
  externalMode?: string;

  closureRoles?: RoleMap;
  requiresVerifiedIncident?: boolean;
  closureMode?: string;

  // --------------------------------------------------
  // Structured sections for richer policy workspace
  // --------------------------------------------------
  verification?: IncidentPolicyVerification;
  dispatch?: IncidentPolicyDispatch;
  notifications?: IncidentPolicyNotifications;
  externalAuthorities?: IncidentPolicyExternalAuthorities;
  closure?: IncidentPolicyClosure;
  playbooks?: IncidentPolicyPlaybooks;

  tags?: string[];
  triggers?: Record<string, unknown>;
  metadata?: Record<string, unknown>;

  [key: string]: unknown;
};