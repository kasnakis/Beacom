export type OperationalNotificationStatus =
  | "PENDING"
  | "PROCESSING"
  | "SENT"
  | "PARTIAL"
  | "RETRY_SCHEDULED"
  | "FAILED"
  | "NO_TARGETS"
  | "CANCELLED"
  | string;

export interface OperationalNotificationRecipientResult {
  userId?: string;
  displayName?: string;
  email?: string;
  tokenCount?: number;
  successCount?: number;
  failureCount?: number;
  status?: string;
  error?: string;
}

export interface OperationalNotificationRequest {
  id: string;
  dataPath?: string;

  incidentId?: string;
  siteId?: string;
  category?: string;
  type?: string;
  trigger?: string;
  status?: OperationalNotificationStatus;
  priority?: string;
  source?: string;
  title?: string;
  body?: string;

  targetRoles?: Record<string, boolean>;
  targetTeams?: Record<string, boolean>;
  targetUsers?: Record<string, boolean>;

  createdAt?: number;
  updatedAt?: number;
  processedAt?: number;
  sentAt?: number;
  nextRetryAt?: number;
  retryCount?: number;
  maxRetries?: number;

  recipientCount?: number;
  successCount?: number;
  failureCount?: number;
  invalidTokenCount?: number;
  retryableFailureCount?: number;

  deliveryResults?: Record<string, OperationalNotificationRecipientResult | string | boolean>;
  invalidTokens?: Record<string, boolean> | string[];
  failedTokens?: Record<string, boolean> | string[];
  retryableFailedTokens?: Record<string, boolean> | string[];

  error?: string;
  lastError?: string;
  notes?: string;
}
