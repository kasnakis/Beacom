export type AdminLevel = "GLOBAL_ADMIN" | "SITE_ADMIN" | "VIEW_ONLY";

export type AdminPermissions = {
  level?: AdminLevel;
};

export type SiteMembership = {
  siteId?: string;
  active?: boolean;
  roles?: Record<string, boolean>;
  teams?: Record<string, boolean>;

  // Site-scoped permissions. Optional, backward compatible for current mobile APKs.
  permissions?: Record<string, boolean>;
};

export type UserProfile = {
  uid: string;
  displayName?: string;
  email?: string;
  active?: boolean;
  siteId?: string;
  primarySiteId?: string;
  lastTokenUpdate?: number;

  platformRoles?: Record<string, boolean>;
  roles?: Record<string, boolean>;
  teams?: Record<string, boolean>;
  siteMemberships?: Record<string, SiteMembership>;

  updatedAt?: number;

  // Admin-only extension for web admin permissions.
  // Safe: optional field, does not affect existing mobile fields.
  adminPermissions?: AdminPermissions;
};

export function hasAdminPortalAccess(profile?: UserProfile | null): boolean {
  return Boolean(profile?.platformRoles?.ADMIN_PORTAL);
}
