import type { DispatchState } from "../../../domain/models/dispatch";
import type { ExternalNotificationRecord } from "../../../domain/models/externalNotification";
import { DispatchTable } from "../../../features/operations/components/DispatchTable";
import { ExternalNotificationsTable } from "../../../features/operations/components/ExternalNotificationsTable";

type Props = {
  dispatches: DispatchState[];
  externalNotifications: ExternalNotificationRecord[];
};

export function SiteLiveTab({ dispatches, externalNotifications }: Props) {
  return (
    <div style={{ display: "grid", gap: 24 }}>
      <div>
        <h3>Ζωντανές κινητοποιήσεις ομάδων</h3>
        <div style={helperStyle}>
          Εδώ εμφανίζονται οι ενεργές ή πρόσφατες κινητοποιήσεις προσωπικού και ομάδων ανταπόκρισης για τη συγκεκριμένη μονάδα εργασίας. Η παρακολούθηση αυτή βοηθά στον επιχειρησιακό συντονισμό κατά τη διάρκεια ενός συμβάντος.
        </div>
        <DispatchTable items={dispatches} />
      </div>

      <div>
        <h3>Εξωτερικές ειδοποιήσεις</h3>
        <div style={helperStyle}>
          Εδώ εμφανίζονται οι ειδοποιήσεις προς εξωτερικές αρχές (Πυροσβεστική, ΕΚΑΒ, Αστυνομία, Πολιτική Προστασία κ.ά.), μαζί με την κατάσταση έγκρισης, αποστολής και επιβεβαίωσης λήψης.
        </div>
        <ExternalNotificationsTable
          items={externalNotifications}
          selectedId={null}
          onSelect={() => {}}
        />
      </div>
    </div>
  );
}

const helperStyle: React.CSSProperties = {
  marginBottom: 10,
  padding: 10,
  borderRadius: 10,
  background: "rgba(255,255,255,0.04)",
  fontSize: 12,
  lineHeight: 1.45,
  opacity: 0.82,
};
