import { useMemo, useState } from "react";
import { UsersTable } from "../../../features/users/components/UsersTable";
import { UsersFilters } from "../../../features/users/components/UsersFilters";
import { UserDetailDrawer } from "../../../features/users/components/UserDetailDrawer";
import { useUsers } from "../../../hooks/useUsers";
import { useAuth } from "../../../hooks/useAuth";
import { resolveAdminCapabilities } from "../../../domain/permissions/adminCapabilities";
import type { UserProfile } from "../../../domain/models/user";
import {
  translateRole,
  translateTeam,
  useDynamicRoles,
  useDynamicTeams,
  userLabel,
} from "../../../features/users/i18n/userManagementLabels";

type Props = {
  siteId?: string;
  users?: UserProfile[];
};

function trueKeys(value?: Record<string, boolean>) {
  if (!value) return [];

  return Object.entries(value)
    .filter(([, enabled]) => enabled)
    .map(([key]) => key);
}

function hasSelectedKey(
  record: Record<string, boolean> | undefined,
  selectedKey: string
) {
  if (!selectedKey) return true;
  return Boolean(record?.[selectedKey]);
}

function matchesSearch(user: UserProfile, term: string) {
  const q = term.trim().toLowerCase();
  if (!q) return true;

  const roleKeys = trueKeys(user.roles);
  const teamKeys = trueKeys(user.teams);

  const roleLabels = roleKeys.map((r) => translateRole(r));
  const teamLabels = teamKeys.map((t) => translateTeam(t));

  const values = [
    user.displayName,
    user.email,
    user.uid,
    user.siteId,
    ...roleKeys,
    ...teamKeys,
    ...roleLabels,
    ...teamLabels,
  ];

  return values
    .filter(Boolean)
    .some((v) => String(v).toLowerCase().includes(q));
}

export function SiteUsersTab({ siteId, users }: Props) {
  const { data = [] } = useUsers();
  const { profile } = useAuth();

  const sourceUsers = users || data;

  const resolvedSiteId =
    siteId ||
    users?.find((user) => Boolean(user.siteId))?.siteId ||
    data.find((user: UserProfile) => Boolean(user.siteId))?.siteId ||
    "";

  const [search, setSearch] = useState("");
  const [activeMode, setActiveMode] = useState("ALL");
  const [roleFilter, setRoleFilter] = useState("");
  const [teamFilter, setTeamFilter] = useState("");
  const [selectedUid, setSelectedUid] = useState<string | null>(null);

  const roleOptions = useDynamicRoles(resolvedSiteId);
  const teamOptions = useDynamicTeams(resolvedSiteId);

  const visibleUsers = useMemo(() => {
    return sourceUsers.filter((user: UserProfile) => {
      const caps = resolveAdminCapabilities(profile, user);

      if (!caps.canViewUser) return false;
      if (!resolvedSiteId) return true;

      return user.siteId === resolvedSiteId;
    });
  }, [sourceUsers, profile, resolvedSiteId]);

  const filtered = useMemo(() => {
    return visibleUsers.filter((user: UserProfile) => {
      const searchOk = matchesSearch(user, search);

      const activeOk =
        activeMode === "ALL"
          ? true
          : activeMode === "ACTIVE"
          ? user.active !== false
          : user.active === false;

      const roleOk = hasSelectedKey(user.roles, roleFilter);
      const teamOk = hasSelectedKey(user.teams, teamFilter);

      return searchOk && activeOk && roleOk && teamOk;
    });
  }, [visibleUsers, search, activeMode, roleFilter, teamFilter]);

  const selectedUser = useMemo(
    () =>
      filtered.find((u) => u.uid === selectedUid) ||
      visibleUsers.find((u) => u.uid === selectedUid) ||
      null,
    [filtered, visibleUsers, selectedUid]
  );

  function clearFilters() {
    setSearch("");
    setActiveMode("ALL");
    setRoleFilter("");
    setTeamFilter("");
  }

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div
        style={{
          padding: 12,
          borderRadius: 12,
          background: "rgba(255,255,255,0.04)",
          fontSize: 13,
          lineHeight: 1.5,
          opacity: 0.88,
        }}
      >
        Από εδώ γίνεται η διαχείριση των χρηστών της μονάδας εργασίας. Μπορείτε να
        ελέγξετε ρόλους, ομάδες ανταπόκρισης, κατάσταση λογαριασμών και δικαιώματα
        πρόσβασης. Οι ρόλοι και οι ομάδες επηρεάζουν άμεσα τις ειδοποιήσεις,
        τις κινητοποιήσεις και τη συμμετοχή σε περιστατικά έκτακτης ανάγκης.
      </div>

      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 5,
          paddingTop: 12,
          paddingBottom: 12,
          background: "rgba(15,23,42,0.96)",
          backdropFilter: "blur(8px)",
        }}
      >
        <UsersFilters
          search={search}
          activeMode={activeMode}
          roleFilter={roleFilter}
          teamFilter={teamFilter}
          hideSiteFilter
          availableRoles={roleOptions}
          availableTeams={teamOptions}
          onSearchChange={setSearch}
          onActiveModeChange={setActiveMode}
          onRoleFilterChange={setRoleFilter}
          onTeamFilterChange={setTeamFilter}
          onClearFilters={clearFilters}
        />
      </div>

      <UsersTable
        users={filtered}
        selectedUid={selectedUid}
        onSelect={setSelectedUid}
        compact
      />

      {selectedUser ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Στοιχεία Χρήστη"
          onClick={() => setSelectedUid(null)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            padding: "72px 24px 24px",
            background: "rgba(15,23,42,0.62)",
            backdropFilter: "blur(4px)",
            overflowY: "auto",
          }}
        >
          <div
            onClick={(event) => event.stopPropagation()}
            style={{
              width: "min(980px, 100%)",
              maxHeight: "calc(100vh - 96px)",
              overflowY: "auto",
              borderRadius: 18,
              boxShadow: "0 26px 80px rgba(0,0,0,0.35)",
            }}
          >
            <UserDetailDrawer
              user={selectedUser}
              availableSites={resolvedSiteId ? [resolvedSiteId] : []}
              onClose={() => setSelectedUid(null)}
            />
          </div>
        </div>
      ) : null}

      <div style={{ opacity: 0.65, fontSize: 13 }}>
        {userLabel("usersCount", filtered.length, visibleUsers.length)}
      </div>
    </div>
  );
}