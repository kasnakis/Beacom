import { useExternalAuthorities } from "../../../hooks/useExternalAuthorities";
import { ExternalAuthoritiesTable } from "../../../features/sites/components/ExternalAuthoritiesTable";

type Props = {
  siteId: string;
};

export function SiteExternalAuthoritiesTab({ siteId }: Props) {
  const { data = [], isLoading, error } = useExternalAuthorities(siteId);

  if (isLoading) {
    return <div>Φόρτωση εξωτερικών αρχών...</div>;
  }

  if (error) {
    return <div>Σφάλμα φόρτωσης εξωτερικών αρχών</div>;
  }

  return (
    <div>
      <h2>Εξωτερικές Αρχές</h2>
      <ExternalAuthoritiesTable items={data} />
    </div>
  );
}