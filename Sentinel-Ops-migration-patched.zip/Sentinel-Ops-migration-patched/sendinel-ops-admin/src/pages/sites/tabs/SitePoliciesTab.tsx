import { useEffect, useMemo, useState } from "react";
import { useIncidentPolicies } from "../../../hooks/useIncidentPolicies";
import { PolicyEditor } from "../../../features/incidentTypes/components/PolicyEditor";
import type { IncidentPolicy } from "../../../domain/models/incidentPolicy";
import { CATEGORY_LABELS_EL, greekLabel } from "../../../features/incidentTypes/components/sections/PolicyLabels";

type Props = {
  siteId: string;
  items?: IncidentPolicy[];
};

export function SitePoliciesTab({ siteId, items }: Props) {
  const { data: fetchedPolicies = [], isLoading } = useIncidentPolicies(siteId);

  const policies = items ?? fetchedPolicies;

  const [selectedKey, setSelectedKey] = useState<string | null>(null);

  useEffect(() => {
    if (!policies.length) {
      setSelectedKey(null);
      return;
    }

    const exists = selectedKey
      ? policies.some((policy) => policy.key === selectedKey)
      : false;

    if (!exists) {
      setSelectedKey(policies[0].key);
    }
  }, [policies, selectedKey]);

  const selectedPolicy = useMemo(
    () => policies.find((p) => p.key === selectedKey) || null,
    [policies, selectedKey]
  );

  if (!items && isLoading) {
    return <div>Φόρτωση πολιτικών συμβάντων...</div>;
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "320px 1fr",
        gap: 16,
        alignItems: "start",
      }}
    >
      <div
        style={{
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 12,
          padding: 12,
          background: "rgba(255,255,255,0.02)",
        }}
      >
        <div style={{ fontWeight: 800, marginBottom: 6 }}>Πολιτικές συμβάντων</div>
        <div style={hintStyle}>
          Επιλέξτε τύπο συμβάντος για να ορίσετε κανόνες επιβεβαίωσης, dispatch,
          ειδοποιήσεων, εξωτερικών αρχών και κλεισίματος.
        </div>

        {policies.length === 0 ? (
          <div style={{ opacity: 0.7 }}>Δεν υπάρχουν πολιτικές για τη μονάδα.</div>
        ) : (
          <div style={{ display: "grid", gap: 6 }}>
            {policies.map((p) => {
              const isSelected = selectedKey === p.key;
              const categoryLabel = greekLabel(p.category || p.key, CATEGORY_LABELS_EL);

              return (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => setSelectedKey(p.key)}
                  style={{
                    textAlign: "left",
                    padding: "10px",
                    borderRadius: 10,
                    border: isSelected
                      ? "1px solid #4ade80"
                      : "1px solid rgba(255,255,255,0.1)",
                    background: isSelected
                      ? "rgba(74,222,128,0.08)"
                      : "transparent",
                    cursor: "pointer",
                    color: "inherit",
                  }}
                >
                  <div style={{ fontWeight: 700 }}>
                    {p.displayName || categoryLabel || p.key}
                  </div>
                  <div style={{ fontSize: 12, opacity: 0.72 }}>
                    {categoryLabel}
                  </div>
                  <div style={{ fontSize: 10, opacity: 0.45 }}>
                    {p.key}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div
        style={{
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 12,
          padding: 12,
          background: "rgba(255,255,255,0.02)",
          minHeight: 240,
        }}
      >
        {selectedPolicy ? (
          <PolicyEditor siteId={siteId} value={selectedPolicy} />
        ) : (
          <div style={{ opacity: 0.7 }}>
            Επιλέξτε πολιτική συμβάντος για επεξεργασία.
          </div>
        )}
      </div>
    </div>
  );
}

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.7,
  lineHeight: 1.4,
  marginBottom: 12,
};
