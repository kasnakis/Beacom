import type { SiteAdminRow } from "../../../domain/models/site";
import { StatusBadge } from "../../../features/shared/components/StatusBadge";
import { SiteEditPanel } from "../../../features/sites/components/SiteEditPanel";

type Props = {
  site: SiteAdminRow | null;
};

export function SiteSummaryTab({ site }: Props) {
  if (!site) {
    return <p>Δεν βρέθηκε η μονάδα.</p>;
  }

  return (
    <div
      style={{
        display: "grid",
        gap: 24,
        gridTemplateColumns: "minmax(0, 1fr) minmax(340px, 420px)",
        alignItems: "start",
      }}
    >
      <div
        style={{
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 16,
          padding: 16,
          background: "rgba(255,255,255,0.02)",
        }}
      >
        <h3 style={{ marginTop: 0 }}>Σύνοψη μονάδας</h3>
        <div style={helperStyle}>
          Η ενότητα δείχνει τα βασικά στοιχεία της μονάδας και γρήγορους δείκτες για χρήστες,
          ανοικτά dispatch και εκκρεμείς εξωτερικές ειδοποιήσεις.
        </div>

        <p><strong>Κωδικός μονάδας:</strong> {site.id}</p>
        <p><strong>Όνομα:</strong> {site.name || "-"}</p>
        <p>
          <strong>Κατάσταση:</strong>{" "}
          <StatusBadge
            label={site.active === false ? "Ανενεργή" : "Ενεργή"}
            tone={site.active === false ? "danger" : "success"}
          />
        </p>

        <div style={{ marginTop: 16 }}>
          <p><strong>Χρήστες:</strong> {site.usersCount}</p>
          <p><strong>Ανοικτές κινητοποιήσεις:</strong> {site.openDispatchesCount}</p>
          <p><strong>Εκκρεμείς εξωτερικές ειδοποιήσεις:</strong> {site.pendingExternalCount}</p>
        </div>
      </div>

      <SiteEditPanel site={site} />
    </div>
  );
}

const helperStyle: React.CSSProperties = {
  marginBottom: 12,
  padding: 10,
  borderRadius: 10,
  background: "rgba(255,255,255,0.04)",
  fontSize: 12,
  lineHeight: 1.45,
  opacity: 0.82,
};
