import { ChangeEvent, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useSitesAdmin } from "../../hooks/useSitesAdmin";
import { useSiteWorkspace } from "../../hooks/useSiteWorkspace";
import { uploadSiteCoverImage } from "../../services/repositories/sitesRepository";
import { SiteWorkspaceSummaryCards } from "../../features/sites/components/SiteWorkspaceSummaryCards";
import { SiteSummaryTab } from "./tabs/SiteSummaryTab";
import { SiteUsersTab } from "./tabs/SiteUsersTab";
import { SiteExternalAuthoritiesTab } from "./tabs/SiteExternalAuthoritiesTab";
import { SitePoliciesTab } from "./tabs/SitePoliciesTab";
import { SiteLiveTab } from "./tabs/SiteLiveTab";

type TabKey = "summary" | "users" | "authorities" | "policies" | "live";

const TAB_LABELS: Record<TabKey, { label: string; description: string }> = {
  summary: {
    label: "Αρχική εικόνα",
    description: "Σύνοψη βασικών στοιχείων, κατάστασης και μετρικών της μονάδας.",
  },
  users: {
    label: "Χρήστες",
    description: "Χρήστες, ρόλοι, ομάδες και δικαιώματα πρόσβασης στη μονάδα.",
  },
  authorities: {
    label: "Εξωτερικές αρχές",
    description: "Στοιχεία επικοινωνίας και επιχειρησιακές επαφές εξωτερικών αρχών.",
  },
  policies: {
    label: "Πολιτικές συμβάντων",
    description: "Κανόνες επιβεβαίωσης, κινητοποίησης, ειδοποιήσεων και κλεισίματος συμβάντων.",
  },
  live: {
    label: "Ζωντανή εικόνα",
    description: "Τρέχοντα συμβάντα, dispatch και ειδοποιήσεις που σχετίζονται με τη μονάδα.",
  },
};

export function SiteDetailPage() {
  const { siteId = "" } = useParams<{ siteId: string }>();
  const { data: sites = [], isLoading: sitesLoading, error: sitesError } = useSitesAdmin();
  const { data, isLoading, error } = useSiteWorkspace(siteId);

  const [tab, setTab] = useState<TabKey>("summary");
  const [uploadingImage, setUploadingImage] = useState(false);

  async function handleCoverImageUpload(
    event: ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];
    if (!file || !siteId) return;

    try {
      setUploadingImage(true);
      await uploadSiteCoverImage(siteId, file);
      window.location.reload();
    } catch (error) {
      console.error(error);
      alert("Αποτυχία μεταφόρτωσης εικόνας μονάδας.");
    } finally {
      setUploadingImage(false);
    }
  }

  const site = useMemo(
    () => sites.find((item) => item.id === siteId) ?? null,
    [sites, siteId]
  );

  if (sitesLoading || isLoading) {
    return <div style={{ padding: 24 }}>Φόρτωση χώρου εργασίας μονάδας...</div>;
  }

  if (sitesError || error || !site || !data) {
    return <div style={{ padding: 24 }}>Σφάλμα φόρτωσης στοιχείων μονάδας</div>;
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={{ marginBottom: 20 }}>
        <div style={eyebrowStyle}>Μονάδα εργασίας</div>
        <h1 style={{ marginBottom: 6 }}>{site.name || site.id}</h1>
        <div style={{ opacity: 0.75 }}>{site.id}</div>
        <div style={pageHelpStyle}>
          Από εδώ γίνεται η κεντρική διαχείριση της μονάδας εργασίας. Μπορείτε να παρακολουθήσετε χρήστες, ρόλους, ομάδες ανταπόκρισης, εξωτερικές αρχές, πολιτικές συμβάντων και τη ζωντανή επιχειρησιακή εικόνα της εγκατάστασης.
        </div>
      </div>

      
      <div
        style={{
          marginBottom: 20,
          borderRadius: 18,
          overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.12)",
          background: "rgba(255,255,255,0.03)",
        }}
      >
        <div
          style={{
            height: 260,
            backgroundImage: `url(${(site as any).coverImageUrl || ""})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundColor: "#0f172a",
          }}
        />

        <div style={{ padding: 16 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 12,
              flexWrap: "wrap",
            }}
          >
            <div>
              <h3 style={{ marginBottom: 6 }}>
                Χαρακτηριστική Εικόνα Μονάδας
              </h3>

              <div
                style={{
                  fontSize: 12,
                  opacity: 0.72,
                  lineHeight: 1.45,
                  maxWidth: 720,
                }}
              >
                Η εικόνα χρησιμοποιείται στην Αρχική Σελίδα,
                στη Ζωντανή Επιχειρησιακή Εικόνα και στα
                operational dashboards του SENDINEL Ops.
              </div>
            </div>

            <label
              style={{
                padding: "10px 14px",
                borderRadius: 12,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(255,255,255,0.05)",
                cursor: "pointer",
                fontWeight: 700,
              }}
            >
              {uploadingImage
                ? "Μεταφόρτωση..."
                : "Αλλαγή Εικόνας"}

              <input
                type="file"
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleCoverImageUpload}
              />
            </label>
          </div>
        </div>
      </div>

<SiteWorkspaceSummaryCards
        usersCount={data.summary.usersCount}
        activeUsersCount={data.summary.activeUsersCount}
        openDispatchesCount={data.summary.openDispatchesCount}
        pendingExternalCount={data.summary.pendingExternalCount}
        authoritiesCount={data.summary.authoritiesCount}
        policiesCount={data.summary.policiesCount}
      />

      <div
        style={{
          display: "flex",
          gap: 10,
          flexWrap: "wrap",
          marginBottom: 20,
        }}
      >
        {(Object.keys(TAB_LABELS) as TabKey[]).map((key) => (
          <TabButton key={key} active={tab === key} onClick={() => setTab(key)}>
            {TAB_LABELS[key].label}
          </TabButton>
        ))}
      </div>

      <div style={tabHelpStyle}>{TAB_LABELS[tab].description}</div>

      {tab === "summary" ? <SiteSummaryTab site={site} /> : null}
      {tab === "users" ? <SiteUsersTab users={data.users} /> : null}
      {tab === "authorities" ? <SiteExternalAuthoritiesTab siteId={siteId} /> : null}
      {tab === "policies" ? <SitePoliciesTab siteId={siteId} items={data.policies} /> : null}
      {tab === "live" ? (
        <SiteLiveTab
          dispatches={data.dispatches}
          externalNotifications={data.externalNotifications}
        />
      ) : null}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "10px 14px",
        borderRadius: 12,
        border: active
          ? "1px solid rgba(72,126,255,0.7)"
          : "1px solid rgba(255,255,255,0.12)",
        background: active ? "rgba(72,126,255,0.12)" : "rgba(255,255,255,0.02)",
        color: "inherit",
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}

const eyebrowStyle: React.CSSProperties = {
  fontSize: 12,
  textTransform: "uppercase",
  letterSpacing: 0.6,
  opacity: 0.65,
  marginBottom: 4,
};

const pageHelpStyle: React.CSSProperties = {
  marginTop: 10,
  padding: 12,
  borderRadius: 12,
  background: "rgba(255,255,255,0.04)",
  fontSize: 13,
  lineHeight: 1.45,
  opacity: 0.86,
};

const tabHelpStyle: React.CSSProperties = {
  marginBottom: 14,
  padding: 10,
  borderRadius: 10,
  background: "rgba(255,255,255,0.035)",
  fontSize: 12,
  lineHeight: 1.4,
  opacity: 0.82,
};