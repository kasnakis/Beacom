import { useMemo, useState } from "react";
import { useSitesAdmin } from "../../hooks/useSitesAdmin";
import { useAuth } from "../../hooks/useAuth";
import { SitesFilters } from "../../features/sites/components/SitesFilters";
import { SitesSummaryCards } from "../../features/sites/components/SitesSummaryCards";
import { SitesTable } from "../../features/sites/components/SitesTable";
import { SiteCreatePanel } from "../../features/sites/components/SiteCreatePanel";
import type { SiteAdminRow } from "../../domain/models/site";

function matchesSearch(item: SiteAdminRow, term: string) {
  const q = term.trim().toLowerCase();
  if (!q) return true;

  return [item.id, item.name]
    .filter(Boolean)
    .some((value) => String(value).toLowerCase().includes(q));
}

export function SitesListPage() {
  const { data = [], isLoading, error } = useSitesAdmin();
  const { profile } = useAuth();

  const [search, setSearch] = useState("");
  const [activeMode, setActiveMode] = useState("ALL");

  const filtered = useMemo(() => {
    return data.filter((item) => {
      const searchOk = matchesSearch(item, search);

      const activeOk =
        activeMode === "ALL"
          ? true
          : activeMode === "ACTIVE"
          ? item.active !== false
          : item.active === false;

      return searchOk && activeOk;
    });
  }, [data, search, activeMode]);

  const totalUsers = filtered.reduce((sum, item) => sum + item.usersCount, 0);
  const totalOpenDispatches = filtered.reduce((sum, item) => sum + item.openDispatchesCount, 0);
  const activeSites = filtered.filter((item) => item.active !== false).length;

  if (isLoading) {
    return <div style={{ padding: 24 }}>Φόρτωση υπηρεσιακών μονάδων...</div>;
  }

  if (error) {
    return <div style={{ padding: 24 }}>Σφάλμα φόρτωσης υπηρεσιακών μονάδων</div>;
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Υπηρεσιακές Μονάδες</h1>

      <SiteCreatePanel sites={data} currentProfile={profile} />

      <div style={{ height: 20 }} />

      <SitesFilters
        search={search}
        activeMode={activeMode}
        onSearchChange={setSearch}
        onActiveModeChange={setActiveMode}
      />

      <SitesSummaryCards
        totalSites={filtered.length}
        activeSites={activeSites}
        totalUsers={totalUsers}
        openDispatches={totalOpenDispatches}
      />

      <div style={{ marginBottom: 12, opacity: 0.75 }}>
        Εμφανίζονται {filtered.length} από {data.length} υπηρεσιακές μονάδες
      </div>

      <SitesTable items={filtered} />
    </div>
  );
}