import { useMemo, useState } from "react";
import { useIncidentTimeline } from "../../hooks/useIncidentTimeline";
import { TimelineFeed } from "../../features/operations/components/TimelineFeed";
import { TimelineFilters } from "../../features/operations/components/TimelineFilters";
import type { IncidentEventRecord } from "../../domain/models/incidentEvent";

function normalize(value: string) {
  return value.trim().toLowerCase();
}

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function uniqueSorted(values: string[]) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

function safeType(item: IncidentEventRecord) {
  return item.eventType || "UNKNOWN";
}

function countByType(items: IncidentEventRecord[], eventType: string) {
  return items.filter((item) => item.eventType === eventType).length;
}

function buildTopTypes(items: IncidentEventRecord[], limit = 6) {
  const counts = new Map<string, number>();

  for (const item of items) {
    const key = safeType(item);
    counts.set(key, (counts.get(key) || 0) + 1);
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([eventType, count]) => ({ eventType, count }));
}

function getTimeBounds(items: IncidentEventRecord[]) {
  if (!items.length) {
    return { latest: undefined, oldest: undefined };
  }

  const sorted = [...items].sort((a, b) => b.createdAt - a.createdAt);

  return {
    latest: sorted[0]?.createdAt,
    oldest: sorted[sorted.length - 1]?.createdAt,
  };
}

export function TimelinePage() {
  const { items, loading, loadingMore, loadMore } = useIncidentTimeline();

  const [siteId, setSiteId] = useState("");
  const [incidentId, setIncidentId] = useState("");
  const [eventType, setEventType] = useState("");

  const availableSites = useMemo(() => {
    return uniqueSorted(items.map((item) => item.siteId || ""));
  }, [items]);

  const availableEventTypes = useMemo(() => {
    return uniqueSorted(items.map((item) => item.eventType || ""));
  }, [items]);

  const filteredItems = useMemo(() => {
    const normalizedIncidentId = normalize(incidentId);

    return items.filter((item: IncidentEventRecord) => {
      const siteOk = !siteId || item.siteId === siteId;
      const incidentOk =
        !incidentId || normalize(item.incidentId || "").includes(normalizedIncidentId);
      const eventOk = !eventType || item.eventType === eventType;

      return siteOk && incidentOk && eventOk;
    });
  }, [items, siteId, incidentId, eventType]);

  const stats = useMemo(() => {
    const bounds = getTimeBounds(filteredItems);

    return {
      totalLoaded: items.length,
      visible: filteredItems.length,
      uniqueIncidents: new Set(filteredItems.map((item) => item.incidentId).filter(Boolean)).size,
      uniqueSites: new Set(filteredItems.map((item) => item.siteId).filter(Boolean)).size,
      latest: bounds.latest,
      oldest: bounds.oldest,
      externalNotifications:
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_REQUESTED") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_APPROVED") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_SENT") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_ACK") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_CANCELLED") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_REJECTED") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_FAILED") +
        countByType(filteredItems, "EXTERNAL_NOTIFICATION_CLOSED"),
      dispatchEvents:
        countByType(filteredItems, "PLAYBOOK_DISPATCH_REQUESTED") +
        countByType(filteredItems, "PLAYBOOK_DISPATCH_MATERIALIZED") +
        countByType(filteredItems, "RESPONDER_DECLARED") +
        countByType(filteredItems, "RESPONDER_LOCATION_UPDATED"),
      playbookEvents:
        countByType(filteredItems, "PLAYBOOK_ACTIVATED") +
        countByType(filteredItems, "PLAYBOOK_STEP_STARTED") +
        countByType(filteredItems, "PLAYBOOK_STEP_COMPLETED"),
      lifecycleEvents:
        countByType(filteredItems, "INCIDENT_CREATED") +
        countByType(filteredItems, "INCIDENT_VERIFIED") +
        countByType(filteredItems, "INCIDENT_REJECTED") +
        countByType(filteredItems, "INCIDENT_CLOSED") +
        countByType(filteredItems, "EMERGENCY_ACTIVATED") +
        countByType(filteredItems, "EMERGENCY_UNDER_CONTROL") +
        countByType(filteredItems, "EMERGENCY_DEACTIVATED"),
    };
  }, [items, filteredItems]);

  const topTypes = useMemo(() => buildTopTypes(filteredItems, 8), [filteredItems]);

  const hasActiveFilters = Boolean(siteId || incidentId.trim() || eventType);

  if (loading) {
    return <div style={{ padding: 24 }}>Φόρτωση timeline...</div>;
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={pageHeader}>
        <div>
          <h1 style={{ margin: 0 }}>Timeline</h1>
          <div style={subtleText}>
            Ενιαία προβολή incident lifecycle, dispatch, playbooks και external authorities audit
            trail.
          </div>
        </div>

        <div style={headerMeta}>
          <div style={headerMetaLine}>
            <strong>Loaded:</strong> {stats.totalLoaded}
          </div>
          <div style={headerMetaLine}>
            <strong>Visible:</strong> {stats.visible}
          </div>
        </div>
      </div>

      <div style={summaryGrid}>
        <div style={summaryCard}>
          <div style={summaryLabel}>Visible Events</div>
          <div style={summaryValue}>{stats.visible}</div>
          <div style={summaryHint}>Μετά τα τρέχοντα φίλτρα</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Incidents</div>
          <div style={summaryValue}>{stats.uniqueIncidents}</div>
          <div style={summaryHint}>Μοναδικά incident IDs</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Sites</div>
          <div style={summaryValue}>{stats.uniqueSites}</div>
          <div style={summaryHint}>Μοναδικά sites</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Lifecycle</div>
          <div style={summaryValue}>{stats.lifecycleEvents}</div>
          <div style={summaryHint}>Core incident state changes</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Playbooks</div>
          <div style={summaryValue}>{stats.playbookEvents}</div>
          <div style={summaryHint}>Activation / step execution</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Dispatch</div>
          <div style={summaryValue}>{stats.dispatchEvents}</div>
          <div style={summaryHint}>Responder / dispatch audit</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>External</div>
          <div style={summaryValue}>{stats.externalNotifications}</div>
          <div style={summaryHint}>Authorities lifecycle events</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Window</div>
          <div style={summaryWindow}>
            <div>{formatDate(stats.latest)}</div>
            <div style={{ opacity: 0.65 }}>→</div>
            <div>{formatDate(stats.oldest)}</div>
          </div>
        </div>
      </div>

      <TimelineFilters
        siteId={siteId}
        incidentId={incidentId}
        eventType={eventType}
        availableSites={availableSites}
        availableEventTypes={availableEventTypes}
        onSiteChange={setSiteId}
        onIncidentChange={setIncidentId}
        onEventTypeChange={setEventType}
      />

      <div style={toolbar}>
        <button
          type="button"
          onClick={() => {
            setSiteId("");
            setIncidentId("");
            setEventType("");
          }}
          style={clearButton}
          disabled={!hasActiveFilters}
        >
          Καθαρισμός φίλτρων
        </button>

        <div style={toolbarInfo}>
          Εμφανίζονται {filteredItems.length} από {items.length} φορτωμένα events
        </div>
      </div>

      <div style={contentGrid}>
        <div>
          <div style={sectionHeader}>
            <h2 style={{ margin: 0 }}>Timeline Feed</h2>
            <div style={sectionHint}>
              Χρονολογική ροή συμβάντων για operational και audit χρήση.
            </div>
          </div>

          <TimelineFeed items={filteredItems} />

          <div style={{ marginTop: 20, textAlign: "center" }}>
            <button
              onClick={loadMore}
              disabled={loadingMore}
              style={loadMoreButton}
            >
              {loadingMore ? "Φόρτωση..." : "Φόρτωση παλαιότερων"}
            </button>
          </div>
        </div>

        <div>
          <div style={sectionHeader}>
            <h2 style={{ margin: 0 }}>Top Event Types</h2>
            <div style={sectionHint}>
              Γρήγορη εικόνα για το τι κυριαρχεί στο τρέχον timeline slice.
            </div>
          </div>

          <div style={sidePanel}>
            {topTypes.length ? (
              topTypes.map((item) => (
                <div key={item.eventType} style={topTypeRow}>
                  <div style={topTypeName}>{item.eventType}</div>
                  <div style={topTypeCount}>{item.count}</div>
                </div>
              ))
            ) : (
              <div style={emptyState}>Δεν υπάρχουν event types για τα τρέχοντα φίλτρα.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const pageHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 16,
  marginBottom: 16,
  flexWrap: "wrap",
};

const subtleText: React.CSSProperties = {
  marginTop: 6,
  fontSize: 13,
  opacity: 0.78,
};

const headerMeta: React.CSSProperties = {
  display: "grid",
  gap: 4,
  minWidth: 140,
};

const headerMetaLine: React.CSSProperties = {
  fontSize: 13,
  opacity: 0.85,
  textAlign: "right",
};

const summaryGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(4, minmax(160px, 1fr))",
  gap: 12,
  marginBottom: 16,
};

const summaryCard: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 12,
  minHeight: 92,
};

const summaryLabel: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
  marginBottom: 8,
};

const summaryValue: React.CSSProperties = {
  fontSize: 26,
  fontWeight: 800,
  lineHeight: 1.1,
};

const summaryHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.68,
};

const summaryWindow: React.CSSProperties = {
  display: "grid",
  gap: 4,
  fontSize: 12,
  lineHeight: 1.35,
};

const toolbar: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 12,
  marginBottom: 12,
  flexWrap: "wrap",
};

const clearButton: React.CSSProperties = {
  borderRadius: 8,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 12px",
  cursor: "pointer",
};

const toolbarInfo: React.CSSProperties = {
  marginLeft: "auto",
  fontSize: 13,
  opacity: 0.75,
};

const contentGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1.35fr 0.75fr",
  gap: 16,
  alignItems: "start",
};

const sectionHeader: React.CSSProperties = {
  marginBottom: 10,
};

const sectionHint: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
};

const sidePanel: React.CSSProperties = {
  display: "grid",
  gap: 10,
  border: "1px solid var(--border)",
  borderRadius: 16,
  background: "var(--surface)",
  padding: 12,
};

const topTypeRow: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr auto",
  gap: 10,
  alignItems: "center",
  padding: "10px 12px",
  borderRadius: 12,
  background: "var(--surface)",
  border: "1px solid var(--border)",
};

const topTypeName: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 600,
  wordBreak: "break-word",
};

const topTypeCount: React.CSSProperties = {
  minWidth: 36,
  textAlign: "center",
  borderRadius: 999,
  padding: "4px 8px",
  fontSize: 12,
  fontWeight: 700,
  background: "rgba(59,130,246,0.16)",
  border: "1px solid rgba(59,130,246,0.28)",
  color: "var(--accent-strong)",
};

const emptyState: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 13,
  opacity: 0.8,
};

const loadMoreButton: React.CSSProperties = {
  padding: "12px 20px",
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  cursor: "pointer",
};