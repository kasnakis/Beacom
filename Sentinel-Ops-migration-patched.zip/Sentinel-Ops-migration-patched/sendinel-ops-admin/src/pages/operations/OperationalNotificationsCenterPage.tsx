import { useEffect, useMemo, useState } from "react";
import { useOperationalNotificationsCenter } from "../../hooks/useOperationalNotificationsCenter";
import type { OperationalNotificationRequest } from "../../domain/models/operationalNotification";

function uniq(values: string[]) {
  return Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b));
}

function formatDate(value?: number) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("el-GR", {
    dateStyle: "short",
    timeStyle: "medium",
  }).format(new Date(value));
}

function safeTime(item: OperationalNotificationRequest) {
  return item.updatedAt || item.processedAt || item.sentAt || item.createdAt || 0;
}

function mapKeys(value?: Record<string, boolean>) {
  if (!value) return [];
  return Object.entries(value)
    .filter(([, enabled]) => enabled !== false)
    .map(([key]) => key);
}

function statusTone(status?: string): React.CSSProperties {
  switch ((status || "").toUpperCase()) {
    case "SENT":
      return { borderColor: "rgba(34,197,94,0.38)", background: "rgba(34,197,94,0.12)" };
    case "PARTIAL":
    case "RETRY_SCHEDULED":
      return { borderColor: "rgba(251,191,36,0.42)", background: "rgba(251,191,36,0.12)" };
    case "FAILED":
    case "NO_TARGETS":
      return { borderColor: "rgba(248,113,113,0.44)", background: "rgba(248,113,113,0.12)" };
    case "PENDING":
    case "PROCESSING":
      return { borderColor: "rgba(96,165,250,0.42)", background: "rgba(96,165,250,0.12)" };
    default:
      return {};
  }
}

function isAttentionItem(item: OperationalNotificationRequest) {
  const status = (item.status || "").toUpperCase();
  return status === "FAILED" || status === "NO_TARGETS" || status === "PARTIAL" || status === "RETRY_SCHEDULED";
}

function isPendingItem(item: OperationalNotificationRequest) {
  const status = (item.status || "").toUpperCase();
  return status === "PENDING" || status === "PROCESSING" || status === "RETRY_SCHEDULED";
}

function countByStatus(items: OperationalNotificationRequest[], status: string) {
  return items.filter((item) => (item.status || "").toUpperCase() === status).length;
}

export function OperationalNotificationsCenterPage() {
  const { data, isLoading, error } = useOperationalNotificationsCenter();
  const items = data ?? [];

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [siteFilter, setSiteFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [triggerFilter, setTriggerFilter] = useState("");
  const [search, setSearch] = useState("");
  const [attentionOnly, setAttentionOnly] = useState(false);

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();

    return items
      .filter((item) => {
        if (attentionOnly && !isAttentionItem(item)) return false;
        if (siteFilter && item.siteId !== siteFilter) return false;
        if (statusFilter && (item.status || "").toUpperCase() !== statusFilter) return false;
        if (triggerFilter && (item.trigger || item.type || "") !== triggerFilter) return false;

        if (q) {
          const haystack = [
            item.id,
            item.incidentId,
            item.siteId,
            item.status,
            item.trigger,
            item.type,
            item.category,
            item.title,
            item.body,
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();
          if (!haystack.includes(q)) return false;
        }

        return true;
      })
      .sort((a, b) => safeTime(b) - safeTime(a));
  }, [attentionOnly, items, search, siteFilter, statusFilter, triggerFilter]);

  useEffect(() => {
    if (!filteredItems.length) {
      if (selectedId) setSelectedId(null);
      return;
    }

    const selectedStillExists = selectedId
      ? filteredItems.some((item) => item.id === selectedId)
      : false;

    if (!selectedStillExists) setSelectedId(filteredItems[0].id);
  }, [filteredItems, selectedId]);

  const selectedItem = useMemo(() => {
    if (!selectedId) return null;
    return filteredItems.find((item) => item.id === selectedId) ?? null;
  }, [filteredItems, selectedId]);

  const siteOptions = useMemo(() => uniq(items.map((item) => item.siteId || "")), [items]);
  const statusOptions = useMemo(
    () => uniq(items.map((item) => (item.status || "").toUpperCase())),
    [items]
  );
  const triggerOptions = useMemo(
    () => uniq(items.map((item) => item.trigger || item.type || "")),
    [items]
  );

  const stats = useMemo(() => {
    const visible = filteredItems.length;
    return {
      total: items.length,
      visible,
      pending: filteredItems.filter(isPendingItem).length,
      sent: countByStatus(filteredItems, "SENT"),
      partial: countByStatus(filteredItems, "PARTIAL"),
      retry: countByStatus(filteredItems, "RETRY_SCHEDULED"),
      failed: countByStatus(filteredItems, "FAILED"),
      noTargets: countByStatus(filteredItems, "NO_TARGETS"),
      attention: filteredItems.filter(isAttentionItem).length,
    };
  }, [filteredItems, items.length]);

  return (
    <div style={{ padding: 16 }}>
      <div style={pageHeader}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22 }}>Κέντρο Ειδοποιήσεων</h1>
          <div style={headerSubtle}>
            Επιχειρησιακή εικόνα για push notification requests, παραδόσεις, αποτυχίες και retry queue.
          </div>
        </div>

        <div style={headerMeta}>
          <div><strong>Σύνολο:</strong> {stats.total}</div>
          <div><strong>Ορατά:</strong> {stats.visible}</div>
        </div>
      </div>

      <div style={summaryGrid}>
        <SummaryCard label="Pending / Processing" value={stats.pending} hint="Περιμένουν επεξεργασία ή retry" />
        <SummaryCard label="Sent" value={stats.sent} hint="Ολοκληρωμένες αποστολές" />
        <SummaryCard label="Partial" value={stats.partial} hint="Μερική επιτυχία" />
        <SummaryCard label="Retry" value={stats.retry} hint="Προγραμματισμένη επανάληψη" />
        <SummaryCard label="Failed" value={stats.failed} hint="Αποτυχία αποστολής" />
        <SummaryCard label="No targets" value={stats.noTargets} hint="Δεν βρέθηκαν παραλήπτες" />
      </div>

      <div style={attentionBanner}>
        <strong>{stats.attention}</strong> ειδοποιήσεις χρειάζονται προσοχή στα τρέχοντα φίλτρα.
        <span style={{ opacity: 0.75 }}> Περιλαμβάνει FAILED, NO_TARGETS, PARTIAL και RETRY_SCHEDULED.</span>
      </div>

      <div style={filtersGrid}>
        <div>
          <label style={labelStyle}>Site</label>
          <select value={siteFilter} onChange={(e) => setSiteFilter(e.target.value)} style={inputStyle}>
            <option value="">Όλα</option>
            {siteOptions.map((site) => <option key={site} value={site}>{site}</option>)}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Status</label>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={inputStyle}>
            <option value="">Όλα</option>
            {statusOptions.map((status) => <option key={status} value={status}>{status}</option>)}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Trigger / Type</label>
          <select value={triggerFilter} onChange={(e) => setTriggerFilter(e.target.value)} style={inputStyle}>
            <option value="">Όλα</option>
            {triggerOptions.map((trigger) => <option key={trigger} value={trigger}>{trigger}</option>)}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Αναζήτηση</label>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="incident, request, τίτλος..." style={inputStyle} />
        </div>
      </div>

      <div style={toolbarStyle}>
        <label style={toggleLabel}>
          <input type="checkbox" checked={attentionOnly} onChange={(e) => setAttentionOnly(e.target.checked)} />
          <span>Μόνο όσα χρειάζονται προσοχή</span>
        </label>

        <button
          type="button"
          style={clearButtonStyle}
          onClick={() => {
            setSiteFilter("");
            setStatusFilter("");
            setTriggerFilter("");
            setSearch("");
            setAttentionOnly(false);
          }}
        >
          Καθαρισμός φίλτρων
        </button>
      </div>

      {isLoading ? (
        <p>Φόρτωση ειδοποιήσεων...</p>
      ) : error ? (
        <p style={{ color: "var(--danger-strong)" }}>Σφάλμα φόρτωσης: {error instanceof Error ? error.message : String(error)}</p>
      ) : (
        <div style={contentGrid}>
          <div>
            <h2 style={{ marginTop: 0, marginBottom: 8 }}>Notification requests</h2>
            <div style={sectionHint}>Ζωντανή ανάγνωση από το node notification_requests.</div>
            <div style={tableWrap}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Status</th>
                    <th style={thStyle}>Trigger</th>
                    <th style={thStyle}>Site</th>
                    <th style={thStyle}>Incident</th>
                    <th style={thStyle}>Recipients</th>
                    <th style={thStyle}>Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredItems.map((item) => {
                    const isSelected = item.id === selectedId;
                    return (
                      <tr
                        key={item.id}
                        onClick={() => setSelectedId(item.id)}
                        style={{
                          cursor: "pointer",
                          background: isSelected ? "rgba(96,165,250,0.16)" : "transparent",
                        }}
                      >
                        <td style={tdStyle}><span style={{ ...badgeStyle, ...statusTone(item.status) }}>{item.status || "UNKNOWN"}</span></td>
                        <td style={tdStyle}>{item.trigger || item.type || "—"}</td>
                        <td style={tdStyle}>{item.siteId || "—"}</td>
                        <td style={tdStyle}>{item.incidentId || "—"}</td>
                        <td style={tdStyle}>{item.recipientCount ?? "—"}</td>
                        <td style={tdStyle}>{formatDate(safeTime(item))}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {!filteredItems.length ? <div style={emptyStateStyle}>Δεν βρέθηκαν notification requests.</div> : null}
          </div>

          <NotificationDetail item={selectedItem} />
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, value, hint }: { label: string; value: number; hint: string }) {
  return (
    <div style={summaryCard}>
      <div style={summaryLabel}>{label}</div>
      <div style={summaryValue}>{value}</div>
      <div style={summaryHint}>{hint}</div>
    </div>
  );
}

function NotificationDetail({ item }: { item: OperationalNotificationRequest | null }) {
  if (!item) {
    return (
      <div>
        <h2 style={{ marginTop: 0, marginBottom: 8 }}>Detail</h2>
        <div style={emptyStateStyle}>Δεν έχει επιλεγεί ειδοποίηση.</div>
      </div>
    );
  }

  const roles = mapKeys(item.targetRoles);
  const teams = mapKeys(item.targetTeams);
  const users = mapKeys(item.targetUsers);
  const deliveryCount = item.deliveryResults ? Object.keys(item.deliveryResults).length : 0;

  return (
    <div>
      <h2 style={{ marginTop: 0, marginBottom: 8 }}>Detail</h2>
      <div style={detailCard}>
        <div style={detailHeader}>
          <span style={{ ...badgeStyle, ...statusTone(item.status) }}>{item.status || "UNKNOWN"}</span>
          <span style={detailId}>{item.id}</span>
        </div>

        <div style={detailTitle}>{item.title || item.trigger || item.type || "Notification request"}</div>
        {item.body ? <div style={detailBody}>{item.body}</div> : null}

        <div style={detailGrid}>
          <Info label="Site" value={item.siteId} />
          <Info label="Incident" value={item.incidentId} />
          <Info label="Category" value={item.category} />
          <Info label="Trigger" value={item.trigger || item.type} />
          <Info label="Created" value={formatDate(item.createdAt)} />
          <Info label="Updated" value={formatDate(safeTime(item))} />
          <Info label="Next retry" value={formatDate(item.nextRetryAt)} />
          <Info label="Retry" value={item.retryCount !== undefined ? `${item.retryCount}/${item.maxRetries ?? "—"}` : undefined} />
        </div>

        <div style={sectionBox}>
          <div style={sectionTitle}>Targeting</div>
          <div style={pillRow}>
            {roles.map((role) => <span key={role} style={pillStyle}>Role: {role}</span>)}
            {teams.map((team) => <span key={team} style={pillStyle}>Team: {team}</span>)}
            {users.map((user) => <span key={user} style={pillStyle}>User: {user}</span>)}
            {!roles.length && !teams.length && !users.length ? <span style={mutedText}>Δεν βρέθηκε targeting metadata.</span> : null}
          </div>
        </div>

        <div style={sectionBox}>
          <div style={sectionTitle}>Delivery summary</div>
          <div style={detailGrid}>
            <Info label="Recipients" value={item.recipientCount} />
            <Info label="Success" value={item.successCount} />
            <Info label="Failure" value={item.failureCount} />
            <Info label="Invalid tokens" value={item.invalidTokenCount} />
            <Info label="Retryable failures" value={item.retryableFailureCount} />
            <Info label="Delivery rows" value={deliveryCount || undefined} />
          </div>
        </div>

        {item.error || item.lastError ? (
          <div style={errorBox}>
            <div style={sectionTitle}>Error</div>
            <div>{item.error || item.lastError}</div>
          </div>
        ) : null}

        <div style={pathText}>{item.dataPath}</div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value?: string | number }) {
  return (
    <div>
      <div style={infoLabel}>{label}</div>
      <div style={infoValue}>{value ?? "—"}</div>
    </div>
  );
}

const pageHeader: React.CSSProperties = { display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start", marginBottom: 16, flexWrap: "wrap" };
const headerSubtle: React.CSSProperties = { marginTop: 6, fontSize: 13, opacity: 0.78 };
const headerMeta: React.CSSProperties = { display: "grid", gap: 4, minWidth: 150, fontSize: 13, opacity: 0.86, textAlign: "right" };
const summaryGrid: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(6, minmax(120px, 1fr))", gap: 12, marginBottom: 12 };
const summaryCard: React.CSSProperties = { borderRadius: 14, border: "1px solid var(--border)", background: "var(--surface)", padding: 12, minHeight: 92 };
const summaryLabel: React.CSSProperties = { fontSize: 12, opacity: 0.75, marginBottom: 8 };
const summaryValue: React.CSSProperties = { fontSize: 26, fontWeight: 800, lineHeight: 1.1 };
const summaryHint: React.CSSProperties = { marginTop: 8, fontSize: 12, opacity: 0.68 };
const attentionBanner: React.CSSProperties = { borderRadius: 12, border: "1px solid rgba(251,191,36,0.28)", background: "rgba(251,191,36,0.08)", padding: 12, marginBottom: 14, fontSize: 13 };
const filtersGrid: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(4, minmax(180px, 1fr))", gap: 12, marginBottom: 12 };
const labelStyle: React.CSSProperties = { display: "block", fontSize: 12, marginBottom: 6, opacity: 0.8 };
const inputStyle: React.CSSProperties = { width: "100%", borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--surface-2)", color: "inherit", padding: "8px 10px" };
const toolbarStyle: React.CSSProperties = { display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap", marginBottom: 12 };
const toggleLabel: React.CSSProperties = { display: "inline-flex", alignItems: "center", gap: 8, fontSize: 13 };
const clearButtonStyle: React.CSSProperties = { borderRadius: 8, border: "1px solid var(--border)", background: "var(--surface-2)", color: "inherit", padding: "8px 12px", cursor: "pointer" };
const contentGrid: React.CSSProperties = { display: "grid", gridTemplateColumns: "1.25fr 0.95fr", gap: 16, alignItems: "start" };
const sectionHint: React.CSSProperties = { fontSize: 12, opacity: 0.72, marginBottom: 10 };
const tableWrap: React.CSSProperties = { overflow: "auto", borderRadius: 12, border: "1px solid var(--border)" };
const tableStyle: React.CSSProperties = { width: "100%", borderCollapse: "collapse", fontSize: 13 };
const thStyle: React.CSSProperties = { textAlign: "left", padding: "10px 12px", borderBottom: "1px solid var(--border)", opacity: 0.78, whiteSpace: "nowrap" };
const tdStyle: React.CSSProperties = { padding: "10px 12px", borderBottom: "1px solid var(--border)", verticalAlign: "top", whiteSpace: "nowrap" };
const badgeStyle: React.CSSProperties = { display: "inline-flex", alignItems: "center", borderRadius: 999, border: "1px solid var(--border-strong)", padding: "3px 8px", fontSize: 12, fontWeight: 700, whiteSpace: "nowrap" };
const emptyStateStyle: React.CSSProperties = { marginTop: 12, padding: 12, borderRadius: 12, border: "1px solid var(--border)", background: "var(--surface)", fontSize: 13, opacity: 0.8 };
const detailCard: React.CSSProperties = { borderRadius: 14, border: "1px solid var(--border)", background: "var(--surface)", padding: 14 };
const detailHeader: React.CSSProperties = { display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", marginBottom: 10 };
const detailId: React.CSSProperties = { fontSize: 11, opacity: 0.62, wordBreak: "break-all", textAlign: "right" };
const detailTitle: React.CSSProperties = { fontSize: 16, fontWeight: 800, marginBottom: 6 };
const detailBody: React.CSSProperties = { fontSize: 13, opacity: 0.8, marginBottom: 12, lineHeight: 1.45 };
const detailGrid: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(2, minmax(120px, 1fr))", gap: 10, marginBottom: 12 };
const infoLabel: React.CSSProperties = { fontSize: 11, opacity: 0.62, marginBottom: 3 };
const infoValue: React.CSSProperties = { fontSize: 13, fontWeight: 650, wordBreak: "break-word" };
const sectionBox: React.CSSProperties = { borderTop: "1px solid var(--border)", paddingTop: 12, marginTop: 12 };
const sectionTitle: React.CSSProperties = { fontSize: 13, fontWeight: 800, marginBottom: 8 };
const pillRow: React.CSSProperties = { display: "flex", gap: 8, flexWrap: "wrap" };
const pillStyle: React.CSSProperties = { borderRadius: 999, border: "1px solid var(--border)", background: "var(--surface-2)", padding: "4px 8px", fontSize: 12 };
const mutedText: React.CSSProperties = { fontSize: 12, opacity: 0.68 };
const errorBox: React.CSSProperties = { borderRadius: 12, border: "1px solid rgba(248,113,113,0.32)", background: "rgba(248,113,113,0.10)", padding: 12, marginTop: 12, fontSize: 13 };
const pathText: React.CSSProperties = { marginTop: 12, fontSize: 11, opacity: 0.5, wordBreak: "break-all" };
