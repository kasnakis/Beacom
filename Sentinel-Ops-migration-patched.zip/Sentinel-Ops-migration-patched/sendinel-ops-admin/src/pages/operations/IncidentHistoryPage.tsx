import { useMemo, useState } from "react";
import { useIncidentTimeline } from "../../hooks/useIncidentTimeline";
import { TimelineFeed } from "../../features/operations/components/TimelineFeed";
import type { IncidentEventRecord } from "../../domain/models/incidentEvent";

type IncidentHistoryGroup = {
  incidentId: string;
  siteId?: string;
  category?: string;
  createdAt?: number;
  updatedAt?: number;
  latestEventType?: string;
  items: IncidentEventRecord[];
};

function formatDate(value?: number) {
  if (!value) return "-";
  return new Date(value).toLocaleString("el-GR");
}

function normalize(value: string) {
  return value.trim().toLowerCase();
}

function uniqueSorted(values: string[]) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

function safeEventType(item: IncidentEventRecord) {
  return item.eventType || "UNKNOWN";
}

function detectCategory(items: IncidentEventRecord[]) {
  for (const item of items) {
    const raw = item as unknown as Record<string, unknown>;
    const category =
      (typeof raw.category === "string" && raw.category) ||
      (typeof raw.incidentCategory === "string" && raw.incidentCategory) ||
      undefined;

    if (category) return category;
  }
  return undefined;
}

function buildIncidentGroups(items: IncidentEventRecord[]): IncidentHistoryGroup[] {
  const map = new Map<string, IncidentEventRecord[]>();

  for (const item of items) {
    const incidentId = item.incidentId || "UNKNOWN_INCIDENT";
    if (!map.has(incidentId)) {
      map.set(incidentId, []);
    }
    map.get(incidentId)!.push(item);
  }

  const groups: IncidentHistoryGroup[] = [];

  for (const [incidentId, groupItems] of map.entries()) {
    const sorted = [...groupItems].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const latest = sorted[0];
    const oldest = sorted[sorted.length - 1];

    groups.push({
      incidentId,
      siteId: latest?.siteId || oldest?.siteId,
      category: detectCategory(sorted),
      createdAt: oldest?.createdAt,
      updatedAt: latest?.createdAt,
      latestEventType: safeEventType(latest),
      items: sorted,
    });
  }

  groups.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  return groups;
}

function countExternalEvents(items: IncidentEventRecord[]) {
  return items.filter((item) =>
    [
      "EXTERNAL_NOTIFICATION_REQUESTED",
      "EXTERNAL_NOTIFICATION_APPROVED",
      "EXTERNAL_NOTIFICATION_SENT",
      "EXTERNAL_NOTIFICATION_ACK",
      "EXTERNAL_NOTIFICATION_CANCELLED",
      "EXTERNAL_NOTIFICATION_REJECTED",
      "EXTERNAL_NOTIFICATION_FAILED",
      "EXTERNAL_NOTIFICATION_CLOSED",
    ].includes(item.eventType || "")
  ).length;
}

function countDispatchEvents(items: IncidentEventRecord[]) {
  return items.filter((item) =>
    [
      "PLAYBOOK_DISPATCH_REQUESTED",
      "PLAYBOOK_DISPATCH_MATERIALIZED",
      "RESPONDER_DECLARED",
      "RESPONDER_LOCATION_UPDATED",
    ].includes(item.eventType || "")
  ).length;
}

function countPlaybookEvents(items: IncidentEventRecord[]) {
  return items.filter((item) =>
    [
      "PLAYBOOK_ACTIVATED",
      "PLAYBOOK_STEP_STARTED",
      "PLAYBOOK_STEP_COMPLETED",
    ].includes(item.eventType || "")
  ).length;
}

function countLifecycleEvents(items: IncidentEventRecord[]) {
  return items.filter((item) =>
    [
      "INCIDENT_CREATED",
      "INCIDENT_VERIFIED",
      "INCIDENT_REJECTED",
      "INCIDENT_CLOSED",
      "EMERGENCY_ACTIVATED",
      "EMERGENCY_UNDER_CONTROL",
      "EMERGENCY_DEACTIVATED",
    ].includes(item.eventType || "")
  ).length;
}

function latestStatusTone(eventType?: string): React.CSSProperties {
  switch (eventType) {
    case "INCIDENT_CLOSED":
    case "EMERGENCY_DEACTIVATED":
      return {
        background: "rgba(99,102,241,0.16)",
        border: "1px solid rgba(99,102,241,0.30)",
        color: "#c7d2fe",
      };
    case "INCIDENT_REJECTED":
    case "EXTERNAL_NOTIFICATION_REJECTED":
    case "EXTERNAL_NOTIFICATION_FAILED":
    case "EXTERNAL_NOTIFICATION_CANCELLED":
      return {
        background: "rgba(239,68,68,0.16)",
        border: "1px solid rgba(239,68,68,0.30)",
        color: "#fecaca",
      };
    case "INCIDENT_VERIFIED":
    case "EXTERNAL_NOTIFICATION_APPROVED":
      return {
        background: "rgba(59,130,246,0.16)",
        border: "1px solid rgba(59,130,246,0.30)",
        color: "var(--accent-strong)",
      };
    case "EXTERNAL_NOTIFICATION_ACK":
    case "EMERGENCY_UNDER_CONTROL":
      return {
        background: "rgba(20,184,166,0.16)",
        border: "1px solid rgba(20,184,166,0.30)",
        color: "#99f6e4",
      };
    default:
      return {
        background: "var(--surface-2)",
        border: "1px solid var(--border)",
        color: "#e5e7eb",
      };
  }
}

function Pill({
  label,
  style,
}: {
  label: string;
  style?: React.CSSProperties;
}) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: 11,
        fontWeight: 800,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {label}
    </span>
  );
}

export function IncidentHistoryPage() {
  const { items, loading, loadingMore, loadMore } = useIncidentTimeline();

  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null);
  const [siteFilter, setSiteFilter] = useState("");
  const [incidentSearch, setIncidentSearch] = useState("");
  const [eventTypeFilter, setEventTypeFilter] = useState("");

  const groupedIncidents = useMemo(() => buildIncidentGroups(items), [items]);

  const availableSites = useMemo(
    () => uniqueSorted(groupedIncidents.map((group) => group.siteId || "")),
    [groupedIncidents]
  );

  const availableEventTypes = useMemo(
    () => uniqueSorted(items.map((item) => item.eventType || "")),
    [items]
  );

  const filteredGroups = useMemo(() => {
    const q = normalize(incidentSearch);

    return groupedIncidents.filter((group) => {
      const siteOk = !siteFilter || group.siteId === siteFilter;
      const incidentOk = !q || normalize(group.incidentId).includes(q);
      const eventOk =
        !eventTypeFilter ||
        group.items.some((item) => (item.eventType || "") === eventTypeFilter);

      return siteOk && incidentOk && eventOk;
    });
  }, [groupedIncidents, siteFilter, incidentSearch, eventTypeFilter]);

  const selectedGroup = useMemo(() => {
    if (!filteredGroups.length) return null;

    const existing = selectedIncidentId
      ? filteredGroups.find((group) => group.incidentId === selectedIncidentId)
      : null;

    return existing || filteredGroups[0];
  }, [filteredGroups, selectedIncidentId]);

  const selectedItems = selectedGroup?.items ?? [];

  const stats = useMemo(() => {
    return {
      incidents: filteredGroups.length,
      loadedEvents: items.length,
      visibleEvents: filteredGroups.reduce((sum, group) => sum + group.items.length, 0),
      external: filteredGroups.reduce((sum, group) => sum + countExternalEvents(group.items), 0),
      dispatch: filteredGroups.reduce((sum, group) => sum + countDispatchEvents(group.items), 0),
      playbooks: filteredGroups.reduce((sum, group) => sum + countPlaybookEvents(group.items), 0),
      lifecycle: filteredGroups.reduce((sum, group) => sum + countLifecycleEvents(group.items), 0),
    };
  }, [filteredGroups, items]);

  const hasFilters = Boolean(siteFilter || incidentSearch.trim() || eventTypeFilter);

  if (loading) {
    return <div style={{ padding: 24 }}>Φόρτωση ιστορικού συμβάντων...</div>;
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={pageHeader}>
        <div>
          <h1 style={{ margin: 0 }}>Incident History</h1>
          <div style={subtleText}>
            Incident-centric προβολή ιστορικού με lifecycle, playbooks, dispatch και external
            authorities.
          </div>
        </div>

        <div style={headerMeta}>
          <div style={headerMetaLine}>
            <strong>Incidents:</strong> {stats.incidents}
          </div>
          <div style={headerMetaLine}>
            <strong>Visible events:</strong> {stats.visibleEvents}
          </div>
        </div>
      </div>

      <div style={summaryGrid}>
        <div style={summaryCard}>
          <div style={summaryLabel}>Incidents</div>
          <div style={summaryValue}>{stats.incidents}</div>
          <div style={summaryHint}>Μετά τα τρέχοντα φίλτρα</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Lifecycle</div>
          <div style={summaryValue}>{stats.lifecycle}</div>
          <div style={summaryHint}>Core incident changes</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Playbooks</div>
          <div style={summaryValue}>{stats.playbooks}</div>
          <div style={summaryHint}>Playbook execution events</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Dispatch</div>
          <div style={summaryValue}>{stats.dispatch}</div>
          <div style={summaryHint}>Responder / dispatch events</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>External</div>
          <div style={summaryValue}>{stats.external}</div>
          <div style={summaryHint}>External authority events</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Loaded events</div>
          <div style={summaryValue}>{stats.loadedEvents}</div>
          <div style={summaryHint}>Στο τρέχον timeline slice</div>
        </div>
      </div>

      <div style={filtersGrid}>
        <div>
          <label style={labelStyle}>Site</label>
          <select
            value={siteFilter}
            onChange={(e) => setSiteFilter(e.target.value)}
            style={inputStyle}
          >
            <option value="">Όλα</option>
            {availableSites.map((site) => (
              <option key={site} value={site}>
                {site}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Incident</label>
          <input
            value={incidentSearch}
            onChange={(e) => setIncidentSearch(e.target.value)}
            placeholder="search incident id..."
            style={inputStyle}
          />
        </div>

        <div>
          <label style={labelStyle}>Event type</label>
          <select
            value={eventTypeFilter}
            onChange={(e) => setEventTypeFilter(e.target.value)}
            style={inputStyle}
          >
            <option value="">Όλα</option>
            {availableEventTypes.map((eventType) => (
              <option key={eventType} value={eventType}>
                {eventType}
              </option>
            ))}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "end" }}>
          <button
            type="button"
            onClick={() => {
              setSiteFilter("");
              setIncidentSearch("");
              setEventTypeFilter("");
            }}
            disabled={!hasFilters}
            style={clearButton}
          >
            Καθαρισμός φίλτρων
          </button>
        </div>
      </div>

      <div style={contentGrid}>
        <div>
          <div style={sectionHeader}>
            <h2 style={{ margin: 0 }}>Incidents</h2>
            <div style={sectionHint}>
              Επιλογή incident για προβολή του πλήρους ιστορικού του.
            </div>
          </div>

          <div style={leftPanel}>
            {filteredGroups.length ? (
              filteredGroups.map((group) => {
                const isSelected = selectedGroup?.incidentId === group.incidentId;

                return (
                  <button
                    key={group.incidentId}
                    type="button"
                    onClick={() => setSelectedIncidentId(group.incidentId)}
                    style={{
                      ...incidentCard,
                      ...(isSelected
                        ? {
                            border: "1px solid rgba(59,130,246,0.28)",
                            background: "rgba(59,130,246,0.10)",
                          }
                        : null),
                    }}
                  >
                    <div style={incidentCardHeader}>
                      <div style={incidentTitleBlock}>
                        <div style={incidentIdStyle}>{group.incidentId}</div>
                        <div style={incidentMetaLine}>
                          {group.siteId || "-"}
                          {group.category ? ` · ${group.category}` : ""}
                        </div>
                      </div>

                      <Pill
                        label={group.latestEventType || "UNKNOWN"}
                        style={latestStatusTone(group.latestEventType)}
                      />
                    </div>

                    <div style={incidentCounters}>
                      <div style={counterBox}>
                        <div style={counterLabel}>Events</div>
                        <div style={counterValue}>{group.items.length}</div>
                      </div>
                      <div style={counterBox}>
                        <div style={counterLabel}>Lifecycle</div>
                        <div style={counterValue}>{countLifecycleEvents(group.items)}</div>
                      </div>
                      <div style={counterBox}>
                        <div style={counterLabel}>Dispatch</div>
                        <div style={counterValue}>{countDispatchEvents(group.items)}</div>
                      </div>
                      <div style={counterBox}>
                        <div style={counterLabel}>External</div>
                        <div style={counterValue}>{countExternalEvents(group.items)}</div>
                      </div>
                    </div>

                    <div style={incidentDates}>
                      <div>Created: {formatDate(group.createdAt)}</div>
                      <div>Updated: {formatDate(group.updatedAt)}</div>
                    </div>
                  </button>
                );
              })
            ) : (
              <div style={emptyState}>
                Δεν βρέθηκαν incidents για τα τρέχοντα φίλτρα.
              </div>
            )}

            <div style={{ marginTop: 14, textAlign: "center" }}>
              <button
                onClick={loadMore}
                disabled={loadingMore}
                style={loadMoreButton}
              >
                {loadingMore ? "Φόρτωση..." : "Φόρτωση παλαιότερων"}
              </button>
            </div>
          </div>
        </div>

        <div>
          <div style={sectionHeader}>
            <h2 style={{ margin: 0 }}>Selected Incident Timeline</h2>
            <div style={sectionHint}>
              Πλήρες audit trail για το επιλεγμένο incident.
            </div>
          </div>

          {selectedGroup ? (
            <div style={rightPanel}>
              <div style={selectedHeader}>
                <div>
                  <div style={selectedIncidentTitle}>{selectedGroup.incidentId}</div>
                  <div style={selectedIncidentMeta}>
                    {selectedGroup.siteId || "-"}
                    {selectedGroup.category ? ` · ${selectedGroup.category}` : ""}
                  </div>
                </div>

                <Pill
                  label={selectedGroup.latestEventType || "UNKNOWN"}
                  style={latestStatusTone(selectedGroup.latestEventType)}
                />
              </div>

              <div style={selectedSummaryGrid}>
                <div style={selectedSummaryItem}>
                  <div style={selectedSummaryLabel}>Events</div>
                  <div style={selectedSummaryValue}>{selectedItems.length}</div>
                </div>
                <div style={selectedSummaryItem}>
                  <div style={selectedSummaryLabel}>Lifecycle</div>
                  <div style={selectedSummaryValue}>{countLifecycleEvents(selectedItems)}</div>
                </div>
                <div style={selectedSummaryItem}>
                  <div style={selectedSummaryLabel}>Playbooks</div>
                  <div style={selectedSummaryValue}>{countPlaybookEvents(selectedItems)}</div>
                </div>
                <div style={selectedSummaryItem}>
                  <div style={selectedSummaryLabel}>Dispatch</div>
                  <div style={selectedSummaryValue}>{countDispatchEvents(selectedItems)}</div>
                </div>
                <div style={selectedSummaryItem}>
                  <div style={selectedSummaryLabel}>External</div>
                  <div style={selectedSummaryValue}>{countExternalEvents(selectedItems)}</div>
                </div>
              </div>

              <TimelineFeed items={selectedItems} />
            </div>
          ) : (
            <div style={emptyState}>
              Δεν υπάρχει επιλεγμένο incident.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const pageHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 16,
  marginBottom: 16,
  flexWrap: "wrap",
};

const subtleText: React.CSSProperties = {
  marginTop: 6,
  fontSize: 13,
  opacity: 0.78,
};

const headerMeta: React.CSSProperties = {
  display: "grid",
  gap: 4,
  minWidth: 150,
};

const headerMetaLine: React.CSSProperties = {
  fontSize: 13,
  opacity: 0.84,
  textAlign: "right",
};

const summaryGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(6, minmax(140px, 1fr))",
  gap: 12,
  marginBottom: 16,
};

const summaryCard: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 12,
  minHeight: 92,
};

const summaryLabel: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
  marginBottom: 8,
};

const summaryValue: React.CSSProperties = {
  fontSize: 26,
  fontWeight: 800,
  lineHeight: 1.1,
};

const summaryHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.68,
};

const filtersGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(4, minmax(180px, 1fr))",
  gap: 12,
  marginBottom: 16,
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  marginBottom: 6,
  opacity: 0.8,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  borderRadius: 8,
  border: "1px solid var(--border-strong)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 10px",
};

const clearButton: React.CSSProperties = {
  borderRadius: 8,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 12px",
  cursor: "pointer",
  width: "100%",
};

const contentGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "0.95fr 1.35fr",
  gap: 16,
  alignItems: "start",
};

const sectionHeader: React.CSSProperties = {
  marginBottom: 10,
};

const sectionHint: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
};

const leftPanel: React.CSSProperties = {
  display: "grid",
  gap: 12,
};

const rightPanel: React.CSSProperties = {
  display: "grid",
  gap: 14,
};

const incidentCard: React.CSSProperties = {
  textAlign: "left",
  borderRadius: 16,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 14,
  cursor: "pointer",
  color: "inherit",
};

const incidentCardHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 10,
  marginBottom: 12,
};

const incidentTitleBlock: React.CSSProperties = {
  minWidth: 0,
};

const incidentIdStyle: React.CSSProperties = {
  fontSize: 13,
  fontWeight: 800,
  wordBreak: "break-word",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
};

const incidentMetaLine: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.72,
};

const incidentCounters: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(4, minmax(70px, 1fr))",
  gap: 8,
  marginBottom: 10,
};

const counterBox: React.CSSProperties = {
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 8,
};

const counterLabel: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.68,
  marginBottom: 4,
};

const counterValue: React.CSSProperties = {
  fontSize: 18,
  fontWeight: 800,
  lineHeight: 1.1,
};

const incidentDates: React.CSSProperties = {
  display: "grid",
  gap: 4,
  fontSize: 12,
  opacity: 0.72,
};

const selectedHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
};

const selectedIncidentTitle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 800,
  wordBreak: "break-word",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
};

const selectedIncidentMeta: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  opacity: 0.74,
};

const selectedSummaryGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(5, minmax(90px, 1fr))",
  gap: 10,
};

const selectedSummaryItem: React.CSSProperties = {
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 10,
};

const selectedSummaryLabel: React.CSSProperties = {
  fontSize: 11,
  opacity: 0.68,
  marginBottom: 4,
};

const selectedSummaryValue: React.CSSProperties = {
  fontSize: 20,
  fontWeight: 800,
};

const emptyState: React.CSSProperties = {
  padding: 14,
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 13,
  opacity: 0.82,
};

const loadMoreButton: React.CSSProperties = {
  padding: "12px 20px",
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  cursor: "pointer",
};