import { useEffect, useMemo, useState } from "react";
import { useLiveDashboard } from "../../hooks/useLiveDashboard";
import { LiveSummaryCards } from "../../features/operations/components/LiveSummaryCards";
import { ActiveIncidentsPanel } from "../../features/operations/components/ActiveIncidentsPanel";
import { SelectedIncidentOverview } from "../../features/operations/components/SelectedIncidentOverview";
import { SelectedIncidentTimelinePanel } from "../../features/operations/components/SelectedIncidentTimelinePanel";
import { SelectedIncidentMapPanel } from "../../features/operations/components/SelectedIncidentMapPanel";
import { LiveDashboardFilters } from "../../features/operations/components/LiveDashboardFilters";

type LiveDashboardTab = "overview" | "map" | "timeline" | "dispatch" | "closure" | "external";

type TabDefinition = {
  id: LiveDashboardTab;
  label: string;
  description: string;
};

const tabs: TabDefinition[] = [
  {
    id: "overview",
    label: "Σύνοψη συμβάντος",
    description: "Βασικά στοιχεία, κατάσταση, lifecycle και σύντομη εικόνα συμβάντος.",
  },
  {
    id: "map",
    label: "Χάρτης συμβάντος",
    description: "Γεωγραφική εικόνα συμβάντος και ανταποκριτών.",
  },
  {
    id: "timeline",
    label: "Χρονολόγιο",
    description: "Πρόσφατα γεγονότα και audit trail του επιλεγμένου συμβάντος.",
  },
  {
    id: "dispatch",
    label: "Κινητοποίηση / responders",
    description: "Dispatch lifecycle, ομάδες και χρήστες που ζητήθηκαν ή ανταποκρίθηκαν.",
  },
  {
    id: "external",
    label: "Εξωτερικές αρχές",
    description: "Execution board και αναλυτικές εγγραφές εξωτερικών αρχών.",
  },
  {
    id: "closure",
    label: "Ολοκλήρωση",
    description: "Σύσταση closure, lifecycle συμβάντος και οδηγίες πριν από κλείσιμο.",
  },
];

export function LiveDashboardPage() {
  const { data, isLoading, error, isFetching } = useLiveDashboard();

  const [siteId, setSiteId] = useState("");
  const [category, setCategory] = useState("");
  const [severity, setSeverity] = useState("");
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<LiveDashboardTab>("overview");

  const availableSites = useMemo(() => {
    return [...new Set((data?.incidents || []).map((item) => item.siteId).filter(Boolean) as string[])].sort();
  }, [data]);

  const availableCategories = useMemo(() => {
    return [...new Set((data?.incidents || []).map((item) => item.category).filter(Boolean) as string[])].sort();
  }, [data]);

  const availableSeverities = useMemo(() => {
    return [...new Set((data?.incidents || []).map((item) => item.severity).filter(Boolean) as string[])].sort();
  }, [data]);

  const filteredIncidents = useMemo(() => {
    return (data?.incidents || []).filter((item) => {
      const siteOk = !siteId || item.siteId === siteId;
      const categoryOk = !category || item.category === category;
      const severityOk = !severity || item.severity === severity;
      return siteOk && categoryOk && severityOk;
    });
  }, [data, siteId, category, severity]);

  useEffect(() => {
    if (!filteredIncidents.length) {
      setSelectedIncidentId(null);
      return;
    }

    const exists = filteredIncidents.some((item) => item.id === selectedIncidentId);
    if (!exists) {
      setSelectedIncidentId(filteredIncidents[0].id);
    }
  }, [filteredIncidents, selectedIncidentId]);

  const selectedIncident = useMemo(
    () => filteredIncidents.find((item) => item.id === selectedIncidentId) ?? null,
    [filteredIncidents, selectedIncidentId]
  );

  const selectedDispatch = useMemo(
    () => data?.dispatches.find((item) => item.incidentId === selectedIncident?.id) ?? null,
    [data, selectedIncident]
  );

  const selectedExternal = useMemo(
    () => data?.externalNotifications.filter((item) => item.incidentId === selectedIncident?.id) ?? [],
    [data, selectedIncident]
  );

  if (isLoading) {
    return <div style={{ padding: 24 }}>Φόρτωση dashboard...</div>;
  }

  if (error || !data) {
    return <div style={{ padding: 24 }}>Σφάλμα φόρτωσης dashboard</div>;
  }

  return (
    <div className="live-dashboard-page">
      <div className="live-dashboard-header">
        <div>
          <h1>Ζωντανή Επιχειρησιακή Εικόνα</h1>
          <p>
            Παρακολούθηση ενεργών συμβάντων, κινητοποιήσεων, responders,
            εξωτερικών ειδοποιήσεων και επιχειρησιακής κατάστασης σε πραγματικό χρόνο.
          </p>
        </div>

        <div className="live-dashboard-status">
          {isFetching ? "Ανανέωση..." : "Ενημερωμένο"}
        </div>
      </div>

      <LiveDashboardFilters
        siteId={siteId}
        category={category}
        severity={severity}
        availableSites={availableSites}
        availableCategories={availableCategories}
        availableSeverities={availableSeverities}
        onSiteChange={setSiteId}
        onCategoryChange={setCategory}
        onSeverityChange={setSeverity}
      />

      <LiveSummaryCards
        activeIncidentsCount={data.activeIncidentsCount}
        openDispatchesCount={data.dispatches.length}
        respondingCount={data.respondingCount}
        pendingExternalCount={data.pendingExternalCount}
      />

      {data.pendingClosureIncidentsCount > 0 ? (
        <div className="live-empty-state" style={{ marginBottom: 16 }}>
          Υπάρχουν {data.pendingClosureIncidentsCount} απενεργοποιημένα συμβάντα που εκκρεμούν για οριστικό κλείσιμο.
          Παραμένουν σε αυτή την επιχειρησιακή οθόνη μέχρι να ολοκληρωθεί το formal closure.
        </div>
      ) : null}

      <div className="live-dashboard-layout">
        <section className="live-dashboard-side-panel">
          <div className="live-section-heading-row">
            <div>
              <h2>Ενεργά / προς κλείσιμο</h2>
              <p>Επιλέξτε ενεργό ή απενεργοποιημένο συμβάν που εκκρεμεί για οριστικό κλείσιμο.</p>
            </div>
            <span>{filteredIncidents.length}</span>
          </div>

          {filteredIncidents.length === 0 ? (
            <div className="live-empty-state">
              Δεν υπάρχουν ενεργά ή προς κλείσιμο συμβάντα με τα τρέχοντα φίλτρα.
            </div>
          ) : (
            <ActiveIncidentsPanel
              items={filteredIncidents}
              selectedId={selectedIncident?.id ?? null}
              onSelect={setSelectedIncidentId}
            />
          )}
        </section>

        <section className="live-dashboard-main-panel">
          <div className="live-selected-header">
            <div>
              <h2>Επιλεγμένο συμβάν</h2>
              <p>
                {selectedIncident
                  ? `${selectedIncident.title || selectedIncident.category || "Συμβάν"} · ${selectedIncident.siteId || "Χωρίς site"}`
                  : "Δεν έχει επιλεγεί συμβάν."}
              </p>
            </div>
          </div>

          <div className="live-tabs" role="tablist" aria-label="Ενότητες ζωντανής εικόνας">
            {tabs.map((tab) => {
              const selected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  className={selected ? "live-tab live-tab-active" : "live-tab"}
                  onClick={() => setActiveTab(tab.id)}
                >
                  <span>{tab.label}</span>
                  <small>{tab.description}</small>
                </button>
              );
            })}
          </div>

          <div className="live-tab-content">
            {activeTab === "overview" && (
              <SelectedIncidentOverview
                incident={selectedIncident}
                dispatch={selectedDispatch}
                externalNotifications={selectedExternal}
                mode="summary"
              />
            )}

            {activeTab === "map" && (
              <SelectedIncidentMapPanel
                incident={selectedIncident}
                dispatch={selectedDispatch}
              />
            )}

            {activeTab === "timeline" && (
              <SelectedIncidentTimelinePanel incidentId={selectedIncident?.id ?? null} />
            )}

            {activeTab === "dispatch" && (
              <SelectedIncidentOverview
                incident={selectedIncident}
                dispatch={selectedDispatch}
                externalNotifications={selectedExternal}
                mode="dispatch"
              />
            )}

            {activeTab === "external" && (
              <SelectedIncidentOverview
                incident={selectedIncident}
                dispatch={selectedDispatch}
                externalNotifications={selectedExternal}
                mode="external"
              />
            )}

            {activeTab === "closure" && (
              <SelectedIncidentOverview
                incident={selectedIncident}
                dispatch={selectedDispatch}
                externalNotifications={selectedExternal}
                mode="closure"
              />
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
