import { useMemo, useState } from "react";
import { useDispatchMonitor } from "../../hooks/useDispatchMonitor";
import { DispatchTable } from "../../features/operations/components/DispatchTable";
import { DispatchResponderTable } from "../../features/operations/components/DispatchResponderTable";
import { DispatchFilters } from "../../features/operations/components/DispatchFilters";

function isOpen(status?: string) {
  return status !== "CLOSED" && status !== "CANCELLED";
}

export function DispatchMonitorPage() {
  const { data = [], isLoading, error, isFetching } = useDispatchMonitor();

  const [siteId, setSiteId] = useState("");
  const [status, setStatus] = useState("OPEN");
  const [incidentSearch, setIncidentSearch] = useState("");
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null);

  const availableSites = useMemo(() => {
    return [...new Set(data.map((d) => d.siteId).filter(Boolean))] as string[];
  }, [data]);

  const filtered = useMemo(() => {
    return data.filter((d) => {
      const siteOk = !siteId || d.siteId === siteId;

      const statusOk =
        status === "ALL"
          ? true
          : status === "OPEN"
          ? isOpen(d.status)
          : !isOpen(d.status);

      const incidentOk =
        !incidentSearch ||
        d.incidentId.toLowerCase().includes(incidentSearch.toLowerCase());

      return siteOk && statusOk && incidentOk;
    });
  }, [data, siteId, status, incidentSearch]);

  const selected = filtered.find((d) => d.incidentId === selectedIncidentId) || null;

  if (isLoading) return <div style={{ padding: 24 }}>Φόρτωση...</div>;
  if (error) return <div style={{ padding: 24 }}>Σφάλμα</div>;

  return (
    <div style={{ padding: 24 }}>
      <h1>Dispatch Monitor</h1>

      <div style={{ opacity: 0.7, marginBottom: 8 }}>
        {isFetching ? "Ανανέωση..." : "Ενημερωμένο"}
      </div>

      <DispatchFilters
        siteId={siteId}
        status={status}
        incidentSearch={incidentSearch}
        availableSites={availableSites}
        onSiteChange={setSiteId}
        onStatusChange={setStatus}
        onIncidentSearchChange={setIncidentSearch}
      />

      <div style={{ marginBottom: 10 }}>
        Εμφανίζονται {filtered.length} από {data.length}
      </div>

      <DispatchTable
        items={filtered}
        onSelect={setSelectedIncidentId}
        selectedId={selectedIncidentId}
      />

      <div style={{ marginTop: 20 }}>
        <h3>Responders</h3>
        {selected ? (
          <DispatchResponderTable responders={selected.responders} />
        ) : (
          <p>Επίλεξε incident</p>
        )}
      </div>
    </div>
  );
}