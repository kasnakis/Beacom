import { useEffect, useMemo, useState } from "react";
import { ExternalNotificationsTable } from "../../features/operations/components/ExternalNotificationsTable";
import { ExternalNotificationDetailDrawer } from "../../features/operations/components/ExternalNotificationDetailDrawer";
import { useExternalNotificationsMonitor } from "../../hooks/useExternalNotificationsMonitor";
import type { ExternalNotificationRecord } from "../../domain/models/externalNotification";

function uniq(values: string[]) {
  return Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b));
}

function safeTime(item: ExternalNotificationRecord) {
  return item.updatedAt ?? item.createdAt ?? 0;
}

function countByStatus(items: ExternalNotificationRecord[], status: string) {
  return items.filter((item) => item.status === status).length;
}

function countCanonical(items: ExternalNotificationRecord[]) {
  return items.filter((item) => item.recordKind === "CANONICAL").length;
}

function countLegacy(items: ExternalNotificationRecord[]) {
  return items.filter((item) => item.recordKind === "LEGACY").length;
}

export function ExternalNotificationsPage() {
  const { data, isLoading, error } = useExternalNotificationsMonitor();
  const items: ExternalNotificationRecord[] = data ?? [];

  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [siteFilter, setSiteFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [authorityFilter, setAuthorityFilter] = useState("");
  const [incidentSearch, setIncidentSearch] = useState("");

  const [showLegacy, setShowLegacy] = useState(false);
  const [groupRows, setGroupRows] = useState(true);

  const filteredItems = useMemo(() => {
    const normalizedIncidentSearch = incidentSearch.trim().toLowerCase();

    return items
      .filter((item: ExternalNotificationRecord) => {
        if (!showLegacy && item.recordKind === "LEGACY") return false;
        if (siteFilter && item.siteId !== siteFilter) return false;
        if (statusFilter && item.status !== statusFilter) return false;

        const authorityLabel = item.authorityName || item.authorityType || "";
        if (authorityFilter && authorityLabel !== authorityFilter) return false;

        if (normalizedIncidentSearch) {
          const incidentId = (item.incidentId || "").toLowerCase();
          if (!incidentId.includes(normalizedIncidentSearch)) return false;
        }

        return true;
      })
      .sort((a: ExternalNotificationRecord, b: ExternalNotificationRecord) => {
        return safeTime(b) - safeTime(a);
      });
  }, [items, showLegacy, siteFilter, statusFilter, authorityFilter, incidentSearch]);

  useEffect(() => {
    if (!filteredItems.length) {
      if (selectedId !== null) {
        setSelectedId(null);
      }
      return;
    }

    const selectedStillExists = selectedId
      ? filteredItems.some((item: ExternalNotificationRecord) => item.id === selectedId)
      : false;

    if (!selectedStillExists) {
      setSelectedId(filteredItems[0].id);
    }
  }, [filteredItems, selectedId]);

  const selectedItem = useMemo(() => {
    if (!selectedId) return null;
    return (
      filteredItems.find((item: ExternalNotificationRecord) => item.id === selectedId) ?? null
    );
  }, [filteredItems, selectedId]);

  const siteOptions = useMemo(
    () => uniq(items.map((item: ExternalNotificationRecord) => item.siteId || "")),
    [items]
  );

  const statusOptions = useMemo(
    () => uniq(items.map((item: ExternalNotificationRecord) => item.status || "")),
    [items]
  );

  const authorityOptions = useMemo(
    () =>
      uniq(
        items.map(
          (item: ExternalNotificationRecord) => item.authorityName || item.authorityType || ""
        )
      ),
    [items]
  );

  const stats = useMemo(() => {
    return {
      total: items.length,
      visible: filteredItems.length,
      canonical: countCanonical(items),
      legacy: countLegacy(items),
      requested: countByStatus(filteredItems, "REQUESTED"),
      approved: countByStatus(filteredItems, "APPROVED"),
      sent: countByStatus(filteredItems, "SENT"),
      acknowledged: countByStatus(filteredItems, "ACKNOWLEDGED"),
      rejected: countByStatus(filteredItems, "REJECTED"),
      cancelled: countByStatus(filteredItems, "CANCELLED"),
      failed: countByStatus(filteredItems, "FAILED"),
      closed: countByStatus(filteredItems, "CLOSED"),
    };
  }, [items, filteredItems]);

  return (
    <div style={{ padding: 16 }}>
      <div style={pageHeader}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22 }}>External Notifications</h1>
          <div style={headerSubtle}>
            Canonical queue για external authorities με συμβατότητα legacy όπου χρειάζεται.
          </div>
        </div>

        <div style={headerMeta}>
          <div style={headerMetaLine}>
            <strong>Σύνολο:</strong> {stats.total}
          </div>
          <div style={headerMetaLine}>
            <strong>Ορατά:</strong> {stats.visible}
          </div>
        </div>
      </div>

      <div style={summaryGrid}>
        <div style={summaryCard}>
          <div style={summaryLabel}>Canonical</div>
          <div style={summaryValue}>{stats.canonical}</div>
          <div style={summaryHint}>Primary operational records</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Legacy</div>
          <div style={summaryValue}>{stats.legacy}</div>
          <div style={summaryHint}>Compatibility / mirrors</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Requested</div>
          <div style={summaryValue}>{stats.requested}</div>
          <div style={summaryHint}>Περιμένουν επόμενη ενέργεια</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Approved</div>
          <div style={summaryValue}>{stats.approved}</div>
          <div style={summaryHint}>Εγκεκριμένα προς εκτέλεση</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Sent</div>
          <div style={summaryValue}>{stats.sent}</div>
          <div style={summaryHint}>Εκτελέστηκαν / απεστάλησαν</div>
        </div>

        <div style={summaryCard}>
          <div style={summaryLabel}>Acknowledged</div>
          <div style={summaryValue}>{stats.acknowledged}</div>
          <div style={summaryHint}>Έχει ληφθεί επιβεβαίωση</div>
        </div>
      </div>

      <div style={filtersGrid}>
        <div>
          <label style={labelStyle}>Site</label>
          <select
            value={siteFilter}
            onChange={(e) => setSiteFilter(e.target.value)}
            style={inputStyle}
          >
            <option value="">Όλα</option>
            {siteOptions.map((site) => (
              <option key={site} value={site}>
                {site}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Status</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={inputStyle}
          >
            <option value="">Όλα</option>
            {statusOptions.map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Authority</label>
          <select
            value={authorityFilter}
            onChange={(e) => setAuthorityFilter(e.target.value)}
            style={inputStyle}
          >
            <option value="">Όλες</option>
            {authorityOptions.map((authority) => (
              <option key={authority} value={authority}>
                {authority}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={labelStyle}>Incident</label>
          <input
            value={incidentSearch}
            onChange={(e) => setIncidentSearch(e.target.value)}
            placeholder="search incident..."
            style={inputStyle}
          />
        </div>
      </div>

      <div style={toolbarStyle}>
        <label style={toggleLabel}>
          <input
            type="checkbox"
            checked={showLegacy}
            onChange={(e) => setShowLegacy(e.target.checked)}
          />
          <span>Show legacy</span>
        </label>

        <label style={toggleLabel}>
          <input
            type="checkbox"
            checked={groupRows}
            onChange={(e) => setGroupRows(e.target.checked)}
          />
          <span>Grouping ανά incident + authority</span>
        </label>

        <button
          type="button"
          onClick={() => {
            setSiteFilter("");
            setStatusFilter("");
            setAuthorityFilter("");
            setIncidentSearch("");
            setShowLegacy(false);
            setGroupRows(true);
          }}
          style={clearButtonStyle}
        >
          Καθαρισμός φίλτρων
        </button>

        <div style={statsStyle}>
          Εμφανίζονται {filteredItems.length} από {items.length} records
        </div>
      </div>

      {isLoading ? (
        <p>Φόρτωση external notifications...</p>
      ) : error ? (
        <p style={{ color: "var(--danger-strong)" }}>
          Σφάλμα φόρτωσης: {error instanceof Error ? error.message : String(error)}
        </p>
      ) : (
        <div style={contentGrid}>
          <div>
            <h2 style={{ marginTop: 0, marginBottom: 8 }}>Queue</h2>
            <div style={sectionHint}>
              Προβολή records από το canonical queue με δυνατότητα εμφάνισης legacy mirrors.
            </div>

            <ExternalNotificationsTable
              items={filteredItems}
              selectedId={selectedId}
              onSelect={setSelectedId}
              grouped={groupRows}
            />

            {!filteredItems.length ? (
              <div style={emptyStateStyle}>
                Δεν βρέθηκαν records με τα τρέχοντα φίλτρα.
              </div>
            ) : null}
          </div>

          <div>
            <h2 style={{ marginTop: 0, marginBottom: 8 }}>Detail</h2>
            <div style={sectionHint}>
              Αναλυτική προβολή lifecycle, policy context και actions για το επιλεγμένο record.
            </div>
            <ExternalNotificationDetailDrawer item={selectedItem} />
          </div>
        </div>
      )}
    </div>
  );
}

const pageHeader: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  gap: 16,
  alignItems: "flex-start",
  marginBottom: 16,
  flexWrap: "wrap",
};

const headerSubtle: React.CSSProperties = {
  marginTop: 6,
  fontSize: 13,
  opacity: 0.78,
};

const headerMeta: React.CSSProperties = {
  display: "grid",
  gap: 4,
  minWidth: 150,
};

const headerMetaLine: React.CSSProperties = {
  fontSize: 13,
  opacity: 0.86,
  textAlign: "right",
};

const summaryGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(6, minmax(120px, 1fr))",
  gap: 12,
  marginBottom: 16,
};

const summaryCard: React.CSSProperties = {
  borderRadius: 14,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  padding: 12,
  minHeight: 92,
};

const summaryLabel: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.75,
  marginBottom: 8,
};

const summaryValue: React.CSSProperties = {
  fontSize: 26,
  fontWeight: 800,
  lineHeight: 1.1,
};

const summaryHint: React.CSSProperties = {
  marginTop: 8,
  fontSize: 12,
  opacity: 0.68,
};

const filtersGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(4, minmax(180px, 1fr))",
  gap: 12,
  marginBottom: 12,
};

const contentGrid: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1.3fr 0.9fr",
  gap: 16,
  alignItems: "start",
};

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  marginBottom: 6,
  opacity: 0.8,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  borderRadius: 8,
  border: "1px solid var(--border-strong)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 10px",
};

const toolbarStyle: React.CSSProperties = {
  display: "flex",
  gap: 16,
  alignItems: "center",
  flexWrap: "wrap",
  marginBottom: 12,
};

const toggleLabel: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  fontSize: 13,
};

const clearButtonStyle: React.CSSProperties = {
  borderRadius: 8,
  border: "1px solid var(--border)",
  background: "var(--surface-2)",
  color: "inherit",
  padding: "8px 12px",
  cursor: "pointer",
};

const statsStyle: React.CSSProperties = {
  marginLeft: "auto",
  fontSize: 13,
  opacity: 0.75,
};

const sectionHint: React.CSSProperties = {
  fontSize: 12,
  opacity: 0.72,
  marginBottom: 10,
};

const emptyStateStyle: React.CSSProperties = {
  marginTop: 12,
  padding: 12,
  borderRadius: 12,
  border: "1px solid var(--border)",
  background: "var(--surface)",
  fontSize: 13,
  opacity: 0.8,
};