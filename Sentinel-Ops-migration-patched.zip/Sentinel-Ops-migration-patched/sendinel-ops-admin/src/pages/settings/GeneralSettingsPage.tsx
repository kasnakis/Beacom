import { useQuery } from "@tanstack/react-query";
import { appConfigRepository } from "../../services/repositories/appConfigRepository";
import { PageHeader } from "../../features/shared/components/PageHeader";
import { LoadingState } from "../../features/shared/components/LoadingState";
import { GeneralSettingsForm } from "../../features/settings/components/GeneralSettingsForm";
import type { AppConfig } from "../../domain/models/appConfig";

export function GeneralSettingsPage() {
  const {
    data,
    isPending,
    error,
    fetchStatus,
  } = useQuery<AppConfig | null>({
    queryKey: ["appConfig"],
    queryFn: () => appConfigRepository.getAppConfig(),
  });

  if (isPending) {
    return (
      <div>
        <PageHeader title="Γενικές Ρυθμίσεις" subtitle="Global application settings" />
        <LoadingState />
        <div style={{ padding: 24, opacity: 0.7 }}>fetchStatus: {fetchStatus}</div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: 24 }}>
        <PageHeader title="Γενικές Ρυθμίσεις" subtitle="Global application settings" />
        <div style={{ color: "crimson" }}>
          Σφάλμα φόρτωσης ρυθμίσεων: {String(error)}
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Γενικές Ρυθμίσεις" subtitle="Global application settings" />
      <GeneralSettingsForm value={data ?? null} />
    </div>
  );
}