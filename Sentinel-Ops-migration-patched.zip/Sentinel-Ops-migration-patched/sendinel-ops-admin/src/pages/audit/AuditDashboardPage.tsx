import { useState } from "react";
import { useAuditLogs } from "../../hooks/useAuditLogs";

function formatDate(ts?: number) {
  if (!ts) return "-";
  return new Date(ts).toLocaleString("el-GR");
}

export default function AuditDashboardPage() {
  const [userFilter, setUserFilter] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const filters = {
    user: userFilter,
    from: from ? new Date(from).getTime() : undefined,
    to: to ? new Date(to).getTime() : undefined,
  };

  const { data = [], isLoading } = useAuditLogs(filters);

  function exportCSV() {
    if (!data.length) return;

    const rows = data.map((log: any) => ({
      date: formatDate(log.createdAt),
      user: log.performedBy?.email || "",
      level: log.performedBy?.level || "",
      fields: (log.changedFields || []).join(" | "),
    }));

    const csv = [
      Object.keys(rows[0]).join(","),
      ...rows.map((r) => Object.values(r).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "audit_logs.csv";
    a.click();
  }

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ marginBottom: 8 }}>Audit</h1>
      <div style={{ opacity: 0.7, marginBottom: 20 }}>
        Administrative and governance trail
      </div>

      {/* FILTERS */}
      <div
        style={{
          display: "flex",
          gap: 10,
          flexWrap: "wrap",
          marginBottom: 20,
        }}
      >
        <input
          placeholder="User email"
          value={userFilter}
          onChange={(e) => setUserFilter(e.target.value)}
          style={{ padding: 6 }}
        />

        <input
          type="date"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
        />

        <input
          type="date"
          value={to}
          onChange={(e) => setTo(e.target.value)}
        />

        <button onClick={exportCSV}>Export CSV</button>
      </div>

      {/* DATA */}
      {isLoading && <div>Loading...</div>}

      {!data.length && !isLoading && (
        <div style={{ opacity: 0.6 }}>Δεν υπάρχουν audit logs</div>
      )}

      {data.map((log: any) => (
        <div
          key={log.id}
          style={{
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 10,
            padding: 12,
            marginBottom: 10,
          }}
        >
          <div style={{ fontWeight: 700 }}>
            {(log.changedFields || []).join(", ")}
          </div>

          <div style={{ fontSize: 12, opacity: 0.7 }}>
            {formatDate(log.createdAt)}
          </div>

          <div style={{ marginTop: 4 }}>
            {log.performedBy?.email} ({log.performedBy?.level})
          </div>

          <details style={{ marginTop: 8 }}>
            <summary>Δες αλλαγές</summary>
            <pre style={{ fontSize: 12 }}>
              {JSON.stringify(log.changes, null, 2)}
            </pre>
          </details>
        </div>
      ))}
    </div>
  );
}