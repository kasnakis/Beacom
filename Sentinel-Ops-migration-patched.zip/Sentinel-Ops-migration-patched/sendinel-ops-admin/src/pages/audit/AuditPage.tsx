import { PageHeader } from "../../features/shared/components/PageHeader";
import { EmptyState } from "../../features/shared/components/EmptyState";

export function AuditPage() {
  return (
    <div>
      <PageHeader title="Audit" subtitle="Administrative and governance trail" />
      <EmptyState title="Starter placeholder για Audit / compliance area" />
    </div>
  );
}
