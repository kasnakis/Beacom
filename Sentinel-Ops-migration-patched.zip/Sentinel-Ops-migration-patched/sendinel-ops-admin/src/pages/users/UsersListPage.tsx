import { useEffect, useMemo, useState } from "react";
import { get, getDatabase, ref } from "firebase/database";
import { UsersTable } from "../../features/users/components/UsersTable";
import { UsersFilters } from "../../features/users/components/UsersFilters";
import { UserDetailDrawer } from "../../features/users/components/UserDetailDrawer";
import { UserCreatePanel } from "../../features/users/components/UserCreatePanel";
import { useUsers } from "../../hooks/useUsers";
import { useAuth } from "../../hooks/useAuth";
import { resolveAdminCapabilities } from "../../domain/permissions/adminCapabilities";
import type { UserProfile } from "../../domain/models/user";
import {
  translateRole,
  translateTeam,
  useDynamicRoles,
  useDynamicTeams,
  userLabel,
} from "../../features/users/i18n/userManagementLabels";

function trueKeys(value?: Record<string, boolean>) {
  if (!value) return [];

  return Object.entries(value)
    .filter(([, enabled]) => enabled)
    .map(([key]) => key);
}

function normalizeSearchTerm(value: string) {
  return value.trim().toLowerCase();
}

function hasSelectedKey(
  record: Record<string, boolean> | undefined,
  selectedKey: string
) {
  if (!selectedKey) return true;
  return Boolean(record?.[selectedKey]);
}

function matchesSearch(user: UserProfile, term: string) {
  const q = normalizeSearchTerm(term);
  if (!q) return true;

  const roleKeys = trueKeys(user.roles);
  const teamKeys = trueKeys(user.teams);
  const platformRoleKeys = trueKeys(user.platformRoles);

  const roleLabels = roleKeys.map((role) => translateRole(role));
  const teamLabels = teamKeys.map((team) => translateTeam(team));

  const searchableValues = [
    user.displayName,
    user.email,
    user.uid,
    user.siteId,
    ...roleKeys,
    ...teamKeys,
    ...platformRoleKeys,
    ...roleLabels,
    ...teamLabels,
  ];

  return searchableValues
    .filter(Boolean)
    .some((value) => String(value).toLowerCase().includes(q));
}

export function UsersListPage() {
  const { data = [], isLoading, error } = useUsers();
  const { profile } = useAuth();

  const [search, setSearch] = useState("");
  const [siteId, setSiteId] = useState("");
  const [activeMode, setActiveMode] = useState("ALL");
  const [roleFilter, setRoleFilter] = useState("");
  const [teamFilter, setTeamFilter] = useState("");
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [sitesFromDb, setSitesFromDb] = useState<string[]>([]);

  const configSiteId = siteId || "tpas_kardias";
  const roleOptions = useDynamicRoles(configSiteId);
  const teamOptions = useDynamicTeams(configSiteId);

  useEffect(() => {
    let mounted = true;

    async function loadSites() {
      try {
        const db = getDatabase();
        const snapshot = await get(ref(db, "sites"));

        if (!mounted) return;

        if (!snapshot.exists()) {
          setSitesFromDb([]);
          return;
        }

        const value = snapshot.val() as Record<
          string,
          { active?: boolean } | null
        >;

        const activeSites = Object.entries(value)
          .filter(([, site]) => site?.active !== false)
          .map(([id]) => id)
          .sort();

        setSitesFromDb(activeSites);
      } catch (err) {
        console.error("Failed to load sites for users page", err);
        setSitesFromDb([]);
      }
    }

    loadSites();

    return () => {
      mounted = false;
    };
  }, []);

  const sitesFromUsers = useMemo(() => {
    return [
      ...new Set(
        data.map((user: UserProfile) => user.siteId).filter(Boolean) as string[]
      ),
    ].sort();
  }, [data]);

  const availableSites = useMemo(() => {
    const merged = new Set<string>();

    sitesFromDb.forEach((site) => merged.add(site));
    sitesFromUsers.forEach((site) => merged.add(site));

    return Array.from(merged).sort();
  }, [sitesFromDb, sitesFromUsers]);

  const visibleUsers = useMemo(() => {
    return data.filter((user: UserProfile) => {
      const caps = resolveAdminCapabilities(profile, user);
      return caps.canViewUser;
    });
  }, [data, profile]);

  const filtered = useMemo(() => {
    return visibleUsers.filter((user: UserProfile) => {
      const searchOk = matchesSearch(user, search);
      const siteOk = !siteId || user.siteId === siteId;

      const activeOk =
        activeMode === "ALL"
          ? true
          : activeMode === "ACTIVE"
          ? user.active !== false
          : user.active === false;

      const roleOk = hasSelectedKey(user.roles, roleFilter);
      const teamOk = hasSelectedKey(user.teams, teamFilter);

      return searchOk && siteOk && activeOk && roleOk && teamOk;
    });
  }, [visibleUsers, search, siteId, activeMode, roleFilter, teamFilter]);

  const selectedUser = useMemo(
    () =>
      filtered.find((item: UserProfile) => item.uid === selectedUid) ??
      data.find((item: UserProfile) => item.uid === selectedUid) ??
      null,
    [filtered, data, selectedUid]
  );

  useEffect(() => {
    if (!selectedUid) return;

    const stillExists = data.some(
      (item: UserProfile) => item.uid === selectedUid
    );

    if (!stillExists) {
      setSelectedUid(null);
    }
  }, [data, selectedUid]);

  function clearFilters() {
    setSearch("");
    setSiteId("");
    setActiveMode("ALL");
    setRoleFilter("");
    setTeamFilter("");
  }

  if (isLoading) {
    return <div style={{ padding: 24 }}>{userLabel("loadingUsers")}</div>;
  }

  if (error) {
    return <div style={{ padding: 24 }}>{userLabel("loadingUsersError")}</div>;
  }

  return (
    <div style={{ padding: 24 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 16,
          alignItems: "flex-start",
          flexWrap: "wrap",
        }}
      >
        <div>
          <h1 style={{ marginBottom: 6 }}>{userLabel("pageTitle")}</h1>
          <div style={{ opacity: 0.72 }}>
            {userLabel("usersCount", filtered.length, visibleUsers.length)}
          </div>
        </div>

      </div>

      <UserCreatePanel currentUser={profile} availableSites={availableSites} />

      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 5,
          paddingTop: 12,
          paddingBottom: 12,
          background: "rgba(15,23,42,0.96)",
          backdropFilter: "blur(8px)",
        }}
      >
        <UsersFilters
          search={search}
          siteId={siteId}
          activeMode={activeMode}
          roleFilter={roleFilter}
          teamFilter={teamFilter}
          availableSites={availableSites}
          availableRoles={roleOptions}
          availableTeams={teamOptions}
          onSearchChange={setSearch}
          onSiteChange={setSiteId}
          onActiveModeChange={setActiveMode}
          onRoleFilterChange={setRoleFilter}
          onTeamFilterChange={setTeamFilter}
          onClearFilters={clearFilters}
        />
      </div>

      <UsersTable
        users={filtered}
        selectedUid={selectedUid}
        onSelect={setSelectedUid}
        compact
      />

      {selectedUser ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Στοιχεία Χρήστη"
          onClick={() => setSelectedUid(null)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            padding: "72px 24px 24px",
            background: "rgba(15,23,42,0.62)",
            backdropFilter: "blur(4px)",
            overflowY: "auto",
          }}
        >
          <div
            onClick={(event) => event.stopPropagation()}
            style={{
              width: "min(980px, 100%)",
              maxHeight: "calc(100vh - 96px)",
              overflowY: "auto",
              borderRadius: 18,
              boxShadow: "0 26px 80px rgba(0,0,0,0.35)",
            }}
          >
            <UserDetailDrawer
              user={selectedUser}
              availableSites={availableSites}
              onClose={() => setSelectedUid(null)}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}