import { useMemo, useState } from "react";
import { useSites } from "../../hooks/useSites";
import { useIncidentPolicies } from "../../hooks/useIncidentPolicies";
import { IncidentTypesGrid } from "../../features/incidentTypes/components/IncidentTypesGrid";

export function IncidentTypesListPage() {
  const { data: sites = [], isLoading: sitesLoading } = useSites();
  const [siteId, setSiteId] = useState("ilarionas");
  const [selectedKey, setSelectedKey] = useState<string | null>(null);

  const { data: items = [], isLoading, error } = useIncidentPolicies(siteId);

  const selectedSiteName = useMemo(() => {
    return sites.find((site) => site.id === siteId)?.name || siteId;
  }, [siteId, sites]);

  const activeCount = items.filter((item) => item.active).length;
  const verificationCount = items.filter((item) => Boolean(item.verification?.required ?? item.requiresVerification)).length;
  const dispatchCount = items.filter((item) => String(item.dispatch?.mode || item.postVerifyDispatchMode || "NONE") !== "NONE").length;
  const externalCount = items.filter((item) => Boolean(item.externalAuthorities?.enabled ?? item.externalEnabled)).length;

  if (sitesLoading) {
    return <div style={{ padding: 28 }}>Φόρτωση υπηρεσιακών μονάδων...</div>;
  }

  return (
    <div style={{ padding: 28 }}>
      <div className="page-header" style={{ marginBottom: 18 }}>
        <div>
          <h1>Τύποι Συμβάντων</h1>
          <p className="muted" style={{ margin: 0, maxWidth: 860 }}>
            Διαχείριση πολιτικών συμβάντων ανά υπηρεσιακή μονάδα: επιβεβαίωση, κινητοποίηση, ειδοποιήσεις,
            εξωτερικές αρχές και κανόνες κλεισίματος.
          </p>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(280px, 420px) 1fr",
          gap: 18,
          alignItems: "end",
          marginBottom: 18,
        }}
      >
        <label style={{ display: "block" }}>
          <div style={{ marginBottom: 8, fontWeight: 850, color: "var(--text-strong)" }}>Υπηρεσιακή Μονάδα</div>
          <select
            value={siteId}
            onChange={(e) => {
              setSiteId(e.target.value);
              setSelectedKey(null);
            }}
            style={{ width: "100%", minHeight: 44 }}
          >
            {sites.map((site) => (
              <option key={site.id} value={site.id}>
                {site.name} ({site.id})
              </option>
            ))}
          </select>
        </label>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, minmax(120px, 1fr))",
            gap: 12,
          }}
        >
          <SummaryCard label="Τύποι" value={items.length} />
          <SummaryCard label="Ενεργοί" value={activeCount} />
          <SummaryCard label="Με verification" value={verificationCount} />
          <SummaryCard label="Με dispatch" value={dispatchCount} />
        </div>
      </div>

      <div
        style={{
          border: "1px solid var(--border)",
          background: "var(--surface)",
          borderRadius: 20,
          padding: 18,
          boxShadow: "var(--shadow-soft)",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start" }}>
          <div>
            <h2 style={{ margin: 0, color: "var(--text-strong)" }}>Πολιτικές συμβάντων</h2>
            <p className="muted" style={{ margin: "6px 0 0" }}>
              Μονάδα: <strong style={{ color: "var(--text-strong)" }}>{selectedSiteName}</strong>
            </p>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <HeaderPill label={`${externalCount} με εξωτερικές αρχές`} />
            <HeaderPill label={selectedKey ? `Επιλεγμένο: ${selectedKey}` : "Δεν έχει επιλεγεί τύπος"} />
          </div>
        </div>

        {isLoading ? (
          <div style={{ marginTop: 20 }}>Φόρτωση τύπων συμβάντων...</div>
        ) : error ? (
          <div style={{ marginTop: 20, color: "var(--danger-strong)", fontWeight: 800 }}>
            Σφάλμα φόρτωσης τύπων συμβάντων.
          </div>
        ) : (
          <IncidentTypesGrid
            items={items}
            selectedKey={selectedKey}
            onSelect={setSelectedKey}
          />
        )}
      </div>
    </div>
  );
}

function SummaryCard({ label, value }: { label: string; value: number }) {
  return (
    <div
      style={{
        border: "1px solid var(--border)",
        background: "var(--surface)",
        borderRadius: 16,
        padding: 14,
        minHeight: 74,
        boxShadow: "var(--shadow-soft)",
      }}
    >
      <div style={{ fontSize: 12, color: "var(--muted-strong)", fontWeight: 800 }}>{label}</div>
      <div style={{ marginTop: 6, fontSize: 24, color: "var(--text-strong)", fontWeight: 950 }}>{value}</div>
    </div>
  );
}

function HeaderPill({ label }: { label: string }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        borderRadius: 999,
        padding: "7px 11px",
        border: "1px solid var(--border)",
        background: "var(--surface-2)",
        color: "var(--muted-strong)",
        fontSize: 12,
        fontWeight: 850,
      }}
    >
      {label}
    </span>
  );
}
