import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useSites } from "../../hooks/useSites";
import { useIncidentPolicy } from "../../hooks/useIncidentPolicy";
import { useExternalAuthorities } from "../../hooks/useExternalAuthorities";
import { PolicyEditor } from "../../features/incidentTypes/components/PolicyEditor";

export function IncidentTypeDetailPage() {
  const { category } = useParams<{ category: string }>();
  const { data: sites = [] } = useSites();

  const [siteId, setSiteId] = useState("ilarionas");

  const policyKey = useMemo(() => category || "", [category]);

  const { data, isLoading, error } = useIncidentPolicy(siteId, policyKey);
  const { data: authorities = [], isLoading: authoritiesLoading } =
    useExternalAuthorities(siteId);

  return (
    <div style={{ padding: 24 }}>
      <h1>Incident Type Detail</h1>

      {/* SELECTORS */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, minmax(0, 280px))",
          gap: 16,
          marginTop: 16,
          marginBottom: 20,
        }}
      >
        <label style={{ display: "block" }}>
          <div style={{ marginBottom: 6 }}>Site</div>
          <select
            value={siteId}
            onChange={(e) => setSiteId(e.target.value)}
            style={{ width: "100%", padding: 10, borderRadius: 10 }}
          >
            {sites.map((site) => (
              <option key={site.id} value={site.id}>
                {site.name} ({site.id})
              </option>
            ))}
          </select>
        </label>

        <div style={{ display: "block" }}>
          <div style={{ marginBottom: 6 }}>Policy Key</div>
          <div
            style={{
              width: "100%",
              padding: 10,
              borderRadius: 10,
              border: "1px solid rgba(255,255,255,0.12)",
              background: "rgba(255,255,255,0.03)",
              minHeight: 42,
              display: "flex",
              alignItems: "center",
            }}
          >
            {policyKey || "-"}
          </div>
        </div>
      </div>

      {/* POLICY EDITOR */}
      {isLoading ? (
        <div>Φόρτωση policy...</div>
      ) : error ? (
        <div>Σφάλμα φόρτωσης policy</div>
      ) : (
        <PolicyEditor siteId={siteId} value={data ?? null} />
      )}

      {/* EXTERNAL AUTHORITIES */}
      <div style={{ marginTop: 30 }}>
        <h2>External Authorities (Site Context)</h2>

        {authoritiesLoading ? (
          <p>Φόρτωση εξωτερικών αρχών...</p>
        ) : authorities.length === 0 ? (
          <p>Δεν υπάρχουν καταχωρημένες εξωτερικές αρχές για αυτό το site</p>
        ) : (
          <div style={{ marginTop: 10 }}>
            <ul style={{ paddingLeft: 16 }}>
              {authorities.map((item) => (
                <li key={item.id} style={{ marginBottom: 6 }}>
                  <strong>{item.name || item.id}</strong> |{" "}
                  {item.type || "-"} | {item.channel || "-"} |{" "}
                  {item.phone || "-"}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}