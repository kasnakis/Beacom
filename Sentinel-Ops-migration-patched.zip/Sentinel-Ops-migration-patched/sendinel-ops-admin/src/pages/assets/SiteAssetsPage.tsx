import { useEffect, useMemo, useRef, useState } from "react";
import { get, ref } from "firebase/database";
import { deleteObject, getDownloadURL, getStorage, ref as storageRef, uploadBytes } from "firebase/storage";
import L from "leaflet";
import type { LeafletMouseEvent } from "leaflet";
import { MapContainer, Marker, Popup, TileLayer, useMap, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { CSSProperties, MouseEvent, ReactNode } from "react";
import type {
  SiteAsset,
  SiteAssetCategory,
  SiteAssetInput,
  SiteAssetStatus,
} from "../../domain/models/siteAsset";
import {
  assetRequiresInspection,
  collectionKeyForCategory,
  labelForAssetCategory,
} from "../../domain/models/siteAsset";
import { useAuth } from "../../hooks/useAuth";
import { db } from "../../services/firebase/firebaseDb";
import { firebaseApp } from "../../services/firebase/firebaseApp";
import { useSites } from "../../hooks/useSites";
import {
  useDeleteSiteAsset,
  useImportSiteAssets,
  useSaveSiteAsset,
  useSiteAssets,
} from "../../hooks/useSiteAssets";

type AssetFormState = {
  id: string;
  category: SiteAssetCategory;
  name: string;
  type: string;
  status: SiteAssetStatus;
  latitude: string;
  longitude: string;
  building: string;
  floor: string;
  zone: string;
  description: string;
  serialNumber: string;
  manufacturer: string;
  model: string;
  inspectionRequired: boolean;
  inspectionFrequencyDays: string;
  lastInspectionAt: string;
  nextInspectionAt: string;
  inspectionNotes: string;
  photoUrl: string;
  photoPath: string;
  photoUpdatedAt: string;
};

type CategoryFilter = "ALL" | SiteAssetCategory;
type InspectionFilter = "ALL" | "DUE" | "MISSING" | "OK";

type SiteMapConfig = {
  centerLatitude: number;
  centerLongitude: number;
  defaultZoom: number;
  enabled: boolean;
};

type MapProvider = "OPENMAP" | "ESRI";

const MAP_PROVIDERS: Record<MapProvider, { label: string; url: string; attribution: string; maxZoom: number }> = {
  OPENMAP: {
    label: "OpenMap",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
  },
  ESRI: {
    label: "Esri",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Tiles &copy; Esri",
    maxZoom: 19,
  },
};

const storage = getStorage(firebaseApp);

const FALLBACK_MAP_CONFIG: SiteMapConfig = {
  centerLatitude: 40.4868,
  centerLongitude: 21.7326,
  defaultZoom: 17,
  enabled: true,
};

const CATEGORY_OPTIONS: { value: SiteAssetCategory; label: string; shortLabel: string }[] = [
  { value: "AED", label: "Απινιδωτές", shortLabel: "AED" },
  { value: "FIRE_ASSET", label: "Πυροσβεστικά μέσα", shortLabel: "Πυρόσβεση" },
  { value: "ASSEMBLY_POINT", label: "Χώροι συγκέντρωσης", shortLabel: "Συγκέντρωση" },
];

const STATUS_OPTIONS: { value: SiteAssetStatus; label: string }[] = [
  { value: "ACTIVE", label: "Ενεργό" },
  { value: "INACTIVE", label: "Ανενεργό" },
  { value: "OUT_OF_SERVICE", label: "Εκτός λειτουργίας" },
];

const TYPE_OPTIONS: Record<SiteAssetCategory, { value: string; label: string }[]> = {
  AED: [
    { value: "AED_FIXED", label: "Σταθερός απινιδωτής" },
    { value: "AED_PORTABLE", label: "Φορητός απινιδωτής" },
    { value: "AED_OTHER", label: "Άλλος απινιδωτής" },
  ],
  FIRE_ASSET: [
    { value: "EXTINGUISHER", label: "Πυροσβεστήρας" },
    { value: "HYDRANT", label: "Κρουνός" },
    { value: "HOSE", label: "Μάνικα / αγωγός νερού" },
    { value: "TRUCK", label: "Πυροσβεστικό όχημα" },
    { value: "OTHER", label: "Άλλο μέσο πυρόσβεσης" },
  ],
  ASSEMBLY_POINT: [{ value: "ASSEMBLY_POINT", label: "Χώρος συγκέντρωσης" }],
};

function emptyForm(category: SiteAssetCategory = "AED"): AssetFormState {
  return {
    id: "",
    category,
    name: "",
    type: category === "ASSEMBLY_POINT" ? "ASSEMBLY_POINT" : "",
    status: "ACTIVE",
    latitude: "",
    longitude: "",
    building: "",
    floor: "",
    zone: "",
    description: "",
    serialNumber: "",
    manufacturer: "",
    model: "",
    inspectionRequired: category !== "ASSEMBLY_POINT",
    inspectionFrequencyDays: "",
    lastInspectionAt: "",
    nextInspectionAt: "",
    inspectionNotes: "",
    photoUrl: "",
    photoPath: "",
    photoUpdatedAt: "",
  };
}

function dateInputToMillis(value: string): number | null {
  if (!value) return null;
  const millis = new Date(`${value}T00:00:00`).getTime();
  return Number.isFinite(millis) ? millis : null;
}

function millisToDateInput(value?: number | null): string {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString().slice(0, 10);
}

function formatDate(value?: number | null): string {
  const input = millisToDateInput(value);
  if (!input) return "Δεν έχει οριστεί";
  const [year, month, day] = input.split("-");
  return `${day}/${month}/${year}`;
}

function formFromAsset(asset: SiteAsset): AssetFormState {
  return {
    id: asset.id,
    category: asset.category,
    name: asset.name || asset.title || "",
    type: asset.type || "",
    status: (asset.status as SiteAssetStatus) || "ACTIVE",
    latitude: asset.latitude != null ? String(asset.latitude) : "",
    longitude: asset.longitude != null ? String(asset.longitude) : "",
    building: asset.building || "",
    floor: asset.floor || "",
    zone: asset.zone || "",
    description: asset.description || asset.locationNotes || "",
    serialNumber: asset.serialNumber || "",
    manufacturer: asset.manufacturer || "",
    model: asset.model || "",
    inspectionRequired: asset.inspection?.required !== false && assetRequiresInspection(asset.category),
    inspectionFrequencyDays:
      asset.inspection?.frequencyDays != null ? String(asset.inspection.frequencyDays) : "",
    lastInspectionAt: millisToDateInput(asset.inspection?.lastInspectionAt),
    nextInspectionAt: millisToDateInput(asset.inspection?.nextInspectionAt),
    inspectionNotes: asset.inspection?.notes || "",
    photoUrl: asset.photoUrl || "",
    photoPath: asset.photoPath || "",
    photoUpdatedAt: asset.photoUpdatedAt != null ? String(asset.photoUpdatedAt) : "",
  };
}

function assetInputFromForm(siteId: string, form: AssetFormState): SiteAssetInput {
  const category = form.category;
  const input: SiteAssetInput = {
    id: form.id.trim(),
    siteId,
    category,
    collectionKey: collectionKeyForCategory(category),
    name: form.name.trim(),
    title: form.name.trim(),
    type: form.type.trim(),
    status: form.status,
    active: form.status === "ACTIVE",
    latitude: form.latitude.trim() === "" ? null : Number(form.latitude),
    longitude: form.longitude.trim() === "" ? null : Number(form.longitude),
    building: form.building.trim(),
    floor: form.floor.trim(),
    zone: form.zone.trim(),
    description: form.description.trim(),
    locationNotes: form.description.trim(),
    serialNumber: form.serialNumber.trim(),
    manufacturer: form.manufacturer.trim(),
    model: form.model.trim(),
    photoUrl: form.photoUrl.trim(),
    photoPath: form.photoPath.trim(),
    photoUpdatedAt: form.photoUpdatedAt ? Number(form.photoUpdatedAt) : null,
  };

  // Inspection data is stored only for AED and fire assets. Firebase RTDB rejects
  // `undefined` values, so assembly points must not carry an `inspection` property.
  if (assetRequiresInspection(category)) {
    input.inspection = {
      required: form.inspectionRequired,
      frequencyDays: form.inspectionFrequencyDays ? Number(form.inspectionFrequencyDays) : null,
      lastInspectionAt: dateInputToMillis(form.lastInspectionAt),
      nextInspectionAt: dateInputToMillis(form.nextInspectionAt),
      notes: form.inspectionNotes.trim(),
    };
  }

  return input;
}

function truePermission(record: Record<string, boolean> | undefined, key: string) {
  return Boolean(record?.[key]);
}

function canManageAssetsForSite(profile: ReturnType<typeof useAuth>["profile"], siteId: string) {
  const adminLevel = profile?.adminPermissions?.level;
  if (adminLevel === "GLOBAL_ADMIN") return true;

  const sameTopLevelSite = profile?.siteId && profile.siteId === siteId;
  if (adminLevel === "SITE_ADMIN" && sameTopLevelSite) return true;

  const membership = profile?.siteMemberships?.[siteId];
  const permissions = membership?.permissions;

  return (
    truePermission(permissions, "SITE_ASSET_MANAGER") ||
    truePermission(permissions, "MANAGE_AED") ||
    truePermission(permissions, "MANAGE_FIRE_ASSETS") ||
    truePermission(permissions, "MANAGE_ASSEMBLY_POINTS")
  );
}

function canManageCategory(
  profile: ReturnType<typeof useAuth>["profile"],
  siteId: string,
  category: SiteAssetCategory
) {
  const adminLevel = profile?.adminPermissions?.level;
  if (adminLevel === "GLOBAL_ADMIN") return true;
  if (adminLevel === "SITE_ADMIN" && profile?.siteId === siteId) return true;

  const permissions = profile?.siteMemberships?.[siteId]?.permissions;
  if (permissions?.SITE_ASSET_MANAGER) return true;
  if (category === "AED") return Boolean(permissions?.MANAGE_AED);
  if (category === "FIRE_ASSET") return Boolean(permissions?.MANAGE_FIRE_ASSETS);
  return Boolean(permissions?.MANAGE_ASSEMBLY_POINTS);
}

function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let quoted = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    const next = line[i + 1];

    if (char === '"' && quoted && next === '"') {
      current += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }

  result.push(current.trim());
  return result;
}

function csvEscape(value: unknown): string {
  const text = String(value ?? "");
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function downloadCsv(filename: string, rows: SiteAsset[]) {
  const headers = [
    "id",
    "category",
    "name",
    "type",
    "status",
    "latitude",
    "longitude",
    "building",
    "floor",
    "zone",
    "description",
    "serialNumber",
    "manufacturer",
    "model",
    "inspectionRequired",
    "inspectionFrequencyDays",
    "lastInspectionDate",
    "nextInspectionDate",
    "inspectionNotes",
    "photoUrl",
    "photoPath",
  ];

  const lines = [
    headers.join(","),
    ...rows.map((asset) =>
      [
        asset.id,
        asset.category,
        asset.name,
        asset.type,
        asset.status,
        asset.latitude,
        asset.longitude,
        asset.building,
        asset.floor,
        asset.zone,
        asset.description || asset.locationNotes,
        asset.serialNumber,
        asset.manufacturer,
        asset.model,
        asset.inspection?.required === false ? "false" : assetRequiresInspection(asset.category) ? "true" : "",
        asset.inspection?.frequencyDays ?? "",
        millisToDateInput(asset.inspection?.lastInspectionAt),
        millisToDateInput(asset.inspection?.nextInspectionAt),
        asset.inspection?.notes || "",
        asset.photoUrl || "",
        asset.photoPath || "",
      ]
        .map(csvEscape)
        .join(",")
    ),
  ];

  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

async function uploadSiteAssetPhoto(siteId: string, assetId: string, file: File) {
  const path = `site_assets/${siteId}/${assetId}/main.jpg`;
  const imageRef = storageRef(storage, path);
  await uploadBytes(imageRef, file, {
    contentType: file.type || "image/jpeg",
    cacheControl: "public,max-age=3600",
  });
  const url = await getDownloadURL(imageRef);
  return { photoUrl: url, photoPath: path, photoUpdatedAt: Date.now() };
}

async function deleteSiteAssetPhoto(path: string) {
  if (!path) return;
  try {
    await deleteObject(storageRef(storage, path));
  } catch (error) {
    console.warn("Could not delete site asset photo", error);
  }
}

function isImageFile(file: File): boolean {
  return file.type.startsWith("image/") && file.size <= 10 * 1024 * 1024;
}

function parseAssetCsv(siteId: string, text: string): SiteAssetInput[] {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]).map((item) => item.trim());
  const indexOf = (key: string) => headers.findIndex((header) => header === key);

  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    const getValue = (key: string) => {
      const index = indexOf(key);
      return index >= 0 ? values[index] || "" : "";
    };

    const category = (getValue("category") || "AED") as SiteAssetCategory;
    const form: AssetFormState = {
      ...emptyForm(category),
      id: getValue("id"),
      category,
      name: getValue("name") || getValue("title"),
      type: getValue("type"),
      status: (getValue("status") || "ACTIVE") as SiteAssetStatus,
      latitude: getValue("latitude"),
      longitude: getValue("longitude"),
      building: getValue("building"),
      floor: getValue("floor"),
      zone: getValue("zone"),
      description: getValue("description"),
      serialNumber: getValue("serialNumber"),
      manufacturer: getValue("manufacturer"),
      model: getValue("model"),
      inspectionRequired: getValue("inspectionRequired") !== "false",
      inspectionFrequencyDays: getValue("inspectionFrequencyDays"),
      lastInspectionAt: getValue("lastInspectionDate"),
      nextInspectionAt: getValue("nextInspectionDate"),
      inspectionNotes: getValue("inspectionNotes"),
      photoUrl: getValue("photoUrl"),
      photoPath: getValue("photoPath"),
      photoUpdatedAt: "",
    };

    return assetInputFromForm(siteId, form);
  });
}

function isPlaceholderAsset(asset: SiteAsset): boolean {
  return asset.id === "_placeholder" || asset.name === "_placeholder" || asset.title === "_placeholder";
}

function isInspectionDue(asset: SiteAsset): boolean {
  if (!assetRequiresInspection(asset.category)) return false;
  const nextInspectionAt = asset.inspection?.nextInspectionAt;
  return !nextInspectionAt || nextInspectionAt < Date.now();
}

function isInspectionMissing(asset: SiteAsset): boolean {
  if (!assetRequiresInspection(asset.category)) return false;
  return !asset.inspection?.nextInspectionAt;
}

function typeLabel(category: SiteAssetCategory, value?: string) {
  if (!value) return "-";
  return TYPE_OPTIONS[category].find((option) => option.value === value)?.label || value;
}

function statusLabel(value?: string) {
  return STATUS_OPTIONS.find((option) => option.value === value)?.label || value || "Ενεργό";
}

function statusTone(value?: string): "success" | "warning" | "danger" | "info" {
  if (value === "ACTIVE") return "success";
  if (value === "OUT_OF_SERVICE") return "danger";
  if (value === "INACTIVE") return "warning";
  return "info";
}

function pageStyle(): CSSProperties {
  return {
    display: "grid",
    gap: 18,
    maxWidth: 1480,
    margin: "0 auto",
    padding: "8px 4px 28px",
  };
}

function cardStyle(extra?: CSSProperties): CSSProperties {
  return {
    border: "1px solid var(--border)",
    borderRadius: 18,
    background: "var(--surface)",
    boxShadow: "var(--shadow-soft)",
    ...extra,
  };
}

function fieldStyle(extra?: CSSProperties): CSSProperties {
  return {
    width: "100%",
    boxSizing: "border-box",
    ...extra,
  };
}

function labelStyle(): CSSProperties {
  return {
    display: "grid",
    gap: 7,
    fontSize: 13,
    color: "var(--muted-strong)",
    fontWeight: 700,
  };
}

function sectionTitleStyle(): CSSProperties {
  return {
    margin: "0 0 12px",
    fontSize: 15,
    color: "var(--text-strong)",
    fontWeight: 800,
  };
}

function SmallButton({
  children,
  onClick,
  disabled = false,
  variant = "secondary",
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
  variant?: "primary" | "secondary" | "danger";
}) {
  const isPrimary = variant === "primary";
  const isDanger = variant === "danger";
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={isPrimary ? undefined : "secondary-button"}
      style={{
        padding: "9px 12px",
        borderRadius: 12,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.55 : 1,
        background: isDanger ? "var(--danger-soft)" : undefined,
        borderColor: isDanger ? "var(--danger)" : undefined,
        color: isDanger ? "var(--danger-strong)" : undefined,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </button>
  );
}

function Badge({ children, tone = "info" }: { children: ReactNode; tone?: "success" | "warning" | "danger" | "info" }) {
  return <span className={`badge-soft ${tone}`}>{children}</span>;
}

function toFixedCoordinate(value: unknown): string {
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return "";
  return numberValue.toFixed(7).replace(/0+$/, "").replace(/\.$/, "");
}

function siteAssetMarkerIcon() {
  return L.divIcon({
    className: "",
    html: `
      <div style="
        width:24px;
        height:24px;
        border-radius:50% 50% 50% 0;
        transform:rotate(-45deg);
        background:#2563eb;
        border:3px solid #fff;
        box-shadow:0 8px 22px rgba(15,23,42,0.35);
      ">
        <div style="
          width:8px;
          height:8px;
          border-radius:999px;
          background:#fff;
          position:absolute;
          left:5px;
          top:5px;
        "></div>
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
  });
}

function MapAutoCenter({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();

  useEffect(() => {
    map.setView(center, zoom, { animate: false });
    window.setTimeout(() => map.invalidateSize(), 120);
  }, [center[0], center[1], zoom, map]);

  return null;
}

function MapInvalidateSize() {
  const map = useMap();

  useEffect(() => {
    const timers = [
      window.setTimeout(() => map.invalidateSize(), 80),
      window.setTimeout(() => map.invalidateSize(), 260),
    ];

    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [map]);

  return null;
}

function LocationPickerEvents({ onPick }: { onPick: (lat: number, lon: number) => void }) {
  useMapEvents({
    click(event: LeafletMouseEvent) {
      onPick(event.latlng.lat, event.latlng.lng);
    },
  });

  return null;
}

function MiniLocationMap({
  latitude,
  longitude,
  siteMapConfig,
  mapProvider,
  onMapProviderChange,
  onPick,
}: {
  latitude: string;
  longitude: string;
  siteMapConfig: SiteMapConfig;
  mapProvider: MapProvider;
  onMapProviderChange: (provider: MapProvider) => void;
  onPick: (lat: number, lon: number) => void;
}) {
  const parsedLat = Number(latitude);
  const parsedLon = Number(longitude);
  const hasAssetPoint = Number.isFinite(parsedLat) && Number.isFinite(parsedLon);
  const tileLayer = MAP_PROVIDERS[mapProvider];
  const zoom = Math.max(1, Math.min(tileLayer.maxZoom, Math.round(siteMapConfig.defaultZoom || 17)));
  const center: [number, number] = [siteMapConfig.centerLatitude, siteMapConfig.centerLongitude];
  const markerPosition: [number, number] | null = hasAssetPoint ? [parsedLat, parsedLon] : null;

  return (
    <div style={{ display: "grid", gap: 8 }}>
      <div
        style={{
          height: 330,
          overflow: "hidden",
          borderRadius: 16,
          border: "1px solid var(--border)",
          background: "var(--surface-muted)",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            right: 12,
            top: 12,
            zIndex: 520,
            display: "flex",
            gap: 6,
            padding: 4,
            borderRadius: 999,
            background: "rgba(255,255,255,0.92)",
            border: "1px solid rgba(148, 163, 184, 0.45)",
            boxShadow: "0 8px 18px rgba(15,23,42,0.18)",
          }}
        >
          {(Object.keys(MAP_PROVIDERS) as MapProvider[]).map((provider) => (
            <button
              key={provider}
              type="button"
              onClick={() => onMapProviderChange(provider)}
              style={{
                border: "none",
                borderRadius: 999,
                padding: "6px 10px",
                fontSize: 12,
                fontWeight: 800,
                cursor: "pointer",
                color: mapProvider === provider ? "#ffffff" : "#0f172a",
                background: mapProvider === provider ? "#2563eb" : "transparent",
              }}
            >
              {MAP_PROVIDERS[provider].label}
            </button>
          ))}
        </div>

        <MapContainer
          key={`${siteMapConfig.centerLatitude}-${siteMapConfig.centerLongitude}-${zoom}-${mapProvider}`}
          center={center}
          zoom={zoom}
          minZoom={1}
          maxZoom={19}
          style={{ height: "100%", width: "100%", zIndex: 1 }}
          scrollWheelZoom={true}
          doubleClickZoom={true}
          dragging={true}
          zoomControl={true}
        >
          <MapInvalidateSize />
          <MapAutoCenter center={center} zoom={zoom} />
          <TileLayer
            attribution={tileLayer.attribution}
            url={tileLayer.url}
            maxZoom={tileLayer.maxZoom}
          />
          <LocationPickerEvents onPick={onPick} />

          {markerPosition ? (
            <Marker position={markerPosition} icon={siteAssetMarkerIcon()}>
              <Popup>
                <strong>Επιλεγμένο σημείο</strong>
                <div>Latitude: {toFixedCoordinate(markerPosition[0])}</div>
                <div>Longitude: {toFixedCoordinate(markerPosition[1])}</div>
              </Popup>
            </Marker>
          ) : null}
        </MapContainer>

        <div
          style={{
            position: "absolute",
            left: 12,
            bottom: 10,
            zIndex: 500,
            padding: "6px 9px",
            borderRadius: 999,
            background: "rgba(15, 23, 42, 0.72)",
            color: "white",
            fontSize: 12,
            pointerEvents: "none",
          }}
        >
          Κλικ στον χάρτη για Latitude / Longitude
        </div>
      </div>

      <div className="muted" style={{ fontSize: 12 }}>
        Κέντρο χάρτη: {toFixedCoordinate(siteMapConfig.centerLatitude)}, {toFixedCoordinate(siteMapConfig.centerLongitude)} · Zoom {zoom} · Υπόβαθρο {tileLayer.label}
      </div>
    </div>
  );
}

function StatCard({ label, value, helper }: { label: string; value: number | string; helper: string }) {
  return (
    <div style={cardStyle({ padding: 16 })}>
      <div className="metric-label">{label}</div>
      <div className="metric-value" style={{ fontSize: 30 }}>{value}</div>
      <div className="muted" style={{ fontSize: 13 }}>{helper}</div>
    </div>
  );
}

export function SiteAssetsPage() {
  const { profile } = useAuth();
  const { data: sites = [], isLoading: sitesLoading } = useSites();
  const [siteId, setSiteId] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("ALL");
  const [statusFilter, setStatusFilter] = useState<"ALL" | SiteAssetStatus>("ALL");
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [inspectionFilter, setInspectionFilter] = useState<InspectionFilter>("ALL");
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<AssetFormState>(emptyForm());
  const [editingAssetId, setEditingAssetId] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedPhotoFile, setSelectedPhotoFile] = useState<File | null>(null);
  const [selectedPhotoPreview, setSelectedPhotoPreview] = useState<string>("");
  const [removeExistingPhoto, setRemoveExistingPhoto] = useState(false);
  const [siteMapConfig, setSiteMapConfig] = useState<SiteMapConfig>(FALLBACK_MAP_CONFIG);
  const [mapProvider, setMapProvider] = useState<MapProvider>(() => {
    const stored = window.localStorage.getItem("siteAssetsMapProvider");
    return stored === "ESRI" ? "ESRI" : "OPENMAP";
  });

  const effectiveSiteId = siteId || profile?.siteId || sites[0]?.id || "";
  const assetsQuery = useSiteAssets(effectiveSiteId);
  const showAssetsLoading = Boolean(effectiveSiteId) && assetsQuery.isLoading;
  const saveMutation = useSaveSiteAsset(effectiveSiteId);
  const deleteMutation = useDeleteSiteAsset(effectiveSiteId);
  const importMutation = useImportSiteAssets(effectiveSiteId);

  useEffect(() => {
    if (!siteId && profile?.siteId) setSiteId(profile.siteId);
  }, [profile?.siteId, siteId]);

  useEffect(() => {
    let cancelled = false;

    async function loadSiteMapConfig() {
      if (!effectiveSiteId) {
        setSiteMapConfig(FALLBACK_MAP_CONFIG);
        return;
      }

      try {
        const snapshot = await get(ref(db, `site_config_data/${effectiveSiteId}/map`));
        const value = snapshot.exists() ? snapshot.val() : null;
        const centerLatitude = Number(value?.centerLatitude);
        const centerLongitude = Number(value?.centerLongitude);
        const defaultZoom = Number(value?.defaultZoom);

        if (!cancelled && Number.isFinite(centerLatitude) && Number.isFinite(centerLongitude)) {
          setSiteMapConfig({
            centerLatitude,
            centerLongitude,
            defaultZoom: Number.isFinite(defaultZoom) ? defaultZoom : FALLBACK_MAP_CONFIG.defaultZoom,
            enabled: value?.enabled !== false,
          });
        } else if (!cancelled) {
          setSiteMapConfig(FALLBACK_MAP_CONFIG);
        }
      } catch {
        if (!cancelled) setSiteMapConfig(FALLBACK_MAP_CONFIG);
      }
    }

    loadSiteMapConfig();

    return () => {
      cancelled = true;
    };
  }, [effectiveSiteId]);

  const changeMapProvider = (provider: MapProvider) => {
    setMapProvider(provider);
    window.localStorage.setItem("siteAssetsMapProvider", provider);
  };

  const canManageAny = canManageAssetsForSite(profile, effectiveSiteId);
  const canManageCurrentCategory = canManageCategory(profile, effectiveSiteId, form.category);

  const allAssets = useMemo(
    () => (assetsQuery.data || []).filter((asset) => !isPlaceholderAsset(asset)),
    [assetsQuery.data]
  );

  const availableTypes = useMemo(() => {
    const categories = categoryFilter === "ALL" ? CATEGORY_OPTIONS.map((item) => item.value) : [categoryFilter];
    return categories.flatMap((category) => TYPE_OPTIONS[category]);
  }, [categoryFilter]);

  const filteredAssets = useMemo(() => {
    const q = search.trim().toLowerCase();

    return allAssets.filter((asset) => {
      const categoryOk = categoryFilter === "ALL" || asset.category === categoryFilter;
      const statusOk = statusFilter === "ALL" || asset.status === statusFilter;
      const typeOk = typeFilter === "ALL" || asset.type === typeFilter;
      const inspectionOk =
        inspectionFilter === "ALL" ||
        (inspectionFilter === "DUE" && isInspectionDue(asset)) ||
        (inspectionFilter === "MISSING" && isInspectionMissing(asset)) ||
        (inspectionFilter === "OK" && assetRequiresInspection(asset.category) && !isInspectionDue(asset));
      const searchOk = !q
        ? true
        : [
            asset.id,
            asset.name,
            asset.title,
            asset.type,
            asset.status,
            asset.building,
            asset.floor,
            asset.zone,
            asset.serialNumber,
            asset.manufacturer,
            asset.model,
          ]
            .filter(Boolean)
            .some((value) => String(value).toLowerCase().includes(q));

      return categoryOk && statusOk && typeOk && inspectionOk && searchOk;
    });
  }, [allAssets, categoryFilter, inspectionFilter, search, statusFilter, typeFilter]);

  const stats = useMemo(() => {
    const count = (category: SiteAssetCategory) => allAssets.filter((asset) => asset.category === category).length;
    return {
      aed: count("AED"),
      fire: count("FIRE_ASSET"),
      assembly: count("ASSEMBLY_POINT"),
      inspectionDue: allAssets.filter(isInspectionDue).length,
    };
  }, [allAssets]);

  function resetForm(category = form.category) {
    setEditingAssetId(null);
    setSelectedPhotoFile(null);
    setSelectedPhotoPreview("");
    setRemoveExistingPhoto(false);
    setForm(emptyForm(category));
  }

  function openNewAsset(category: SiteAssetCategory = categoryFilter === "ALL" ? "AED" : categoryFilter) {
    setFeedback(null);
    setEditingAssetId(null);
    setSelectedPhotoFile(null);
    setSelectedPhotoPreview("");
    setRemoveExistingPhoto(false);
    setForm(emptyForm(category));
    setDrawerOpen(true);
  }

  function editAsset(asset: SiteAsset) {
    setFeedback(null);
    setEditingAssetId(asset.id);
    setSelectedPhotoFile(null);
    setSelectedPhotoPreview("");
    setRemoveExistingPhoto(false);
    setForm(formFromAsset(asset));
    setDrawerOpen(true);
  }

  function fillCurrentBrowserLocation() {
    if (!navigator.geolocation) {
      window.alert("Ο browser δεν υποστηρίζει ανάγνωση τοποθεσίας.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setForm((prev) => ({
          ...prev,
          latitude: toFixedCoordinate(position.coords.latitude),
          longitude: toFixedCoordinate(position.coords.longitude),
        }));
      },
      () => window.alert("Δεν ήταν δυνατή η ανάγνωση της τρέχουσας θέσης."),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  function pickMapPoint(latitude: number, longitude: number) {
    setForm((prev) => ({
      ...prev,
      latitude: toFixedCoordinate(latitude),
      longitude: toFixedCoordinate(longitude),
    }));
  }

  function handlePhotoFile(file: File | null) {
    if (!file) return;
    if (!isImageFile(file)) {
      window.alert("Επιλέξτε εικόνα έως 10MB.");
      return;
    }
    setSelectedPhotoFile(file);
    setRemoveExistingPhoto(false);
    setSelectedPhotoPreview(URL.createObjectURL(file));
  }

  async function removePhoto() {
    setSelectedPhotoFile(null);
    setSelectedPhotoPreview("");
    setRemoveExistingPhoto(true);
    setForm((prev) => ({ ...prev, photoUrl: "", photoPath: "", photoUpdatedAt: "" }));
  }

  async function saveAsset() {
    if (!effectiveSiteId || !canManageCurrentCategory) return;
    setFeedback(null);

    let nextForm = { ...form };
    const assetId = nextForm.id.trim();

    if ((selectedPhotoFile || removeExistingPhoto) && !assetId) {
      window.alert("Για upload φωτογραφίας πρέπει πρώτα να συμπληρωθεί το ID του μέσου.");
      return;
    }

    if (selectedPhotoFile && assetId) {
      const uploaded = await uploadSiteAssetPhoto(effectiveSiteId, assetId, selectedPhotoFile);
      nextForm = {
        ...nextForm,
        photoUrl: uploaded.photoUrl,
        photoPath: uploaded.photoPath,
        photoUpdatedAt: String(uploaded.photoUpdatedAt),
      };
    } else if (removeExistingPhoto && form.photoPath) {
      await deleteSiteAssetPhoto(form.photoPath);
      nextForm = { ...nextForm, photoUrl: "", photoPath: "", photoUpdatedAt: "" };
    }

    await saveMutation.mutateAsync(assetInputFromForm(effectiveSiteId, nextForm));
    setFeedback("Η καταχώρηση αποθηκεύτηκε.");
    setDrawerOpen(false);
    resetForm(nextForm.category);
  }

  async function deleteAsset(asset: SiteAsset) {
    if (!canManageCategory(profile, effectiveSiteId, asset.category)) return;
    const ok = window.confirm(`Να διαγραφεί το '${asset.name}' από το site;`);
    if (!ok) return;
    setFeedback(null);
    await deleteMutation.mutateAsync({ category: asset.category, id: asset.id });
    setFeedback("Η καταχώρηση διαγράφηκε.");
  }

  async function handleImport(file: File) {
    const text = await file.text();
    const importedAssets = parseAssetCsv(effectiveSiteId, text);
    if (!importedAssets.length) {
      window.alert("Δεν βρέθηκαν εγγραφές στο CSV.");
      return;
    }
    setFeedback(null);
    await importMutation.mutateAsync(importedAssets);
    setFeedback(`Ολοκληρώθηκε import ${importedAssets.length} εγγραφών.`);
  }

  return (
    <div style={pageStyle()}>
      <div className="page-header" style={{ marginBottom: 0 }}>
        <div>
          <h1>Μέσα Site</h1>
          <div className="muted">
            Διαχείριση απινιδωτών, πυροσβεστικών μέσων και χώρων συγκέντρωσης ανά εγκατάσταση.
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <SmallButton
            onClick={() => downloadCsv(`site_assets_${effectiveSiteId || "export"}.csv`, filteredAssets)}
          >
            Export CSV
          </SmallButton>
          <SmallButton onClick={() => fileInputRef.current?.click()} disabled={!canManageAny}>
            Import CSV
          </SmallButton>
          <SmallButton onClick={() => openNewAsset()} disabled={!canManageAny} variant="primary">
            Νέο μέσο
          </SmallButton>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            style={{ display: "none" }}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleImport(file);
              e.currentTarget.value = "";
            }}
          />
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 14 }}>
        <StatCard label="Απινιδωτές" value={stats.aed} helper="AED ενεργά ή καταχωρημένα" />
        <StatCard label="Πυροσβεστικά μέσα" value={stats.fire} helper="Πυροσβεστήρες, κρουνοί, μάνικες" />
        <StatCard label="Χώροι συγκέντρωσης" value={stats.assembly} helper="Σημεία συγκέντρωσης προσωπικού" />
        <StatCard label="Εκκρεμείς επιθεωρήσεις" value={stats.inspectionDue} helper="AED και πυροσβεστικά μέσα" />
      </div>

      <div style={cardStyle({ padding: 16 })}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(220px, 1.1fr) minmax(220px, 1.5fr) 1fr 1fr", gap: 12 }}>
          <label style={labelStyle()}>
            Site
            <select value={effectiveSiteId} onChange={(e) => setSiteId(e.target.value)} style={fieldStyle()}>
              {sites.map((site) => (
                <option key={site.id} value={site.id}>
                  {site.name || site.id}
                </option>
              ))}
            </select>
          </label>

          <label style={labelStyle()}>
            Αναζήτηση
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Όνομα, τύπος, κτίριο, serial..."
              style={fieldStyle()}
            />
          </label>

          <label style={labelStyle()}>
            Status
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as "ALL" | SiteAssetStatus)} style={fieldStyle()}>
              <option value="ALL">Όλα</option>
              {STATUS_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>

          <label style={labelStyle()}>
            Επιθεώρηση
            <select value={inspectionFilter} onChange={(e) => setInspectionFilter(e.target.value as InspectionFilter)} style={fieldStyle()}>
              <option value="ALL">Όλες</option>
              <option value="DUE">Εκκρεμεί / ληγμένη</option>
              <option value="MISSING">Δεν έχει οριστεί</option>
              <option value="OK">Εντός προγράμματος</option>
            </select>
          </label>
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginTop: 14, flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <SmallButton onClick={() => setCategoryFilter("ALL")} variant={categoryFilter === "ALL" ? "primary" : "secondary"}>
              Όλα ({allAssets.length})
            </SmallButton>
            {CATEGORY_OPTIONS.map((option) => (
              <SmallButton
                key={option.value}
                onClick={() => {
                  setCategoryFilter(option.value);
                  setTypeFilter("ALL");
                }}
                variant={categoryFilter === option.value ? "primary" : "secondary"}
              >
                {option.label} ({allAssets.filter((asset) => asset.category === option.value).length})
              </SmallButton>
            ))}
          </div>

          <label style={{ ...labelStyle(), minWidth: 220 }}>
            Τύπος
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} style={fieldStyle()}>
              <option value="ALL">Όλοι οι τύποι</option>
              {availableTypes.map((option) => (
                <option key={`${option.value}-${option.label}`} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {!canManageAny ? (
        <div style={cardStyle({ padding: 14, borderColor: "var(--warning)", background: "var(--warning-soft)" })}>
          <strong>Μόνο προβολή.</strong> Για καταχώρηση, επεξεργασία ή διαγραφή χρειάζεται ανάθεση δικαιωμάτων μέσων στο site.
        </div>
      ) : null}

      {feedback ? (
        <div style={cardStyle({ padding: 14, borderColor: "var(--success)", background: "var(--success-soft)", color: "var(--success-strong)" })}>
          {feedback}
        </div>
      ) : null}

      {(saveMutation.isError || importMutation.isError || deleteMutation.isError) ? (
        <div style={cardStyle({ padding: 14, borderColor: "var(--danger)", background: "var(--danger-soft)", color: "var(--danger-strong)" })}>
          Σφάλμα: {String(saveMutation.error || importMutation.error || deleteMutation.error)}
        </div>
      ) : null}

      <div style={cardStyle({ overflow: "hidden" })}>
        <div style={{ padding: "18px 20px", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", borderBottom: "1px solid var(--border)", flexWrap: "wrap" }}>
          <div>
            <h2 style={{ margin: 0 }}>Καταχωρημένα μέσα</h2>
            <div className="muted" style={{ fontSize: 13 }}>
              {filteredAssets.length} εγγραφές στα τρέχοντα φίλτρα
            </div>
          </div>
          <SmallButton onClick={() => assetsQuery.refetch()}>Ανανέωση</SmallButton>
        </div>

        {showAssetsLoading ? <div style={{ padding: 20 }}>Φόρτωση...</div> : null}
        {!effectiveSiteId && !sitesLoading ? (
          <div style={{ padding: 20, color: "var(--warning-strong)" }}>
            Δεν έχει επιλεγεί site. Ελέγξτε ότι υπάρχει διαθέσιμο site στον λογαριασμό ή επιλέξτε site από τα φίλτρα.
          </div>
        ) : null}
        {assetsQuery.isError ? <div style={{ padding: 20, color: "var(--danger)" }}>Σφάλμα φόρτωσης μέσων.</div> : null}

        <div style={{ overflowX: "auto" }}>
          <table className="data-table" style={{ minWidth: 1120 }}>
            <thead>
              <tr>
                <th>Κατηγορία</th>
                <th>Μέσο</th>
                <th>Τύπος</th>
                <th>Status</th>
                <th>Θέση</th>
                <th>Επιθεώρηση</th>
                <th>Ενέργειες</th>
              </tr>
            </thead>
            <tbody>
              {filteredAssets.map((asset) => {
                const canManageThis = canManageCategory(profile, effectiveSiteId, asset.category);
                return (
                  <tr key={`${asset.category}-${asset.id}`}>
                    <td>
                      <Badge>{labelForAssetCategory(asset.category)}</Badge>
                    </td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        {asset.photoUrl ? (
                          <img src={asset.photoUrl} alt={asset.name || asset.id} style={{ width: 46, height: 36, objectFit: "cover", borderRadius: 8, border: "1px solid var(--border)" }} />
                        ) : (
                          <div style={{ width: 46, height: 36, borderRadius: 8, border: "1px dashed var(--border)", display: "grid", placeItems: "center", color: "var(--muted)", fontSize: 11 }}>Χωρίς</div>
                        )}
                        <div>
                          <div style={{ fontWeight: 800, color: "var(--text-strong)" }}>{asset.name || asset.title}</div>
                          <div className="muted" style={{ fontSize: 12 }}>{asset.id}</div>
                        </div>
                      </div>
                    </td>
                    <td>{typeLabel(asset.category, asset.type)}</td>
                    <td><Badge tone={statusTone(asset.status)}>{statusLabel(asset.status)}</Badge></td>
                    <td>
                      <div style={{ fontWeight: 700 }}>{asset.latitude}, {asset.longitude}</div>
                      <div className="muted" style={{ fontSize: 12 }}>
                        {[asset.building, asset.floor, asset.zone].filter(Boolean).join(" / ") || "Δεν έχει οριστεί εσωτερική θέση"}
                      </div>
                    </td>
                    <td>
                      {assetRequiresInspection(asset.category) ? (
                        <div>
                          <Badge tone={isInspectionDue(asset) ? "warning" : "success"}>
                            {isInspectionDue(asset) ? "Εκκρεμεί" : "ΟΚ"}
                          </Badge>
                          <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
                            Επόμενη: {formatDate(asset.inspection?.nextInspectionAt)}
                          </div>
                        </div>
                      ) : "-"}
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <SmallButton onClick={() => editAsset(asset)} disabled={!canManageThis}>Επεξεργασία</SmallButton>
                        <SmallButton onClick={() => deleteAsset(asset)} disabled={!canManageThis} variant="danger">Διαγραφή</SmallButton>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {!filteredAssets.length && !showAssetsLoading && effectiveSiteId ? (
          <div style={{ padding: 30, textAlign: "center" }}>
            <h3 style={{ margin: "0 0 6px" }}>Δεν υπάρχουν καταχωρήσεις</h3>
            <div className="muted">Δεν βρέθηκαν μέσα για τα επιλεγμένα φίλτρα.</div>
            {canManageAny ? (
              <div style={{ marginTop: 14 }}>
                <SmallButton onClick={() => openNewAsset()} variant="primary">Προσθήκη πρώτης καταχώρησης</SmallButton>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      {drawerOpen ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 50,
            background: "rgba(0,0,0,0.42)",
            display: "flex",
            justifyContent: "flex-end",
          }}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setDrawerOpen(false);
          }}
        >
          <div
            style={{
              width: "min(720px, 100%)",
              height: "100%",
              overflowY: "auto",
              background: "var(--bg)",
              borderLeft: "1px solid var(--border)",
              boxShadow: "var(--shadow-soft)",
              padding: 22,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start", marginBottom: 16 }}>
              <div>
                <h2 style={{ margin: "0 0 4px" }}>{editingAssetId ? "Επεξεργασία μέσου" : "Νέα καταχώρηση"}</h2>
                <div className="muted">Συμπλήρωση στοιχείων και θέσης μέσου site.</div>
              </div>
              <SmallButton onClick={() => setDrawerOpen(false)}>Κλείσιμο</SmallButton>
            </div>

            <div style={{ display: "grid", gap: 16 }}>
              <div style={cardStyle({ padding: 16 })}>
                <h3 style={sectionTitleStyle()}>Βασικά στοιχεία</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <label style={labelStyle()}>
                    Κατηγορία
                    <select
                      value={form.category}
                      onChange={(e) => {
                        const category = e.target.value as SiteAssetCategory;
                        setForm((prev) => ({
                          ...emptyForm(category),
                          id: prev.id,
                          name: prev.name,
                          latitude: prev.latitude,
                          longitude: prev.longitude,
                        }));
                      }}
                      style={fieldStyle()}
                    >
                      {CATEGORY_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </label>

                  <label style={labelStyle()}>
                    Status
                    <select value={form.status} onChange={(e) => setForm((prev) => ({ ...prev, status: e.target.value as SiteAssetStatus }))} style={fieldStyle()}>
                      {STATUS_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </label>

                  <label style={labelStyle()}>
                    ID
                    <input value={form.id} onChange={(e) => setForm((prev) => ({ ...prev, id: e.target.value }))} placeholder="π.χ. aed_gate_001" style={fieldStyle()} />
                  </label>

                  <label style={labelStyle()}>
                    Όνομα
                    <input value={form.name} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} placeholder="π.χ. AED Κεντρικής Πύλης" style={fieldStyle()} />
                  </label>

                  <label style={labelStyle()}>
                    Τύπος
                    <select value={form.type} onChange={(e) => setForm((prev) => ({ ...prev, type: e.target.value }))} style={fieldStyle()}>
                      <option value="">Επιλογή τύπου</option>
                      {TYPE_OPTIONS[form.category].map((option) => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </label>
                </div>
              </div>

              <div style={cardStyle({ padding: 16 })}>
                <h3 style={sectionTitleStyle()}>Φωτογραφία</h3>
                <div style={{ display: "grid", gap: 12 }}>
                  {(selectedPhotoPreview || (!removeExistingPhoto && form.photoUrl)) ? (
                    <img
                      src={selectedPhotoPreview || form.photoUrl}
                      alt="Φωτογραφία μέσου"
                      style={{ width: "100%", maxHeight: 260, objectFit: "cover", borderRadius: 14, border: "1px solid var(--border)" }}
                    />
                  ) : (
                    <div
                      style={{
                        border: "1px dashed var(--border)",
                        borderRadius: 14,
                        padding: 18,
                        color: "var(--muted)",
                        background: "var(--surface-muted)",
                      }}
                    >
                      Δεν έχει οριστεί φωτογραφία για το μέσο.
                    </div>
                  )}

                  {form.photoPath && !removeExistingPhoto ? (
                    <div className="muted" style={{ fontSize: 12 }}>Storage path: {form.photoPath}</div>
                  ) : null}

                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                    <SmallButton onClick={() => photoInputRef.current?.click()} disabled={!canManageCurrentCategory}>
                      Upload / αντικατάσταση
                    </SmallButton>
                    <SmallButton
                      onClick={removePhoto}
                      disabled={!canManageCurrentCategory || (!form.photoUrl && !selectedPhotoFile)}
                      variant="danger"
                    >
                      Διαγραφή φωτογραφίας
                    </SmallButton>
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/*"
                      style={{ display: "none" }}
                      onChange={(e) => {
                        handlePhotoFile(e.target.files?.[0] || null);
                        e.currentTarget.value = "";
                      }}
                    />
                  </div>
                </div>
              </div>

              <div style={cardStyle({ padding: 16 })}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", marginBottom: 12 }}>
                  <h3 style={{ ...sectionTitleStyle(), margin: 0 }}>Τοποθεσία</h3>
                  <SmallButton onClick={fillCurrentBrowserLocation}>Χρήση τρέχουσας θέσης</SmallButton>
                </div>
                {siteMapConfig.enabled ? (
                  <div style={{ marginBottom: 12 }}>
                    <MiniLocationMap
                      latitude={form.latitude}
                      longitude={form.longitude}
                      siteMapConfig={siteMapConfig}
                      mapProvider={mapProvider}
                      onMapProviderChange={changeMapProvider}
                      onPick={pickMapPoint}
                    />
                  </div>
                ) : null}

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <label style={labelStyle()}>
                    Latitude
                    <input value={form.latitude} onChange={(e) => setForm((prev) => ({ ...prev, latitude: e.target.value }))} style={fieldStyle()} />
                  </label>
                  <label style={labelStyle()}>
                    Longitude
                    <input value={form.longitude} onChange={(e) => setForm((prev) => ({ ...prev, longitude: e.target.value }))} style={fieldStyle()} />
                  </label>
                  <label style={labelStyle()}>
                    Κτίριο
                    <input value={form.building} onChange={(e) => setForm((prev) => ({ ...prev, building: e.target.value }))} style={fieldStyle()} />
                  </label>
                  <label style={labelStyle()}>
                    Όροφος
                    <input value={form.floor} onChange={(e) => setForm((prev) => ({ ...prev, floor: e.target.value }))} style={fieldStyle()} />
                  </label>
                  <label style={labelStyle()}>
                    Ζώνη
                    <input value={form.zone} onChange={(e) => setForm((prev) => ({ ...prev, zone: e.target.value }))} style={fieldStyle()} />
                  </label>
                </div>
                <label style={{ ...labelStyle(), marginTop: 12 }}>
                  Περιγραφή / σημειώσεις θέσης
                  <textarea value={form.description} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} rows={3} style={fieldStyle()} />
                </label>
              </div>

              {assetRequiresInspection(form.category) ? (
                <details open style={cardStyle({ padding: 16 })}>
                  <summary style={{ cursor: "pointer", fontWeight: 800, color: "var(--text-strong)", marginBottom: 12 }}>
                    Στοιχεία επιθεώρησης & τεχνικά στοιχεία
                  </summary>

                  <div style={{ display: "grid", gap: 12 }}>
                    <label style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--text)", fontWeight: 700 }}>
                      <input
                        type="checkbox"
                        checked={form.inspectionRequired}
                        onChange={(e) => setForm((prev) => ({ ...prev, inspectionRequired: e.target.checked }))}
                      />
                      Απαιτείται περιοδική επιθεώρηση
                    </label>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                      <label style={labelStyle()}>
                        Συχνότητα (ημέρες)
                        <input value={form.inspectionFrequencyDays} onChange={(e) => setForm((prev) => ({ ...prev, inspectionFrequencyDays: e.target.value }))} style={fieldStyle()} />
                      </label>
                      <label style={labelStyle()}>
                        Τελευταία επιθεώρηση
                        <input type="date" value={form.lastInspectionAt} onChange={(e) => setForm((prev) => ({ ...prev, lastInspectionAt: e.target.value }))} style={fieldStyle()} />
                      </label>
                      <label style={labelStyle()}>
                        Επόμενη επιθεώρηση
                        <input type="date" value={form.nextInspectionAt} onChange={(e) => setForm((prev) => ({ ...prev, nextInspectionAt: e.target.value }))} style={fieldStyle()} />
                      </label>
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                      <label style={labelStyle()}>
                        Serial number
                        <input value={form.serialNumber} onChange={(e) => setForm((prev) => ({ ...prev, serialNumber: e.target.value }))} style={fieldStyle()} />
                      </label>
                      <label style={labelStyle()}>
                        Κατασκευαστής
                        <input value={form.manufacturer} onChange={(e) => setForm((prev) => ({ ...prev, manufacturer: e.target.value }))} style={fieldStyle()} />
                      </label>
                      <label style={labelStyle()}>
                        Μοντέλο
                        <input value={form.model} onChange={(e) => setForm((prev) => ({ ...prev, model: e.target.value }))} style={fieldStyle()} />
                      </label>
                    </div>

                    <label style={labelStyle()}>
                      Σημειώσεις επιθεώρησης
                      <textarea value={form.inspectionNotes} onChange={(e) => setForm((prev) => ({ ...prev, inspectionNotes: e.target.value }))} rows={2} style={fieldStyle()} />
                    </label>
                  </div>
                </details>
              ) : null}

              {!canManageCurrentCategory ? (
                <div style={cardStyle({ padding: 12, borderColor: "var(--warning)", background: "var(--warning-soft)" })}>
                  Δεν έχετε δικαίωμα διαχείρισης για την κατηγορία {labelForAssetCategory(form.category)} στο site.
                </div>
              ) : null}

              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", flexWrap: "wrap" }}>
                <SmallButton onClick={() => resetForm()}>Καθαρισμός</SmallButton>
                <SmallButton onClick={() => setDrawerOpen(false)}>Ακύρωση</SmallButton>
                <SmallButton onClick={saveAsset} disabled={!canManageCurrentCategory || saveMutation.isPending} variant="primary">
                  {saveMutation.isPending ? "Αποθήκευση..." : "Αποθήκευση"}
                </SmallButton>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
