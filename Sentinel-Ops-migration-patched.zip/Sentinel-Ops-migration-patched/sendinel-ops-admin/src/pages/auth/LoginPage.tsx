import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginWithEmail } from "../../services/auth/authService";
import { getUserProfile } from "../../services/repositories/usersRepository";
import { hasAdminPortalAccess } from "../../domain/models/user";
import { BRAND } from "../../config/branding";

export default function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");

    try {
      const result = await loginWithEmail(email, password);
      const profile = await getUserProfile(result.user.uid);

      if (!profile) {
        setError("Δεν βρέθηκε προφίλ χρήστη στη βάση");
        return;
      }

      if (!hasAdminPortalAccess(profile)) {
        setError("Δεν έχετε δικαίωμα πρόσβασης στο admin dashboard");
        return;
      }

      navigate("/app/overview", { replace: true });
    } catch (err) {
      console.error(err);
      setError("Αποτυχία σύνδεσης");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24 }}>
      <form
        onSubmit={handleSubmit}
        style={{
          width: "100%",
          maxWidth: 420,
          padding: 24,
          border: "1px solid #ddd",
          borderRadius: 16,
          background: "var(--surface, #fff)",
        }}
      >
        <h1 style={{ marginTop: 0 }}>{BRAND.appName}</h1>
        <p>Σύνδεση στο web admin dashboard</p>

        <label style={{ display: "block", marginBottom: 12 }}>
          <div>Email</div>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            style={{ width: "100%", padding: 10, borderRadius: 10 }}
          />
        </label>

        <label style={{ display: "block", marginBottom: 12 }}>
          <div>Κωδικός</div>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            style={{ width: "100%", padding: 10, borderRadius: 10 }}
          />
        </label>

        {error ? (
          <div style={{ color: "crimson", marginBottom: 12 }}>{error}</div>
        ) : null}

        <button
          type="submit"
          disabled={submitting}
          style={{
            width: "100%",
            padding: 12,
            borderRadius: 12,
            border: "none",
            cursor: "pointer",
          }}
        >
          {submitting ? "Σύνδεση..." : "Είσοδος"}
        </button>
      </form>
    </div>
  );
}