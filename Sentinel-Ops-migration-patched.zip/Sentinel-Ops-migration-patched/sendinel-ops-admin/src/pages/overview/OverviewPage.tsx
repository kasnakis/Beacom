import { Link } from "react-router-dom";
import { ROUTES } from "../../app/config/routes";
import { useOverviewData } from "../../hooks/useOverviewData";
import type { SiteOperationalDashboardRow } from "../../hooks/useOverviewData";

function formatDate(value?: number): string {
  if (!value) return "-";
  return new Intl.DateTimeFormat("el-GR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

function severityLabel(value?: string): string {
  const normalized = (value || "").toUpperCase();
  if (normalized === "CRITICAL") return "Κρίσιμο";
  if (normalized === "HIGH") return "Υψηλό";
  if (normalized === "MEDIUM") return "Μεσαίο";
  if (normalized === "LOW") return "Χαμηλό";
  return "-";
}

function operationalTone(row: SiteOperationalDashboardRow): string {
  if (row.liveIncidentsCount > 0 || row.openDispatchesCount > 0) return "Σε εξέλιξη";
  if (row.hasStaleDispatchArtifacts) return "Έλεγχος";
  return "Κανονική";
}

function operationalToneClass(row: SiteOperationalDashboardRow): string {
  if (row.liveIncidentsCount > 0 || row.openDispatchesCount > 0) return "is-alert";
  if (row.hasStaleDispatchArtifacts) return "is-warning";
  return "is-normal";
}

export function OverviewPage() {
  const { data, isLoading, error } = useOverviewData();

  if (isLoading) {
    return <div className="page-loading">Φόρτωση...</div>;
  }

  if (error || !data) {
    return <div className="page-loading">Σφάλμα φόρτωσης αρχικής σελίδας</div>;
  }

  return (
    <div className="overview-page">
      <div className="overview-header">
        <div>
          <h1>Αρχική</h1>
        </div>
      </div>

      <div className="overview-metrics-grid">
        <OverviewMetric icon="👥" label="Υπηρεσιακές Μονάδες" value={data.sitesCount} tone="blue" />
        <OverviewMetric icon="👤" label="Χρήστες" value={data.usersCount} tone="blue" />
        <OverviewMetric icon="〽" label="Ενεργά Συμβάντα" value={data.activeIncidentsCount} tone="green" />
        <OverviewMetric icon="🚚" label="Ενεργές Κινητοποιήσεις" value={data.openDispatches} tone="orange" />
        <OverviewMetric
          icon="📋"
          label="Εκκρεμείς Εξωτερικές Ειδοποιήσεις"
          value={data.pendingExternalNotifications}
          tone="purple"
        />
        <OverviewMetric icon="📡" label="Dispatch προς Έλεγχο" value={data.staleDispatchArtifacts} tone="purple" />
      </div>

      <section className="overview-section overview-sites-section">
        <div className="overview-section-header">
          <div>
            <h2>Επιχειρησιακό Dashboard ανά Μονάδα</h2>
            <p>
              Συνοπτική επιχειρησιακή εικόνα ανά site: ενεργά συμβάντα, ανοικτά dispatch,
              responders, εξωτερικές αρχές και πιθανές ασυνέπειες από παλιότερα runtime δεδομένα.
            </p>
          </div>

          <Link to={ROUTES.LIVE_DASHBOARD} className="button-link button-link-outline">
            ▣ Άνοιγμα Ζωντανής Εικόνας
          </Link>
        </div>

        <div className="site-operational-grid">
          {data.siteOperationalRows.map((row) => (
            <SiteOperationalCard key={row.siteId} row={row} />
          ))}
        </div>
      </section>

      <section className="overview-section">
        <h2>Γενικές Ρυθμίσεις</h2>
        <div className="settings-summary-grid">
          <SettingsCard icon="🌐" label="Default language" value="el" tone="blue" />
          <SettingsCard icon="🕘" label="Default timezone" value="Europe/Athens" tone="green" />
          <SettingsCard icon="🔔" label="Notification mode" value="POLICY_DRIVEN" tone="yellow" />
          <SettingsCard icon="⚙" label="Policy mode" value="SITE_DRIVEN" tone="purple" />
        </div>
      </section>
    </div>
  );
}

function OverviewMetric({
  icon,
  label,
  value,
  tone,
}: {
  icon: string;
  label: string;
  value: string | number;
  tone: "blue" | "green" | "orange" | "purple";
}) {
  return (
    <div className="overview-metric-card">
      <div className={`overview-metric-icon tone-${tone}`}>{icon}</div>
      <div>
        <div className="overview-metric-label">{label}</div>
        <div className="overview-metric-value">{value}</div>
      </div>
    </div>
  );
}

function SiteOperationalCard({ row }: { row: SiteOperationalDashboardRow }) {
  const tone = operationalTone(row);
  const toneClass = operationalToneClass(row);

  return (
    <article className={`site-operational-card ${toneClass}`}>
      <div
        className="site-operational-card-hero"
        style={{
          backgroundImage: `linear-gradient(180deg, rgba(15,23,42,0.08), rgba(15,23,42,0.22)), url(${row.coverImageUrl || ""})`,
        }}
      >
        <div className="site-title-badge">
          <span className="site-code">{row.siteId}</span>
          <strong>{row.siteName}</strong>
        </div>

        <span className={`site-status-pill ${toneClass}`}>{tone}</span>
      </div>

      <div className="site-operational-card-body">
        <div className="site-mini-metrics-grid">
          <MiniMetric icon="🛡" label="Συμβάντα" value={row.liveIncidentsCount} tone="red" />
          <MiniMetric icon="📋" label="Dispatch" value={row.openDispatchesCount} tone="blue" />
          <MiniMetric icon="🧡" label="Responding" value={row.respondingCount} tone="orange" />
          <MiniMetric icon="🏢" label="Εξωτερικές" value={row.pendingExternalCount} tone="purple" />
          <MiniMetric icon="✓" label="Arrived" value={row.arrivedCount} tone="green" />
          <MiniMetric icon="👥" label="Χρήστες" value={`${row.activeUsersCount}/${row.usersCount}`} tone="blue" strong />
        </div>

        <div className="site-operational-meta">
          <div>
            Μέγιστη σοβαρότητα: <strong>{severityLabel(row.highestSeverity)}</strong>
          </div>
          <div>
            Τελευταίο συμβάν: <strong>{formatDate(row.lastIncidentAt)}</strong>
          </div>
          {row.hasStaleDispatchArtifacts ? (
            <div className="site-warning-line">
              ⚠ Υπάρχουν παλιά dispatch artifacts που πρέπει να ελεγχθούν μετά το επόμενο test.
            </div>
          ) : null}
        </div>

        <div className="site-card-actions">
          <Link to={`/app/sites/${row.siteId}`} className="button-link button-link-soft">
            ⌂ Άνοιγμα μονάδας
          </Link>
          <Link to={ROUTES.LIVE_DASHBOARD} className="button-link button-link-primary">
            〽 Ζωντανή εικόνα
          </Link>
        </div>
      </div>
    </article>
  );
}

function MiniMetric({
  icon,
  label,
  value,
  tone,
  strong,
}: {
  icon: string;
  label: string;
  value: string | number;
  tone: "red" | "blue" | "orange" | "purple" | "green";
  strong?: boolean;
}) {
  return (
    <div className="site-mini-metric">
      <span className={`site-mini-icon tone-${tone}`}>{icon}</span>
      <div>
        <div className="site-mini-label">{label}</div>
        <div className={strong ? "site-mini-value strong" : "site-mini-value"}>{value}</div>
      </div>
    </div>
  );
}

function SettingsCard({
  icon,
  label,
  value,
  tone,
}: {
  icon: string;
  label: string;
  value: string;
  tone: "blue" | "green" | "yellow" | "purple";
}) {
  return (
    <div className="settings-summary-card">
      <div className={`settings-summary-icon tone-${tone}`}>{icon}</div>
      <div>
        <div className="settings-summary-label">{label}</div>
        <div className="settings-summary-value">{value}</div>
      </div>
    </div>
  );
}
