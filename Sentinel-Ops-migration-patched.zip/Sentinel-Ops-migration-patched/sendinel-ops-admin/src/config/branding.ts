export const BRAND = {
  appName: "SENTINEL Ops",
  shortName: "SENTINEL",
  adminTitle: "SENTINEL Ops Admin",
} as const;
