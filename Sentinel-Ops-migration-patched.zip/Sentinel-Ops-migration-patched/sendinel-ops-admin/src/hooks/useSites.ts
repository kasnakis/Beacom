import { useQuery } from "@tanstack/react-query";
import { sitesRepository } from "../services/repositories/sitesRepository";

export function useSites() {
  return useQuery({
    queryKey: ["sites"],
    queryFn: () => sitesRepository.list(),
  });
}