import { useMutation, useQueryClient } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";
import type { AdminPermissions, SiteMembership } from "../domain/models/user";
import { useAuth } from "./useAuth";

type Payload = {
  uid: string;
  values: {
    active?: boolean;
    siteId?: string;
    platformRoles?: Record<string, boolean>;
    roles?: Record<string, boolean>;
    teams?: Record<string, boolean>;
    adminPermissions?: AdminPermissions;
    siteMemberships?: Record<string, SiteMembership>;
  };
};

export function useUpdateUser() {
  const queryClient = useQueryClient();
  const { profile } = useAuth();

  return useMutation({
    mutationFn: async ({ uid, values }: Payload) => {
      await usersRepository.updateBasicFields(uid, values, {
        performedBy: {
          uid: profile?.uid || "unknown",
          email: profile?.email || "",
          level: profile?.adminPermissions?.level || "UNKNOWN",
        },
      });
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      queryClient.invalidateQueries({ queryKey: ["user", variables.uid] });
      queryClient.invalidateQueries({ queryKey: ["sitesAdmin"] });
      queryClient.invalidateQueries({ queryKey: ["siteWorkspace"] });
    },
  });
}