import { useQuery } from "@tanstack/react-query";
import { operationalNotificationsRepository } from "../services/repositories/operationalNotificationsRepository";
import type { OperationalNotificationRequest } from "../domain/models/operationalNotification";
import { useAuth } from "./useAuth";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";

function statusRank(status?: string): number {
  switch ((status || "").toUpperCase()) {
    case "PENDING":
      return 0;
    case "PROCESSING":
      return 1;
    case "RETRY_SCHEDULED":
      return 2;
    case "PARTIAL":
      return 3;
    case "FAILED":
      return 4;
    case "NO_TARGETS":
      return 5;
    case "SENT":
      return 6;
    case "CANCELLED":
      return 7;
    default:
      return 99;
  }
}

function safeTime(item: OperationalNotificationRequest): number {
  return item.updatedAt || item.processedAt || item.sentAt || item.createdAt || 0;
}

function sortItems(items: OperationalNotificationRequest[]) {
  return [...items].sort((a, b) => {
    const rankDiff = statusRank(a.status) - statusRank(b.status);
    if (rankDiff !== 0) return rankDiff;
    return safeTime(b) - safeTime(a);
  });
}

export function useOperationalNotificationsCenter() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["operationalNotificationsCenter", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const items = await operationalNotificationsRepository.list();
      return sortItems(items.filter((item) => canViewSiteIncidents(profile, item.siteId)));
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}
