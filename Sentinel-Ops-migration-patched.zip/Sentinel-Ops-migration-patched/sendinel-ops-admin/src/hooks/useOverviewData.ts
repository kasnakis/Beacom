import { useQuery } from "@tanstack/react-query";
import { dispatchRepository } from "../services/repositories/dispatchRepository";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";
import { usersRepository } from "../services/repositories/usersRepository";
import { sitesRepository } from "../services/repositories/sitesRepository";
import { incidentsRepository } from "../services/repositories/incidentsRepository";
import type { DispatchState } from "../domain/models/dispatch";
import type { ExternalNotificationRecord } from "../domain/models/externalNotification";
import type { IncidentRecord } from "../domain/models/incident";
import type { SiteSummary } from "../domain/models/site";
import type { UserProfile } from "../domain/models/user";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";
import { useAuth } from "./useAuth";

export type SiteOperationalDashboardRow = {
  siteId: string;
  siteName: string;
  active: boolean;
  coverImageUrl?: string;
  usersCount: number;
  activeUsersCount: number;
  liveIncidentsCount: number;
  openDispatchesCount: number;
  respondingCount: number;
  arrivedCount: number;
  pendingExternalCount: number;
  highestSeverity: string;
  lastIncidentAt?: number;
  hasStaleDispatchArtifacts: boolean;
};

function normalized(value?: string): string {
  return (value || "").trim().toUpperCase();
}

function isTerminalIncident(item?: IncidentRecord): boolean {
  if (!item) return false;
  if (item.active === false) return true;

  const status = normalized(item.status);
  return status === "CLOSED" || status === "DEACTIVATED" || status === "REJECTED" || status === "CANCELLED";
}

function isLiveIncident(item: IncidentRecord): boolean {
  return !isTerminalIncident(item);
}

function isOpenDispatch(item: DispatchState, incident?: IncidentRecord): boolean {
  const status = normalized(item.status);
  if (status === "CLOSED" || status === "CANCELLED" || status === "COMPLETED") return false;
  if (isTerminalIncident(incident)) return false;
  return true;
}

function isStaleDispatchArtifact(item: DispatchState, incident?: IncidentRecord): boolean {
  const status = normalized(item.status);
  if (status === "CLOSED" || status === "CANCELLED" || status === "COMPLETED") return false;
  return isTerminalIncident(incident);
}

function isPendingExternal(item: ExternalNotificationRecord): boolean {
  const status = normalized(item.status);
  return status === "REQUESTED" || status === "APPROVED" || status === "SENT";
}

function userBelongsToSite(user: UserProfile, siteId: string): boolean {
  return canViewSiteIncidents(user, siteId);
}

function severityRank(value?: string): number {
  const status = normalized(value);
  if (status === "CRITICAL") return 5;
  if (status === "HIGH") return 4;
  if (status === "MEDIUM") return 3;
  if (status === "LOW") return 2;
  return 1;
}

function pickHighestSeverity(items: IncidentRecord[]): string {
  if (!items.length) return "-";
  return items.reduce((best, item) => (severityRank(item.severity) > severityRank(best) ? item.severity || best : best), items[0].severity || "-");
}

function buildSiteRows(params: {
  currentUser: UserProfile | null | undefined;
  sites: SiteSummary[];
  users: UserProfile[];
  incidents: IncidentRecord[];
  dispatches: DispatchState[];
  externalNotifications: ExternalNotificationRecord[];
}): SiteOperationalDashboardRow[] {
  const { currentUser, sites, users, incidents, dispatches, externalNotifications } = params;
  const incidentsById = new Map(incidents.map((item) => [item.id, item]));

  return sites
    .filter((site) => canViewSiteIncidents(currentUser, site.id))
    .map((site) => {
      const siteIncidents = incidents.filter((item) => item.siteId === site.id);
      const liveIncidents = siteIncidents.filter(isLiveIncident);
      const siteDispatches = dispatches.filter((item) => item.siteId === site.id || incidentsById.get(item.incidentId)?.siteId === site.id);
      const openDispatches = siteDispatches.filter((item) => isOpenDispatch(item, incidentsById.get(item.incidentId)));
      const siteExternal = externalNotifications.filter((item) => item.siteId === site.id || incidentsById.get(item.incidentId || "")?.siteId === site.id);
      const siteUsers = users.filter((user) => userBelongsToSite(user, site.id));

      return {
        siteId: site.id,
        siteName: site.name || site.id,
        active: site.active !== false,
        coverImageUrl: (site as any).coverImageUrl,
        usersCount: siteUsers.length,
        activeUsersCount: siteUsers.filter((user) => user.active !== false).length,
        liveIncidentsCount: liveIncidents.length,
        openDispatchesCount: openDispatches.length,
        respondingCount: openDispatches.reduce((sum, item) => sum + (item.respondingResponders || 0), 0),
        arrivedCount: openDispatches.reduce((sum, item) => sum + (item.arrivedResponders || 0), 0),
        pendingExternalCount: siteExternal.filter(isPendingExternal).length,
        highestSeverity: pickHighestSeverity(liveIncidents),
        lastIncidentAt: siteIncidents.reduce<number | undefined>((latest, item) => {
          const ts = item.createdAt || item.updatedAt || 0;
          if (!ts) return latest;
          return latest === undefined || ts > latest ? ts : latest;
        }, undefined),
        hasStaleDispatchArtifacts: siteDispatches.some((item) => isStaleDispatchArtifact(item, incidentsById.get(item.incidentId))),
      };
    })
    .sort((a, b) => {
      if (b.liveIncidentsCount !== a.liveIncidentsCount) return b.liveIncidentsCount - a.liveIncidentsCount;
      if (b.openDispatchesCount !== a.openDispatchesCount) return b.openDispatchesCount - a.openDispatchesCount;
      return a.siteName.localeCompare(b.siteName, "el");
    });
}

export function useOverviewData() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["overview", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const [sites, users, dispatches, externalNotifications, incidents] = await Promise.all([
        sitesRepository.list(),
        usersRepository.listUsers(),
        dispatchRepository.list(),
        externalNotificationsRepository.list(),
        incidentsRepository.list(),
      ]);

      const visibleIncidents = incidents.filter((item) => canViewSiteIncidents(profile, item.siteId));
      const incidentsById = new Map(visibleIncidents.map((item) => [item.id, item]));
      const visibleDispatches = dispatches.filter((item) => {
        const incident = incidentsById.get(item.incidentId);
        const dispatchSiteId = item.siteId || incident?.siteId;
        return canViewSiteIncidents(profile, dispatchSiteId);
      });
      const visibleExternalNotifications = externalNotifications.filter((item) => {
        const siteId = item.siteId || incidentsById.get(item.incidentId || "")?.siteId;
        return canViewSiteIncidents(profile, siteId);
      });
      const openDispatches = visibleDispatches.filter((item: DispatchState) => isOpenDispatch(item, incidentsById.get(item.incidentId)));
      const liveIncidents = visibleIncidents.filter(isLiveIncident);
      const pendingExternal = visibleExternalNotifications.filter((item: ExternalNotificationRecord) => isPendingExternal(item));

      return {
        sitesCount: sites.filter((site) => canViewSiteIncidents(profile, site.id)).length,
        usersCount: users.filter((user) => {
          const userSiteId = user.primarySiteId || user.siteId;
          return canViewSiteIncidents(profile, userSiteId);
        }).length,
        activeIncidentsCount: liveIncidents.length,
        openDispatches: openDispatches.length,
        pendingExternalNotifications: pendingExternal.length,
        staleDispatchArtifacts: visibleDispatches.filter((item) => isStaleDispatchArtifact(item, incidentsById.get(item.incidentId))).length,
        siteOperationalRows: buildSiteRows({
          currentUser: profile,
          sites,
          users,
          incidents: visibleIncidents,
          dispatches: visibleDispatches,
          externalNotifications: visibleExternalNotifications,
        }),
      };
    },
  });
}
