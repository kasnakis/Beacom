import { useQuery } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";
import type { UserProfile } from "../domain/models/user";

export function useUsers() {
  return useQuery<UserProfile[]>({
    queryKey: ["users"],
    queryFn: () => usersRepository.listUsers(),
  });
}