import { useQuery } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";

export function useAuditLogs(filters?: {
  user?: string;
  from?: number;
  to?: number;
}) {
  return useQuery({
    queryKey: ["auditLogs", filters],
    queryFn: async () => {
      const data = await usersRepository.listAuditLogs();

      return data.filter((log: any) => {
        if (filters?.user && !log.performedBy?.email?.includes(filters.user)) {
          return false;
        }

        if (filters?.from && log.createdAt < filters.from) return false;
        if (filters?.to && log.createdAt > filters.to) return false;

        return true;
      });
    },
  });
}