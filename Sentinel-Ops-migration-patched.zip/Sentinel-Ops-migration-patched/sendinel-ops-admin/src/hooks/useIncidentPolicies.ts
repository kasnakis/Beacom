import { useQuery } from "@tanstack/react-query";
import { incidentPoliciesRepository } from "../services/repositories/incidentPoliciesRepository";

export function useIncidentPolicies(siteId: string) {
  return useQuery({
    queryKey: ["incidentPolicies", siteId],
    queryFn: () => incidentPoliciesRepository.listBySite(siteId),
    enabled: !!siteId,
  });
}