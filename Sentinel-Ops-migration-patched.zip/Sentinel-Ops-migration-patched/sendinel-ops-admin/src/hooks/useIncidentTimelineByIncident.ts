import { useQuery } from "@tanstack/react-query";
import { incidentEventsRepository } from "../services/repositories/incidentEventsRepository";
import type { IncidentEventRecord } from "../domain/models/incidentEvent";

function sortEvents(items: IncidentEventRecord[]) {
  return [...items].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

export function useIncidentTimelineByIncident(incidentId: string) {
  return useQuery({
    queryKey: ["incidentTimelineByIncident", incidentId],
    queryFn: async () => {
      const items = await incidentEventsRepository.listLatest();
      return sortEvents(items.filter((item) => item.incidentId === incidentId)).slice(0, 12);
    },
    enabled: !!incidentId,
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}