import { useMutation, useQueryClient } from "@tanstack/react-query";
import { sitesRepository } from "../services/repositories/sitesRepository";

type Payload = {
  siteId: string;
  values: {
    name?: string;
    active?: boolean;
  };
};

export function useUpdateSite() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ siteId, values }: Payload) => {
      await sitesRepository.updateBasicFields(siteId, values);
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["sitesAdmin"] });
      queryClient.invalidateQueries({ queryKey: ["sites"] });
      queryClient.invalidateQueries({ queryKey: ["siteWorkspace", variables.siteId] });
    },
  });
}