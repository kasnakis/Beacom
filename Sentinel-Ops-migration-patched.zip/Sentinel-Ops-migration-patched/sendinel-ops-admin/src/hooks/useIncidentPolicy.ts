import { useQuery } from "@tanstack/react-query";
import { incidentPoliciesRepository } from "../services/repositories/incidentPoliciesRepository";

export function useIncidentPolicy(siteId: string, key: string) {
  return useQuery({
    queryKey: ["incidentPolicy", siteId, key],
    queryFn: () => incidentPoliciesRepository.getBySiteAndKey(siteId, key),
    enabled: !!siteId && !!key,
  });
}