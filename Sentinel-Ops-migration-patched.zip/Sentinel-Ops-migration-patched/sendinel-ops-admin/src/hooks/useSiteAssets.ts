import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { SiteAssetCategory, SiteAssetInput } from "../domain/models/siteAsset";
import { siteAssetsRepository } from "../services/repositories/siteAssetsRepository";
import { useAuth } from "./useAuth";

function useAuditContext() {
  const { profile } = useAuth();
  return {
    performedBy: {
      uid: profile?.uid || "unknown",
      email: profile?.email || "",
      level: profile?.adminPermissions?.level || "UNKNOWN",
    },
  };
}

export function useSiteAssets(siteId: string) {
  return useQuery({
    queryKey: ["siteAssets", siteId],
    queryFn: () => siteAssetsRepository.listBySite(siteId),
    enabled: Boolean(siteId),
  });
}

export function useSaveSiteAsset(siteId: string) {
  const queryClient = useQueryClient();
  const auditCtx = useAuditContext();

  return useMutation({
    mutationFn: (asset: SiteAssetInput) => siteAssetsRepository.saveAsset(siteId, asset, auditCtx),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["siteAssets", siteId] });
    },
  });
}

export function useDeleteSiteAsset(siteId: string) {
  const queryClient = useQueryClient();
  const auditCtx = useAuditContext();

  return useMutation({
    mutationFn: ({ category, id }: { category: SiteAssetCategory; id: string }) =>
      siteAssetsRepository.deleteAsset(siteId, category, id, auditCtx),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["siteAssets", siteId] });
    },
  });
}

export function useImportSiteAssets(siteId: string) {
  const queryClient = useQueryClient();
  const auditCtx = useAuditContext();

  return useMutation({
    mutationFn: (assets: SiteAssetInput[]) => siteAssetsRepository.importAssets(siteId, assets, auditCtx),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["siteAssets", siteId] });
    },
  });
}
