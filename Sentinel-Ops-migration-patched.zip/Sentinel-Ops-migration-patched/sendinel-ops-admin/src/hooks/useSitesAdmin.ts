import { useQuery } from "@tanstack/react-query";
import { sitesRepository } from "../services/repositories/sitesRepository";
import { usersRepository } from "../services/repositories/usersRepository";
import { dispatchRepository } from "../services/repositories/dispatchRepository";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";
import type { SiteAdminRow } from "../domain/models/site";

function isOpenDispatch(status?: string) {
  const s = (status || "").toUpperCase();
  return s !== "CLOSED" && s !== "CANCELLED";
}

function isPendingExternal(status?: string) {
  const s = (status || "").toUpperCase();
  return s === "REQUESTED" || s === "APPROVED" || s === "SENT";
}

export function useSitesAdmin() {
  return useQuery({
    queryKey: ["sitesAdmin"],
    queryFn: async (): Promise<SiteAdminRow[]> => {
      const [sites, users, dispatches, externalNotifications] = await Promise.all([
        sitesRepository.list(),
        usersRepository.listUsers(),
        dispatchRepository.list(),
        externalNotificationsRepository.list(),
      ]);

      return sites.map((site) => {
        const usersCount = users.filter((u) => u.siteId === site.id).length;

        const openDispatchesCount = dispatches.filter(
          (d) => d.siteId === site.id && isOpenDispatch(d.status)
        ).length;

        const pendingExternalCount = externalNotifications.filter(
          (n) => n.siteId === site.id && isPendingExternal(n.status)
        ).length;

        return {
          ...site,
          usersCount,
          openDispatchesCount,
          pendingExternalCount,
        };
      });
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}