import { useMutation, useQueryClient } from "@tanstack/react-query";
import { sitesRepository } from "../services/repositories/sitesRepository";
import type { CreateSitePayload } from "../domain/models/site";
import type { UserProfile } from "../domain/models/user";

function resolveAdminLevel(profile: UserProfile | null): string {
  return profile?.adminPermissions?.level || (profile?.platformRoles?.ADMIN_PORTAL ? "GLOBAL_ADMIN" : "VIEW_ONLY");
}

export function useCreateSite(currentProfile: UserProfile | null) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: CreateSitePayload) => {
      await sitesRepository.createSite(payload, {
        performedBy: {
          uid: currentProfile?.uid || "unknown",
          email: currentProfile?.email || "",
          level: resolveAdminLevel(currentProfile),
        },
      });
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["sitesAdmin"] });
      queryClient.invalidateQueries({ queryKey: ["sites"] });
      queryClient.invalidateQueries({ queryKey: ["siteWorkspace", variables.siteId] });
    },
  });
}
