import { useQuery } from "@tanstack/react-query";
import { dispatchRepository } from "../services/repositories/dispatchRepository";
import type { DispatchState } from "../domain/models/dispatch";
import { useAuth } from "./useAuth";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";

function sortDispatches(items: DispatchState[]) {
  return [...items].sort((a, b) => {
    const aClosed = a.status === "CLOSED" || a.status === "CANCELLED";
    const bClosed = b.status === "CLOSED" || b.status === "CANCELLED";

    if (aClosed !== bClosed) {
      return aClosed ? 1 : -1;
    }

    return (b.arrivedResponders || 0) - (a.arrivedResponders || 0);
  });
}

export function useDispatchMonitor() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["dispatchMonitor", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const dispatches = await dispatchRepository.list();
      return sortDispatches(dispatches.filter((item) => canViewSiteIncidents(profile, item.siteId)));
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}