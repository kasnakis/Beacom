import { useQuery } from "@tanstack/react-query";
import { externalAuthoritiesRepository } from "../services/repositories/externalAuthoritiesRepository";

export function useExternalAuthorities(siteId: string) {
  return useQuery({
    queryKey: ["externalAuthorities", siteId],
    queryFn: () => externalAuthoritiesRepository.listBySite(siteId),
    enabled: !!siteId,
  });
}