import { useQuery } from "@tanstack/react-query";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";

export function useExternalNotifications() {
  return useQuery({ queryKey: ["externalNotifications"], queryFn: externalNotificationsRepository.list });
}
