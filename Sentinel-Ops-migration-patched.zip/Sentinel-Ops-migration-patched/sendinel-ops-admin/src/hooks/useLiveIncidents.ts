import { useQuery } from "@tanstack/react-query";
import { incidentsRepository } from "../services/repositories/incidentsRepository";
import type { IncidentRecord } from "../domain/models/incident";
import { useAuth } from "./useAuth";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";

function isLiveIncident(item: IncidentRecord): boolean {
  if (item.active === false) return false;

  const status = (item.status || "").toUpperCase();
  if (status === "CLOSED" || status === "DEACTIVATED" || status === "REJECTED" || status === "CANCELLED") {
    return false;
  }

  return true;
}

function sortIncidents(items: IncidentRecord[]) {
  return [...items].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

export function useLiveIncidents() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["liveIncidents", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const items = await incidentsRepository.list();
      return sortIncidents(items.filter((item) => canViewSiteIncidents(profile, item.siteId)).filter(isLiveIncident));
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}