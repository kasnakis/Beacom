import { useMutation, useQueryClient } from "@tanstack/react-query";
import { httpsCallable } from "firebase/functions";
import { functions } from "../services/firebase/firebaseFunctions";
import type { AdminLevel } from "../domain/models/user";

export type CreateAdminUserPayload = {
  email: string;
  displayName: string;
  siteId: string;
  active?: boolean;
  platformRoles?: Record<string, boolean>;
  adminPermissions?: {
    level?: AdminLevel;
  };
  roles?: Record<string, boolean>;
  teams?: Record<string, boolean>;
};

type CreateAdminUserResult = {
  uid?: string;
  email?: string;
  displayName?: string;
  siteId?: string;
};

export function useCreateAdminUser() {
  const queryClient = useQueryClient();

  return useMutation<CreateAdminUserResult, Error, CreateAdminUserPayload>({
    mutationFn: async (payload) => {
      const createUser = httpsCallable<
        CreateAdminUserPayload,
        CreateAdminUserResult
      >(functions, "createAdminUser");

      const result = await createUser(payload);
      return result.data;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });
}
