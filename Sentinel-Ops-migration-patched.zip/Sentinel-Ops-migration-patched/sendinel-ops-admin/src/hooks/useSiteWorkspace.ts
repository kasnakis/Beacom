import { useQuery } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";
import { dispatchRepository } from "../services/repositories/dispatchRepository";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";
import { externalAuthoritiesRepository } from "../services/repositories/externalAuthoritiesRepository";
import { incidentPoliciesRepository } from "../services/repositories/incidentPoliciesRepository";
import type { UserProfile } from "../domain/models/user";
import type { DispatchState } from "../domain/models/dispatch";
import type { ExternalNotificationRecord } from "../domain/models/externalNotification";
import type { ExternalAuthority } from "../domain/models/externalAuthority";
import type { IncidentPolicy } from "../domain/models/incidentPolicy";

function isOpenDispatch(status?: string) {
  const s = (status || "").toUpperCase();
  return s !== "CLOSED" && s !== "CANCELLED";
}

function isPendingExternal(status?: string) {
  const s = (status || "").toUpperCase();
  return s === "REQUESTED" || s === "APPROVED" || s === "SENT";
}

export type SiteWorkspaceData = {
  users: UserProfile[];
  dispatches: DispatchState[];
  externalNotifications: ExternalNotificationRecord[];
  authorities: ExternalAuthority[];
  policies: IncidentPolicy[];
  summary: {
    usersCount: number;
    activeUsersCount: number;
    openDispatchesCount: number;
    pendingExternalCount: number;
    authoritiesCount: number;
    policiesCount: number;
  };
};

export function useSiteWorkspace(siteId: string) {
  return useQuery({
    queryKey: ["siteWorkspace", siteId],
    enabled: !!siteId,
    queryFn: async (): Promise<SiteWorkspaceData> => {
      const [users, dispatches, externalNotifications, authorities, policies] =
        await Promise.all([
          usersRepository.listUsers(),
          dispatchRepository.list(),
          externalNotificationsRepository.list(),
          externalAuthoritiesRepository.listBySite(siteId),
          incidentPoliciesRepository.listBySite(siteId),
        ]);

      const siteUsers = users.filter((u: UserProfile) => u.siteId === siteId);
      const siteDispatches = dispatches.filter((d: DispatchState) => d.siteId === siteId);
      const siteExternal = externalNotifications.filter(
        (n: ExternalNotificationRecord) => n.siteId === siteId
      );

      return {
        users: siteUsers,
        dispatches: siteDispatches,
        externalNotifications: siteExternal,
        authorities,
        policies,
        summary: {
          usersCount: siteUsers.length,
          activeUsersCount: siteUsers.filter((u: UserProfile) => u.active !== false).length,
          openDispatchesCount: siteDispatches.filter((d: DispatchState) => isOpenDispatch(d.status)).length,
          pendingExternalCount: siteExternal.filter((n: ExternalNotificationRecord) => isPendingExternal(n.status)).length,
          authoritiesCount: authorities.length,
          policiesCount: policies.length,
        },
      };
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}