import { useEffect, useState } from "react";
import { incidentEventsRepository } from "../services/repositories/incidentEventsRepository";
import type { IncidentEventRecord } from "../domain/models/incidentEvent";

export function useIncidentTimeline() {
  const [items, setItems] = useState<IncidentEventRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    async function loadInitial() {
      setLoading(true);
      const data = await incidentEventsRepository.listLatest();
      setItems(data);
      setLoading(false);
    }

    loadInitial();
  }, []);

  async function loadMore() {
    if (!items.length) return;

    const last = items[items.length - 1];
    if (!last?.createdAt) return;

    setLoadingMore(true);

    const older = await incidentEventsRepository.listBefore(last.createdAt);

    setItems((prev) => [...prev, ...older]);
    setLoadingMore(false);
  }

  return {
    items,
    loading,
    loadingMore,
    loadMore,
  };
}