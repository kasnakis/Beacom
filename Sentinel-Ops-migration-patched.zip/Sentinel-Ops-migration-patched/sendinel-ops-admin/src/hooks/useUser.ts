import { useQuery } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";
import type { UserProfile } from "../domain/models/user";

export function useUser(uid: string) {
  return useQuery<UserProfile | null>({
    queryKey: ["user", uid],
    queryFn: () => usersRepository.getUserProfile(uid),
    enabled: !!uid,
  });
}