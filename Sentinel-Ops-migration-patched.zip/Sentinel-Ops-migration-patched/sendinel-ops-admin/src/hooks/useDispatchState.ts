import { useQuery } from "@tanstack/react-query";
import { dispatchRepository } from "../services/repositories/dispatchRepository";

export function useDispatchState() {
  return useQuery({ queryKey: ["dispatch"], queryFn: dispatchRepository.list });
}
