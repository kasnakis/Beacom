import { useQuery } from "@tanstack/react-query";
import { usersRepository } from "../services/repositories/usersRepository";

type Filters = {
  fromDate?: number | null;
  toDate?: number | null;
};

export function useUserAuditLogs(
  targetUserId?: string | null,
  filters?: Filters
) {
  return useQuery({
    queryKey: ["userAuditLogs", targetUserId, filters],
    enabled: Boolean(targetUserId),
    queryFn: async () => {
      if (!targetUserId) return [];

      const data = await usersRepository.listUserAuditLogs(targetUserId);

      if (!filters) return data;

      return data.filter((log) => {
        const ts = log.createdAt || 0;

        if (filters.fromDate && ts < filters.fromDate) return false;
        if (filters.toDate && ts > filters.toDate) return false;

        return true;
      });
    },
  });
}