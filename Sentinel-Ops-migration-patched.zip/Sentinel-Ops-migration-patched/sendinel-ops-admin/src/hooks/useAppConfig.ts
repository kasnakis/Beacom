import { useQuery } from "@tanstack/react-query";
import { appConfigRepository } from "../services/repositories/appConfigRepository";

export function useAppConfig() {
  return useQuery({
    queryKey: ["app_config"],
    queryFn: () => appConfigRepository.getAppConfig(),
  });
}