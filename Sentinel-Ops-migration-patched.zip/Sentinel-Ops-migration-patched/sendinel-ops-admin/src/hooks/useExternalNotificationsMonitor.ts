import { useQuery } from "@tanstack/react-query";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";
import type { ExternalNotificationRecord } from "../domain/models/externalNotification";
import { useAuth } from "./useAuth";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";

function statusRank(status?: string): number {
  switch (status) {
    case "REQUESTED":
      return 0;
    case "APPROVED":
      return 1;
    case "SENT":
      return 2;
    case "ACKNOWLEDGED":
      return 3;
    case "REJECTED":
      return 4;
    case "CLOSED":
      return 5;
    default:
      return 99;
  }
}

function sortRecords(items: ExternalNotificationRecord[]) {
  return [...items].sort((a, b) => {
    const rankDiff = statusRank(a.status) - statusRank(b.status);
    if (rankDiff !== 0) return rankDiff;

    return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0);
  });
}

export function useExternalNotificationsMonitor() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["externalNotificationsMonitor", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const items = await externalNotificationsRepository.list();
      return sortRecords(items.filter((item) => canViewSiteIncidents(profile, item.siteId)));
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}