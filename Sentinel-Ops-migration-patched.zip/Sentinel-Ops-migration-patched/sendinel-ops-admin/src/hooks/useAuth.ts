import { useSessionStore } from "../store/sessionStore";
import { hasAdminPortalAccess } from "../domain/models/user";

export function useAuth() {
  const firebaseUser = useSessionStore((s) => s.firebaseUser);
  const profile = useSessionStore((s) => s.profile);
  const loading = useSessionStore((s) => s.loading);
  const error = useSessionStore((s) => s.error);

  console.log("AUTH PROFILE:", profile);

  return {
    firebaseUser,
    profile,
    loading,
    error,
    isAuthenticated: !!firebaseUser,
    isAdminPortal: hasAdminPortalAccess(profile),
  };
}