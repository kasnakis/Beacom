import { useQuery } from "@tanstack/react-query";
import { dispatchRepository } from "../services/repositories/dispatchRepository";
import { externalNotificationsRepository } from "../services/repositories/externalNotificationsRepository";
import { incidentsRepository } from "../services/repositories/incidentsRepository";
import type { DispatchState } from "../domain/models/dispatch";
import type { ExternalNotificationRecord } from "../domain/models/externalNotification";
import type { IncidentRecord } from "../domain/models/incident";
import { useAuth } from "./useAuth";
import { canViewSiteIncidents } from "../domain/permissions/siteAccess";

function isTerminalIncident(item?: IncidentRecord): boolean {
  if (!item) return false;

  const status = (item.status || "").toUpperCase();
  return status === "CLOSED" || status === "REJECTED" || status === "CANCELLED";
}

function isPendingFormalClosure(item: IncidentRecord): boolean {
  const status = (item.status || "").toUpperCase();
  return status === "DEACTIVATED" && item.status !== "CLOSED";
}

function isOpenDispatch(item: DispatchState, incident?: IncidentRecord): boolean {
  const status = (item.status || "").toUpperCase();
  if (status === "CLOSED" || status === "CANCELLED" || status === "COMPLETED") {
    return false;
  }

  // Safety guard for older/stale data: a dispatch must not remain operationally open
  // when the parent incident has already been deactivated/closed.
  if (isTerminalIncident(incident)) return false;

  return true;
}

function isPendingExternal(item: ExternalNotificationRecord): boolean {
  return item.status === "REQUESTED" || item.status === "APPROVED" || item.status === "SENT";
}

function isLiveIncident(item: IncidentRecord): boolean {
  const status = (item.status || "").toUpperCase();
  if (isPendingFormalClosure(item)) return true;
  if (item.active === false) return false;
  if (status === "CLOSED" || status === "REJECTED" || status === "CANCELLED") {
    return false;
  }

  return true;
}

export function useLiveDashboard() {
  const { profile } = useAuth();

  return useQuery({
    queryKey: ["liveDashboard", profile?.uid, profile?.siteId, profile?.primarySiteId, profile?.siteMemberships],
    queryFn: async () => {
      const [incidents, dispatches, externalNotifications] = await Promise.all([
        incidentsRepository.list(),
        dispatchRepository.list(),
        externalNotificationsRepository.list(),
      ]);

      const visibleIncidents = incidents.filter((item) => canViewSiteIncidents(profile, item.siteId));

      const liveIncidents = visibleIncidents
        .filter(isLiveIncident)
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      const pendingClosureIncidents = liveIncidents.filter(isPendingFormalClosure);

      const incidentsById = new Map(visibleIncidents.map((item) => [item.id, item]));
      const openDispatches = dispatches.filter((item) => {
        const incident = incidentsById.get(item.incidentId);
        const dispatchSiteId = item.siteId || incident?.siteId;
        return canViewSiteIncidents(profile, dispatchSiteId) && isOpenDispatch(item, incident);
      });
      const openIncidentIds = new Set(openDispatches.map((d) => d.incidentId));

      const visibleExternal = externalNotifications.filter(
        (n: ExternalNotificationRecord) =>
          !!n.incidentId && canViewSiteIncidents(profile, n.siteId || incidentsById.get(n.incidentId)?.siteId)
      );

      const liveExternal = visibleExternal.filter(
        (n: ExternalNotificationRecord) => isPendingExternal(n) && openIncidentIds.has(n.incidentId)
      );

      const responding = openDispatches.reduce(
        (sum, d) => sum + (d.respondingResponders || 0),
        0
      );

      return {
        activeIncidentsCount: liveIncidents.filter((item) => !isPendingFormalClosure(item)).length,
        pendingClosureIncidentsCount: pendingClosureIncidents.length,
        openDispatchesCount: openDispatches.length,
        respondingCount: responding,
        pendingExternalCount: liveExternal.length,
        incidents: liveIncidents,
        dispatches: openDispatches,
        externalNotifications: visibleExternal,
      };
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
}