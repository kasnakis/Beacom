import { useMutation, useQueryClient } from "@tanstack/react-query";
import { incidentPoliciesRepository } from "../services/repositories/incidentPoliciesRepository";

type Payload = {
  siteId: string;
  key: string;
  values: {
    active?: boolean;
    displayName?: string;

    requiresVerification?: boolean;
    verificationRoles?: Record<string, boolean>;
    minimumApprovals?: number;

    postVerifyDispatchMode?: string;
    allowAutoDispatch?: boolean;
    dispatchRoles?: Record<string, boolean>;
    dispatchTeams?: Record<string, boolean>;
    trackingEnabled?: boolean;

    notificationMode?: string;
    notificationTargets?: Record<string, boolean>;

    externalEnabled?: boolean;
    externalAuthorityTypes?: Record<string, boolean>;
    externalMode?: string;

    allowedRequesterRoles?: Record<string, boolean>;
    allowedApproverRoles?: Record<string, boolean>;
    allowedExecutorRoles?: Record<string, boolean>;
    approvalRequired?: boolean;
    acknowledgementRequired?: boolean;
    externalChannels?: Record<string, boolean>;

    closureRoles?: Record<string, boolean>;
    requiresVerifiedIncident?: boolean;
    requiresActionsCompleted?: boolean;
    requiresInvestigationCompleted?: boolean;
    overrideRoles?: Record<string, boolean>;
    overrideRequiresNotes?: boolean;
  };
};

export function useUpdateIncidentPolicy() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ siteId, key, values }: Payload) => {
      await incidentPoliciesRepository.updateBasicFields(siteId, key, values);
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: ["incidentPolicy", variables.siteId, variables.key],
      });

      queryClient.invalidateQueries({
        queryKey: ["incidentPolicies", variables.siteId],
      });

      queryClient.invalidateQueries({
        queryKey: ["siteWorkspace", variables.siteId],
      });
    },
  });
}