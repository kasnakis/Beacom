import { el } from "./el";

export const t = el;

export function translateRole(key?: string) {
  if (!key) return "-";
  return t.roles[key as keyof typeof t.roles] || key;
}

export function translateTeam(key?: string) {
  if (!key) return "-";
  return t.teams[key as keyof typeof t.teams] || key;
}

export function translateStatus(key?: string) {
  if (!key) return "-";
  return t.statuses[key as keyof typeof t.statuses] || key;
}

export function translateVerificationStatus(key?: string) {
  if (!key) return "-";
  return t.verificationStatuses[key as keyof typeof t.verificationStatuses] || key;
}

export function translateSeverity(key?: string) {
  if (!key) return "-";
  return t.severities[key as keyof typeof t.severities] || key;
}