import { create } from "zustand";
import type { User } from "firebase/auth";
import type { UserProfile } from "../domain/models/user";

type SessionState = {
  firebaseUser: User | null;
  profile: UserProfile | null;
  loading: boolean;
  error: string | null;
  setFirebaseUser: (user: User | null) => void;
  setProfile: (profile: UserProfile | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearSession: () => void;
};

export const useSessionStore = create<SessionState>((set) => ({
  firebaseUser: null,
  profile: null,
  loading: true,
  error: null,

  setFirebaseUser: (firebaseUser) => set({ firebaseUser }),
  setProfile: (profile) => set({ profile }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),

  clearSession: () =>
    set({
      firebaseUser: null,
      profile: null,
      loading: false,
      error: null,
    }),
}));