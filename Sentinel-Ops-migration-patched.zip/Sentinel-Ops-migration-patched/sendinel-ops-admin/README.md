# SENDINEL Ops Admin Starter

Starter React + TypeScript + Vite project για το νέο web admin dashboard του SENDINEL Ops.

## Τι περιλαμβάνει
- Login page
- Protected app shell
- Sidebar / topbar / theme toggle
- Overview
- General settings
- Sites
- Users
- Incident types
- Live dashboard / dispatch / external notifications / timeline
- Repository layer για Firebase RTDB
- Permission resolver scaffold

## Πριν το τρέξεις
1. Αντέγραψε το `.env.example` σε `.env`
2. Βάλε τα σωστά Firebase credentials
3. Αν θες deploy σε Hosting, αντέγραψε το `.firebaserc.example` σε `.firebaserc` και βάλε το project id

## Εγκατάσταση
Από τον φάκελο του project:

```bash
npm install
```

## Local development
Από τον φάκελο του project:

```bash
npm run dev
```

## Build
Από τον φάκελο του project:

```bash
npm run build
```

Το build βγαίνει στον φάκελο `dist`.

## Preview build locally
Από τον φάκελο του project:

```bash
npm run preview
```

## Firebase Hosting deploy
### Επιλογή 1: αν έχεις default project στο `.firebaserc`
Από τον φάκελο του project:

```bash
npm run deploy:hosting
```

### Επιλογή 2: αν θες να δηλώσεις project τη στιγμή του deploy
Από τον φάκελο του project:

```bash
firebase login
firebase use --add
npm run build
firebase deploy --only hosting --project YOUR_FIREBASE_PROJECT_ID
```

## Προτεινόμενη σειρά συνέχισης
1. Σύνδεση πραγματικού Firebase project
2. Σύνδεση login με πραγματικό `users/{uid}` profile
3. Γέμισμα repositories με πραγματικά nodes
4. Ενεργοποίηση write actions στις ρυθμίσεις / users / sites / external notifications
5. Incident policy editor v1
6. Live dashboard v1 με πραγματικά δεδομένα
