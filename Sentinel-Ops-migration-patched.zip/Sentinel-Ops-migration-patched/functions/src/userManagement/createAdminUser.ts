import * as admin from "firebase-admin";
import { logger } from "firebase-functions";
import { onCall, HttpsError } from "firebase-functions/v2/https";

const FUNCTION_OPTIONS = {
  region: "europe-west1" as const,
  maxInstances: 10,
};

const DEFAULT_INITIAL_PASSWORD = "sentinel";
const ADMIN_LEVELS = new Set(["GLOBAL_ADMIN", "SITE_ADMIN", "VIEW_ONLY"]);

type CreateAdminUserData = {
  email?: string;
  displayName?: string;
  phone?: string;
  siteId?: string;
  active?: boolean;
  roles?: Record<string, boolean> | string[];
  teams?: Record<string, boolean> | string[];
  platformRoles?: Record<string, boolean> | string[];
  adminAccess?: boolean;
  adminLevel?: string;
  sendEmailVerification?: boolean;
};

type ActorProfile = {
  uid: string;
  email: string;
  displayName: string;
  adminLevel: string;
};

function safeString(value: unknown): string {
  return value == null ? "" : String(value).trim();
}

function normalizeEmail(value: unknown): string {
  return safeString(value).toLowerCase();
}

function normalizeSiteId(value: unknown): string {
  return safeString(value).toLowerCase();
}

function normalizeKey(value: unknown): string {
  return safeString(value).toUpperCase();
}

function assertValidSiteId(siteId: string): void {
  if (!siteId) {
    throw new HttpsError("invalid-argument", "Λείπει το siteId");
  }

  // Firebase RTDB keys cannot contain: . # $ [ ] /
  if (!/^[a-z0-9_-]{2,64}$/.test(siteId)) {
    throw new HttpsError(
      "invalid-argument",
      "Μη έγκυρο siteId. Επιτρέπονται μόνο μικρά λατινικά, αριθμοί, _ και -."
    );
  }
}

function normalizeBooleanMap(
  value: Record<string, boolean> | string[] | undefined,
  normalize: (value: unknown) => string = normalizeKey
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (Array.isArray(value)) {
    for (const item of value) {
      const key = normalize(item);
      if (key) result[key] = true;
    }
    return result;
  }

  if (value && typeof value === "object") {
    for (const [rawKey, rawValue] of Object.entries(value)) {
      const key = normalize(rawKey);
      if (key && rawValue === true) result[key] = true;
    }
  }

  return result;
}

function firstRole(roles: Record<string, boolean>): string | null {
  return Object.keys(roles).find((key) => roles[key] === true) || null;
}

async function loadActorOrThrow(uid: string, email?: string | null): Promise<ActorProfile> {
  const snap = await admin.database().ref(`users/${uid}`).get();
  const actor = snap.exists() ? snap.val() || {} : {};
  const adminLevel = safeString(actor?.adminPermissions?.level);
  const hasAdminPortal = actor?.platformRoles?.ADMIN_PORTAL === true;

  if (!hasAdminPortal || adminLevel !== "GLOBAL_ADMIN") {
    throw new HttpsError(
      "permission-denied",
      "Απαιτείται GLOBAL_ADMIN με ADMIN_PORTAL πρόσβαση"
    );
  }

  return {
    uid,
    email: safeString(actor.email || email),
    displayName: safeString(actor.displayName || actor.name || email || uid),
    adminLevel,
  };
}

function sanitizeCreateData(raw: unknown): Required<Pick<CreateAdminUserData, "email" | "displayName" | "siteId">> &
  Omit<CreateAdminUserData, "email" | "displayName" | "siteId"> {
  const data = (raw || {}) as CreateAdminUserData;
  const email = normalizeEmail(data.email);
  const displayName = safeString(data.displayName);
  const siteId = normalizeSiteId(data.siteId);

  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    throw new HttpsError("invalid-argument", "Μη έγκυρο email χρήστη");
  }

  if (!displayName) {
    throw new HttpsError("invalid-argument", "Λείπει το ονοματεπώνυμο χρήστη");
  }

  assertValidSiteId(siteId);

  return {
    ...data,
    email,
    displayName,
    siteId,
  };
}

async function assertSiteExists(siteId: string): Promise<void> {
  const siteSnap = await admin.database().ref(`sites/${siteId}`).get();
  if (!siteSnap.exists()) {
    throw new HttpsError("not-found", `Δεν βρέθηκε site με ID '${siteId}'`);
  }
}

function buildUserProfile(params: {
  uid: string;
  data: ReturnType<typeof sanitizeCreateData>;
  createdAt: number;
  actor: ActorProfile;
}): Record<string, unknown> {
  const { uid, data, createdAt, actor } = params;
  const active = data.active !== false;
  const roles = normalizeBooleanMap(data.roles);
  const teams = normalizeBooleanMap(data.teams);
  const requestedPlatformRoles = normalizeBooleanMap(data.platformRoles);
  const adminLevel = normalizeKey(data.adminLevel);
  const shouldGrantAdminPortal =
    data.adminAccess === true ||
    ADMIN_LEVELS.has(adminLevel) ||
    requestedPlatformRoles.ADMIN_PORTAL === true;

  const platformRoles: Record<string, boolean> = {
    ...requestedPlatformRoles,
  };

  if (shouldGrantAdminPortal) {
    platformRoles.ADMIN_PORTAL = true;
  }

  const profile: Record<string, unknown> = {
    uid,
    email: data.email,
    displayName: data.displayName,
    phone: safeString(data.phone),
    active,
    enabled: active,
    siteId: data.siteId,
    primarySiteId: data.siteId,
    roles,
    teams,
    operationalRoles: roles,
    role: firstRole(roles),
    platformRoles,
    siteMemberships: {
      [data.siteId]: {
        active,
        roles,
        teams,
        addedAt: createdAt,
        addedBy: actor.uid,
      },
    },
    createdAt,
    createdBy: actor.uid,
    createdByName: actor.displayName,
    updatedAt: createdAt,
    updatedBy: actor.uid,
    source: "WEB_ADMIN_CLOUD_FUNCTION",
  };

  if (shouldGrantAdminPortal) {
    profile.adminPermissions = {
      level: ADMIN_LEVELS.has(adminLevel) ? adminLevel : "VIEW_ONLY",
      grantedAt: createdAt,
      grantedBy: actor.uid,
    };
  }

  return profile;
}

export const createAdminUser = onCall(FUNCTION_OPTIONS, async (request) => {
  if (!request.auth?.uid) {
    throw new HttpsError("unauthenticated", "Απαιτείται σύνδεση χρήστη");
  }

  const actor = await loadActorOrThrow(request.auth.uid, request.auth.token.email);
  const data = sanitizeCreateData(request.data);
  await assertSiteExists(data.siteId);

  const now = Date.now();
  let createdAuthUser: admin.auth.UserRecord | null = null;

  try {
    createdAuthUser = await admin.auth().createUser({
      email: data.email,
      displayName: data.displayName,
      password: DEFAULT_INITIAL_PASSWORD,
      disabled: data.active === false,
      emailVerified: false,
    });

    const uid = createdAuthUser.uid;
    const userProfile = buildUserProfile({
      uid,
      data,
      createdAt: now,
      actor,
    });

    const auditRef = admin.database().ref("user_audit_logs").push();
    const updates: Record<string, unknown> = {
      [`users/${uid}`]: userProfile,
      [`user_audit_logs/${auditRef.key}`]: {
        id: auditRef.key,
        source: "WEB_ADMIN_CLOUD_FUNCTION",
        action: "CREATE_USER",
        targetUserId: uid,
        targetUserEmail: data.email,
        targetSiteId: data.siteId,
        performedBy: actor.uid,
        performedByName: actor.displayName,
        performedByEmail: actor.email,
        performedByAdminLevel: actor.adminLevel,
        changedFields: [
          "authUser",
          "email",
          "displayName",
          "siteId",
          "roles",
          "teams",
          "platformRoles",
          "adminPermissions",
          "siteMemberships",
        ],
        before: null,
        after: userProfile,
        createdAt: now,
      },
    };

    await admin.database().ref().update(updates);

    if (data.sendEmailVerification === true) {
      const verificationLink = await admin.auth().generateEmailVerificationLink(data.email);
      logger.info("CREATE_ADMIN_USER email verification link generated", {
        uid,
        email: data.email,
        verificationLinkGenerated: Boolean(verificationLink),
      });
    }

    logger.info("CREATE_ADMIN_USER completed", {
      uid,
      email: data.email,
      siteId: data.siteId,
      performedBy: actor.uid,
    });

    return {
      ok: true,
      uid,
      email: data.email,
      siteId: data.siteId,
      initialPasswordMode: "DEFAULT_PASSWORD",
      initialPassword: DEFAULT_INITIAL_PASSWORD,
    };
  } catch (error: any) {
    if (createdAuthUser?.uid) {
      try {
        await admin.auth().deleteUser(createdAuthUser.uid);
      } catch (rollbackError) {
        logger.error("CREATE_ADMIN_USER rollback failed", {
          uid: createdAuthUser.uid,
          rollbackError,
        });
      }
    }

    if (error instanceof HttpsError) {
      throw error;
    }

    if (error?.code === "auth/email-already-exists") {
      throw new HttpsError("already-exists", "Υπάρχει ήδη χρήστης Auth με αυτό το email");
    }

    logger.error("CREATE_ADMIN_USER failed", {
      error,
      email: data.email,
      siteId: data.siteId,
      performedBy: actor.uid,
    });

    throw new HttpsError("internal", "Απέτυχε η δημιουργία χρήστη");
  }
});
