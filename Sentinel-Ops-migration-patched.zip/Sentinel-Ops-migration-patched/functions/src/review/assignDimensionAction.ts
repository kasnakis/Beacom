import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";

type ReviewActorContext = {
  userId: string;
  displayName: string;
  siteId: string;
  roles: string[];
  sessionType?: "REAL_SESSION" | "PILOT_SESSION";
};

type AssignDimensionActionData = {
  incidentId: string;
  dimensionKey: string;
  title: string;
  description?: string;
  assignedToUserId: string;
  dueDate?: number;
  actor?: ReviewActorContext;
};

type ReviewMatrixEntry = {
  label?: string;
  roles?: Record<string, boolean>;
  requiredRoles?: Record<string, boolean>;
  minimumApprovals?: number;
};

type DimensionConfigEntry = {
  label?: string;
  ownerRoles?: Record<string, boolean>;
  requiredRoles?: Record<string, boolean>;
  roles?: Record<string, boolean>;
  minimumApprovals?: number;
  assignmentAllowedRoles?: Record<string, boolean>;
  investigationOwnerRoles?: Record<string, boolean>;
};

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  displayName?: string;
  reviewMode?: string;
  reviewMatrix?: Record<string, ReviewMatrixEntry>;
  dimensionConfig?: {
    allowDynamicExpansion?: boolean;
    aggregationMode?: string;
    rejectMode?: string;
    dimensions?: Record<string, DimensionConfigEntry>;
  };
  workflowExtensions?: {
    actions?: {
      enabled?: boolean;
      allowReassignment?: boolean;
      assignableRoles?: Record<string, boolean>;
      requireAcceptance?: boolean;
    };
    investigation?: {
      enabled?: boolean;
      perDimension?: boolean;
      requiredBeforeClosure?: boolean;
    };
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
    reminders?: {
      enabled?: boolean;
      intervalDays?: number;
      notifyAssignee?: boolean;
      targetRoles?: Record<string, boolean>;
    };
  };
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toSafeInt(value: unknown, fallback = 0): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.floor(parsed)) : fallback;
}

function toBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, boolean>;
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  const input = toBooleanRecord(value);
  const result: Record<string, boolean> = {};
  Object.entries(input).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

function uniqueNormalizedKeys(values: unknown[]): string[] {
  return Array.from(
    new Set(
      values
        .map((value) => normalizeKey(value))
        .filter((value) => value.length > 0)
    )
  );
}

function normalizeSelectedReviewDimensions(
  incident: Record<string, any>
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  const selected = incident.selectedReviewDimensions;
  if (Array.isArray(selected)) {
    selected.forEach((item) => {
      const key = normalizeKey(item);
      if (key) result[key] = true;
    });
  } else if (selected && typeof selected === "object") {
    Object.entries(selected as Record<string, unknown>).forEach(([key, enabled]) => {
      const normalizedKey = normalizeKey(key);
      if (normalizedKey && enabled === true) {
        result[normalizedKey] = true;
      }
    });
  }

  const reviewDimensions = incident.reviewDimensions;
  if (reviewDimensions && typeof reviewDimensions === "object") {
    Object.keys(reviewDimensions as Record<string, unknown>).forEach((key) => {
      const normalizedKey = normalizeKey(key);
      if (normalizedKey) {
        result[normalizedKey] = true;
      }
    });
  }

  return result;
}

function resolveReviewMatrix(
  policy: IncidentPolicy
): Record<string, ReviewMatrixEntry> {
  if (!policy.reviewMatrix || typeof policy.reviewMatrix !== "object") {
    return {};
  }
  return policy.reviewMatrix;
}

function resolveDimensionConfig(
  policy: IncidentPolicy
): Record<string, DimensionConfigEntry> {
  const dimensions = policy.dimensionConfig?.dimensions;
  if (!dimensions || typeof dimensions !== "object") {
    return {};
  }
  return dimensions;
}

function resolveDimensionEntry(
  dimensionKey: string,
  policy: IncidentPolicy
): ReviewMatrixEntry | DimensionConfigEntry | null {
  const dimensionConfig = resolveDimensionConfig(policy);
  if (dimensionConfig[dimensionKey]) {
    return dimensionConfig[dimensionKey];
  }

  const reviewMatrix = resolveReviewMatrix(policy);
  if (reviewMatrix[dimensionKey]) {
    return reviewMatrix[dimensionKey];
  }

  return null;
}

function resolveRequiredRolesForDimension(
  dimensionValue: ReviewMatrixEntry | DimensionConfigEntry
): Record<string, boolean> {
  const requiredRoles = sanitizeBooleanRecord(dimensionValue.requiredRoles);
  if (Object.keys(requiredRoles).length > 0) {
    return requiredRoles;
  }

  const ownerRoles = sanitizeBooleanRecord(
    (dimensionValue as DimensionConfigEntry).ownerRoles
  );
  if (Object.keys(ownerRoles).length > 0) {
    return ownerRoles;
  }

  return sanitizeBooleanRecord(dimensionValue.roles);
}

function resolveAssignmentAllowedRoles(
  policy: IncidentPolicy,
  dimensionKey: string,
): Record<string, boolean> {
  const dimensionEntry = resolveDimensionEntry(dimensionKey, policy);
  const dimensionAllowed = sanitizeBooleanRecord(
    (dimensionEntry as DimensionConfigEntry | null)?.assignmentAllowedRoles
  );
  if (Object.keys(dimensionAllowed).length > 0) {
    return dimensionAllowed;
  }

  const globalAllowed = sanitizeBooleanRecord(
    policy.workflowExtensions?.actions?.assignableRoles
  );
  return globalAllowed;
}

function actorHasAtLeastOneRole(
  actorRoles: string[],
  allowedRoles: Record<string, boolean>
): boolean {
  if (Object.keys(allowedRoles).length === 0) return false;
  return actorRoles.some((role) => allowedRoles[normalizeKey(role)] === true);
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .once("value");

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = toBooleanRecord((policy as any).matchCategories);
    const matchTypes = toBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

async function resolveExplicitUserForNotification(
  db: admin.database.Database,
  siteId: string,
  userId: string
): Promise<{
  resolvedUsers: Record<string, any>;
  droppedUsers: Record<string, string>;
}> {
  const resolvedUsers: Record<string, any> = {};
  const droppedUsers: Record<string, string> = {};

  const userSnap = await db.ref(`users/${userId}`).once("value");
  if (!userSnap.exists()) {
    droppedUsers[userId] = "USER_NOT_FOUND";
    return { resolvedUsers, droppedUsers };
  }

  const user = userSnap.val() || {};
  if (user.active === false) {
    droppedUsers[userId] = "USER_INACTIVE";
    return { resolvedUsers, droppedUsers };
  }

  const userSiteId = safeString(user.siteId).toLowerCase();
  if (userSiteId !== safeString(siteId).toLowerCase()) {
    droppedUsers[userId] = "USER_SITE_MISMATCH";
    return { resolvedUsers, droppedUsers };
  }

  const tokenMap: Record<string, string> = {};
  const fcmTokens = user.fcmTokens || {};
  Object.entries(fcmTokens).forEach(([key, value]) => {
    const token = safeString(value);
    if (token) tokenMap[key] = token;
  });

  const fallbackToken = safeString(user.fcmToken);
  if (fallbackToken && !Object.values(tokenMap).includes(fallbackToken)) {
    tokenMap.default = fallbackToken;
  }

  if (Object.keys(tokenMap).length === 0) {
    droppedUsers[userId] = "NO_TOKENS";
    return { resolvedUsers, droppedUsers };
  }

  resolvedUsers[userId] = {
    siteId,
    displayName: safeString(user.displayName) || userId,
    viaRoles: {},
    viaTeams: {},
    viaExplicit: true,
    tokens: tokenMap,
  };

  return {
    resolvedUsers,
    droppedUsers,
  };
}

function buildNotificationRetryBlock() {
  return {
    enabled: false,
    retryCount: 0,
    maxRetryCount: 0,
    retryReason: "",
    nextRetryAt: 0,
  };
}

export const assignDimensionAction = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = admin.database();

    try {
      if (!request.auth) {
        throw new HttpsError("unauthenticated", "User must be authenticated");
      }

      const authUid = request.auth.uid;
      const data = (request.data || {}) as AssignDimensionActionData;

      const incidentId = safeString(data.incidentId);
      const dimensionKey = normalizeKey(data.dimensionKey);
      const title = safeString(data.title);
      const description = safeString(data.description);
      const assignedToUserId = safeString(data.assignedToUserId);
      const dueDate = toSafeInt(data.dueDate, 0);

      if (!incidentId) {
        throw new HttpsError("invalid-argument", "Missing incidentId");
      }

      if (!dimensionKey) {
        throw new HttpsError("invalid-argument", "Missing dimensionKey");
      }

      if (!title) {
        throw new HttpsError("invalid-argument", "Missing title");
      }

      if (!assignedToUserId) {
        throw new HttpsError("invalid-argument", "Missing assignedToUserId");
      }

      const incidentRef = db.ref(`incidents/${incidentId}`);
      const incidentSnap = await incidentRef.once("value");
      if (!incidentSnap.exists()) {
        throw new HttpsError("not-found", "Incident not found");
      }

      const incident = (incidentSnap.val() || {}) as Record<string, any>;

      const authUserSnap = await db.ref(`users/${authUid}`).once("value");
      const authUser = authUserSnap.val() || {};

      const actorUserId =
        safeString(data.actor?.userId) ||
        safeString(authUser.uid) ||
        authUid;

      const actorDisplayName =
        safeString(data.actor?.displayName) ||
        safeString(authUser.displayName) ||
        "Unknown User";

      const actorSiteId =
        safeString(data.actor?.siteId) ||
        safeString(incident.siteId) ||
        safeString(incident.site) ||
        safeString(authUser.siteId);

      const actorRolesRaw = Array.isArray(data.actor?.roles)
        ? data.actor?.roles || []
        : Object.keys(authUser.roles || {});
      const actorRoles = uniqueNormalizedKeys(actorRolesRaw);

      const sessionType =
        data.actor?.sessionType === "PILOT_SESSION"
          ? "PILOT_SESSION"
          : "REAL_SESSION";

      if (!actorSiteId) {
        throw new HttpsError("failed-precondition", "Missing actor siteId");
      }

      const incidentSiteId = safeString(incident.siteId || incident.site);
      if (incidentSiteId.toLowerCase() !== actorSiteId.toLowerCase()) {
        throw new HttpsError("permission-denied", "Actor site does not match incident site");
      }

      if (normalizeKey(incident.category) !== "UNSAFE_CONDITION") {
        throw new HttpsError(
          "failed-precondition",
          "Action assignment is currently supported only for UNSAFE_CONDITION"
        );
      }

      if (normalizeKey(incident.reviewMode) !== "MULTI_DIMENSIONAL") {
        throw new HttpsError(
          "failed-precondition",
          "Incident is not in MULTI_DIMENSIONAL review mode"
        );
      }

      const incidentStatus = normalizeKey(incident.status);
      const verificationStatus = normalizeKey(incident.verificationStatus);
      if (incidentStatus === "CLOSED") {
        throw new HttpsError("failed-precondition", "Cannot assign action to a closed incident");
      }
      if (incidentStatus === "REJECTED" || verificationStatus === "REJECTED") {
        throw new HttpsError("failed-precondition", "Cannot assign action to a rejected incident");
      }

      const resolvedPolicy = await resolveIncidentPolicy(db, actorSiteId, incident);
      if (!resolvedPolicy) {
        throw new HttpsError(
          "failed-precondition",
          "No incident policy found for this incident"
        );
      }

      const { policyKey, policy } = resolvedPolicy;

      if (policy.enabled === false) {
        throw new HttpsError("failed-precondition", "Incident policy is disabled");
      }

      if (policy.workflowExtensions?.actions?.enabled !== true) {
        throw new HttpsError(
          "failed-precondition",
          "Actions workflow is disabled for this policy"
        );
      }

      const selectedDimensions = normalizeSelectedReviewDimensions(incident);
      if (selectedDimensions[dimensionKey] !== true) {
        throw new HttpsError(
          "invalid-argument",
          `Dimension '${dimensionKey}' is not active on this incident`
        );
      }

      const reviewDimensions = (incident.reviewDimensions || {}) as Record<string, any>;
      const dimensionNode = (reviewDimensions[dimensionKey] || {}) as Record<string, any>;
      if (!dimensionNode || Object.keys(dimensionNode).length === 0) {
        throw new HttpsError(
          "failed-precondition",
          `Dimension '${dimensionKey}' review node is missing`
        );
      }

      const dimensionStatus = normalizeKey(dimensionNode.status);
      if (dimensionStatus === "REJECTED") {
        throw new HttpsError(
          "failed-precondition",
          "Cannot assign action to a rejected dimension"
        );
      }

      const dimensionEntry = resolveDimensionEntry(dimensionKey, policy);
      if (!dimensionEntry) {
        throw new HttpsError(
          "failed-precondition",
          `No policy configuration found for dimension '${dimensionKey}'`
        );
      }

      const dimensionLabel =
        safeString((dimensionEntry as any).label) ||
        safeString(dimensionNode.label) ||
        dimensionKey;

      const assignmentAllowedRoles = resolveAssignmentAllowedRoles(policy, dimensionKey);
      if (!actorHasAtLeastOneRole(actorRoles, assignmentAllowedRoles)) {
        throw new HttpsError(
          "permission-denied",
          "Actor is not allowed to assign actions for this dimension"
        );
      }

      const assignedUserSnap = await db.ref(`users/${assignedToUserId}`).once("value");
      if (!assignedUserSnap.exists()) {
        throw new HttpsError("not-found", "Assigned user not found");
      }

      const assignedUser = assignedUserSnap.val() || {};
      if (assignedUser.active === false) {
        throw new HttpsError("failed-precondition", "Assigned user is inactive");
      }

      const assignedUserSiteId = safeString(assignedUser.siteId);
      if (assignedUserSiteId.toLowerCase() !== actorSiteId.toLowerCase()) {
        throw new HttpsError(
          "failed-precondition",
          "Assigned user site does not match incident site"
        );
      }

      const assignedToDisplayName =
        safeString(assignedUser.displayName) || assignedToUserId;
      const assignedToRoles = sanitizeBooleanRecord(assignedUser.roles);

      const requireAcceptance =
        policy.workflowExtensions?.actions?.requireAcceptance === true;

      const now = Date.now();
      const actionRef = db.ref(`incidents/${incidentId}/dimensionActions/${dimensionKey}`).push();
      const actionId = actionRef.key;

      if (!actionId) {
        throw new HttpsError("internal", "Failed to generate action id");
      }

      const actionStatus = requireAcceptance ? "PENDING_ACCEPTANCE" : "ASSIGNED";

      const actionRecord = {
        id: actionId,
        incidentId,
        siteId: actorSiteId,
        category: incident.category || "",
        dimensionKey,
        dimensionLabel,
        title,
        description,
        assignedTo: assignedToUserId,
        assignedToName: assignedToDisplayName,
        assignedToRoles,
        assignedBy: actorUserId,
        assignedByName: actorDisplayName,
        assignedByRoles: actorRoles.reduce<Record<string, boolean>>((acc, role) => {
          acc[role] = true;
          return acc;
        }, {}),
        status: actionStatus,
        acceptanceRequired: requireAcceptance,
        acceptanceStatus: requireAcceptance ? "PENDING" : "NOT_REQUIRED",
        dueDate,
        createdAt: now,
        updatedAt: now,
        updatedBy: actorUserId,
        updatedByName: actorDisplayName,
        acceptedAt: 0,
        acceptedBy: "",
        acceptedByName: "",
        rejectedAt: 0,
        rejectedBy: "",
        rejectedByName: "",
        rejectionReason: "",
        completedAt: 0,
        completedBy: "",
        completedByName: "",
        completionComment: "",
        source: "MOBILE",
      };

      await actionRef.set(actionRecord);

      const dimensionActionsRef = db.ref(`incidents/${incidentId}/dimensionActions/${dimensionKey}`);
      const dimensionActionsSnap = await dimensionActionsRef.once("value");
      const dimensionActions = dimensionActionsSnap.exists()
        ? (dimensionActionsSnap.val() || {}) as Record<string, any>
        : {};

      const openActionCount = Object.values(dimensionActions).filter((value) => {
        const status = normalizeKey((value as Record<string, any>)?.status);
        return status !== "COMPLETED" && status !== "REJECTED";
      }).length;

      const dimensionTracks = (incident.dimensionTracks || {}) as Record<string, any>;
      const currentTrack = (dimensionTracks[dimensionKey] || {}) as Record<string, any>;

      const dimensionInvestigations = {
        ...((incident.dimensionInvestigations || {}) as Record<string, any>),
      };

      const currentInvestigation = (dimensionInvestigations[dimensionKey] || {}) as Record<string, any>;
      dimensionInvestigations[dimensionKey] = {
        ...currentInvestigation,
        dimensionKey,
        label: currentInvestigation.label || dimensionLabel,
        assignedRoles:
          currentInvestigation.assignedRoles ||
          resolveRequiredRolesForDimension(dimensionEntry),
        status: currentInvestigation.status || "PENDING",
        notes: currentInvestigation.notes || "",
        actionsSummary: currentInvestigation.actionsSummary || "",
        updatedAt: now,
        updatedBy: actorUserId,
        updatedByName: actorDisplayName,
        completedAt: Number(currentInvestigation.completedAt ?? 0),
        completedBy: currentInvestigation.completedBy || "",
        completedByName: currentInvestigation.completedByName || "",
      };

      await incidentRef.update({
        [`dimensionTracks/${dimensionKey}/actionsStatus`]: openActionCount > 0 ? "PENDING" : "NOT_REQUIRED",
        [`dimensionTracks/${dimensionKey}/updatedAt`]: now,
        [`dimensionTracks/${dimensionKey}/updatedBy`]: actorUserId,
        [`dimensionTracks/${dimensionKey}/updatedByName`]: actorDisplayName,
        [`dimensionInvestigations/${dimensionKey}`]: dimensionInvestigations[dimensionKey],
      });

      const eventRef = db.ref("incident_events").push();
      await eventRef.set({
        id: eventRef.key,
        incidentId,
        siteId: actorSiteId,
        source: "FUNCTION",
        userId: actorUserId,
        userName: actorDisplayName,
        authUserId: authUid,
        createdAt: now,
        eventType: "INCIDENT_ACTION_ASSIGNED",
        extra: {
          category: incident.category || "",
          severity: incident.severity || "",
          actorRoles,
          sessionType,
          policyKey,
          dimensionKey,
          dimensionLabel,
          actionId,
          title,
          description,
          assignedToUserId,
          assignedToName: assignedToDisplayName,
          dueDate,
          requireAcceptance,
          actionStatus,
          openActionCount,
          previousActionsStatus: currentTrack.actionsStatus || "NOT_REQUIRED",
          nextActionsStatus: openActionCount > 0 ? "PENDING" : "NOT_REQUIRED",
        },
      });

      const resolution = await resolveExplicitUserForNotification(
        db,
        actorSiteId,
        assignedToUserId
      );

      const requestRef = db.ref("notification_requests").push();
      await requestRef.set({
        id: requestRef.key,
        incidentId,
        siteId: actorSiteId,
        category: incident.category || "",
        type: "ACTION_ASSIGNMENT",
        status: "PENDING",
        meta: {
          schemaVersion: 2,
          source: "SYSTEM",
          triggerEvent: "ACTION_ASSIGNED",
          createdAt: now,
          processedAt: 0,
          lastAttemptAt: 0,
        },
        policy: {
          policyUsed: true,
          policySourcePath: `site_config_data/${actorSiteId}/incident_policies/${policyKey}`,
          matchedPolicyIds: {
            [policyKey]: true,
          },
          dynamicTargeting: true,
          dynamicTargetSource: "UNSAFE_CONDITION_ACTION_ASSIGNMENT",
        },
        targeting: {
          mode: "DIRECT_USER",
          siteScope: "SITE_ONLY",
          siteId: actorSiteId,
          targetRoles: {},
          targetTeams: {},
          explicitUsers: {
            [assignedToUserId]: true,
          },
        },
        context: {
          dimensionKey,
          dimensionLabel,
          actionId,
          actionTitle: title,
          actionStatus,
          dueDate,
        },
        resolution: {
          resolvedUsers: resolution.resolvedUsers,
          resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
          droppedUsers: resolution.droppedUsers,
          droppedUserCount: Object.keys(resolution.droppedUsers).length,
        },
        delivery: {
          channel: "FCM",
          attemptedRecipientCount: 0,
          validRecipientCount: 0,
          successCount: 0,
          failureCount: 0,
          invalidTokenCount: 0,
          deliveryResults: {},
          failedTokens: [],
          invalidTokens: [],
          retryableFailedTokens: [],
        },
        retry: buildNotificationRetryBlock(),
      });

      logger.info("assignDimensionAction completed", {
        incidentId,
        dimensionKey,
        dimensionLabel,
        actionId,
        actorUserId,
        actorRoles,
        assignedToUserId,
        requireAcceptance,
        actionStatus,
        notificationRequestId: requestRef.key,
        openActionCount,
      });

      return {
        ok: true,
        incidentId,
        dimensionKey,
        actionId,
        assignedToUserId,
        assignedToName: assignedToDisplayName,
        actionStatus,
        requireAcceptance,
        dueDate,
        notificationRequestId: requestRef.key,
        openActionCount,
      };
    } catch (error: any) {
      logger.error("assignDimensionAction failed", {
        error: error?.message || String(error),
        stack: error?.stack || null,
        rawData: request.data ?? null,
        authUid: request.auth?.uid || null,
      });

      if (error instanceof HttpsError) {
        throw error;
      }

      throw new HttpsError(
        "internal",
        error?.message || "Failed to assign dimension action"
      );
    }
  }
);