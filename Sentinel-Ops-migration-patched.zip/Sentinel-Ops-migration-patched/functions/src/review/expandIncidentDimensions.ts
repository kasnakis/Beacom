import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";
import { recomputeIncidentAggregation } from "./recomputeIncidentAggregation";

type ReviewActorContext = {
  userId: string;
  displayName: string;
  siteId: string;
  roles: string[];
  sessionType?: "REAL_SESSION" | "PILOT_SESSION";
};

type ExpandIncidentDimensionsData = {
  incidentId: string;
  addedDimensions: string[];
  comment?: string;
  actor?: ReviewActorContext;
};

type ReviewMatrixEntry = {
  label?: string;
  roles?: Record<string, boolean>;
  requiredRoles?: Record<string, boolean>;
  minimumApprovals?: number;
};

type DimensionConfigEntry = {
  label?: string;
  ownerRoles?: Record<string, boolean>;
  requiredRoles?: Record<string, boolean>;
  roles?: Record<string, boolean>;
  minimumApprovals?: number;
};

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  reviewMode?: string;
  reviewMatrix?: Record<string, ReviewMatrixEntry>;
  dimensionConfig?: {
    allowDynamicExpansion?: boolean;
    aggregationMode?: string;
    rejectMode?: string;
    dimensions?: Record<string, DimensionConfigEntry>;
  };
  workflowExtensions?: Record<string, unknown>;
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, boolean>;
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  const input = toBooleanRecord(value);
  const result: Record<string, boolean> = {};
  Object.entries(input).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[key] = true;
    }
  });
  return result;
}

function uniqueNormalizedKeys(values: unknown[]): string[] {
  return Array.from(
    new Set(
      values
        .map((v) => normalizeKey(v))
        .filter((v) => v.length > 0)
    )
  );
}

function resolveReviewMatrix(
  policy: IncidentPolicy
): Record<string, ReviewMatrixEntry> {
  if (!policy.reviewMatrix || typeof policy.reviewMatrix !== "object") {
    return {};
  }
  return policy.reviewMatrix;
}

function resolveDimensionConfig(
  policy: IncidentPolicy
): Record<string, DimensionConfigEntry> {
  const dimensions = policy.dimensionConfig?.dimensions;
  if (!dimensions || typeof dimensions !== "object") {
    return {};
  }
  return dimensions;
}

function resolveDimensionEntry(
  dimensionKey: string,
  policy: IncidentPolicy
): ReviewMatrixEntry | DimensionConfigEntry | null {
  const dimensionConfig = resolveDimensionConfig(policy);
  if (dimensionConfig[dimensionKey]) {
    return dimensionConfig[dimensionKey];
  }

  const reviewMatrix = resolveReviewMatrix(policy);
  if (reviewMatrix[dimensionKey]) {
    return reviewMatrix[dimensionKey];
  }

  return null;
}

function resolveRequiredRolesForDimension(
  dimensionValue: ReviewMatrixEntry | DimensionConfigEntry
): Record<string, boolean> {
  const requiredRoles = sanitizeBooleanRecord(dimensionValue.requiredRoles);
  if (Object.keys(requiredRoles).length > 0) {
    return requiredRoles;
  }

  const ownerRoles = sanitizeBooleanRecord(
    (dimensionValue as DimensionConfigEntry).ownerRoles
  );
  if (Object.keys(ownerRoles).length > 0) {
    return ownerRoles;
  }

  return sanitizeBooleanRecord(dimensionValue.roles);
}

function normalizeSelectedReviewDimensions(
  incident: Record<string, any>
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  const selected = incident.selectedReviewDimensions;
  if (Array.isArray(selected)) {
    selected.forEach((item) => {
      const key = normalizeKey(item);
      if (key) result[key] = true;
    });
  } else if (selected && typeof selected === "object") {
    Object.entries(selected as Record<string, unknown>).forEach(([key, enabled]) => {
      const normalizedKey = normalizeKey(key);
      if (normalizedKey && enabled === true) {
        result[normalizedKey] = true;
      }
    });
  }

  const reviewDimensions = incident.reviewDimensions;
  if (reviewDimensions && typeof reviewDimensions === "object") {
    Object.keys(reviewDimensions as Record<string, unknown>).forEach((key) => {
      const normalizedKey = normalizeKey(key);
      if (normalizedKey) {
        result[normalizedKey] = true;
      }
    });
  }

  return result;
}

function actorCanExpandDimensions(
  incident: Record<string, any>,
  actorRoles: string[]
): boolean {
  const normalizedActorRoles = actorRoles.map(normalizeKey).filter(Boolean);

  if (normalizedActorRoles.length === 0) return false;

  const pendingRoles = sanitizeBooleanRecord(incident.pendingRoles);
  const completedRoles = sanitizeBooleanRecord(incident.completedRoles);
  const reviewDimensions = (incident.reviewDimensions || {}) as Record<string, any>;

  if (
    normalizedActorRoles.some(
      (role) => pendingRoles[role] === true || completedRoles[role] === true
    )
  ) {
    return true;
  }

  for (const value of Object.values(reviewDimensions)) {
    const requiredRoles = sanitizeBooleanRecord((value as Record<string, any>).requiredRoles);
    if (normalizedActorRoles.some((role) => requiredRoles[role] === true)) {
      return true;
    }
  }

  return false;
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .once("value");

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = toBooleanRecord((policy as any).matchCategories);
    const matchTypes = toBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

async function resolveUsersWithProvenance(
  db: admin.database.Database,
  siteId: string,
  targetRoles: Record<string, boolean>
): Promise<{
  resolvedUsers: Record<string, any>;
  droppedUsers: Record<string, string>;
}> {
  const usersSnap = await db.ref("users").once("value");
  const users = usersSnap.exists() ? usersSnap.val() || {} : {};

  const resolvedUsers: Record<string, any> = {};
  const droppedUsers: Record<string, string> = {};

  for (const [uid, user] of Object.entries<any>(users)) {
    if (!user) continue;

    if (uid === "anonymous") {
      droppedUsers[uid] = "ANONYMOUS_NOT_TARGETABLE";
      continue;
    }

    if (user.active === false) {
      droppedUsers[uid] = "USER_INACTIVE";
      continue;
    }

    const userSiteId = safeString(user.siteId).toLowerCase();
    if (userSiteId !== safeString(siteId).toLowerCase()) {
      continue;
    }

    const roleMap = sanitizeBooleanRecord(user.roles);
    const matchedRoles: Record<string, boolean> = {};

    Object.keys(targetRoles).forEach((role) => {
      if (roleMap[role] === true) {
        matchedRoles[role] = true;
      }
    });

    if (Object.keys(matchedRoles).length === 0) {
      continue;
    }

    const tokenMap: Record<string, string> = {};
    const fcmTokens = user.fcmTokens || {};
    Object.entries(fcmTokens).forEach(([key, value]) => {
      const token = safeString(value);
      if (token) tokenMap[key] = token;
    });

    const fallbackToken = safeString(user.fcmToken);
    if (fallbackToken && !Object.values(tokenMap).includes(fallbackToken)) {
      tokenMap.default = fallbackToken;
    }

    if (Object.keys(tokenMap).length === 0) {
      droppedUsers[uid] = "NO_TOKENS";
      continue;
    }

    resolvedUsers[uid] = {
      siteId,
      displayName: safeString(user.displayName) || uid,
      viaRoles: matchedRoles,
      viaTeams: {},
      viaExplicit: false,
      tokens: tokenMap,
    };
  }

  return {
    resolvedUsers,
    droppedUsers,
  };
}

function buildNotificationRetryBlock() {
  return {
    enabled: false,
    retryCount: 0,
    maxRetryCount: 0,
    retryReason: "",
    nextRetryAt: 0,
  };
}

export const expandIncidentDimensions = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = admin.database();

    try {
      if (!request.auth) {
        throw new HttpsError("unauthenticated", "User must be authenticated");
      }

      const authUid = request.auth.uid;
      const data = (request.data || {}) as ExpandIncidentDimensionsData;

      const incidentId = safeString(data.incidentId);
      const addedDimensions = uniqueNormalizedKeys(
        Array.isArray(data.addedDimensions) ? data.addedDimensions : []
      );
      const comment = safeString(data.comment);

      if (!incidentId) {
        throw new HttpsError("invalid-argument", "Missing incidentId");
      }

      if (addedDimensions.length === 0) {
        throw new HttpsError("invalid-argument", "No dimensions provided");
      }

      const incidentRef = db.ref(`incidents/${incidentId}`);
      const incidentSnap = await incidentRef.once("value");
      if (!incidentSnap.exists()) {
        throw new HttpsError("not-found", "Incident not found");
      }

      const incident = (incidentSnap.val() || {}) as Record<string, any>;

      const authUserSnap = await db.ref(`users/${authUid}`).once("value");
      const authUser = authUserSnap.val() || {};

      const actorUserId =
        safeString(data.actor?.userId) ||
        safeString(authUser.uid) ||
        authUid;

      const actorDisplayName =
        safeString(data.actor?.displayName) ||
        safeString(authUser.displayName) ||
        "Unknown User";

      const actorSiteId =
        safeString(data.actor?.siteId) ||
        safeString(incident.siteId) ||
        safeString(incident.site) ||
        safeString(authUser.siteId);

      const actorRolesRaw = Array.isArray(data.actor?.roles)
        ? data.actor?.roles || []
        : Object.keys(authUser.roles || {});
      const actorRoles = uniqueNormalizedKeys(actorRolesRaw);

      const sessionType =
        data.actor?.sessionType === "PILOT_SESSION"
          ? "PILOT_SESSION"
          : "REAL_SESSION";

      if (!actorSiteId) {
        throw new HttpsError("failed-precondition", "Missing actor siteId");
      }

      if (
        safeString(incident.siteId || incident.site).toLowerCase() !==
        actorSiteId.toLowerCase()
      ) {
        throw new HttpsError("permission-denied", "Actor site does not match incident site");
      }

      if (normalizeKey(incident.category) !== "UNSAFE_CONDITION") {
        throw new HttpsError(
          "failed-precondition",
          "Dimension expansion is supported only for UNSAFE_CONDITION"
        );
      }

      if (normalizeKey(incident.reviewMode) !== "MULTI_DIMENSIONAL") {
        throw new HttpsError(
          "failed-precondition",
          "Incident is not in MULTI_DIMENSIONAL review mode"
        );
      }

      const incidentStatus = normalizeKey(incident.status);
      const verificationStatus = normalizeKey(incident.verificationStatus);

      if (incidentStatus === "CLOSED") {
        throw new HttpsError("failed-precondition", "Cannot expand a closed incident");
      }

      if (incidentStatus === "REJECTED" || verificationStatus === "REJECTED") {
        throw new HttpsError("failed-precondition", "Cannot expand a rejected incident");
      }

      if (!actorCanExpandDimensions(incident, actorRoles)) {
        throw new HttpsError(
          "permission-denied",
          "Actor is not allowed to expand dimensions for this incident"
        );
      }

      const resolvedPolicy = await resolveIncidentPolicy(db, actorSiteId, incident);
      if (!resolvedPolicy) {
        throw new HttpsError(
          "failed-precondition",
          "No incident policy found for this incident"
        );
      }

      const { policyKey, policy } = resolvedPolicy;
      const reviewMatrix = resolveReviewMatrix(policy);
      const dimensionConfig = resolveDimensionConfig(policy);

      if (
        Object.keys(reviewMatrix).length === 0 &&
        Object.keys(dimensionConfig).length === 0
      ) {
        throw new HttpsError(
          "failed-precondition",
          "Policy dimensionConfig/reviewMatrix is missing"
        );
      }

      const selectedReviewDimensions = normalizeSelectedReviewDimensions(incident);
      const existingReviewDimensions = ((incident.reviewDimensions || {}) as Record<string, any>);
      const dimensionsToAdd = addedDimensions.filter(
        (dimensionKey) => selectedReviewDimensions[dimensionKey] !== true
      );

      if (dimensionsToAdd.length === 0) {
        throw new HttpsError(
          "already-exists",
          "All requested dimensions already exist on the incident"
        );
      }

      const now = Date.now();
      const incidentUpdates: Record<string, any> = {};
      const newlyAddedRoles: Record<string, boolean> = {};
      const addedDimensionDetails: Array<{
        key: string;
        label: string;
        requiredRoles: Record<string, boolean>;
      }> = [];

      for (const dimensionKey of dimensionsToAdd) {
        const dimensionEntry = resolveDimensionEntry(dimensionKey, policy);
        if (!dimensionEntry) {
          throw new HttpsError(
            "invalid-argument",
            `Unknown dimension '${dimensionKey}' for UNSAFE_CONDITION policy`
          );
        }

        const requiredRoles = resolveRequiredRolesForDimension(dimensionEntry);
        if (Object.keys(requiredRoles).length === 0) {
          throw new HttpsError(
            "failed-precondition",
            `Dimension '${dimensionKey}' has no requiredRoles/ownerRoles in policy`
          );
        }

        const label = safeString(dimensionEntry.label) || dimensionKey;
        const minimumApprovals = Math.max(
          1,
          Number(dimensionEntry.minimumApprovals ?? 1)
        );

        incidentUpdates[`selectedReviewDimensions/${dimensionKey}`] = true;
        incidentUpdates[`reviewDimensions/${dimensionKey}`] = {
          label,
          requiredRoles,
          minimumApprovals,
          recognizeCount: 0,
          rejectCount: 0,
          completedRoles: {},
          status: "PENDING",
          lastUpdatedAt: now,
        };

        incidentUpdates[`dimensionTracks/${dimensionKey}`] = {
          active: true,
          dimensionKey,
          label,
          ownerRoles: requiredRoles,
          reviewStatus: "PENDING",
          decision: "",
          decisionBy: "",
          decisionByName: "",
          decisionAt: 0,
          decisionComment: "",
          investigationStatus: "NOT_STARTED",
          actionsStatus: "NOT_REQUIRED",
          closureStatus: "OPEN",
          updatedAt: now,
          updatedBy: actorUserId,
          updatedByName: actorDisplayName,
        };

        Object.keys(requiredRoles).forEach((roleKey) => {
          newlyAddedRoles[roleKey] = true;
        });

        addedDimensionDetails.push({
          key: dimensionKey,
          label,
          requiredRoles,
        });
      }

      await incidentRef.update(incidentUpdates);

      const recomputeResult = await recomputeIncidentAggregation(db, incidentId);

      const eventRef = db.ref("incident_events").push();
      await eventRef.set({
        id: eventRef.key,
        incidentId,
        siteId: actorSiteId,
        source: "FUNCTION",
        userId: actorUserId,
        userName: actorDisplayName,
        authUserId: authUid,
        createdAt: now,
        eventType: "INCIDENT_DIMENSIONS_EXPANDED",
        extra: {
          policyKey,
          category: incident.category || "",
          severity: incident.severity || "",
          actorRoles,
          sessionType,
          comment,
          addedDimensions: addedDimensionDetails.map((item) => item.key),
          addedDimensionLabels: addedDimensionDetails.reduce<Record<string, string>>((acc, item) => {
            acc[item.key] = item.label;
            return acc;
          }, {}),
          newTargetRoles: newlyAddedRoles,
          reviewAggregationStatus: recomputeResult.reviewAggregationStatus,
          finalIncidentStatus: recomputeResult.incidentStatus,
          finalVerificationStatus: recomputeResult.verificationStatus,
        },
      });

      const resolution = await resolveUsersWithProvenance(
        db,
        actorSiteId,
        newlyAddedRoles
      );

      const requestRef = db.ref("notification_requests").push();
      await requestRef.set({
        id: requestRef.key,
        incidentId,
        siteId: actorSiteId,
        category: incident.category || "",
        type: "VERIFY_INCIDENT",
        status: "PENDING",
        meta: {
          schemaVersion: 2,
          source: "SYSTEM",
          triggerEvent: "INCIDENT_DIMENSIONS_EXPANDED",
          createdAt: now,
          processedAt: 0,
          lastAttemptAt: 0,
        },
        policy: {
          policyUsed: true,
          policySourcePath: `site_config_data/${actorSiteId}/incident_policies/${policyKey}`,
          matchedPolicyIds: {
            [policyKey]: true,
          },
          dynamicTargeting: true,
          dynamicTargetSource: "UNSAFE_CONDITION_DIMENSION_EXPANSION",
        },
        targeting: {
          mode: "VERIFY_FIRST",
          siteScope: "SITE_ONLY",
          siteId: actorSiteId,
          targetRoles: newlyAddedRoles,
          targetTeams: {},
          explicitUsers: {},
        },
        resolution: {
          resolvedUsers: resolution.resolvedUsers,
          resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
          droppedUsers: resolution.droppedUsers,
          droppedUserCount: Object.keys(resolution.droppedUsers).length,
        },
        delivery: {
          channel: "FCM",
          attemptedRecipientCount: 0,
          validRecipientCount: 0,
          successCount: 0,
          failureCount: 0,
          invalidTokenCount: 0,
          deliveryResults: {},
          failedTokens: [],
          invalidTokens: [],
          retryableFailedTokens: [],
        },
        retry: buildNotificationRetryBlock(),
      });

      logger.info("expandIncidentDimensions completed", {
        incidentId,
        actorUserId,
        actorRoles,
        actorSiteId,
        addedDimensions: dimensionsToAdd,
        newlyAddedRoles: Object.keys(newlyAddedRoles),
        notificationRequestId: requestRef.key,
        reviewAggregationStatus: recomputeResult.reviewAggregationStatus,
        incidentStatus: recomputeResult.incidentStatus,
        verificationStatus: recomputeResult.verificationStatus,
      });

      return {
        ok: true,
        incidentId,
        addedDimensions: dimensionsToAdd,
        addedRoles: Object.keys(newlyAddedRoles),
        notificationRequestId: requestRef.key,
        reviewAggregationStatus: recomputeResult.reviewAggregationStatus,
        verificationStatus: recomputeResult.verificationStatus,
        incidentStatus: recomputeResult.incidentStatus,
      };
    } catch (error: any) {
      logger.error("expandIncidentDimensions failed", {
        error: error?.message || String(error),
        stack: error?.stack || null,
        rawData: request.data ?? null,
        authUid: request.auth?.uid || null,
      });

      if (error instanceof HttpsError) {
        throw error;
      }

      throw new HttpsError(
        "internal",
        error?.message || "Failed to expand incident dimensions"
      );
    }
  }
);