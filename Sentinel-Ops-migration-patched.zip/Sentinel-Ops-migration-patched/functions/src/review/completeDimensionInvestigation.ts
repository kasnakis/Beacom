import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as admin from "firebase-admin";

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  closure?: {
    allowedRoles?: Record<string, boolean>;
    requiresVerifiedIncident?: boolean;
    overrideRoles?: Record<string, boolean>;
    overrideRequiresNotes?: boolean;
  };
  workflowExtensions?: {
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
  };
};

type ActorContext = {
  userId?: string;
  displayName?: string;
  siteId?: string;
  roles?: string[];
  sessionType?: string;
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

function sanitizeRoleArray(value: unknown): Record<string, boolean> {
  if (!Array.isArray(value)) return {};
  const result: Record<string, boolean> = {};
  value.forEach((item) => {
    const key = normalizeKey(item);
    if (key) result[key] = true;
  });
  return result;
}

function hasAnyRole(
  actorRoles: Record<string, boolean>,
  allowedRoles: Record<string, boolean>
): boolean {
  if (Object.keys(allowedRoles).length === 0) return true;
  return Object.keys(actorRoles).some((role) => allowedRoles[normalizeKey(role)] === true);
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .get();

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = sanitizeBooleanRecord((policy as any).matchCategories);
    const matchTypes = sanitizeBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

function resolveDimensionsReviewed(
  dimensionTracks: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const track = (dimensionTracks || {})[dimensionKey] || {};
    const reviewStatus = normalizeKey(track.reviewStatus);
    if (reviewStatus !== "RECOGNIZED") {
      return false;
    }
  }
  return true;
}

function resolveActionsCompleted(
  dimensionActions: Record<string, any>
): boolean {
  for (const actions of Object.values(dimensionActions || {})) {
    for (const action of Object.values((actions || {}) as Record<string, any>)) {
      const status = normalizeKey((action as Record<string, any>).status);
      if (status !== "COMPLETED") {
        return false;
      }
    }
  }
  return true;
}

function resolveInvestigationsCompleted(
  dimensionInvestigations: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const investigation = (dimensionInvestigations || {})[dimensionKey] || {};
    const status = normalizeKey(investigation.status);
    if (status !== "COMPLETED") {
      return false;
    }
  }
  return true;
}

async function tryAutoCloseIncident(
  db: admin.database.Database,
  incidentRef: admin.database.Reference,
  incidentId: string,
  incident: Record<string, any>,
  siteId: string
): Promise<boolean> {
  const resolvedPolicy = await resolveIncidentPolicy(db, siteId, incident);
  if (!resolvedPolicy) return false;

  const { policyKey, policy } = resolvedPolicy;

  const verificationStatus = normalizeKey(incident.verificationStatus);
  const incidentStatus = normalizeKey(incident.status);

  if (incidentStatus === "CLOSED" || incidentStatus === "REJECTED") return false;
  if (verificationStatus === "REJECTED") return false;

  const requiresVerifiedIncident =
    policy.closure?.requiresVerifiedIncident !== false;

  if (
    requiresVerifiedIncident &&
    verificationStatus !== "VERIFIED" &&
    verificationStatus !== "AUTO_VERIFIED"
  ) {
    return false;
  }

  const closureMode =
    normalizeKey(policy.workflowExtensions?.closure?.mode) || "SINGLE_TRACK";

  const requiresActionsCompleted =
    policy.workflowExtensions?.closure?.requiresActionsCompleted === true;

  const requiresInvestigationCompleted =
    policy.workflowExtensions?.closure?.requiresInvestigationCompleted === true;

  const selectedReviewDimensions = sanitizeBooleanRecord(incident.selectedReviewDimensions);
  const dimensionTracks = (incident.dimensionTracks || {}) as Record<string, any>;
  const dimensionActions = (incident.dimensionActions || {}) as Record<string, any>;
  const dimensionInvestigations = (incident.dimensionInvestigations || {}) as Record<string, any>;

  if (closureMode === "ALL_TRACKS_REQUIRED") {
    const allDimensionsReviewed = resolveDimensionsReviewed(
      dimensionTracks,
      selectedReviewDimensions
    );
    if (!allDimensionsReviewed) return false;
  }

  if (requiresActionsCompleted) {
    const actionsCompleted = resolveActionsCompleted(dimensionActions);
    if (!actionsCompleted) return false;
  }

  if (requiresInvestigationCompleted) {
    const investigationsCompleted = resolveInvestigationsCompleted(
      dimensionInvestigations,
      selectedReviewDimensions
    );
    if (!investigationsCompleted) return false;
  }

  const now = Date.now();

  await incidentRef.update({
    status: "CLOSED",
    active: false,
    closedAt: now,
    closedBy: "SYSTEM AUTO CLOSE",
    closedByUid: "system_auto_close",
    closureNotes: "Αυτόματο κλείσιμο μετά την ολοκλήρωση όλων των απαιτούμενων διερευνήσεων/ενεργειών",
    closureMode: "AUTO",
  });

  const eventRef = db.ref("incident_events").push();
  await eventRef.set({
    id: eventRef.key,
    incidentId,
    siteId,
    eventType: "INCIDENT_CLOSED",
    createdAt: now,
    userId: "system_auto_close",
    userName: "SYSTEM AUTO CLOSE",
    authUserId: null,
    source: "FUNCTION",
    extra: {
      category: incident.category || "",
      policyKey,
      closureNotes: "Αυτόματο κλείσιμο μετά την ολοκλήρωση όλων των απαιτούμενων διερευνήσεων/ενεργειών",
      actorRoles: {},
      sessionType: "SYSTEM",
      closureMode: "AUTO",
    },
  });

  return true;
}

export const completeDimensionInvestigation = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const authUserId = request.auth?.uid;
    const { incidentId, dimensionKey, notes, actor } = request.data || {};
    const actorContext = (actor || {}) as ActorContext;

    if (!authUserId) {
      throw new HttpsError("unauthenticated", "Μη εξουσιοδοτημένη πρόσβαση");
    }

    if (!incidentId || !dimensionKey) {
      throw new HttpsError("invalid-argument", "Λείπουν απαραίτητες παράμετροι");
    }

    const db = admin.database();

    const incidentRef = db.ref(`incidents/${incidentId}`);
    const snapshot = await incidentRef.get();

    if (!snapshot.exists()) {
      throw new HttpsError("not-found", "Το συμβάν δεν βρέθηκε");
    }

    const incident = snapshot.val() || {};
    const siteId = safeString(incident.siteId || incident.site);

    if (!siteId) {
      throw new HttpsError("failed-precondition", "Δεν βρέθηκε site συμβάντος");
    }

    const actorUserId = safeString(actorContext.userId) || authUserId;
    const actorDisplayName = safeString(actorContext.displayName) || authUserId;
    const actorSiteId = safeString(actorContext.siteId) || siteId;
    const actorRoles = sanitizeRoleArray(actorContext.roles);

    if (normalizeKey(actorSiteId) !== normalizeKey(siteId)) {
      throw new HttpsError(
        "permission-denied",
        "Ο χρήστης δεν ανήκει στο site του συμβάντος"
      );
    }

    const normalizedDimension = normalizeKey(dimensionKey);

    const investigationRef = incidentRef
      .child("dimensionInvestigations")
      .child(normalizedDimension);

    const investigationSnap = await investigationRef.get();

    if (!investigationSnap.exists()) {
      throw new HttpsError(
        "failed-precondition",
        "Δεν βρέθηκε διερεύνηση για τη συγκεκριμένη διάσταση"
      );
    }

    const investigation = investigationSnap.val() || {};
    const currentStatus = normalizeKey(investigation.status);
    const assignedRoles = sanitizeBooleanRecord(investigation.assignedRoles);

    if (!hasAnyRole(actorRoles, assignedRoles)) {
      throw new HttpsError(
        "permission-denied",
        "Δεν έχετε ρόλο για ολοκλήρωση αυτής της διερεύνησης"
      );
    }

    if (currentStatus === "COMPLETED") {
      throw new HttpsError(
        "failed-precondition",
        "Η διερεύνηση έχει ήδη ολοκληρωθεί"
      );
    }

    const now = Date.now();
    const completedByName = actorDisplayName;
    const updates: Record<string, unknown> = {
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/status`]: "COMPLETED",
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/completedAt`]: now,
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/completedBy`]: actorUserId,
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/completedByName`]: completedByName,
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/notes`]: safeString(notes),
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/updatedAt`]: now,
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/updatedBy`]: actorUserId,
      [`incidents/${incidentId}/dimensionInvestigations/${normalizedDimension}/updatedByName`]: completedByName,
      [`incidents/${incidentId}/dimensionTracks/${normalizedDimension}/investigationStatus`]: "COMPLETED",
      [`incidents/${incidentId}/dimensionTracks/${normalizedDimension}/closureStatus`]: "READY_FOR_CLOSURE",
      [`incidents/${incidentId}/dimensionTracks/${normalizedDimension}/updatedAt`]: now,
      [`incidents/${incidentId}/dimensionTracks/${normalizedDimension}/updatedBy`]: actorUserId,
      [`incidents/${incidentId}/dimensionTracks/${normalizedDimension}/updatedByName`]: completedByName,
    };

    Object.keys(assignedRoles).forEach((role) => {
      updates[`incidents/${incidentId}/completedRoles/${role}`] = true;
      updates[`incidents/${incidentId}/pendingRoles/${role}`] = null;
    });

    await db.ref().update(updates);

    const eventRef = db.ref("incident_events").push();

    await eventRef.set({
      id: eventRef.key,
      incidentId,
      siteId,
      eventType: "INCIDENT_INVESTIGATION_COMPLETED",
      createdAt: now,
      userId: actorUserId,
      userName: completedByName,
      authUserId,
      source: "FUNCTION",
      extra: {
        dimensionKey: normalizedDimension,
        notes: safeString(notes),
        actorRoles,
        sessionType: safeString(actorContext.sessionType) || "REAL_SESSION",
      },
    });

    const refreshedIncidentSnap = await incidentRef.get();
    const refreshedIncident = refreshedIncidentSnap.val() || {};
    const autoClosed = await tryAutoCloseIncident(
      db,
      incidentRef,
      incidentId,
      refreshedIncident,
      safeString(refreshedIncident.siteId || refreshedIncident.site)
    );

    return {
      ok: true,
      incidentId,
      dimensionKey: normalizedDimension,
      status: "COMPLETED",
      autoClosed,
    };
  }
);