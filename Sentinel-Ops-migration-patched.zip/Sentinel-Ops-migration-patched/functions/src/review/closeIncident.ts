import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type CloseIncidentRequest = {
  incidentId: string;
  closureNotes?: string;
  actor?: {
    userId?: string;
    displayName?: string;
    siteId?: string;
    roles?: string[];
    sessionType?: string;
  };
};

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  closure?: {
    allowedRoles?: Record<string, boolean>;
    requiresVerifiedIncident?: boolean;
    overrideRoles?: Record<string, boolean>;
    overrideRequiresNotes?: boolean;
  };
  workflowExtensions?: {
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
    investigation?: {
      enabled?: boolean;
      perDimension?: boolean;
      requiredBeforeClosure?: boolean;
      requiredFields?: Record<string, boolean>;
    };
    actions?: {
      enabled?: boolean;
      allowReassignment?: boolean;
      requireAcceptance?: boolean;
      assignableRoles?: Record<string, boolean>;
    };
  };
};

type OperationalClosureReadiness = {
  canClose: boolean;
  openStepCount: number;
  openDispatchRequestCount: number;
  openExternalNotificationCount: number;
  blockingReasons: string[];
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function safeNumber(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function safeNullableString(value: unknown): string | null {
  const normalized = safeString(value);
  return normalized.length > 0 ? normalized : null;
}

function safeNullableNumber(value: unknown): number | null {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function safeObject(value: unknown): Record<string, any> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, any>)
    : {};
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

function sanitizeRoleArray(value: unknown): Record<string, boolean> {
  if (!Array.isArray(value)) return {};
  const result: Record<string, boolean> = {};
  value.forEach((item) => {
    const key = normalizeKey(item);
    if (key) result[key] = true;
  });
  return result;
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .get();

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = sanitizeBooleanRecord((policy as any).matchCategories);
    const matchTypes = sanitizeBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

function resolveActionsCompleted(
  dimensionActions: Record<string, any>
): boolean {
  for (const actions of Object.values(dimensionActions || {})) {
    for (const action of Object.values((actions || {}) as Record<string, any>)) {
      const status = normalizeKey((action as Record<string, any>).status);
      if (status !== "COMPLETED") {
        return false;
      }
    }
  }
  return true;
}

function resolveInvestigationsCompleted(
  dimensionInvestigations: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const investigation = (dimensionInvestigations || {})[dimensionKey] || {};
    const status = normalizeKey(investigation.status);
    if (status !== "COMPLETED") {
      return false;
    }
  }
  return true;
}

function resolveDimensionsReviewed(
  dimensionTracks: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const track = (dimensionTracks || {})[dimensionKey] || {};
    const reviewStatus = normalizeKey(track.reviewStatus);
    if (reviewStatus !== "RECOGNIZED") {
      return false;
    }
  }
  return true;
}

function resolveSingleTrackInvestigationCompleted(
  incident: Record<string, any>,
  policy: IncidentPolicy
): boolean {
  const investigationPolicy = policy.workflowExtensions?.investigation;
  const investigation = (incident.investigation || {}) as Record<string, any>;
  const status = normalizeKey(investigation.status);

  if (investigationPolicy?.enabled !== true) {
    return true;
  }

  if (investigationPolicy?.requiredBeforeClosure !== true) {
    return true;
  }

  return status === "COMPLETED" || status === "NOT_REQUIRED";
}

function resolveSingleTrackActionsCompleted(
  incident: Record<string, any>,
  policy: IncidentPolicy
): boolean {
  const actionsPolicy = policy.workflowExtensions?.actions;
  const summary = (incident.incidentActionsSummary || {}) as Record<string, any>;

  if (actionsPolicy?.enabled !== true) {
    return true;
  }

  const status = normalizeKey(summary.status);
  if (status === "NOT_REQUIRED" || status === "COMPLETED" || status === "CLOSED") {
    return true;
  }

  const total = safeNumber(summary.total, 0);
  const open = safeNumber(summary.open, 0);
  const accepted = safeNumber(summary.accepted, 0);
  const completed = safeNumber(summary.completed, 0);
  const overdue = safeNumber(summary.overdue, 0);

  if (total <= 0) {
    return true;
  }

  return open <= 0 && accepted <= 0 && overdue <= 0 && completed >= total;
}

function validateOperationalClosureReadiness(
  incident: Record<string, any>
): OperationalClosureReadiness {
  const executionRuntime = safeObject(incident.incident_playbook_execution);
  const playbooks = safeObject(executionRuntime.playbooks);
  const playbookDispatchRequests = safeObject(incident.playbook_dispatch_requests);
  const externalNotificationRequests = safeObject(incident.external_notification_requests);

  const openStepCount = countOpenRuntimeSteps(playbooks, incident);
  const openDispatchRequestCount = countOpenDispatchRequests(playbookDispatchRequests, incident);
  const openExternalNotificationCount = countOpenExternalNotifications(
    externalNotificationRequests
  );

  const blockingReasons: string[] = [];
  if (openStepCount > 0) blockingReasons.push("OPEN_PLAYBOOK_STEPS");
  if (openDispatchRequestCount > 0) blockingReasons.push("OPEN_DISPATCH_REQUESTS");
  if (openExternalNotificationCount > 0) {
    blockingReasons.push("OPEN_EXTERNAL_NOTIFICATIONS");
  }

  return {
    canClose: blockingReasons.length === 0,
    openStepCount,
    openDispatchRequestCount,
    openExternalNotificationCount,
    blockingReasons,
  };
}

function countOpenRuntimeSteps(
  playbooks: Record<string, any>,
  incident: Record<string, any>
): number {
  let count = 0;

  Object.values(playbooks || {}).forEach((playbookRaw) => {
    const playbook = safeObject(playbookRaw);
    const steps = safeObject(playbook.steps);

    Object.values(steps).forEach((stepRaw) => {
      const step = safeObject(stepRaw);
      const status = normalizeKey(step.status || "PENDING");
      if (isTerminalStepStatus(status)) return;

      // REQUESTED-only dispatches are not true operational movement.
      // They must not block closure when nobody pressed "Κατευθύνομαι".
      if (isFieldMovementStepType(normalizeKey(step.type || "")) &&
          !hasActiveUncompletedResponders(incident)) {
        return;
      }

      count += 1;
    });
  });

  return count;
}

function countOpenDispatchRequests(
  requests: Record<string, any>,
  incident: Record<string, any>
): number {
  let count = 0;

  Object.entries(requests || {}).forEach(([requestKey, requestRaw]) => {
    const request = safeObject(requestRaw);
    const status = normalizeKey(request.status || "");
    if (isTerminalDispatchStatus(status)) return;

    // A dispatch request blocks closure only if at least one responder actually
    // accepted/started moving and remains active. Pure REQUESTED users are ignored.
    if (hasActiveUncompletedResponderForDispatchRequest(incident, requestKey, request)) {
      count += 1;
    }
  });

  return count;
}

function isFieldMovementStepType(stepType: string): boolean {
  return (
    stepType === "DISPATCH_TEAM" ||
    stepType === "PREPARE_EVACUATION" ||
    stepType === "EVACUATION"
  );
}

function hasActiveUncompletedResponders(incident: Record<string, any>): boolean {
  return Object.values(safeObject(incident.responders)).some((responderRaw) =>
    isActiveUncompletedResponder(safeObject(responderRaw))
  );
}

function hasActiveUncompletedResponderForDispatchRequest(
  incident: Record<string, any>,
  requestKey: string,
  request: Record<string, any>
): boolean {
  const requestId = String(request.id || requestKey || "");
  const requestTeam = normalizeKey(request.team || "");

  return Object.values(safeObject(incident.responders)).some((responderRaw) => {
    const responder = safeObject(responderRaw);
    if (!isActiveUncompletedResponder(responder)) return false;

    const responderDispatchId = String(responder.sourceDispatchRequestId || "");
    const responderTeam = normalizeKey(responder.team || "");

    return (
      (requestId.length > 0 && responderDispatchId === requestId) ||
      (requestTeam.length > 0 && responderTeam === requestTeam)
    );
  });
}

function isActiveUncompletedResponder(responder: Record<string, any>): boolean {
  const status = normalizeKey(responder.status || "");
  return (
    status === "RESPONDING" ||
    status === "ARRIVED" ||
    status === "ON_SCENE" ||
    status === "IN_PROGRESS" ||
    status === "EN_ROUTE"
  );
}

function countOpenExternalNotifications(requests: Record<string, any>): number {
  let count = 0;

  Object.values(requests || {}).forEach((requestRaw) => {
    const request = safeObject(requestRaw);
    const status = normalizeKey(request.status || "");
    if (!isTerminalExternalNotificationStatus(status)) {
      count += 1;
    }
  });

  return count;
}

function isTerminalStepStatus(status: string): boolean {
  return (
    status === "COMPLETED" ||
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE"
  );
}

function isTerminalDispatchStatus(status: string): boolean {
  return (
    status === "COMPLETED" ||
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE"
  );
}

function isTerminalExternalNotificationStatus(status: string): boolean {
  return (
    status === "ACKNOWLEDGED" ||
    status === "SENT" ||
    status === "REJECTED" ||
    status === "FAILED" ||
    status === "COMPLETED" ||
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE"
  );
}

function buildSingleTrackLifecycleForClosure(
  incident: Record<string, any>,
  now: number,
  actorUserId: string,
  actorDisplayName: string
): Record<string, any> {
  const existing = (incident.singleTrackLifecycle || {}) as Record<string, any>;
  const investigation = (incident.investigation || {}) as Record<string, any>;
  const actionsSummary = (incident.incidentActionsSummary || {}) as Record<string, any>;

  return {
    ...existing,
    reviewStatus:
      existing.reviewStatus ||
      normalizeKey(incident.reviewAggregationStatus || incident.verificationStatus || "VERIFIED"),
    investigationStatus:
      investigation.status ||
      existing.investigationStatus ||
      "NOT_REQUIRED",
    actionsStatus:
      actionsSummary.status ||
      existing.actionsStatus ||
      "NOT_REQUIRED",
    closureStatus: "CLOSED",
    updatedAt: now,
    updatedBy: actorUserId,
    updatedByName: actorDisplayName,
  };
}


async function pushClosureBlockedEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  actorUserId: string,
  actorDisplayName: string,
  authUserId: string,
  policyKey: string,
  reason: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventRef = db.ref("incident_events").push();
  await eventRef.set({
    id: eventRef.key,
    incidentId,
    siteId,
    eventType: "INCIDENT_CLOSURE_BLOCKED",
    createdAt: Date.now(),
    userId: actorUserId,
    userName: actorDisplayName,
    authUserId,
    source: "FUNCTION",
    extra: {
      policyKey,
      reason,
      ...extra,
    },
  });
}

export const closeIncident = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const authUserId = request.auth?.uid;
    const { incidentId, closureNotes, actor } = (request.data || {}) as CloseIncidentRequest;

    if (!authUserId) {
      throw new HttpsError("unauthenticated", "Unauthenticated");
    }

    if (!incidentId || !incidentId.trim()) {
      throw new HttpsError("invalid-argument", "Missing incidentId");
    }

    const db = admin.database();

    const incidentRef = db.ref(`incidents/${incidentId}`);
    const incidentSnap = await incidentRef.get();

    if (!incidentSnap.exists()) {
      throw new HttpsError("not-found", "Incident not found");
    }

    const incident = (incidentSnap.val() || {}) as Record<string, any>;
    const siteId = safeString(incident.siteId || incident.site);
    if (!siteId) {
      throw new HttpsError("failed-precondition", "Incident siteId is missing");
    }

    const userSnap = await db.ref(`users/${authUserId}`).get();
    const dbUser = userSnap.exists() ? (userSnap.val() || {}) : null;

    const actorUserId =
      safeString(dbUser?.uid) ||
      safeString(dbUser?.userId) ||
      safeString(actor?.userId) ||
      authUserId;

    const actorDisplayName =
      safeString(dbUser?.displayName) ||
      safeString(dbUser?.fullName) ||
      safeString(dbUser?.name) ||
      safeString(actor?.displayName) ||
      authUserId;

    const actorSiteId =
      safeString(dbUser?.siteId) ||
      safeString(actor?.siteId) ||
      siteId;

    const actorRoles = {
      ...sanitizeBooleanRecord(dbUser?.roles),
      ...sanitizeRoleArray(actor?.roles),
    };

    if (normalizeKey(actorSiteId) !== normalizeKey(siteId)) {
      throw new HttpsError(
        "permission-denied",
        "User site does not match incident site"
      );
    }

    const incidentStatus = normalizeKey(incident.status);
    const verificationStatus = normalizeKey(incident.verificationStatus);

    if (incidentStatus === "CLOSED") {
      throw new HttpsError("failed-precondition", "Incident is already closed");
    }

    if (incidentStatus === "REJECTED" || verificationStatus === "REJECTED") {
      throw new HttpsError("failed-precondition", "Rejected incident cannot be closed");
    }

    const resolvedPolicy = await resolveIncidentPolicy(db, siteId, incident);
    if (!resolvedPolicy) {
      throw new HttpsError("failed-precondition", "No incident policy found");
    }

    const { policyKey, policy } = resolvedPolicy;

    const allowedRoles = sanitizeBooleanRecord(policy.closure?.allowedRoles);
    const hasAllowedRole =
      Object.keys(allowedRoles).length > 0 &&
      Object.keys(actorRoles).some((role) => allowedRoles[normalizeKey(role)] === true);

    if (!hasAllowedRole) {
      throw new HttpsError(
        "permission-denied",
        "User is not allowed to close this incident"
      );
    }

    const overrideRoles = sanitizeBooleanRecord(policy.closure?.overrideRoles);
    const isOverrideRole = Object.keys(actorRoles).some(
      (role) => overrideRoles[normalizeKey(role)] === true
    );

    const overrideRequiresNotes =
      policy.closure?.overrideRequiresNotes === true;

    const hasNotes = !!safeString(closureNotes);

    const requiresVerifiedIncident =
      policy.closure?.requiresVerifiedIncident !== false;

    const closureMode =
      normalizeKey(policy.workflowExtensions?.closure?.mode) || "SINGLE_TRACK";

    const requiresActionsCompleted =
      policy.workflowExtensions?.closure?.requiresActionsCompleted === true;

    const requiresInvestigationCompleted =
      policy.workflowExtensions?.closure?.requiresInvestigationCompleted === true;

    if (
      requiresVerifiedIncident &&
      verificationStatus !== "VERIFIED" &&
      verificationStatus !== "AUTO_VERIFIED"
    ) {
      throw new HttpsError(
        "failed-precondition",
        "Incident must be verified before closure"
      );
    }

    const selectedReviewDimensions = sanitizeBooleanRecord(incident.selectedReviewDimensions);
    const dimensionTracks = (incident.dimensionTracks || {}) as Record<string, any>;
    const dimensionActions = (incident.dimensionActions || {}) as Record<string, any>;
    const dimensionInvestigations = (incident.dimensionInvestigations || {}) as Record<string, any>;

    const operationalReadiness = validateOperationalClosureReadiness(incident);

    if (!operationalReadiness.canClose) {
      if (isOverrideRole) {
        if (overrideRequiresNotes && !hasNotes) {
          await pushClosureBlockedEvent(
            db,
            incidentId,
            siteId,
            actorUserId,
            actorDisplayName,
            authUserId,
            policyKey,
            "OVERRIDE_NOTES_REQUIRED_FOR_OPERATIONAL_PENDING",
            { operationalReadiness, actorRoles }
          );
          throw new HttpsError(
            "failed-precondition",
            "Closure notes are required for override closure"
          );
        }
      } else {
        await pushClosureBlockedEvent(
          db,
          incidentId,
          siteId,
          actorUserId,
          actorDisplayName,
          authUserId,
          policyKey,
          "OPERATIONAL_OBLIGATIONS_PENDING",
          { operationalReadiness, actorRoles }
        );
        throw new HttpsError(
          "failed-precondition",
          `There are pending operational obligations: ${operationalReadiness.blockingReasons.join(", ")}`
        );
      }
    }

    if (closureMode === "ALL_TRACKS_REQUIRED") {
      const allDimensionsReviewed = resolveDimensionsReviewed(
        dimensionTracks,
        selectedReviewDimensions
      );

      if (!allDimensionsReviewed) {
        throw new HttpsError(
          "failed-precondition",
          "Not all active dimensions are fully recognized"
        );
      }
    }

    if (requiresActionsCompleted) {
      const actionsCompleted =
        closureMode === "ALL_TRACKS_REQUIRED"
          ? resolveActionsCompleted(dimensionActions)
          : resolveSingleTrackActionsCompleted(incident, policy);

      if (!actionsCompleted) {
        if (isOverrideRole) {
          if (overrideRequiresNotes && !hasNotes) {
            throw new HttpsError(
              "failed-precondition",
              "Closure notes are required for override closure"
            );
          }
        } else {
          throw new HttpsError(
            "failed-precondition",
            "There are pending or incomplete actions"
          );
        }
      }
    }

    if (requiresInvestigationCompleted) {
      const investigationsCompleted =
        closureMode === "ALL_TRACKS_REQUIRED"
          ? resolveInvestigationsCompleted(
              dimensionInvestigations,
              selectedReviewDimensions
            )
          : resolveSingleTrackInvestigationCompleted(incident, policy);

      if (!investigationsCompleted) {
        if (isOverrideRole) {
          if (overrideRequiresNotes && !hasNotes) {
            throw new HttpsError(
              "failed-precondition",
              "Closure notes are required for override closure"
            );
          }
        } else {
          throw new HttpsError(
            "failed-precondition",
            "There are pending investigations"
          );
        }
      }
    }

    const now = Date.now();

    const incidentUpdates: Record<string, any> = {
      status: "CLOSED",
      active: false,
      closedAt: now,
      closedBy: actorDisplayName,
      closedByUid: actorUserId,
      closureNotes: closureNotes || "",
      closureMode: isOverrideRole ? "OVERRIDE" : "STANDARD",
      closureValidation: {
        status: "PASSED",
        checkedAt: now,
        checkedBy: "closeIncident",
        policyKey,
        operationalReadiness,
        requiresActionsCompleted,
        requiresInvestigationCompleted,
      },
      dispatchStatus: "CLOSED",
    };

    if (closureMode !== "ALL_TRACKS_REQUIRED") {
      incidentUpdates.singleTrackLifecycle = buildSingleTrackLifecycleForClosure(
        incident,
        now,
        actorUserId,
        actorDisplayName
      );
    }

    await incidentRef.update(incidentUpdates);

    const eventRef = db.ref("incident_events").push();
    await eventRef.set({
      id: eventRef.key,
      incidentId,
      siteId,
      eventType: "INCIDENT_CLOSED",
      createdAt: now,
      userId: actorUserId,
      userName: actorDisplayName,
      authUserId,
      source: "FUNCTION",
      extra: {
        category: incident.category || "",
        policyKey,
        closureNotes: closureNotes || "",
        actorRoles,
        sessionType: safeString(actor?.sessionType) || "REAL_SESSION",
        closureMode: isOverrideRole ? "OVERRIDE" : "STANDARD",
        operationalReadiness,
      },
    });

    const currentDispatchStateSnap = await db.ref(`dispatch_state/${incidentId}`).get();
    const currentDispatchState = currentDispatchStateSnap.exists()
      ? currentDispatchStateSnap.val() || {}
      : {};

    const rootUpdates: Record<string, any> = {};

    rootUpdates[`incidents/${incidentId}/responders`] = null;

    rootUpdates[`dispatch_state/${incidentId}`] = {
      incidentId,
      siteId,
      category: normalizeKey(incident.category || ""),
      status: "CLOSED",
      activeResponders: safeNumber(currentDispatchState.activeResponders, 0),
      requestedResponders: safeNumber(currentDispatchState.requestedResponders, 0),
      respondingResponders: safeNumber(currentDispatchState.respondingResponders, 0),
      arrivedResponders: safeNumber(currentDispatchState.arrivedResponders, 0),
      completedResponders: safeNumber(currentDispatchState.completedResponders, 0),
      cancelledResponders: safeNumber(currentDispatchState.cancelledResponders, 0),
      closestResponderId: safeNullableString(currentDispatchState.closestResponderId),
      closestDistanceMeters: safeNullableNumber(currentDispatchState.closestDistanceMeters),
      closestEtaSeconds: safeNullableNumber(currentDispatchState.closestEtaSeconds),
      staleResponderCount: safeNumber(currentDispatchState.staleResponderCount, 0),
      requestedTeams: safeObject(currentDispatchState.requestedTeams),
      requestedByPlaybooks: safeObject(currentDispatchState.requestedByPlaybooks),
      responders: safeObject(currentDispatchState.responders),
      lastDispatchUpdate: now,
      serverOwned: true,
      dispatchVersion: 3,
      closedAt: now,
      closedBy: actorDisplayName,
      closureMode: isOverrideRole ? "OVERRIDE" : "STANDARD",
    };

    await db.ref().update(rootUpdates);

    logger.info("closeIncident completed", {
      incidentId,
      siteId,
      authUserId,
      actorUserId,
      actorDisplayName,
      policyKey,
      closureMode: isOverrideRole ? "OVERRIDE" : "STANDARD",
    });

    return {
      ok: true,
      incidentId,
      closedAt: now,
      closedBy: actorDisplayName,
      closureMode: isOverrideRole ? "OVERRIDE" : "STANDARD",
    };
  }
);