import * as admin from "firebase-admin";

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  displayName?: string;
  reviewMode?: string;
  verification?: {
    allowedRoles?: Record<string, boolean>;
    minimumApprovals?: number;
    finalAuthorityRoles?: Record<string, boolean>;
    rejectOverrides?: boolean;
  };
  workflow?: {
    requiresVerification?: boolean;
    autoDispatchOnCreate?: boolean;
    autoDispatchOnVerify?: boolean;
  };
  reviewMatrix?: Record<
    string,
    {
      label?: string;
      roles?: Record<string, boolean>;
      requiredRoles?: Record<string, boolean>;
      minimumApprovals?: number;
    }
  >;
};

type ReviewRecord = {
  action?: string;
  role?: string;
  actorRoles?: string[];
  actorUserId?: string;
  userId?: string;
  userName?: string;
  displayName?: string;
  sessionType?: string;
  comment?: string;
  siteId?: string;
  policyKey?: string;
  dimensionKey?: string;
  dimensionLabel?: string;
  createdAt?: number;
};

export type RecomputeIncidentAggregationResult = {
  incidentId: string;
  policyKey: string;
  reviewMode: "SINGLE" | "MULTI_DIMENSIONAL";
  reviewAggregationStatus: "PENDING" | "UNDER_REVIEW" | "VERIFIED" | "REJECTED";
  verificationStatus: "PENDING" | "UNDER_REVIEW" | "VERIFIED" | "REJECTED";
  incidentStatus: "PENDING" | "CONFIRMED" | "REJECTED" | "CLOSED";
  verified: boolean;
  active: boolean;
  visibleToSite: boolean;
  recognizeCount: number;
  rejectCount: number;
  hasAuthorityReject: boolean;
  completedRoles: Record<string, boolean>;
  pendingRoles: Record<string, boolean>;
  reviewDimensions: Record<string, any>;
  latestReview: ReviewRecord | null;
};

function normalizeKey(value: string | undefined | null): string {
  return (value || "").trim().toUpperCase();
}

function toBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, boolean>;
}

function isTruthy(value: unknown): boolean {
  return value === true;
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  const input = toBooleanRecord(value);
  const result: Record<string, boolean> = {};
  Object.entries(input).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[key] = true;
    }
  });
  return result;
}

function resolveReviewMatrix(
  policy: IncidentPolicy
): Record<
  string,
  {
    label?: string;
    roles?: Record<string, boolean>;
    requiredRoles?: Record<string, boolean>;
    minimumApprovals?: number;
  }
> {
  if (!policy.reviewMatrix || typeof policy.reviewMatrix !== "object") {
    return {};
  }
  return policy.reviewMatrix;
}

function resolveRequiredRolesForDimension(
  dimensionValue: {
    label?: string;
    roles?: Record<string, boolean>;
    requiredRoles?: Record<string, boolean>;
    minimumApprovals?: number;
  }
): Record<string, boolean> {
  const requiredRoles = toBooleanRecord(dimensionValue.requiredRoles);
  if (Object.keys(requiredRoles).length > 0) {
    return requiredRoles;
  }
  return toBooleanRecord(dimensionValue.roles);
}

function resolveActiveDimensionKeys(
  incident: Record<string, any>,
  reviewMatrix: Record<
    string,
    {
      label?: string;
      roles?: Record<string, boolean>;
      requiredRoles?: Record<string, boolean>;
      minimumApprovals?: number;
    }
  >
): string[] {
  const selectedFromIncident = sanitizeBooleanRecord(
    incident.selectedReviewDimensions
  );
  if (Object.keys(selectedFromIncident).length > 0) {
    return Object.keys(selectedFromIncident).map(normalizeKey);
  }

  const existingReviewDimensions = incident.reviewDimensions;
  if (existingReviewDimensions && typeof existingReviewDimensions === "object") {
    const keys = Object.keys(existingReviewDimensions).map(normalizeKey);
    if (keys.length > 0) {
      return keys;
    }
  }

  return Object.keys(reviewMatrix).map(normalizeKey);
}

function resolveActiveReviewMatrix(
  incident: Record<string, any>,
  reviewMatrix: Record<
    string,
    {
      label?: string;
      roles?: Record<string, boolean>;
      requiredRoles?: Record<string, boolean>;
      minimumApprovals?: number;
    }
  >
): Record<
  string,
  {
    label?: string;
    roles?: Record<string, boolean>;
    requiredRoles?: Record<string, boolean>;
    minimumApprovals?: number;
  }
> {
  const activeKeys = new Set(resolveActiveDimensionKeys(incident, reviewMatrix));
  const result: Record<
    string,
    {
      label?: string;
      roles?: Record<string, boolean>;
      requiredRoles?: Record<string, boolean>;
      minimumApprovals?: number;
    }
  > = {};

  Object.entries(reviewMatrix).forEach(([dimensionKeyRaw, value]) => {
    const normalizedKey = normalizeKey(dimensionKeyRaw);
    if (activeKeys.has(normalizedKey)) {
      result[normalizedKey] = value;
    }
  });

  return result;
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .once("value");

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = toBooleanRecord((policy as any).matchCategories);
    const matchTypes = toBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      isTruthy(matchCategories[incidentCategory]) ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      isTruthy(matchTypes[incidentType]) ||
      isTruthy(matchTypes[incidentSubtype]) ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

async function readAllReviews(
  db: admin.database.Database,
  incidentId: string
): Promise<Array<{ reviewId: string; data: ReviewRecord }>> {
  const reviewsSnap = await db.ref(`incident_reviews/${incidentId}`).once("value");
  if (!reviewsSnap.exists()) {
    return [];
  }

  const reviews: Array<{ reviewId: string; data: ReviewRecord }> = [];
  reviewsSnap.forEach((child) => {
    reviews.push({
      reviewId: child.key || "",
      data: (child.val() || {}) as ReviewRecord,
    });
    return false;
  });

  return reviews;
}

function findLatestReview(
  reviews: Array<{ reviewId: string; data: ReviewRecord }>
): ReviewRecord | null {
  if (reviews.length === 0) return null;

  const sorted = [...reviews].sort((a, b) => {
    const aTs = Number(a.data.createdAt ?? 0);
    const bTs = Number(b.data.createdAt ?? 0);
    return bTs - aTs;
  });

  return sorted[0]?.data || null;
}

function buildFlattenedRoleStateFromDimensions(
  reviewDimensions: Record<string, any>
): {
  completedRoles: Record<string, boolean>;
  pendingRoles: Record<string, boolean>;
} {
  const completedRoles: Record<string, boolean> = {};
  const pendingRoles: Record<string, boolean> = {};

  Object.values(reviewDimensions).forEach((value) => {
    const dimension = (value || {}) as Record<string, any>;
    const requiredRoles = sanitizeBooleanRecord(dimension.requiredRoles);
    const completedForDimension = sanitizeBooleanRecord(dimension.completedRoles);

    Object.keys(completedForDimension).forEach((roleKey) => {
      completedRoles[roleKey] = true;
    });

    Object.keys(requiredRoles).forEach((roleKey) => {
      if (!completedForDimension[roleKey]) {
        pendingRoles[roleKey] = true;
      }
    });
  });

  return { completedRoles, pendingRoles };
}

function computeLegacyReviewStats(
  reviews: Array<{ reviewId: string; data: ReviewRecord }>,
  finalAuthorityRoles: Record<string, boolean>
): {
  recognizeCount: number;
  rejectCount: number;
  hasAuthorityReject: boolean;
} {
  let recognizeCount = 0;
  let rejectCount = 0;
  let hasAuthorityReject = false;

  reviews.forEach(({ data }) => {
    const action = normalizeKey(data.action);
    const directRole = normalizeKey(data.role);
    const actorRoles = Array.isArray(data.actorRoles)
      ? data.actorRoles.map(normalizeKey)
      : [];

    if (action === "RECOGNIZE") {
      recognizeCount += 1;
    }

    if (action === "REJECT") {
      rejectCount += 1;

      const directRoleIsAuthority =
        directRole.length > 0 && finalAuthorityRoles[directRole] === true;

      const actorRoleIsAuthority =
        actorRoles.some((role) => finalAuthorityRoles[role] === true);

      if (directRoleIsAuthority || actorRoleIsAuthority) {
        hasAuthorityReject = true;
      }
    }
  });

  return {
    recognizeCount,
    rejectCount,
    hasAuthorityReject,
  };
}

function collectLatestDimensionReviews(
  reviews: Array<{ reviewId: string; data: ReviewRecord }>,
  dimensionKey: string
): Array<{ reviewId: string; data: ReviewRecord }> {
  const latestByActor: Record<string, { reviewId: string; data: ReviewRecord }> = {};

  reviews.forEach(({ reviewId, data }) => {
    const reviewDimensionKey = normalizeKey(data.dimensionKey);
    if (reviewDimensionKey !== dimensionKey) return;

    const actorKey = (data.actorUserId || data.userId || "").trim();
    if (!actorKey) return;

    const createdAt = Number(data.createdAt ?? 0);
    const existing = latestByActor[actorKey];
    const existingCreatedAt = Number(existing?.data.createdAt ?? 0);

    if (!existing || createdAt >= existingCreatedAt) {
      latestByActor[actorKey] = { reviewId, data };
    }
  });

  return Object.values(latestByActor);
}

export async function recomputeIncidentAggregation(
  db: admin.database.Database,
  incidentId: string
): Promise<RecomputeIncidentAggregationResult> {
  const incidentRef = db.ref(`incidents/${incidentId}`);
  const incidentSnap = await incidentRef.once("value");

  if (!incidentSnap.exists()) {
    throw new Error(`Incident not found: ${incidentId}`);
  }

  const incident = (incidentSnap.val() || {}) as Record<string, any>;
  const siteId = (incident.siteId || incident.site || "").trim();

  if (!siteId) {
    throw new Error(`Missing siteId for incident ${incidentId}`);
  }

  const resolvedPolicy = await resolveIncidentPolicy(db, siteId, incident);
  if (!resolvedPolicy) {
    throw new Error(`No policy found for incident ${incidentId}`);
  }

  const { policyKey, policy } = resolvedPolicy;
  const reviews = await readAllReviews(db, incidentId);
  const latestReview = findLatestReview(reviews);

  const policyReviewMode = normalizeKey(policy.reviewMode);
  const incidentReviewMode = normalizeKey(incident.reviewMode);
  const reviewMatrix = resolveReviewMatrix(policy);
  const activeReviewMatrix = resolveActiveReviewMatrix(incident, reviewMatrix);

  const multiDimensionalEnabled =
    (incidentReviewMode === "MULTI_DIMENSIONAL" ||
      policyReviewMode === "MULTI_DIMENSIONAL") &&
    Object.keys(activeReviewMatrix).length > 0;

  const finalAuthorityRoles = toBooleanRecord(policy.verification?.finalAuthorityRoles);
  const rejectOverrides = policy.verification?.rejectOverrides === true;
  const requiresVerification = policy.workflow?.requiresVerification === true;
  const minimumApprovals = Math.max(
    0,
    Number(policy.verification?.minimumApprovals ?? 0)
  );

  let reviewDimensions: Record<string, any> = {};
  let dimensionTracks: Record<string, any> = {
    ...((incident.dimensionTracks || {}) as Record<string, any>),
  };
  let completedRoles: Record<string, boolean> = {};
  let pendingRoles: Record<string, boolean> = {};
  let reviewAggregationStatus: "PENDING" | "UNDER_REVIEW" | "VERIFIED" | "REJECTED" = "PENDING";

  const legacyStats = computeLegacyReviewStats(reviews, finalAuthorityRoles);

  if (multiDimensionalEnabled) {
    Object.entries(activeReviewMatrix).forEach(([dimensionKeyRaw, dimensionValue]) => {
      const dimensionKey = normalizeKey(dimensionKeyRaw);
      const requiredRoles = resolveRequiredRolesForDimension(dimensionValue);
      const minimumApprovalsForDimension = Math.max(
        1,
        Number(dimensionValue.minimumApprovals ?? 1)
      );

      const latestDimensionReviews = collectLatestDimensionReviews(reviews, dimensionKey);

      const dimensionCompletedRoles: Record<string, boolean> = {};
      let recognizeCount = 0;
      let rejectCount = 0;

      latestDimensionReviews.forEach(({ data }) => {
        const action = normalizeKey(data.action);
        const reviewRole = normalizeKey(data.role);

        if (reviewRole) {
          dimensionCompletedRoles[reviewRole] = true;
        }

        if (action === "RECOGNIZE") {
          recognizeCount += 1;
        } else if (action === "REJECT") {
          rejectCount += 1;
        }
      });

      let status = "PENDING";
      if (rejectCount > 0) {
        status = "REJECTED";
      } else if (recognizeCount >= minimumApprovalsForDimension) {
        status = "RECOGNIZED";
      } else if (recognizeCount > 0) {
        status = "UNDER_REVIEW";
      }

      const previousDimension = (incident.reviewDimensions || {})[dimensionKey] || {};

      reviewDimensions[dimensionKey] = {
        label: dimensionValue.label || dimensionKeyRaw,
        requiredRoles,
        minimumApprovals: minimumApprovalsForDimension,
        recognizeCount,
        rejectCount,
        completedRoles: dimensionCompletedRoles,
        status,
        lastUpdatedAt:
          Number(latestDimensionReviews[0]?.data.createdAt ?? 0) ||
          Number(previousDimension.lastUpdatedAt ?? incident.createdAt ?? Date.now()),
      };

      const previousDimensionTrack =
        (dimensionTracks[dimensionKey] || {}) as Record<string, any>;

      dimensionTracks[dimensionKey] = {
        ...previousDimensionTrack,
        active:
          previousDimensionTrack.active === false ? false : true,
        dimensionKey,
        label: dimensionValue.label || dimensionKeyRaw,
        ownerRoles: requiredRoles,
        reviewStatus: status,
        recognizeCount,
        rejectCount,
        decision:
          status === "RECOGNIZED"
            ? "RECOGNIZE"
            : status === "REJECTED"
              ? "REJECT"
              : previousDimensionTrack.decision || "",
        decisionBy:
          latestDimensionReviews[0]?.data.actorUserId ||
          latestDimensionReviews[0]?.data.userId ||
          previousDimensionTrack.decisionBy ||
          "",
        decisionAt:
          Number(latestDimensionReviews[0]?.data.createdAt ?? 0) ||
          Number(previousDimensionTrack.decisionAt ?? 0),
        decisionComment:
          latestDimensionReviews[0]?.data.comment ||
          previousDimensionTrack.decisionComment ||
          "",
        investigationStatus:
          previousDimensionTrack.investigationStatus || "NOT_STARTED",
        actionsStatus:
          previousDimensionTrack.actionsStatus || "NOT_REQUIRED",
        closureStatus:
          previousDimensionTrack.closureStatus || "OPEN",
        updatedAt:
          Number(latestDimensionReviews[0]?.data.createdAt ?? 0) ||
          Number(previousDimension.lastUpdatedAt ?? incident.createdAt ?? Date.now()),
        updatedBy:
          latestDimensionReviews[0]?.data.actorUserId ||
          latestDimensionReviews[0]?.data.userId ||
          previousDimensionTrack.updatedBy ||
          "",
        updatedByName:
          latestDimensionReviews[0]?.data.displayName ||
          latestDimensionReviews[0]?.data.userName ||
          previousDimensionTrack.updatedByName ||
          "",
      };
    });

    const flattenedState = buildFlattenedRoleStateFromDimensions(reviewDimensions);
    completedRoles = flattenedState.completedRoles;
    pendingRoles = flattenedState.pendingRoles;

    const dimensionStatuses = Object.values(reviewDimensions).map((value) =>
      normalizeKey((value as Record<string, any>).status as string)
    );

    const allTerminal =
      dimensionStatuses.length > 0 &&
      dimensionStatuses.every(
        (status) => status === "RECOGNIZED" || status === "REJECTED"
      );

    const allRecognized =
      dimensionStatuses.length > 0 &&
      dimensionStatuses.every((status) => status === "RECOGNIZED");

    if (allTerminal) {
      reviewAggregationStatus = allRecognized ? "VERIFIED" : "REJECTED";
    } else if (Object.keys(completedRoles).length > 0) {
      reviewAggregationStatus = "UNDER_REVIEW";
    } else {
      reviewAggregationStatus = "PENDING";
    }
  } else {
    reviewDimensions = incident.reviewDimensions || {};
    completedRoles = sanitizeBooleanRecord(incident.completedRoles);
    pendingRoles = sanitizeBooleanRecord(incident.pendingRoles);

    const approvalsNeeded = requiresVerification
      ? Math.max(1, minimumApprovals)
      : 0;

    const shouldRejectFinally =
      legacyStats.hasAuthorityReject && rejectOverrides;

    const shouldRecognizeFinally =
      !shouldRejectFinally &&
      (!requiresVerification ||
        approvalsNeeded === 0 ||
        legacyStats.recognizeCount >= approvalsNeeded);

    if (shouldRejectFinally) {
      reviewAggregationStatus = "REJECTED";
    } else if (shouldRecognizeFinally) {
      reviewAggregationStatus = "VERIFIED";
    } else if (legacyStats.recognizeCount > 0 || legacyStats.rejectCount > 0) {
      reviewAggregationStatus = "UNDER_REVIEW";
    } else {
      reviewAggregationStatus = "PENDING";
    }
  }

  let verificationStatus: "PENDING" | "UNDER_REVIEW" | "VERIFIED" | "REJECTED" = "PENDING";
  let incidentStatus: "PENDING" | "CONFIRMED" | "REJECTED" | "CLOSED" =
    normalizeKey(incident.status) === "CLOSED" ? "CLOSED" : "PENDING";
  let verified = false;
  let active = normalizeKey(incident.status) === "CLOSED" ? false : true;
  let visibleToSite = false;

  const isClosed = normalizeKey(incident.status) === "CLOSED";

  if (reviewAggregationStatus === "VERIFIED") {
    verificationStatus = "VERIFIED";
    incidentStatus = isClosed ? "CLOSED" : "CONFIRMED";
    verified = true;
    active = !isClosed;
    visibleToSite = true;
  } else if (reviewAggregationStatus === "REJECTED") {
    verificationStatus = "REJECTED";
    incidentStatus = isClosed ? "CLOSED" : "REJECTED";
    verified = false;
    active = false;
    visibleToSite = false;
  } else if (reviewAggregationStatus === "UNDER_REVIEW") {
    verificationStatus = "UNDER_REVIEW";
    incidentStatus = isClosed ? "CLOSED" : "PENDING";
    verified = false;
    active = !isClosed;
    visibleToSite = false;
  } else {
    verificationStatus = requiresVerification ? "PENDING" : "VERIFIED";
    incidentStatus = isClosed
      ? "CLOSED"
      : requiresVerification
        ? "PENDING"
        : "CONFIRMED";
    verified = !requiresVerification;
    active = !isClosed;
    visibleToSite = !requiresVerification;
  }

  const updates: Record<string, any> = {
    reviewMode: multiDimensionalEnabled ? "MULTI_DIMENSIONAL" : "SINGLE",
    reviewDimensions,
    dimensionTracks,
    selectedReviewDimensions: Object.keys(reviewDimensions).reduce(
      (acc, key) => {
        acc[key] = true;
        return acc;
      },
      {} as Record<string, boolean>
    ),
    completedRoles,
    pendingRoles,
    reviewAggregationStatus,
    verificationStatus,
    status: incidentStatus,
    verified,
    active,
    visibleToSite,
  };

  if (reviewAggregationStatus === "VERIFIED") {
    updates.verifiedAt = Number(latestReview?.createdAt ?? Date.now());
    updates.verifiedBy = latestReview?.actorUserId || latestReview?.userId || null;
    updates.verifiedByName =
      latestReview?.displayName || latestReview?.userName || null;
    updates.verifiedByRole = latestReview?.role || null;
    updates.verificationSource = "FUNCTION";
    updates.verificationComment = latestReview?.comment || "";

    updates.rejectedAt = null;
    updates.rejectedBy = null;
    updates.rejectedByName = null;
    updates.rejectedByRole = null;
    updates.rejectionComment = null;
    updates.rejectionSource = null;
  } else if (reviewAggregationStatus === "REJECTED") {
    updates.rejectedAt = Number(latestReview?.createdAt ?? Date.now());
    updates.rejectedBy = latestReview?.actorUserId || latestReview?.userId || null;
    updates.rejectedByName =
      latestReview?.displayName || latestReview?.userName || null;
    updates.rejectedByRole = latestReview?.role || null;
    updates.rejectionComment = latestReview?.comment || "";
    updates.rejectionSource = "FUNCTION";

    updates.verifiedAt = null;
    updates.verifiedBy = null;
    updates.verifiedByName = null;
    updates.verifiedByRole = null;
    updates.verificationComment = null;
    updates.verificationSource = null;
  } else {
    updates.verifiedAt = null;
    updates.verifiedBy = null;
    updates.verifiedByName = null;
    updates.verifiedByRole = null;
    updates.verificationComment = null;
    updates.verificationSource = null;

    updates.rejectedAt = null;
    updates.rejectedBy = null;
    updates.rejectedByName = null;
    updates.rejectedByRole = null;
    updates.rejectionComment = null;
    updates.rejectionSource = null;
  }

  await incidentRef.update(updates);

  return {
    incidentId,
    policyKey,
    reviewMode: multiDimensionalEnabled ? "MULTI_DIMENSIONAL" : "SINGLE",
    reviewAggregationStatus,
    verificationStatus,
    incidentStatus,
    verified,
    active,
    visibleToSite,
    recognizeCount: legacyStats.recognizeCount,
    rejectCount: legacyStats.rejectCount,
    hasAuthorityReject: legacyStats.hasAuthorityReject,
    completedRoles,
    pendingRoles,
    reviewDimensions,
    latestReview,
  };
}