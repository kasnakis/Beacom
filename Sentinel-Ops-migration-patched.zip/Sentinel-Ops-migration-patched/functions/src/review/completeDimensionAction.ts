import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  closure?: {
    allowedRoles?: Record<string, boolean>;
    requiresVerifiedIncident?: boolean;
    overrideRoles?: Record<string, boolean>;
    overrideRequiresNotes?: boolean;
  };
  workflowExtensions?: {
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
  };
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .get();

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = sanitizeBooleanRecord((policy as any).matchCategories);
    const matchTypes = sanitizeBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

function resolveDimensionsReviewed(
  dimensionTracks: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const track = (dimensionTracks || {})[dimensionKey] || {};
    const reviewStatus = normalizeKey(track.reviewStatus);
    if (reviewStatus !== "RECOGNIZED") {
      return false;
    }
  }
  return true;
}

function resolveActionsCompleted(
  dimensionActions: Record<string, any>
): boolean {
  for (const actions of Object.values(dimensionActions || {})) {
    for (const action of Object.values((actions || {}) as Record<string, any>)) {
      const status = normalizeKey((action as Record<string, any>).status);
      if (status !== "COMPLETED") {
        return false;
      }
    }
  }
  return true;
}

function resolveInvestigationsCompleted(
  dimensionInvestigations: Record<string, any>,
  activeDimensions: Record<string, boolean>
): boolean {
  for (const dimensionKey of Object.keys(activeDimensions || {})) {
    const investigation = (dimensionInvestigations || {})[dimensionKey] || {};
    const status = normalizeKey(investigation.status);
    if (status !== "COMPLETED") {
      return false;
    }
  }
  return true;
}

async function tryAutoCloseIncident(
  db: admin.database.Database,
  incidentRef: admin.database.Reference,
  incidentId: string,
  incident: Record<string, any>,
  siteId: string
): Promise<boolean> {
  const resolvedPolicy = await resolveIncidentPolicy(db, siteId, incident);
  if (!resolvedPolicy) return false;

  const { policyKey, policy } = resolvedPolicy;

  const verificationStatus = normalizeKey(incident.verificationStatus);
  const incidentStatus = normalizeKey(incident.status);

  if (incidentStatus === "CLOSED" || incidentStatus === "REJECTED") return false;
  if (verificationStatus === "REJECTED") return false;

  const requiresVerifiedIncident =
    policy.closure?.requiresVerifiedIncident !== false;

  if (
    requiresVerifiedIncident &&
    verificationStatus !== "VERIFIED" &&
    verificationStatus !== "AUTO_VERIFIED"
  ) {
    return false;
  }

  const closureMode =
    normalizeKey(policy.workflowExtensions?.closure?.mode) || "SINGLE_TRACK";

  const requiresActionsCompleted =
    policy.workflowExtensions?.closure?.requiresActionsCompleted === true;

  const requiresInvestigationCompleted =
    policy.workflowExtensions?.closure?.requiresInvestigationCompleted === true;

  const selectedReviewDimensions = sanitizeBooleanRecord(incident.selectedReviewDimensions);
  const dimensionTracks = (incident.dimensionTracks || {}) as Record<string, any>;
  const dimensionActions = (incident.dimensionActions || {}) as Record<string, any>;
  const dimensionInvestigations = (incident.dimensionInvestigations || {}) as Record<string, any>;

  if (closureMode === "ALL_TRACKS_REQUIRED") {
    const allDimensionsReviewed = resolveDimensionsReviewed(
      dimensionTracks,
      selectedReviewDimensions
    );
    if (!allDimensionsReviewed) return false;
  }

  if (requiresActionsCompleted) {
    const actionsCompleted = resolveActionsCompleted(dimensionActions);
    if (!actionsCompleted) return false;
  }

  if (requiresInvestigationCompleted) {
    const investigationsCompleted = resolveInvestigationsCompleted(
      dimensionInvestigations,
      selectedReviewDimensions
    );
    if (!investigationsCompleted) return false;
  }

  const now = Date.now();

  await incidentRef.update({
    status: "CLOSED",
    active: false,
    closedAt: now,
    closedBy: "SYSTEM AUTO CLOSE",
    closedByUid: "system_auto_close",
    closureNotes: "Αυτόματο κλείσιμο μετά την ολοκλήρωση όλων των απαιτούμενων διερευνήσεων/ενεργειών",
    closureMode: "AUTO",
  });

  const eventRef = db.ref("incident_events").push();
  await eventRef.set({
    id: eventRef.key,
    incidentId,
    siteId,
    eventType: "INCIDENT_CLOSED",
    createdAt: now,
    userId: "system_auto_close",
    userName: "SYSTEM AUTO CLOSE",
    authUserId: null,
    source: "FUNCTION",
    extra: {
      category: incident.category || "",
      policyKey,
      closureNotes: "Αυτόματο κλείσιμο μετά την ολοκλήρωση όλων των απαιτούμενων διερευνήσεων/ενεργειών",
      actorRoles: {},
      sessionType: "SYSTEM",
      closureMode: "AUTO",
    },
  });

  return true;
}

export const completeDimensionAction = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = admin.database();

    try {
      if (!request.auth) {
        throw new HttpsError("unauthenticated", "Μη εξουσιοδοτημένη πρόσβαση");
      }

      const authUid = request.auth.uid;

      const {
        incidentId,
        dimensionKey,
        actionId,
        completionComment,
      } = request.data || {};

      if (!incidentId || !dimensionKey || !actionId) {
        throw new HttpsError("invalid-argument", "Λείπουν απαραίτητες παράμετροι");
      }

      const dimKey = normalizeKey(dimensionKey);

      const incidentRef = db.ref(`incidents/${incidentId}`);
      const incidentSnap = await incidentRef.get();

      if (!incidentSnap.exists()) {
        throw new HttpsError("not-found", "Το συμβάν δεν βρέθηκε");
      }

      const incident = incidentSnap.val() || {};
      const siteId = safeString(incident.siteId || incident.site);

      const actionRef = incidentRef
        .child("dimensionActions")
        .child(dimKey)
        .child(actionId);

      const actionSnap = await actionRef.get();

      if (!actionSnap.exists()) {
        throw new HttpsError("not-found", "Η ενέργεια δεν βρέθηκε");
      }

      const action = actionSnap.val() || {};

      const assignedTo = safeString(action.assignedTo);
      if (assignedTo !== authUid) {
        throw new HttpsError(
          "permission-denied",
          "Μόνο ο ανατεθειμένος χρήστης μπορεί να ολοκληρώσει την ενέργεια"
        );
      }

      const currentStatus = normalizeKey(action.status);

      if (currentStatus === "COMPLETED") {
        throw new HttpsError("failed-precondition", "Η ενέργεια έχει ήδη ολοκληρωθεί");
      }

      if (currentStatus === "REJECTED") {
        throw new HttpsError(
          "failed-precondition",
          "Απορριφθείσα ενέργεια δεν μπορεί να ολοκληρωθεί"
        );
      }

      if (currentStatus !== "ACCEPTED" && currentStatus !== "IN_PROGRESS") {
        throw new HttpsError(
          "failed-precondition",
          "Μόνο αποδεκτή ή σε εξέλιξη ενέργεια μπορεί να ολοκληρωθεί"
        );
      }

      const now = Date.now();
      const completedByName =
        safeString(request.auth.token?.name) ||
        safeString(action.assignedToName) ||
        authUid;

      await actionRef.update({
        status: "COMPLETED",
        completedAt: now,
        completedBy: authUid,
        completedByName,
        completionComment: safeString(completionComment),
        updatedAt: now,
        updatedBy: authUid,
        updatedByName: completedByName,
      });

      const dimensionActionsSnap = await incidentRef
        .child("dimensionActions")
        .child(dimKey)
        .get();

      const allActions = (dimensionActionsSnap.val() || {}) as Record<string, any>;

      const remainingOpenActions = Object.values(allActions).filter((item: any) => {
        const status = normalizeKey(item?.status);
        return status !== "COMPLETED" && status !== "REJECTED";
      });

      const nextActionsStatus =
        Object.keys(allActions).length === 0
          ? "NOT_REQUIRED"
          : remainingOpenActions.length == 0
          ? "COMPLETED"
          : "PENDING";

      await incidentRef.child("dimensionTracks").child(dimKey).update({
        actionsStatus: nextActionsStatus,
        updatedAt: now,
        updatedBy: authUid,
        updatedByName: completedByName,
      });

      const eventRef = db.ref("incident_events").push();

      await eventRef.set({
        id: eventRef.key,
        incidentId,
        siteId,
        eventType: "INCIDENT_ACTION_COMPLETED",
        createdAt: now,
        userId: authUid,
        userName: completedByName,
        authUserId: authUid,
        source: "FUNCTION",
        extra: {
          actionId,
          dimensionKey: dimKey,
          actionTitle: safeString(action.title),
          comment: safeString(completionComment),
          nextActionsStatus,
        },
      });

      const refreshedIncidentSnap = await incidentRef.get();
      const refreshedIncident = refreshedIncidentSnap.val() || {};
      const autoClosed = await tryAutoCloseIncident(
        db,
        incidentRef,
        incidentId,
        refreshedIncident,
        safeString(refreshedIncident.siteId || refreshedIncident.site)
      );

      logger.info("completeDimensionAction success", {
        incidentId,
        dimensionKey: dimKey,
        actionId,
        nextActionsStatus,
        autoClosed,
      });

      return {
        ok: true,
        incidentId,
        dimensionKey: dimKey,
        actionId,
        nextActionsStatus,
        autoClosed,
      };
    } catch (error: any) {
      logger.error("completeDimensionAction failed", {
        error: error?.message,
      });

      if (error instanceof HttpsError) throw error;
      throw new HttpsError("internal", "Αποτυχία ολοκλήρωσης ενέργειας");
    }
  }
);