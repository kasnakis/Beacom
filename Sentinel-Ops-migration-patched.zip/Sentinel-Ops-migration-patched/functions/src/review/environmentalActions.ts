import * as admin from "firebase-admin";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { updateEnvironmentalActionSummary } from "./updateEnvironmentalActionSummary";

type ActorInput = {
  userId?: unknown;
  displayName?: unknown;
  siteId?: unknown;
  roles?: unknown;
  sessionType?: unknown;
};

function getDb(): admin.database.Database {
  return admin.database();
}

function ensure(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new HttpsError("failed-precondition", message);
  }
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function normalizeKey(value: unknown): string {
  return safeString(value).toUpperCase();
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

function sanitizeRolesFromUnknown(value: unknown): Record<string, boolean> {
  if (Array.isArray(value)) {
    const result: Record<string, boolean> = {};
    value.forEach((item) => {
      const key = normalizeKey(item);
      if (key) result[key] = true;
    });
    return result;
  }
  return sanitizeBooleanRecord(value);
}

function hasAnyRole(
  userRoles: Record<string, boolean> | undefined,
  allowedRoles: string[]
): boolean {
  if (!userRoles) return false;
  return allowedRoles.some((role) => userRoles[normalizeKey(role)] === true);
}

export const upsertEnvironmentalAction = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = getDb();
    const authUid = request.auth?.uid;
    const { incidentId, actionId, mode, payload, actor } = request.data ?? {};

    if (!authUid) {
      throw new HttpsError("unauthenticated", "Μη εξουσιοδοτημένη πρόσβαση");
    }

    ensure(incidentId, "incidentId required");
    ensure(mode, "mode required");

    const incidentRef = db.ref(`incidents/${incidentId}`);
    const incidentSnap = await incidentRef.get();
    ensure(incidentSnap.exists(), "Incident not found");

    const incident = incidentSnap.val() || {};
    const incidentSiteId = safeString(incident.siteId || incident.site);
    ensure(incidentSiteId, "Incident siteId missing");

    const actorInput = (actor || {}) as ActorInput;
    const actorUserId = safeString(actorInput.userId);
    const actorDisplayName = safeString(actorInput.displayName);
    const actorSiteId = safeString(actorInput.siteId);
    const actorRoles = sanitizeRolesFromUnknown(actorInput.roles);

    const profileUserId = actorUserId || authUid;
    ensure(profileUserId, "User id missing");

    const userRef = db.ref(`users/${profileUserId}`);
    const userSnap = await userRef.get();
    const user = userSnap.val() || {};

    const userSiteId = safeString(user.siteId || user.site || actorSiteId);
    const userRolesFromProfile = sanitizeBooleanRecord(user.roles);
    const userRoles =
      Object.keys(userRolesFromProfile).length > 0 ? userRolesFromProfile : actorRoles;

    const actorName =
      safeString(user.displayName) ||
      actorDisplayName ||
      safeString(request.auth?.token?.name) ||
      profileUserId;

    if (!userSnap.exists() && !actorUserId) {
      throw new HttpsError("permission-denied", "User not found");
    }

    ensure(userSiteId, "User siteId missing");
    ensure(normalizeKey(userSiteId) === normalizeKey(incidentSiteId), "Cross-site access denied");

    ensure(
      normalizeKey(incident.category) === "ENVIRONMENTAL_INCIDENT",
      "Invalid incident type"
    );

    ensure(
      normalizeKey(incident.verificationStatus) === "VERIFIED" ||
        normalizeKey(incident.verificationStatus) === "AUTO_VERIFIED",
      "Incident must be verified"
    );

    const workflowExtensions = incident.policySnapshot?.workflowExtensions || null;
    const actionsPolicy = workflowExtensions?.actions || null;

    const assignAllowed = actionsPolicy?.assignableRoles || {
      ENVIRONMENTAL_OFFICER: true,
      HSE_MANAGER: true,
      SITE_MANAGER: true,
      SUPERVISOR: true,
    };

    const now = Date.now();
    const actionsRef = incidentRef.child("singleTrackActions");

    if (mode === "ASSIGN") {
      ensure(payload?.title, "title required");
      ensure(payload?.assigneeUid, "assigneeUid required");

      const canAssign = hasAnyRole(
        userRoles,
        Object.keys(assignAllowed).filter((role) => assignAllowed[role] === true)
      );
      ensure(canAssign, "Not allowed to assign action");

      const assigneeRef = db.ref(`users/${payload.assigneeUid}`);
      const assigneeSnap = await assigneeRef.get();
      ensure(assigneeSnap.exists(), "Assignee not found");

      const assignee = assigneeSnap.val() || {};
      const assigneeSiteId = safeString(assignee.siteId || assignee.site);
      ensure(
        normalizeKey(assigneeSiteId) === normalizeKey(incidentSiteId),
        "Assignee must belong to same site"
      );

      const actionKey = actionsRef.push().key;
      ensure(actionKey, "Failed to generate action id");

      const action = {
        id: actionKey,
        title: safeString(payload.title),
        description: safeString(payload.description),
        assigneeUid: safeString(payload.assigneeUid),
        assigneeName: safeString(payload.assigneeName) || safeString(assignee.displayName),
        status: "ASSIGNED",
        createdAt: now,
        createdBy: profileUserId,
        createdByName: actorName,
        dueDate: payload.dueDate || null,
        required: payload.required !== false,
        notes: safeString(payload.notes),
      };

      await actionsRef.child(actionKey).set(action);

      await db.ref("incident_events").push({
        eventType: "INCIDENT_ACTION_ASSIGNED",
        incidentId,
        createdAt: now,
        userId: profileUserId,
        userName: actorName,
        authUserId: authUid,
        source: "FUNCTION",
        siteId: incidentSiteId,
        extra: {
          actionId: actionKey,
          title: action.title,
          assigneeUid: action.assigneeUid,
          assigneeName: action.assigneeName,
          dueDate: action.dueDate,
          sessionType: safeString(actorInput.sessionType) || null,
        },
      });

      await updateEnvironmentalActionSummary(incidentId);

      return { success: true, actionId: actionKey };
    }

    ensure(actionId, "actionId required");

    const actionRef = actionsRef.child(actionId);
    const actionSnap = await actionRef.get();
    ensure(actionSnap.exists(), "Action not found");

    const action = actionSnap.val() || {};

    if (mode === "RESPOND") {
      ensure(payload?.response, "response required");
      ensure(action.assigneeUid === profileUserId, "Only assignee can respond");

      const response = String(payload.response).toUpperCase();
      ensure(response === "ACCEPT" || response === "REJECT", "Invalid response");

      const newStatus = response === "ACCEPT" ? "ACCEPTED" : "REJECTED";

      await actionRef.update({
        status: newStatus,
        respondedAt: now,
        respondedBy: profileUserId,
        respondedByName: actorName,
        responseNotes: safeString(payload.notes),
      });

      await db.ref("incident_events").push({
        eventType:
          newStatus === "ACCEPTED"
            ? "INCIDENT_ACTION_ACCEPTED"
            : "INCIDENT_ACTION_REJECTED",
        incidentId,
        createdAt: now,
        userId: profileUserId,
        userName: actorName,
        authUserId: authUid,
        source: "FUNCTION",
        siteId: incidentSiteId,
        extra: {
          actionId,
          response: newStatus,
          sessionType: safeString(actorInput.sessionType) || null,
        },
      });

      await updateEnvironmentalActionSummary(incidentId);

      return { success: true };
    }

    if (mode === "COMPLETE") {
      const canComplete =
        action.assigneeUid === profileUserId ||
        userRoles.HSE_MANAGER === true ||
        userRoles.ENVIRONMENTAL_OFFICER === true ||
        userRoles.SITE_MANAGER === true;

      ensure(canComplete, "Not allowed to complete");

      await actionRef.update({
        status: "COMPLETED",
        completedAt: now,
        completedBy: profileUserId,
        completedByName: actorName,
        completionNotes: safeString(payload?.notes),
      });

      await db.ref("incident_events").push({
        eventType: "INCIDENT_ACTION_COMPLETED",
        incidentId,
        createdAt: now,
        userId: profileUserId,
        userName: actorName,
        authUserId: authUid,
        source: "FUNCTION",
        siteId: incidentSiteId,
        extra: {
          actionId,
          sessionType: safeString(actorInput.sessionType) || null,
        },
      });

      await updateEnvironmentalActionSummary(incidentId);

      return { success: true };
    }

    throw new HttpsError("invalid-argument", "Invalid mode");
  }
);