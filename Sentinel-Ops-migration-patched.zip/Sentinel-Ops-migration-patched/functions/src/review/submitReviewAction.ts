import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";

type ReviewAction = "RECOGNIZE" | "REJECT";

type ReviewActorContext = {
  userId: string;
  displayName: string;
  siteId: string;
  roles: string[];
  sessionType?: "REAL_SESSION" | "PILOT_SESSION";
};

type SubmitReviewActionData = {
  incidentId: string;
  action: ReviewAction;
  comment?: string;
  role: string;
  actor?: ReviewActorContext;
};

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  displayName?: string;
  reviewMode?: string;
  verification?: {
    allowedRoles?: Record<string, boolean>;
    minimumApprovals?: number;
    finalAuthorityRoles?: Record<string, boolean>;
    rejectOverrides?: boolean;
  };
  workflow?: {
    requiresVerification?: boolean;
    autoDispatchOnCreate?: boolean;
    autoDispatchOnVerify?: boolean;
  };
  workflowExtensions?: {
    investigation?: {
      enabled?: boolean;
      perDimension?: boolean;
      requiredBeforeClosure?: boolean;
      requiredFields?: Record<string, boolean>;
    };
    actions?: {
      enabled?: boolean;
      allowReassignment?: boolean;
      requireAcceptance?: boolean;
      assignableRoles?: Record<string, boolean>;
    };
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
    reminders?: {
      enabled?: boolean;
      intervalDays?: number;
      notifyAssignee?: boolean;
      targetRoles?: Record<string, boolean>;
    };
    manualNotify?: {
      enabled?: boolean;
      allowedRoles?: Record<string, boolean>;
      sameSiteOnly?: boolean;
      requireVerifiedIncident?: boolean;
    };
  };
  notifications?: {
    onVerified?: {
      enabled?: boolean;
      templateKey?: string;
      targetRoles?: Record<string, boolean>;
      targetTeams?: Record<string, boolean>;
    };
  };
  dispatch?: {
    enabled?: boolean;
  };
  reviewMatrix?: Record<
    string,
    {
      label?: string;
      roles?: Record<string, boolean>;
      requiredRoles?: Record<string, boolean>;
      minimumApprovals?: number;
    }
  >;
};

type ReviewRecord = {
  action?: string;
  role?: string;
  actorRoles?: string[];
  actorUserId?: string;
  userId?: string;
  dimensionKey?: string;
  createdAt?: number;
};

type ReviewMatrixEntry = {
  label?: string;
  roles?: Record<string, boolean>;
  requiredRoles?: Record<string, boolean>;
  minimumApprovals?: number;
};

function normalizeKey(value: string | undefined | null): string {
  return (value || "").trim().toUpperCase();
}

function toBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, boolean>;
}

function isTruthy(value: unknown): boolean {
  return value === true;
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.filter((x) => x.trim().length > 0)));
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  const input = toBooleanRecord(value);
  const result: Record<string, boolean> = {};
  Object.entries(input).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[key] = true;
    }
  });
  return result;
}

function resolveReviewMatrix(
  policy: IncidentPolicy
): Record<string, ReviewMatrixEntry> {
  if (!policy.reviewMatrix || typeof policy.reviewMatrix !== "object") {
    return {};
  }
  return policy.reviewMatrix;
}

function resolveRequiredRolesForDimension(
  dimensionValue: ReviewMatrixEntry
): Record<string, boolean> {
  const requiredRoles = toBooleanRecord(dimensionValue.requiredRoles);
  if (Object.keys(requiredRoles).length > 0) {
    return requiredRoles;
  }
  return toBooleanRecord(dimensionValue.roles);
}

function resolveActiveDimensionKeys(
  incident: Record<string, any>,
  reviewMatrix: Record<string, ReviewMatrixEntry>
): string[] {
  const selectedFromIncident = sanitizeBooleanRecord(
    incident.selectedReviewDimensions
  );
  if (Object.keys(selectedFromIncident).length > 0) {
    return Object.keys(selectedFromIncident).map(normalizeKey);
  }

  const existingReviewDimensions = incident.reviewDimensions;
  if (existingReviewDimensions && typeof existingReviewDimensions === "object") {
    const keys = Object.keys(existingReviewDimensions).map(normalizeKey);
    if (keys.length > 0) {
      return keys;
    }
  }

  return Object.keys(reviewMatrix).map(normalizeKey);
}

function resolveActiveReviewMatrix(
  incident: Record<string, any>,
  reviewMatrix: Record<string, ReviewMatrixEntry>
): Record<string, ReviewMatrixEntry> {
  const activeKeys = new Set(resolveActiveDimensionKeys(incident, reviewMatrix));
  const result: Record<string, ReviewMatrixEntry> = {};

  Object.entries(reviewMatrix).forEach(([dimensionKeyRaw, value]) => {
    const normalizedKey = normalizeKey(dimensionKeyRaw);
    if (activeKeys.has(normalizedKey)) {
      result[normalizedKey] = value;
    }
  });

  return result;
}

function resolveMultiDimensionalAssignment(
  activeReviewMatrix: Record<string, ReviewMatrixEntry>,
  roleNormalized: string,
  normalizedActorRoles: string[]
): {
  dimensionKey: string;
  dimensionLabel: string;
  requiredRoles: Record<string, boolean>;
  minimumApprovals: number;
} | null {
  for (const [dimensionKeyRaw, dimensionValue] of Object.entries(activeReviewMatrix)) {
    const requiredRoles = resolveRequiredRolesForDimension(dimensionValue);
    const dimensionKey = normalizeKey(dimensionKeyRaw);

    const roleAllowed =
      requiredRoles[roleNormalized] === true ||
      normalizedActorRoles.some((r) => requiredRoles[r] === true);

    if (roleAllowed) {
      return {
        dimensionKey,
        dimensionLabel: dimensionValue.label || dimensionKeyRaw,
        requiredRoles,
        minimumApprovals: Math.max(
          1,
          Number(dimensionValue.minimumApprovals ?? 1)
        ),
      };
    }
  }

  return null;
}

function initializeReviewDimensionsFromMatrix(
  activeReviewMatrix: Record<string, ReviewMatrixEntry>,
  existingReviewDimensions: Record<string, any> | undefined,
  incidentCreatedAt: number,
): Record<string, any> {
  const result: Record<string, any> = {};
  const existing = existingReviewDimensions || {};

  Object.entries(activeReviewMatrix).forEach(([dimensionKeyRaw, dimensionValue]) => {
    const dimensionKey = normalizeKey(dimensionKeyRaw);
    const existingDimension = (existing[dimensionKey] || {}) as Record<string, any>;
    const requiredRoles = resolveRequiredRolesForDimension(dimensionValue);

    result[dimensionKey] = {
      label: dimensionValue.label || dimensionKeyRaw,
      requiredRoles,
      minimumApprovals: Math.max(
        1,
        Number(dimensionValue.minimumApprovals ?? 1)
      ),
      recognizeCount: Number(existingDimension.recognizeCount ?? 0),
      rejectCount: Number(existingDimension.rejectCount ?? 0),
      completedRoles: sanitizeBooleanRecord(existingDimension.completedRoles),
      status: existingDimension.status || "PENDING",
      lastUpdatedAt: Number(existingDimension.lastUpdatedAt ?? incidentCreatedAt ?? Date.now()),
    };
  });

  return result;
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .once("value");

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = toBooleanRecord((policy as any).matchCategories);
    const matchTypes = toBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      isTruthy(matchCategories[incidentCategory]) ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      isTruthy(matchTypes[incidentType]) ||
      isTruthy(matchTypes[incidentSubtype]) ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

async function readReviewStats(
  db: admin.database.Database,
  incidentId: string,
  finalAuthorityRoles: Record<string, boolean>
): Promise<{
  recognizeCount: number;
  rejectCount: number;
  hasAuthorityReject: boolean;
}> {
  const reviewsSnap = await db.ref(`incident_reviews/${incidentId}`).once("value");
  if (!reviewsSnap.exists()) {
    return {
      recognizeCount: 0,
      rejectCount: 0,
      hasAuthorityReject: false,
    };
  }

  let recognizeCount = 0;
  let rejectCount = 0;
  let hasAuthorityReject = false;

  reviewsSnap.forEach((child) => {
    const review = (child.val() || {}) as ReviewRecord;
    const action = normalizeKey(review.action);
    const directRole = normalizeKey(review.role);
    const actorRoles = Array.isArray(review.actorRoles)
      ? review.actorRoles.map(normalizeKey)
      : [];

    if (action === "RECOGNIZE") {
      recognizeCount += 1;
    }

    if (action === "REJECT") {
      rejectCount += 1;

      const directRoleIsAuthority =
        directRole.length > 0 && finalAuthorityRoles[directRole] === true;

      const actorRoleIsAuthority =
        actorRoles.some((reviewRole) => finalAuthorityRoles[reviewRole] === true);

      if (directRoleIsAuthority || actorRoleIsAuthority) {
        hasAuthorityReject = true;
      }
    }

    return false;
  });

  return {
    recognizeCount,
    rejectCount,
    hasAuthorityReject,
  };
}

async function findExistingReviewForActorDimension(
  db: admin.database.Database,
  incidentId: string,
  actorUserId: string,
  dimensionKey: string
): Promise<{ reviewId: string; data: ReviewRecord } | null> {
  const reviewsSnap = await db.ref(`incident_reviews/${incidentId}`).once("value");
  if (!reviewsSnap.exists()) {
    return null;
  }

  let latestMatch: { reviewId: string; data: ReviewRecord } | null = null;

  reviewsSnap.forEach((child) => {
    const reviewId = child.key || "";
    const data = (child.val() || {}) as ReviewRecord;
    const reviewActorUserId = (data.actorUserId || data.userId || "").trim();
    const reviewDimensionKey = normalizeKey(data.dimensionKey);

    if (
      reviewActorUserId === actorUserId &&
      reviewDimensionKey === dimensionKey
    ) {
      const createdAt = Number(data.createdAt ?? 0);
      const latestCreatedAt = Number(latestMatch?.data.createdAt ?? 0);

      if (!latestMatch || createdAt >= latestCreatedAt) {
        latestMatch = { reviewId, data };
      }
    }

    return false;
  });

  return latestMatch;
}

async function collectLatestDimensionReviews(
  db: admin.database.Database,
  incidentId: string,
  dimensionKey: string
): Promise<Array<{ reviewId: string; data: ReviewRecord }>> {
  const reviewsSnap = await db.ref(`incident_reviews/${incidentId}`).once("value");
  if (!reviewsSnap.exists()) {
    return [];
  }

  const latestByActor: Record<string, { reviewId: string; data: ReviewRecord }> = {};

  reviewsSnap.forEach((child) => {
    const reviewId = child.key || "";
    const data = (child.val() || {}) as ReviewRecord;
    const reviewDimensionKey = normalizeKey(data.dimensionKey);
    if (reviewDimensionKey !== dimensionKey) {
      return false;
    }

    const actorKey = (data.actorUserId || data.userId || "").trim();
    if (!actorKey) {
      return false;
    }

    const createdAt = Number(data.createdAt ?? 0);
    const existing = latestByActor[actorKey];
    const existingCreatedAt = Number(existing?.data.createdAt ?? 0);

    if (!existing || createdAt >= existingCreatedAt) {
      latestByActor[actorKey] = { reviewId, data };
    }

    return false;
  });

  return Object.values(latestByActor);
}

function buildFlattenedRoleStateFromDimensions(
  reviewDimensions: Record<string, any>
): {
  completedRoles: Record<string, boolean>;
  pendingRoles: Record<string, boolean>;
} {
  const completedRoles: Record<string, boolean> = {};
  const pendingRoles: Record<string, boolean> = {};

  Object.values(reviewDimensions).forEach((value) => {
    const dimension = (value || {}) as Record<string, any>;
    const requiredRoles = sanitizeBooleanRecord(dimension.requiredRoles);
    const completedForDimension = sanitizeBooleanRecord(dimension.completedRoles);

    Object.keys(completedForDimension).forEach((roleKey) => {
      completedRoles[roleKey] = true;
    });

    Object.keys(requiredRoles).forEach((roleKey) => {
      if (!completedForDimension[roleKey]) {
        pendingRoles[roleKey] = true;
      }
    });
  });

  return { completedRoles, pendingRoles };
}

function initializeDimensionInvestigations(
  existingDimensionInvestigations: Record<string, any> | undefined
): Record<string, any> {
  return { ...(existingDimensionInvestigations || {}) };
}

function initializeDimensionTracks(
  activeReviewMatrix: Record<string, ReviewMatrixEntry>,
  existingDimensionTracks: Record<string, any> | undefined,
  incidentCreatedAt: number,
): Record<string, any> {
  const result: Record<string, any> = {};
  const existing = existingDimensionTracks || {};

  Object.entries(activeReviewMatrix).forEach(([dimensionKeyRaw, dimensionValue]) => {
    const dimensionKey = normalizeKey(dimensionKeyRaw);
    const existingTrack = (existing[dimensionKey] || {}) as Record<string, any>;
    const ownerRoles = sanitizeBooleanRecord(
      existingTrack.ownerRoles || resolveRequiredRolesForDimension(dimensionValue)
    );
    const label = String(existingTrack.label || dimensionValue.label || dimensionKeyRaw).trim() || dimensionKeyRaw;

    result[dimensionKey] = {
      active: existingTrack.active !== false,
      dimensionKey,
      label,
      ownerRoles,
      reviewStatus: existingTrack.reviewStatus || existingTrack.status || "PENDING",
      decision: existingTrack.decision || "",
      decisionBy: existingTrack.decisionBy || "",
      decisionAt: Number(existingTrack.decisionAt ?? 0),
      decisionComment: existingTrack.decisionComment || "",
      investigationStatus: existingTrack.investigationStatus || "NOT_STARTED",
      actionsStatus: existingTrack.actionsStatus || "NOT_REQUIRED",
      closureStatus: existingTrack.closureStatus || "OPEN",
      updatedAt: Number(existingTrack.updatedAt ?? incidentCreatedAt ?? Date.now()),
      updatedBy: existingTrack.updatedBy || "",
      updatedByName: existingTrack.updatedByName || "",
    };
  });

  return result;
}

function resolveSingleTrackOwnerRoles(
  policy: IncidentPolicy,
  allowedRolesRecord: Record<string, boolean>,
  finalAuthorityRoles: Record<string, boolean>
): Record<string, boolean> {
  const finalAuthority = sanitizeBooleanRecord(finalAuthorityRoles);
  if (Object.keys(finalAuthority).length > 0) {
    return finalAuthority;
  }

  const allowed = sanitizeBooleanRecord(allowedRolesRecord);
  if (Object.keys(allowed).length > 0) {
    return allowed;
  }

  return {};
}

function initializeSingleTrackInvestigation(
  existingInvestigation: Record<string, any> | undefined,
  policy: IncidentPolicy,
  incident: Record<string, any>,
  policyKey: string,
  ownerRoles: Record<string, boolean>,
  now: number,
  actorUserId: string,
  actorDisplayName: string
): Record<string, any> {
  const existing = existingInvestigation || {};
  const investigationPolicy = policy.workflowExtensions?.investigation;
  const requiredFields = sanitizeBooleanRecord(investigationPolicy?.requiredFields);
  const label = String(
    existing.label ||
      incident.trackLabel ||
      policy.displayName ||
      incident.category ||
      incident.type ||
      policyKey
  ).trim();

  return {
    trackKey: normalizeKey(policyKey),
    label,
    required: investigationPolicy?.enabled === true,
    requiredBeforeClosure: investigationPolicy?.requiredBeforeClosure === true,
    ownerRoles,
    status:
      existing.status ||
      (investigationPolicy?.enabled === true ? "PENDING" : "NOT_REQUIRED"),
    requiredFields,
    investigatorUserId: existing.investigatorUserId || "",
    investigatorName: existing.investigatorName || "",
    startedAt: Number(existing.startedAt ?? 0),
    updatedAt: Number(existing.updatedAt ?? now),
    updatedBy: existing.updatedBy || actorUserId,
    updatedByName: existing.updatedByName || actorDisplayName,
    completedAt: Number(existing.completedAt ?? 0),
    completedBy: existing.completedBy || "",
    completedByName: existing.completedByName || "",
    data: {
      incidentDescription: existing.data?.incidentDescription || incident.description || "",
      incidentTypes: existing.data?.incidentTypes || [],
      intensity: existing.data?.intensity || "",
      impactExtent: existing.data?.impactExtent || "",
      pollutionReceivers: existing.data?.pollutionReceivers || [],
      cause: existing.data?.cause || "",
      involvedPersons: existing.data?.involvedPersons || [],
      involvedNotes: existing.data?.involvedNotes || "",
      impact: existing.data?.impact || "",
      actionsTaken: existing.data?.actionsTaken || "",
      meansUsed: existing.data?.meansUsed || "",
      responseEvaluation: existing.data?.responseEvaluation || "",
      improvementProposals: existing.data?.improvementProposals || "",
      notes: existing.data?.notes || "",
    },
  };
}

function initializeSingleTrackActionsSummary(
  existingActionsSummary: Record<string, any> | undefined,
  policy: IncidentPolicy,
  ownerRoles: Record<string, boolean>,
  now: number
): Record<string, any> {
  const existing = existingActionsSummary || {};
  const actionsPolicy = policy.workflowExtensions?.actions;

  return {
    enabled: actionsPolicy?.enabled === true,
    requireAcceptance: actionsPolicy?.requireAcceptance === true,
    allowReassignment: actionsPolicy?.allowReassignment === true,
    assignableRoles: sanitizeBooleanRecord(actionsPolicy?.assignableRoles),
    ownerRoles,
    total: Number(existing.total ?? 0),
    open: Number(existing.open ?? 0),
    accepted: Number(existing.accepted ?? 0),
    completed: Number(existing.completed ?? 0),
    rejected: Number(existing.rejected ?? 0),
    overdue: Number(existing.overdue ?? 0),
    status:
      existing.status ||
      (actionsPolicy?.enabled === true ? "READY" : "NOT_REQUIRED"),
    updatedAt: Number(existing.updatedAt ?? now),
  };
}

function initializeSingleTrackLifecycle(
  existingLifecycle: Record<string, any> | undefined,
  policy: IncidentPolicy,
  policyKey: string,
  ownerRoles: Record<string, boolean>,
  now: number,
  actorUserId: string,
  actorDisplayName: string,
  reviewStatus: string
): Record<string, any> {
  const existing = existingLifecycle || {};
  const investigationEnabled = policy.workflowExtensions?.investigation?.enabled === true;
  const actionsEnabled = policy.workflowExtensions?.actions?.enabled === true;

  return {
    trackKey: normalizeKey(policyKey),
    reviewStatus,
    ownerRoles,
    investigationStatus:
      existing.investigationStatus ||
      (investigationEnabled ? "PENDING" : "NOT_REQUIRED"),
    actionsStatus:
      existing.actionsStatus ||
      (actionsEnabled ? "READY" : "NOT_REQUIRED"),
    closureStatus: existing.closureStatus || "OPEN",
    updatedAt: Number(existing.updatedAt ?? now),
    updatedBy: existing.updatedBy || actorUserId,
    updatedByName: existing.updatedByName || actorDisplayName,
  };
}



function resolveAuditSessionType(
  actorSessionType: string | undefined,
  actorUserId: string,
  authUid: string
): "REAL_SESSION" | "PILOT_SESSION" {
  if (actorSessionType === "PILOT_SESSION" && actorUserId && authUid && actorUserId !== authUid) {
    return "PILOT_SESSION";
  }
  return "REAL_SESSION";
}

export const submitReviewAction = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = admin.database();

    try {
      logger.info("submitReviewAction called", {
        hasAuth: !!request.auth,
        rawData: request.data ?? null,
      });

      const auth = request.auth;
      const data = request.data as SubmitReviewActionData | undefined;

      if (!auth) {
        logger.error("submitReviewAction unauthenticated", {
          rawData: request.data ?? null,
        });
        throw new HttpsError("unauthenticated", "Ξ‘Ο€Ξ±ΞΉΟ„ΞµΞ―Ο„Ξ±ΞΉ ΟƒΟΞ½Ξ΄ΞµΟƒΞ· Ο‡ΟΞ®ΟƒΟ„Ξ·");
      }

      const authUid = auth.uid;
      const { incidentId, action, comment = "", role, actor } =
        data || ({} as SubmitReviewActionData);

      if (!incidentId || !action || !role) {
        throw new HttpsError("invalid-argument", "Ξ›ΞµΞ―Ο€ΞΏΟ…Ξ½ Ο…Ο€ΞΏΟ‡ΟΞµΟ‰Ο„ΞΉΞΊΞ¬ Ο€ΞµΞ΄Ξ―Ξ±");
      }

      if (action !== "RECOGNIZE" && action !== "REJECT") {
        throw new HttpsError("invalid-argument", "ΞΞ· Ξ­Ξ³ΞΊΟ…ΟΞ· ΞµΞ½Ξ­ΟΞ³ΞµΞΉΞ±");
      }

      const incidentRef = db.ref(`incidents/${incidentId}`);
      const incidentSnap = await incidentRef.once("value");
      if (!incidentSnap.exists()) {
        logger.error("submitReviewAction incident not found", { incidentId });
        throw new HttpsError("not-found", "Ξ¤ΞΏ ΟƒΟ…ΞΌΞ²Ξ¬Ξ½ Ξ΄ΞµΞ½ Ξ²ΟΞ­ΞΈΞ·ΞΊΞµ");
      }

      const incident = (incidentSnap.val() || {}) as Record<string, any>;

      const authUserSnap = await db.ref(`users/${authUid}`).once("value");
      const authUser = authUserSnap.val() || {};

      const canonicalUserId = authUser.uid || authUser.userId || authUid;

      const actorUserId = actor?.userId?.trim() || canonicalUserId;

      const actorDisplayName =
        actor?.displayName?.trim() ||
        authUser.displayName ||
        authUser.fullName ||
        "Ξ†Ξ³Ξ½Ο‰ΟƒΟ„ΞΏΟ‚ Ο‡ΟΞ®ΟƒΟ„Ξ·Ο‚";

      const actorSiteId =
        actor?.siteId?.trim() ||
        incident.siteId ||
        incident.site ||
        authUser.siteId ||
        "";

      const actorRoles =
        Array.isArray(actor?.roles) && actor.roles.length > 0
          ? uniqueStrings(actor.roles)
          : uniqueStrings(Object.keys(authUser.roles || {}));

      const sessionType = resolveAuditSessionType(actor?.sessionType, actorUserId, authUid);

      const category = incident.category || "";
      const severity = incident.severity || "";

      logger.info("submitReviewAction actor resolved", {
        authUid,
        canonicalUserId,
        actorUserId,
        actorDisplayName,
        actorSiteId,
        actorRoles,
        sessionType,
        authUserExists: authUserSnap.exists(),
      });

      if (!actorSiteId) {
        throw new HttpsError("failed-precondition", "Ξ›ΞµΞ―Ο€ΞµΞΉ Ο„ΞΏ site Ο„ΞΏΟ… Ο‡ΟΞ®ΟƒΟ„Ξ·");
      }

      const incidentSiteId = String(incident.siteId || incident.site || "").trim();
      if (incidentSiteId && normalizeKey(actorSiteId) !== normalizeKey(incidentSiteId)) {
        throw new HttpsError(
          "permission-denied",
          "Ξ Ο‡ΟΞ®ΟƒΟ„Ξ·Ο‚ Ξ΄ΞµΞ½ Ξ±Ξ½Ξ®ΞΊΞµΞΉ ΟƒΟ„ΞΏ Ξ―Ξ΄ΞΉΞΏ site ΞΌΞµ Ο„ΞΏ ΟƒΟ…ΞΌΞ²Ξ¬Ξ½"
        );
      }

      const resolvedPolicy = await resolveIncidentPolicy(db, actorSiteId, incident);
      if (!resolvedPolicy) {
        throw new HttpsError(
          "failed-precondition",
          "Ξ”ΞµΞ½ Ξ²ΟΞ­ΞΈΞ·ΞΊΞµ Ο€ΞΏΞ»ΞΉΟ„ΞΉΞΊΞ® Ξ³ΞΉΞ± Ο„ΞΏ ΟƒΟ…ΞΌΞ²Ξ¬Ξ½"
        );
      }

      const { policyKey, policy } = resolvedPolicy;

      if (policy.enabled === false) {
        throw new HttpsError(
          "failed-precondition",
          "Ξ— Ο€ΞΏΞ»ΞΉΟ„ΞΉΞΊΞ® Ο„ΞΏΟ… ΟƒΟ…ΞΌΞ²Ξ¬Ξ½Ο„ΞΏΟ‚ ΞµΞ―Ξ½Ξ±ΞΉ Ξ±Ο€ΞµΞ½ΞµΟΞ³ΞΏΟ€ΞΏΞΉΞ·ΞΌΞ­Ξ½Ξ·"
        );
      }

      const requiresVerification = policy.workflow?.requiresVerification === true;
      const minimumApprovals = Math.max(
        0,
        Number(policy.verification?.minimumApprovals ?? 0)
      );
      const allowedRolesRecord = toBooleanRecord(policy.verification?.allowedRoles);
      const finalAuthorityRoles = toBooleanRecord(policy.verification?.finalAuthorityRoles);
      const rejectOverrides = policy.verification?.rejectOverrides === true;

      const roleNormalized = normalizeKey(role);
      const normalizedActorRoles = actorRoles.map(normalizeKey);

      const incidentReviewMode = normalizeKey(incident.reviewMode);
      const policyReviewMode = normalizeKey(policy.reviewMode);
      const reviewMatrix = resolveReviewMatrix(policy);
      const activeReviewMatrix = resolveActiveReviewMatrix(incident, reviewMatrix);

      const multiDimensionalEnabled =
        (incidentReviewMode === "MULTI_DIMENSIONAL" ||
          policyReviewMode === "MULTI_DIMENSIONAL") &&
        Object.keys(activeReviewMatrix).length > 0;

      const singleTrackWorkflowEnabled =
        !multiDimensionalEnabled &&
        normalizeKey(policy.workflowExtensions?.closure?.mode) === "SINGLE_TRACK_REQUIRED";

      let dimensionKey = normalizeKey(incident.category || incident.type || policyKey);
      let dimensionLabel =
        policy.displayName || incident.category || incident.type || policyKey;

      let dimensionRequiredRoles: Record<string, boolean> = {};
      let dimensionMinimumApprovals = 1;

      if (multiDimensionalEnabled) {
        const assignment = resolveMultiDimensionalAssignment(
          activeReviewMatrix,
          roleNormalized,
          normalizedActorRoles
        );

        if (!assignment) {
          throw new HttpsError(
            "permission-denied",
            "Ξ ΟΟΞ»ΞΏΟ‚ Ξ΄ΞµΞ½ Ξ­Ο‡ΞµΞΉ Ξ΄ΞΉΞΊΞ±Ξ―Ο‰ΞΌΞ± Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ·Ο‚"
          );
        }

        dimensionKey = assignment.dimensionKey;
        dimensionLabel = assignment.dimensionLabel;
        dimensionRequiredRoles = assignment.requiredRoles;
        dimensionMinimumApprovals = assignment.minimumApprovals;
      } else {
        const roleAllowed =
          Object.keys(allowedRolesRecord).length === 0 ||
          allowedRolesRecord[roleNormalized] === true;

        const actorHasAllowedRole =
          normalizedActorRoles.some((r) => allowedRolesRecord[r] === true);

        if (requiresVerification && !roleAllowed && !actorHasAllowedRole) {
          throw new HttpsError(
            "permission-denied",
            "Ξ ΟΟΞ»ΞΏΟ‚ Ξ΄ΞµΞ½ Ξ­Ο‡ΞµΞΉ Ξ΄ΞΉΞΊΞ±Ξ―Ο‰ΞΌΞ± Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ·Ο‚"
          );
        }
      }

      const now = Date.now();

      let reviewId: string | null = null;
      let reviewRef: admin.database.Reference;

      if (multiDimensionalEnabled) {
        const currentAggregationStatus = normalizeKey(
          incident.reviewAggregationStatus || incident.verificationStatus || incident.status
        );

        if (currentAggregationStatus === "REJECTED" || currentAggregationStatus === "VERIFIED") {
          throw new HttpsError(
            "failed-precondition",
            "Ξ— Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ· Ο„ΞΏΟ… ΟƒΟ…ΞΌΞ²Ξ¬Ξ½Ο„ΞΏΟ‚ Ξ­Ο‡ΞµΞΉ Ξ®Ξ΄Ξ· ΞΏΞ»ΞΏΞΊΞ»Ξ·ΟΟ‰ΞΈΞµΞ―"
          );
        }

        const existingReview = await findExistingReviewForActorDimension(
          db,
          incidentId,
          actorUserId,
          dimensionKey
        );

        if (existingReview?.reviewId) {
          reviewId = existingReview.reviewId;
          reviewRef = db.ref(`incident_reviews/${incidentId}/${reviewId}`);
        } else {
          reviewRef = db.ref(`incident_reviews/${incidentId}`).push();
          reviewId = reviewRef.key;
        }
      } else {
        reviewRef = db.ref(`incident_reviews/${incidentId}`).push();
        reviewId = reviewRef.key;
      }

      if (!reviewId) {
        throw new HttpsError("internal", "Ξ‘Ο€ΞΏΟ„Ο…Ο‡Ξ―Ξ± Ξ΄Ξ·ΞΌΞΉΞΏΟ…ΟΞ³Ξ―Ξ±Ο‚ Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ·Ο‚");
      }

      const reviewData = {
        incidentId,
        authUserId: authUid,
        actorUserId,
        userId: actorUserId,
        userName: actorDisplayName,
        displayName: actorDisplayName,
        siteId: actorSiteId,
        actorRoles,
        sessionType,
        role,
        action,
        comment,
        createdAt: now,
        source: "MOBILE",
        policyKey,
        dimensionKey,
        dimensionLabel,
        reviewScope: multiDimensionalEnabled ? "DIMENSION" : "SINGLE_TRACK",
        affectsAggregation: true,
      };

      await reviewRef.set(reviewData);

      let dimensionReviewStatus = "PENDING";
      let nextReviewAggregationStatus = normalizeKey(incident.reviewAggregationStatus) || "PENDING";

      if (multiDimensionalEnabled) {
        const reviewDimensions = initializeReviewDimensionsFromMatrix(
          activeReviewMatrix,
          incident.reviewDimensions as Record<string, any> | undefined,
          Number(incident.createdAt ?? now),
        );

        let dimensionInvestigations = initializeDimensionInvestigations(
          incident.dimensionInvestigations as Record<string, any> | undefined
        );

        const dimensionTracks = initializeDimensionTracks(
          activeReviewMatrix,
          incident.dimensionTracks as Record<string, any> | undefined,
          Number(incident.createdAt ?? now),
        );

        const latestDimensionReviews = await collectLatestDimensionReviews(
          db,
          incidentId,
          dimensionKey
        );

        const dimensionCompletedRoles: Record<string, boolean> = {};
        let dimensionRecognizeCount = 0;
        let dimensionRejectCount = 0;

        latestDimensionReviews.forEach(({ data }) => {
          const reviewAction = normalizeKey(data.action);
          const reviewRole = normalizeKey(data.role);

          if (reviewRole) {
            dimensionCompletedRoles[reviewRole] = true;
          }

          if (reviewAction === "RECOGNIZE") {
            dimensionRecognizeCount += 1;
          } else if (reviewAction === "REJECT") {
            dimensionRejectCount += 1;
          }
        });

        if (dimensionRejectCount > 0) {
          dimensionReviewStatus = "REJECTED";
        } else if (dimensionRecognizeCount >= dimensionMinimumApprovals) {
          dimensionReviewStatus = "RECOGNIZED";
        } else if (dimensionRecognizeCount > 0) {
          dimensionReviewStatus = "UNDER_REVIEW";
        } else {
          dimensionReviewStatus = "PENDING";
        }

        reviewDimensions[dimensionKey] = {
          label: dimensionLabel,
          requiredRoles: dimensionRequiredRoles,
          minimumApprovals: dimensionMinimumApprovals,
          recognizeCount: dimensionRecognizeCount,
          rejectCount: dimensionRejectCount,
          completedRoles: dimensionCompletedRoles,
          status: dimensionReviewStatus,
          lastUpdatedAt: now,
        };

        dimensionTracks[dimensionKey] = {
          ...(dimensionTracks[dimensionKey] || {}),
          active: true,
          dimensionKey,
          label: dimensionLabel,
          ownerRoles: dimensionRequiredRoles,
          reviewStatus: dimensionReviewStatus,
          decision: action,
          decisionBy: actorUserId,
          decisionAt: now,
          decisionComment: comment,
          recognizeCount: dimensionRecognizeCount,
          rejectCount: dimensionRejectCount,
          updatedAt: now,
          updatedBy: actorUserId,
          updatedByName: actorDisplayName,
        };

        if (
          dimensionReviewStatus === "RECOGNIZED" &&
          !dimensionInvestigations[dimensionKey]
        ) {
          dimensionInvestigations[dimensionKey] = {
            dimensionKey,
            label: dimensionLabel,
            assignedRoles: dimensionRequiredRoles,
            status: "PENDING",
            notes: "",
            actionsSummary: "",
            updatedAt: now,
            updatedBy: actorUserId,
            updatedByName: actorDisplayName,
            completedAt: 0,
            completedBy: "",
            completedByName: "",
          };
        }

        const flattenedState = buildFlattenedRoleStateFromDimensions(reviewDimensions);

        const dimensionStatuses = Object.values(reviewDimensions).map((value) =>
          normalizeKey((value as Record<string, any>).status as string)
        );

        const anyRejected = dimensionStatuses.some(
          (status) => status === "REJECTED"
        );

        const allRecognized =
          dimensionStatuses.length > 0 &&
          dimensionStatuses.every(
            (status) => status === "RECOGNIZED"
          );

        const hasAnyActivity =
          Object.keys(flattenedState.completedRoles).length > 0 ||
          dimensionStatuses.some(
            (status) =>
              status === "RECOGNIZED" ||
              status === "REJECTED" ||
              status === "UNDER_REVIEW"
          );

        if (anyRejected) {
          nextReviewAggregationStatus = "REJECTED";
        } else if (allRecognized) {
          nextReviewAggregationStatus = "VERIFIED";
        } else if (hasAnyActivity) {
          nextReviewAggregationStatus = "UNDER_REVIEW";
        } else {
          nextReviewAggregationStatus = "PENDING";
        }

        await incidentRef.update({
          reviewMode: "MULTI_DIMENSIONAL",
          reviewDimensions,
          dimensionTracks,
          dimensionInvestigations,
          selectedReviewDimensions: Object.keys(reviewDimensions).reduce(
            (acc, key) => {
              acc[key] = true;
              return acc;
            },
            {} as Record<string, boolean>
          ),
          pendingRoles: flattenedState.pendingRoles,
          completedRoles: flattenedState.completedRoles,
          reviewAggregationStatus: nextReviewAggregationStatus,
        });
      }

      const stats = await readReviewStats(db, incidentId, finalAuthorityRoles);

      let finalIncidentStatus = incident.status || "PENDING";
      let finalVerificationStatus = incident.verificationStatus || "PENDING";

      let shouldRejectFinally = false;
      let shouldRecognizeFinally = false;

      if (multiDimensionalEnabled) {
        shouldRejectFinally = nextReviewAggregationStatus === "REJECTED";
        shouldRecognizeFinally = nextReviewAggregationStatus === "VERIFIED";
      } else {
        const approvalsNeeded = requiresVerification ? Math.max(1, minimumApprovals) : 0;

        shouldRejectFinally = stats.hasAuthorityReject && rejectOverrides;

        shouldRecognizeFinally =
          !shouldRejectFinally &&
          (!requiresVerification || approvalsNeeded === 0 || stats.recognizeCount >= approvalsNeeded);

        nextReviewAggregationStatus = shouldRejectFinally
          ? "REJECTED"
          : shouldRecognizeFinally
            ? "VERIFIED"
            : stats.recognizeCount > 0 || stats.rejectCount > 0
              ? "UNDER_REVIEW"
              : "PENDING";
      }

      if (shouldRejectFinally) {
        const rejectTrackOwnerRoles = resolveSingleTrackOwnerRoles(
          policy,
          allowedRolesRecord,
          finalAuthorityRoles
        );

        const rejectTrack = initializeSingleTrackLifecycle(
          incident.singleTrackLifecycle,
          policy,
          policyKey,
          rejectTrackOwnerRoles,
          now,
          actorUserId,
          actorDisplayName,
          "REJECTED"
        );

        const updates = {
          verified: false,
          verificationStatus: "REJECTED",
          rejectedBy: actorUserId,
          rejectedByName: actorDisplayName,
          rejectedByRole: role,
          rejectedAt: now,
          rejectionSource: "FUNCTION",
          rejectionComment: comment,
          status: "REJECTED",
          visibleToSite: false,
          active: false,
          reviewAggregationStatus: nextReviewAggregationStatus,
          ...(multiDimensionalEnabled ? {} : {
            reviewMode: singleTrackWorkflowEnabled ? "SINGLE_TRACK" : (incident.reviewMode || "SINGLE"),
            singleTrackLifecycle: {
              ...rejectTrack,
              reviewStatus: "REJECTED",
              closureStatus: "LOCKED",
              updatedAt: now,
              updatedBy: actorUserId,
              updatedByName: actorDisplayName,
            },
          }),

          verifiedBy: null,
          verifiedByName: null,
          verifiedByRole: null,
          verifiedAt: null,
          verificationSource: null,
          verificationComment: null,
        };

        await incidentRef.update(updates);

        finalIncidentStatus = "REJECTED";
        finalVerificationStatus = "REJECTED";
      } else if (shouldRecognizeFinally) {
        const isAggregatedVerification = multiDimensionalEnabled;
        const singleTrackOwnerRoles = resolveSingleTrackOwnerRoles(
          policy,
          allowedRolesRecord,
          finalAuthorityRoles
        );

        const singleTrackInvestigation = initializeSingleTrackInvestigation(
          incident.investigation,
          policy,
          incident,
          policyKey,
          singleTrackOwnerRoles,
          now,
          actorUserId,
          actorDisplayName
        );

        const singleTrackActionsSummary = initializeSingleTrackActionsSummary(
          incident.incidentActionsSummary,
          policy,
          singleTrackOwnerRoles,
          now
        );

        const singleTrackLifecycle = initializeSingleTrackLifecycle(
          incident.singleTrackLifecycle,
          policy,
          policyKey,
          singleTrackOwnerRoles,
          now,
          actorUserId,
          actorDisplayName,
          "RECOGNIZED"
        );

        const updates: Record<string, any> = {
          verified: true,
          verificationStatus: "VERIFIED",
          verifiedBy: isAggregatedVerification ? "MULTI_DIMENSIONAL_WORKFLOW" : actorUserId,
          verifiedByName: isAggregatedVerification ? "Ξ£Ο…Ξ»Ξ»ΞΏΞ³ΞΉΞΊΞ® Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ·" : actorDisplayName,
          verifiedByRole: isAggregatedVerification ? "MULTI_ROLE" : role,
          verifiedAt: now,
          verificationSource: "FUNCTION",
          verificationComment: comment,
          status: "CONFIRMED",
          visibleToSite: true,
          active: true,
          reviewAggregationStatus: nextReviewAggregationStatus,

          rejectedBy: null,
          rejectedByName: null,
          rejectedByRole: null,
          rejectedAt: null,
          rejectionSource: null,
          rejectionComment: null,
        };

        if (!multiDimensionalEnabled) {
          updates.reviewMode = singleTrackWorkflowEnabled ? "SINGLE_TRACK" : (incident.reviewMode || "SINGLE");
          updates.singleTrackLifecycle = {
            ...singleTrackLifecycle,
            reviewStatus: "RECOGNIZED",
            investigationStatus: singleTrackInvestigation.status,
            actionsStatus: singleTrackActionsSummary.status,
            closureStatus: "OPEN",
            updatedAt: now,
            updatedBy: actorUserId,
            updatedByName: actorDisplayName,
          };

          if (policy.workflowExtensions?.investigation?.enabled === true) {
            updates.investigation = singleTrackInvestigation;
          }

          if (policy.workflowExtensions?.actions?.enabled === true) {
            updates.incidentActionsSummary = singleTrackActionsSummary;
          }
        }

        await incidentRef.update(updates);

        finalIncidentStatus = "CONFIRMED";
        finalVerificationStatus = "VERIFIED";
      } else {
        const singleTrackOwnerRoles = resolveSingleTrackOwnerRoles(
          policy,
          allowedRolesRecord,
          finalAuthorityRoles
        );

        const pendingTrack = initializeSingleTrackLifecycle(
          incident.singleTrackLifecycle,
          policy,
          policyKey,
          singleTrackOwnerRoles,
          now,
          actorUserId,
          actorDisplayName,
          "UNDER_REVIEW"
        );

        const updates: Record<string, any> = {
          verificationStatus: "UNDER_REVIEW",
          status: "PENDING",
          visibleToSite: false,
          active: true,
          verified: false,
          reviewAggregationStatus: nextReviewAggregationStatus,
          verifiedBy: null,
          verifiedByName: null,
          verifiedByRole: null,
          verifiedAt: null,
          verificationSource: null,
          verificationComment: null,
          rejectedBy: null,
          rejectedByName: null,
          rejectedByRole: null,
          rejectedAt: null,
          rejectionSource: null,
          rejectionComment: null,
        };

        if (!multiDimensionalEnabled) {
          updates.reviewMode = singleTrackWorkflowEnabled ? "SINGLE_TRACK" : (incident.reviewMode || "SINGLE");
          updates.singleTrackLifecycle = {
            ...pendingTrack,
            reviewStatus: "UNDER_REVIEW",
            updatedAt: now,
            updatedBy: actorUserId,
            updatedByName: actorDisplayName,
          };
        }

        await incidentRef.update(updates);

        finalIncidentStatus = "PENDING";
        finalVerificationStatus = "UNDER_REVIEW";
      }

      const eventRef = db.ref("incident_events").push();
      const eventId = eventRef.key;
      if (!eventId) {
        throw new HttpsError("internal", "Ξ‘Ο€ΞΏΟ„Ο…Ο‡Ξ―Ξ± Ξ΄Ξ·ΞΌΞΉΞΏΟ…ΟΞ³Ξ―Ξ±Ο‚ event");
      }

      const eventType = shouldRejectFinally
        ? "INCIDENT_REJECTED"
        : shouldRecognizeFinally
          ? "INCIDENT_RECOGNIZED"
          : "INCIDENT_REVIEW_RECORDED";

      const eventData = {
        id: eventId,
        incidentId,
        eventType,
        createdAt: now,
        authUserId: authUid,
        userId: actorUserId,
        userName: actorDisplayName,
        siteId: actorSiteId,
        source: "FUNCTION",
        extra: {
          category,
          severity,
          roleUsed: role,
          actorRoles,
          sessionType,
          comment,
          policyKey,
          requiresVerification,
          minimumApprovals,
          rejectOverrides,
          dimensionKey,
          dimensionLabel,
          dimensionReviewStatus,
          reviewAggregationStatus: nextReviewAggregationStatus,
          finalAuthorityRoles: Object.keys(finalAuthorityRoles).filter(
            (key) => finalAuthorityRoles[key] === true
          ),
          recognizeCount: stats.recognizeCount,
          rejectCount: stats.rejectCount,
          hasAuthorityReject: stats.hasAuthorityReject,
          finalIncidentStatus,
          finalVerificationStatus,
          reviewId,
          aggregationMode: multiDimensionalEnabled ? "MULTI_DIMENSIONAL" : "SINGLE",
          singleTrackWorkflowEnabled,
          investigationEnabled: policy.workflowExtensions?.investigation?.enabled === true,
          actionsEnabled: policy.workflowExtensions?.actions?.enabled === true,
        },
      };

      await eventRef.set(eventData);

      logger.info("submitReviewAction completed", {
        incidentId,
        reviewId,
        eventId,
        action,
        policyKey,
        dimensionKey,
        requiresVerification,
        minimumApprovals,
        rejectOverrides,
        recognizeCount: stats.recognizeCount,
        rejectCount: stats.rejectCount,
        hasAuthorityReject: stats.hasAuthorityReject,
        reviewAggregationStatus: nextReviewAggregationStatus,
        finalIncidentStatus,
        finalVerificationStatus,
        aggregationMode: multiDimensionalEnabled ? "MULTI_DIMENSIONAL" : "SINGLE",
        singleTrackWorkflowEnabled,
      });

      return {
        success: true,
        reviewId,
        eventId,
        actorUserId,
        actorDisplayName,
        actorSiteId,
        policyKey,
        requiresVerification,
        minimumApprovals,
        rejectOverrides,
        recognizeCount: stats.recognizeCount,
        rejectCount: stats.rejectCount,
        hasAuthorityReject: stats.hasAuthorityReject,
        reviewAggregationStatus: nextReviewAggregationStatus,
        incidentStatus: finalIncidentStatus,
        verificationStatus: finalVerificationStatus,
        aggregationMode: multiDimensionalEnabled ? "MULTI_DIMENSIONAL" : "SINGLE",
        singleTrackWorkflowEnabled,
      };
    } catch (error: any) {
      logger.error("submitReviewAction failed", {
        message: error?.message || "unknown",
        code: error?.code || "unknown",
        stack: error?.stack || "",
      });

      if (error instanceof HttpsError) {
        throw error;
      }

      throw new HttpsError(
        "internal",
        error?.message || "Ξ‘Ο€ΞΏΟ„Ο…Ο‡Ξ―Ξ± ΞΊΞ±Ο„Ξ±Ο‡ΟΟΞ·ΟƒΞ·Ο‚ Ξ±ΞΎΞΉΞΏΞ»ΟΞ³Ξ·ΟƒΞ·Ο‚"
      );
    }
  }
);
