import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";

type ReviewActorContext = {
  userId: string;
  displayName: string;
  siteId: string;
  roles: string[];
  sessionType?: "REAL_SESSION" | "PILOT_SESSION";
};

type ActionResponse = "ACCEPT" | "REJECT";

type RespondDimensionActionData = {
  incidentId: string;
  dimensionKey: string;
  actionId: string;
  response: ActionResponse;
  comment?: string;
  actor?: ReviewActorContext;
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toSafeInt(value: unknown, fallback = 0): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.floor(parsed)) : fallback;
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

function uniqueNormalizedKeys(values: unknown[]): string[] {
  return Array.from(
    new Set(
      values
        .map((value) => normalizeKey(value))
        .filter((value) => value.length > 0)
    )
  );
}

function buildNotificationRetryBlock() {
  return {
    enabled: false,
    retryCount: 0,
    maxRetryCount: 0,
    retryReason: "",
    nextRetryAt: 0,
  };
}

async function resolveExplicitUserForNotification(
  db: admin.database.Database,
  siteId: string,
  userId: string
): Promise<{
  resolvedUsers: Record<string, any>;
  droppedUsers: Record<string, string>;
}> {
  const resolvedUsers: Record<string, any> = {};
  const droppedUsers: Record<string, string> = {};

  const userSnap = await db.ref(`users/${userId}`).once("value");
  if (!userSnap.exists()) {
    droppedUsers[userId] = "USER_NOT_FOUND";
    return { resolvedUsers, droppedUsers };
  }

  const user = userSnap.val() || {};
  if (user.active === false) {
    droppedUsers[userId] = "USER_INACTIVE";
    return { resolvedUsers, droppedUsers };
  }

  const userSiteId = safeString(user.siteId).toLowerCase();
  if (userSiteId !== safeString(siteId).toLowerCase()) {
    droppedUsers[userId] = "USER_SITE_MISMATCH";
    return { resolvedUsers, droppedUsers };
  }

  const tokenMap: Record<string, string> = {};
  const fcmTokens = user.fcmTokens || {};
  Object.entries(fcmTokens).forEach(([key, value]) => {
    const token = safeString(value);
    if (token) tokenMap[key] = token;
  });

  const fallbackToken = safeString(user.fcmToken);
  if (fallbackToken && !Object.values(tokenMap).includes(fallbackToken)) {
    tokenMap.default = fallbackToken;
  }

  if (Object.keys(tokenMap).length === 0) {
    droppedUsers[userId] = "NO_TOKENS";
    return { resolvedUsers, droppedUsers };
  }

  resolvedUsers[userId] = {
    siteId,
    displayName: safeString(user.displayName) || userId,
    viaRoles: {},
    viaTeams: {},
    viaExplicit: true,
    tokens: tokenMap,
  };

  return {
    resolvedUsers,
    droppedUsers,
  };
}

function resolveDimensionActionsStatus(
  dimensionActions: Record<string, any>
): "NOT_REQUIRED" | "PENDING" | "COMPLETED" {
  const actions = Object.values(dimensionActions || {}) as Array<Record<string, any>>;
  if (actions.length === 0) {
    return "NOT_REQUIRED";
  }

  const statuses = actions.map((item) => normalizeKey(item.status));

  const hasOpenOrUnresolved = statuses.some((status) =>
    [
      "PENDING",
      "PENDING_ACCEPTANCE",
      "ASSIGNED",
      "ACCEPTED",
      "IN_PROGRESS",
      "REJECTED",
    ].includes(status)
  );

  if (hasOpenOrUnresolved) {
    return "PENDING";
  }

  const allCompleted =
    statuses.length > 0 && statuses.every((status) => status === "COMPLETED");

  if (allCompleted) {
    return "COMPLETED";
  }

  return "PENDING";
}

export const respondDimensionAction = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const db = admin.database();

    try {
      if (!request.auth) {
        throw new HttpsError("unauthenticated", "Απαιτείται σύνδεση χρήστη");
      }

      const authUid = request.auth.uid;
      const data = (request.data || {}) as RespondDimensionActionData;

      const incidentId = safeString(data.incidentId);
      const dimensionKey = normalizeKey(data.dimensionKey);
      const actionId = safeString(data.actionId);
      const response = normalizeKey(data.response) as ActionResponse;
      const comment = safeString(data.comment);

      if (!incidentId) {
        throw new HttpsError("invalid-argument", "Λείπει το incidentId");
      }

      if (!dimensionKey) {
        throw new HttpsError("invalid-argument", "Λείπει το dimensionKey");
      }

      if (!actionId) {
        throw new HttpsError("invalid-argument", "Λείπει το actionId");
      }

      if (response !== "ACCEPT" && response !== "REJECT") {
        throw new HttpsError("invalid-argument", "Μη έγκυρη απάντηση");
      }

      const incidentRef = db.ref(`incidents/${incidentId}`);
      const incidentSnap = await incidentRef.once("value");
      if (!incidentSnap.exists()) {
        throw new HttpsError("not-found", "Το συμβάν δεν βρέθηκε");
      }

      const incident = (incidentSnap.val() || {}) as Record<string, any>;

      const authUserSnap = await db.ref(`users/${authUid}`).once("value");
      const authUser = authUserSnap.val() || {};

      const actorUserId =
        safeString(data.actor?.userId) ||
        safeString(authUser.uid) ||
        authUid;

      const actorDisplayName =
        safeString(data.actor?.displayName) ||
        safeString(authUser.displayName) ||
        "Άγνωστος χρήστης";

      const actorSiteId =
        safeString(data.actor?.siteId) ||
        safeString(incident.siteId) ||
        safeString(incident.site) ||
        safeString(authUser.siteId);

      const actorRolesRaw = Array.isArray(data.actor?.roles)
        ? data.actor?.roles || []
        : Object.keys(authUser.roles || {});
      const actorRoles = uniqueNormalizedKeys(actorRolesRaw);

      const sessionType =
        data.actor?.sessionType === "PILOT_SESSION"
          ? "PILOT_SESSION"
          : "REAL_SESSION";

      if (!actorSiteId) {
        throw new HttpsError("failed-precondition", "Λείπει το site του χρήστη");
      }

      const incidentSiteId = safeString(incident.siteId || incident.site);
      if (incidentSiteId.toLowerCase() !== actorSiteId.toLowerCase()) {
        throw new HttpsError(
          "permission-denied",
          "Ο χρήστης δεν ανήκει στο ίδιο site με το συμβάν"
        );
      }

      if (normalizeKey(incident.category) !== "UNSAFE_CONDITION") {
        throw new HttpsError(
          "failed-precondition",
          "Η απάντηση σε ενέργεια υποστηρίζεται μόνο για Μη Ασφαλή Κατάσταση"
        );
      }

      const incidentStatus = normalizeKey(incident.status);
      const verificationStatus = normalizeKey(incident.verificationStatus);

      if (incidentStatus === "CLOSED") {
        throw new HttpsError(
          "failed-precondition",
          "Δεν επιτρέπεται ενέργεια σε κλειστό συμβάν"
        );
      }

      if (incidentStatus === "REJECTED" || verificationStatus === "REJECTED") {
        throw new HttpsError(
          "failed-precondition",
          "Δεν επιτρέπεται ενέργεια σε απορριφθέν συμβάν"
        );
      }

      const actionRef = db.ref(`incidents/${incidentId}/dimensionActions/${dimensionKey}/${actionId}`);
      const actionSnap = await actionRef.once("value");
      if (!actionSnap.exists()) {
        throw new HttpsError("not-found", "Η ενέργεια δεν βρέθηκε");
      }

      const actionRecord = (actionSnap.val() || {}) as Record<string, any>;
      const assignedTo = safeString(actionRecord.assignedTo);
      const assignedBy = safeString(actionRecord.assignedBy);
      const currentStatus = normalizeKey(actionRecord.status);
      const acceptanceRequired = actionRecord.acceptanceRequired === true;

      if (!assignedTo) {
        throw new HttpsError("failed-precondition", "Η ενέργεια δεν έχει ανατεθεί");
      }

      if (assignedTo !== actorUserId) {
        throw new HttpsError(
          "permission-denied",
          "Μόνο ο ανατεθειμένος χρήστης μπορεί να απαντήσει"
        );
      }

      if (currentStatus === "COMPLETED") {
        throw new HttpsError("failed-precondition", "Η ενέργεια έχει ήδη ολοκληρωθεί");
      }

      if (currentStatus === "REJECTED") {
        throw new HttpsError("failed-precondition", "Η ενέργεια έχει ήδη απορριφθεί");
      }

      if (response === "ACCEPT" && !acceptanceRequired) {
        throw new HttpsError(
          "failed-precondition",
          "Η ενέργεια δεν απαιτεί αποδοχή"
        );
      }

      if (
        response === "ACCEPT" &&
        currentStatus !== "PENDING_ACCEPTANCE"
      ) {
        throw new HttpsError(
          "failed-precondition",
          "Μόνο ενέργειες σε αναμονή αποδοχής μπορούν να γίνουν αποδεκτές"
        );
      }

      if (
        response === "REJECT" &&
        !["PENDING_ACCEPTANCE", "ASSIGNED", "ACCEPTED", "IN_PROGRESS", "PENDING"].includes(currentStatus)
      ) {
        throw new HttpsError(
          "failed-precondition",
          "Η ενέργεια δεν μπορεί να απορριφθεί στην τρέχουσα κατάσταση"
        );
      }

      const dimensionTracks = (incident.dimensionTracks || {}) as Record<string, any>;
      const currentTrack = (dimensionTracks[dimensionKey] || {}) as Record<string, any>;
      if (!currentTrack || Object.keys(currentTrack).length === 0) {
        throw new HttpsError(
          "failed-precondition",
          `Η διάσταση '${dimensionKey}' δεν υπάρχει στο συμβάν`
        );
      }

      const now = Date.now();

      const nextStatus = response === "ACCEPT" ? "ACCEPTED" : "REJECTED";
      const nextAcceptanceStatus =
        response === "ACCEPT"
          ? "ACCEPTED"
          : acceptanceRequired
            ? "REJECTED"
            : "NOT_REQUIRED";

      const actionUpdates: Record<string, any> = {
        status: nextStatus,
        acceptanceStatus: nextAcceptanceStatus,
        updatedAt: now,
        updatedBy: actorUserId,
        updatedByName: actorDisplayName,
      };

      if (response === "ACCEPT") {
        actionUpdates.acceptedAt = now;
        actionUpdates.acceptedBy = actorUserId;
        actionUpdates.acceptedByName = actorDisplayName;
        actionUpdates.rejectedAt = 0;
        actionUpdates.rejectedBy = "";
        actionUpdates.rejectedByName = "";
        actionUpdates.rejectionReason = "";
      } else {
        actionUpdates.rejectedAt = now;
        actionUpdates.rejectedBy = actorUserId;
        actionUpdates.rejectedByName = actorDisplayName;
        actionUpdates.rejectionReason = comment;
      }

      await actionRef.update(actionUpdates);

      const dimensionActionsRef = db.ref(`incidents/${incidentId}/dimensionActions/${dimensionKey}`);
      const dimensionActionsSnap = await dimensionActionsRef.once("value");
      const dimensionActions = dimensionActionsSnap.exists()
        ? (dimensionActionsSnap.val() || {}) as Record<string, any>
        : {};

      const nextActionsStatus = resolveDimensionActionsStatus(dimensionActions);

      await incidentRef.update({
        [`dimensionTracks/${dimensionKey}/actionsStatus`]: nextActionsStatus,
        [`dimensionTracks/${dimensionKey}/updatedAt`]: now,
        [`dimensionTracks/${dimensionKey}/updatedBy`]: actorUserId,
        [`dimensionTracks/${dimensionKey}/updatedByName`]: actorDisplayName,
      });

      const eventRef = db.ref("incident_events").push();
      const eventType =
        response === "ACCEPT"
          ? "INCIDENT_ACTION_ACCEPTED"
          : "INCIDENT_ACTION_REJECTED";

      await eventRef.set({
        id: eventRef.key,
        incidentId,
        siteId: actorSiteId,
        source: "FUNCTION",
        userId: actorUserId,
        userName: actorDisplayName,
        authUserId: authUid,
        createdAt: now,
        eventType,
        extra: {
          category: incident.category || "",
          severity: incident.severity || "",
          actorRoles,
          sessionType,
          dimensionKey,
          dimensionLabel:
            safeString(actionRecord.dimensionLabel) ||
            safeString(currentTrack.label) ||
            dimensionKey,
          actionId,
          title: safeString(actionRecord.title),
          previousStatus: currentStatus,
          nextStatus,
          comment,
          assignedTo,
          assignedToName: safeString(actionRecord.assignedToName),
          assignedBy,
          assignedByName: safeString(actionRecord.assignedByName),
          dueDate: toSafeInt(actionRecord.dueDate, 0),
          nextActionsStatus,
        },
      });

      let notificationRequestId = "";

      if (assignedBy && assignedBy !== actorUserId) {
        const resolution = await resolveExplicitUserForNotification(
          db,
          actorSiteId,
          assignedBy
        );

        const requestRef = db.ref("notification_requests").push();
        await requestRef.set({
          id: requestRef.key,
          incidentId,
          siteId: actorSiteId,
          category: incident.category || "",
          type: "ACTION_RESPONSE",
          status: "PENDING",
          meta: {
            schemaVersion: 2,
            source: "SYSTEM",
            triggerEvent: response === "ACCEPT" ? "ACTION_ACCEPTED" : "ACTION_REJECTED",
            createdAt: now,
            processedAt: 0,
            lastAttemptAt: 0,
          },
          policy: {
            policyUsed: true,
            policySourcePath: "",
            matchedPolicyIds: {},
            dynamicTargeting: true,
            dynamicTargetSource:
              response === "ACCEPT"
                ? "UNSAFE_CONDITION_ACTION_ACCEPTED"
                : "UNSAFE_CONDITION_ACTION_REJECTED",
          },
          targeting: {
            mode: "DIRECT_USER",
            siteScope: "SITE_ONLY",
            siteId: actorSiteId,
            targetRoles: {},
            targetTeams: {},
            explicitUsers: {
              [assignedBy]: true,
            },
          },
          context: {
            dimensionKey,
            actionId,
            actionTitle: safeString(actionRecord.title),
            actionResponse: response,
            comment,
          },
          resolution: {
            resolvedUsers: resolution.resolvedUsers,
            resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
            droppedUsers: resolution.droppedUsers,
            droppedUserCount: Object.keys(resolution.droppedUsers).length,
          },
          delivery: {
            channel: "FCM",
            attemptedRecipientCount: 0,
            validRecipientCount: 0,
            successCount: 0,
            failureCount: 0,
            invalidTokenCount: 0,
            deliveryResults: {},
            failedTokens: [],
            invalidTokens: [],
            retryableFailedTokens: [],
          },
          retry: buildNotificationRetryBlock(),
        });

        notificationRequestId = requestRef.key || "";
      }

      logger.info("respondDimensionAction completed", {
        incidentId,
        dimensionKey,
        actionId,
        response,
        actorUserId,
        assignedBy,
        nextStatus,
        nextActionsStatus,
        notificationRequestId,
      });

      return {
        ok: true,
        incidentId,
        dimensionKey,
        actionId,
        response,
        actionStatus: nextStatus,
        actionsStatus: nextActionsStatus,
        notificationRequestId,
      };
    } catch (error: any) {
      logger.error("respondDimensionAction failed", {
        error: error?.message || String(error),
        stack: error?.stack || null,
        rawData: request.data ?? null,
        authUid: request.auth?.uid || null,
      });

      if (error instanceof HttpsError) {
        throw error;
      }

      throw new HttpsError(
        "internal",
        error?.message || "Αποτυχία καταχώρησης απάντησης ενέργειας"
      );
    }
  }
);