import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as admin from "firebase-admin";

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  verification?: {
    allowedRoles?: Record<string, boolean>;
    minimumApprovals?: number;
    finalAuthorityRoles?: Record<string, boolean>;
    rejectOverrides?: boolean;
  };
  workflow?: {
    requiresVerification?: boolean;
  };
  workflowExtensions?: {
    investigation?: {
      enabled?: boolean;
      perDimension?: boolean;
      requiredBeforeClosure?: boolean;
      requiredFields?: Record<string, boolean>;
    };
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
  };
};

type InvestigationPayload = {
  incidentDescription?: unknown;
  incidentTypes?: unknown;
  intensity?: unknown;
  impactExtent?: unknown;
  pollutionReceivers?: unknown;
  cause?: unknown;
  involvedPersons?: unknown;
  involvedNotes?: unknown;
  impact?: unknown;
  actionsTaken?: unknown;
  meansUsed?: unknown;
  responseEvaluation?: unknown;
  improvementProposals?: unknown;
  notes?: unknown;
};

type ActorInput = {
  userId?: unknown;
  displayName?: unknown;
  siteId?: unknown;
  roles?: unknown;
  sessionType?: unknown;
};

function normalizeKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeKey(key)] = true;
    }
  });
  return result;
}

/**
 * Κρατά τα original field names όπως είναι στο policy node.
 * Π.χ. actionsTaken, responseEvaluation
 * ΔΕΝ τα κάνει uppercase.
 */
function sanitizeNamedBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    const cleanKey = safeString(key);
    if (cleanKey && enabled === true) {
      result[cleanKey] = true;
    }
  });
  return result;
}

function sanitizeRolesFromUnknown(value: unknown): Record<string, boolean> {
  if (Array.isArray(value)) {
    const result: Record<string, boolean> = {};
    value.forEach((item) => {
      const key = normalizeKey(item);
      if (key) result[key] = true;
    });
    return result;
  }
  return sanitizeBooleanRecord(value);
}

function sanitizeStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => safeString(item))
    .filter((item) => item.length > 0);
}

function buildInvestigationData(input: InvestigationPayload): Record<string, unknown> {
  return {
    incidentDescription: safeString(input.incidentDescription),
    incidentTypes: sanitizeStringArray(input.incidentTypes),
    intensity: safeString(input.intensity),
    impactExtent: safeString(input.impactExtent),
    pollutionReceivers: sanitizeStringArray(input.pollutionReceivers),
    cause: safeString(input.cause),
    involvedPersons: sanitizeStringArray(input.involvedPersons),
    involvedNotes: safeString(input.involvedNotes),
    impact: safeString(input.impact),
    actionsTaken: safeString(input.actionsTaken),
    meansUsed: safeString(input.meansUsed),
    responseEvaluation: safeString(input.responseEvaluation),
    improvementProposals: safeString(input.improvementProposals),
    notes: safeString(input.notes),
  };
}

function hasValue(value: unknown): boolean {
  if (Array.isArray(value)) return value.length > 0;
  return safeString(value).length > 0;
}

function resolveMissingRequiredFields(
  data: Record<string, unknown>,
  requiredFields: Record<string, boolean>
): string[] {
  return Object.keys(requiredFields || {}).filter((fieldKey) => {
    if (requiredFields[fieldKey] !== true) return false;
    return !hasValue(data[fieldKey]);
  });
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: Record<string, any>
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db.ref(`site_config_data/${siteId}/incident_policies`).get();

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeKey(incident.category);
  const incidentType = normalizeKey(incident.type);
  const incidentSubtype = normalizeKey(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null = null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = sanitizeBooleanRecord((policy as any).matchCategories);
    const matchTypes = sanitizeBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeKey(policy.category) === incidentCategory ||
      normalizeKey(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeKey(policyKey) === incidentType ||
      normalizeKey(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

function resolveAllActionsCompleted(singleTrackActions: Record<string, any>): boolean {
  for (const action of Object.values(singleTrackActions || {})) {
    const status = normalizeKey((action as Record<string, unknown>).status);
    if (status !== "COMPLETED") {
      return false;
    }
  }
  return true;
}

export const upsertEnvironmentalInvestigation = onCall(
  {
    region: "europe-west1",
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    const authUserId = request.auth?.uid;
    const { incidentId, investigation, complete, actor } = request.data || {};

    if (!authUserId) {
      throw new HttpsError("unauthenticated", "Μη εξουσιοδοτημένη πρόσβαση");
    }

    if (!incidentId) {
      throw new HttpsError("invalid-argument", "Λείπει το incidentId");
    }

    if (!investigation || typeof investigation !== "object") {
      throw new HttpsError("invalid-argument", "Λείπουν τα στοιχεία διερεύνησης");
    }

    const db = admin.database();
    const incidentRef = db.ref(`incidents/${incidentId}`);
    const incidentSnap = await incidentRef.get();

    if (!incidentSnap.exists()) {
      throw new HttpsError("not-found", "Το συμβάν δεν βρέθηκε");
    }

    const incident = incidentSnap.val() || {};
    const siteId = safeString(incident.siteId || incident.site);

    if (!siteId) {
      throw new HttpsError("failed-precondition", "Το συμβάν δεν έχει siteId");
    }

    const actorInput = (actor || {}) as ActorInput;
    const actorUserId = safeString(actorInput.userId);
    const actorDisplayName = safeString(actorInput.displayName);
    const actorSiteId = safeString(actorInput.siteId);
    const actorRoles = sanitizeRolesFromUnknown(actorInput.roles);

    const profileUserId = actorUserId || authUserId;
    const userSnap = await db.ref(`users/${profileUserId}`).get();
    const user = userSnap.val() || {};

    const userSiteId = safeString(user.siteId || user.site || actorSiteId);
    const userRolesFromProfile = sanitizeBooleanRecord(user.roles);
    const userRoles =
      Object.keys(userRolesFromProfile).length > 0 ? userRolesFromProfile : actorRoles;

    const actorName =
      safeString(user.displayName) ||
      actorDisplayName ||
      safeString(request.auth?.token?.name) ||
      profileUserId;

    if (!userSnap.exists() && !actorUserId) {
      throw new HttpsError("permission-denied", "Ο χρήστης δεν βρέθηκε στο προφίλ χρηστών");
    }

    if (!userSiteId || normalizeKey(userSiteId) !== normalizeKey(siteId)) {
      throw new HttpsError("permission-denied", "Ο χρήστης δεν ανήκει στο ίδιο site με το συμβάν");
    }

    const resolvedPolicy = await resolveIncidentPolicy(db, siteId, incident);
    if (!resolvedPolicy) {
      throw new HttpsError("failed-precondition", "Δεν βρέθηκε policy για το συμβάν");
    }

    const { policyKey, policy } = resolvedPolicy;
    const incidentCategory = normalizeKey(incident.category);

    if (incidentCategory !== "ENVIRONMENTAL_INCIDENT") {
      throw new HttpsError(
        "failed-precondition",
        "Η λειτουργία αυτή υποστηρίζει μόνο το ENVIRONMENTAL_INCIDENT"
      );
    }

    const investigationPolicy = policy.workflowExtensions?.investigation;
    if (investigationPolicy?.enabled !== true) {
      throw new HttpsError(
        "failed-precondition",
        "Η διερεύνηση δεν είναι ενεργή για αυτό το policy"
      );
    }

    if (investigationPolicy.perDimension === true) {
      throw new HttpsError(
        "failed-precondition",
        "Το policy είναι dimension-based και δεν υποστηρίζεται από αυτό το function"
      );
    }

    const isAllowedRole =
      userRoles.ENVIRONMENTAL_OFFICER === true ||
      userRoles.HSE_MANAGER === true ||
      userRoles.SITE_MANAGER === true;

    if (!isAllowedRole) {
      throw new HttpsError(
        "permission-denied",
        "Δεν έχεις δικαίωμα ενημέρωσης της διερεύνησης"
      );
    }

    const verificationRequired = policy.workflow?.requiresVerification !== false;
    const verificationStatus = normalizeKey(incident.verificationStatus);
    if (
      verificationRequired &&
      verificationStatus !== "VERIFIED" &&
      verificationStatus !== "AUTO_VERIFIED"
    ) {
      throw new HttpsError(
        "failed-precondition",
        "Η διερεύνηση μπορεί να ενημερωθεί μόνο μετά την επιβεβαίωση του συμβάντος"
      );
    }

    const currentStatus = normalizeKey(incident.status);
    if (currentStatus === "REJECTED" || currentStatus === "CLOSED") {
      throw new HttpsError(
        "failed-precondition",
        "Δεν μπορεί να ενημερωθεί διερεύνηση σε κλειστό ή απορριφθέν συμβάν"
      );
    }

    const now = Date.now();
    const existingInvestigation = (incident.investigation || {}) as Record<string, any>;
    const existingData = (existingInvestigation.data || {}) as Record<string, unknown>;
    const newData = buildInvestigationData(investigation as InvestigationPayload);
    const mergedData = {
      ...existingData,
      ...newData,
    };

    const shouldComplete = complete === true;

    // ΚΡΑΤΑΜΕ ΤΑ ORIGINAL FIELD NAMES
    const requiredFields = sanitizeNamedBooleanRecord(investigationPolicy.requiredFields);

    const missingRequiredFields = shouldComplete
      ? resolveMissingRequiredFields(mergedData, requiredFields)
      : [];

    if (shouldComplete && missingRequiredFields.length > 0) {
      throw new HttpsError(
        "failed-precondition",
        `Λείπουν υποχρεωτικά πεδία διερεύνησης: ${missingRequiredFields.join(", ")}`
      );
    }

    const previousStartedAt = Number(existingInvestigation.startedAt || 0) || now;
    const nextStatus = shouldComplete ? "COMPLETED" : "IN_PROGRESS";

    const updates: Record<string, unknown> = {
      investigation: {
        ...existingInvestigation,
        status: nextStatus,
        required: investigationPolicy.requiredBeforeClosure === true,
        investigatorUserId: profileUserId,
        investigatorName: actorName,
        startedAt: previousStartedAt,
        updatedAt: now,
        updatedBy: profileUserId,
        updatedByName: actorName,
        completedAt: shouldComplete ? now : existingInvestigation.completedAt || 0,
        completedBy: shouldComplete ? profileUserId : existingInvestigation.completedBy || "",
        completedByName: shouldComplete ? actorName : existingInvestigation.completedByName || "",
        data: mergedData,
      },
      singleTrackLifecycle: {
        ...((incident.singleTrackLifecycle || {}) as Record<string, unknown>),
        investigationStatus: nextStatus,
        updatedAt: now,
        updatedBy: profileUserId,
        updatedByName: actorName,
      },
    };

    if (shouldComplete) {
      const singleTrackActions = (incident.singleTrackActions || {}) as Record<string, any>;
      const allActionsCompleted = resolveAllActionsCompleted(singleTrackActions);
      const actionCount = Object.keys(singleTrackActions).length;

      updates.incidentActionsSummary = {
        ...((incident.incidentActionsSummary || {}) as Record<string, unknown>),
        totalCount: actionCount,
        completedCount: allActionsCompleted
          ? actionCount
          : Number((incident.incidentActionsSummary || {}).completedCount || 0),
        allCompleted: allActionsCompleted,
        updatedAt: now,
      };
    }

    await incidentRef.update(updates);

    const eventRef = db.ref("incident_events").push();
    const eventType = shouldComplete
      ? "INCIDENT_INVESTIGATION_COMPLETED"
      : "INCIDENT_INVESTIGATION_UPDATED";

    await eventRef.set({
      id: eventRef.key,
      incidentId,
      siteId,
      eventType,
      createdAt: now,
      userId: profileUserId,
      userName: actorName,
      authUserId,
      source: "FUNCTION",
      extra: {
        category: incident.category || "",
        policyKey,
        completionRequested: shouldComplete,
        missingRequiredFields,
        actorUserId: actorUserId || null,
        sessionType: safeString(actorInput.sessionType) || null,
      },
    });

    const closurePolicy = policy.workflowExtensions?.closure;
    const closureEligible =
      normalizeKey(incident.verificationStatus) === "VERIFIED" &&
      (closurePolicy?.requiresInvestigationCompleted !== true || shouldComplete === true) &&
      (closurePolicy?.requiresActionsCompleted !== true ||
        resolveAllActionsCompleted((incident.singleTrackActions || {}) as Record<string, any>) === true);

    return {
      ok: true,
      incidentId,
      status: nextStatus,
      eventType,
      missingRequiredFields,
      closureEligible,
    };
  }
);