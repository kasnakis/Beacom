import * as admin from "firebase-admin";

type ActionStatus =
  | "ASSIGNED"
  | "ACCEPTED"
  | "REJECTED"
  | "COMPLETED"
  | string;

function getDb(): admin.database.Database {
  return admin.database();
}

function resolveActionsStatus(args: {
  total: number;
  open: number;
  completed: number;
  accepted: number;
}): string {
  const { total, open, completed, accepted } = args;

  if (total === 0) return "NO_ACTIONS";
  if (open === 0 && completed === total) return "COMPLETED";
  if (accepted > 0 || completed > 0) return "IN_PROGRESS";
  return "PENDING";
}

export async function updateEnvironmentalActionSummary(
  incidentId: string
): Promise<void> {
  const db = getDb();
  const incidentRef = db.ref(`incidents/${incidentId}`);
  const actionsRef = incidentRef.child("singleTrackActions");

  const actionsSnap = await actionsRef.get();
  const actionsData = actionsSnap.val() || {};

  let total = 0;
  let open = 0;
  let completed = 0;
  let rejected = 0;
  let accepted = 0;
  let assigned = 0;

  for (const action of Object.values(actionsData) as Array<{ status?: ActionStatus }>) {
    total += 1;

    const status = action?.status ?? "ASSIGNED";

    switch (status) {
      case "COMPLETED":
        completed += 1;
        break;
      case "REJECTED":
        rejected += 1;
        open += 1;
        break;
      case "ACCEPTED":
        accepted += 1;
        open += 1;
        break;
      case "ASSIGNED":
      default:
        assigned += 1;
        open += 1;
        break;
    }
  }

  const now = Date.now();
  const actionsStatus = resolveActionsStatus({
    total,
    open,
    completed,
    accepted,
  });

  await incidentRef.update({
    incidentActionsSummary: {
      total,
      open,
      completed,
      rejected,
      accepted,
      assigned,
      lastUpdatedAt: now,
    },
    "singleTrackLifecycle/actionsStatus": actionsStatus,
    "singleTrackLifecycle/actionsLastUpdatedAt": now,
  });
}