export type ExternalAuthorityType =
  | "CIVIL_PROTECTION"
  | "EMS"
  | "ENVIRONMENTAL_AUTHORITY"
  | "FIRE_BRIGADE"
  | "POLICE";

export type ExternalNotificationMode =
  | "AUTO"
  | "MANUAL"
  | "MANUAL_APPROVAL"
  | "MANUAL_LOGGED";

export type ExternalNotificationChannel =
  | "PHONE"
  | "EMAIL"
  | "SMS"
  | "API";

export type ExternalResolverTrigger =
  | "INCIDENT_CREATED"
  | "INCIDENT_VERIFIED"
  | "INCIDENT_UNDER_CONTROL"
  | "MANUAL_REQUEST";

export type ExternalAuthorityContact = {
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
};

export type ExternalAuthorityRegistryEntry = {
  id?: string;
  name?: string;
  type?: string;
  siteId?: string;
  enabled?: boolean;
  active?: boolean;
  defaultChannel?: string;
  supportedChannels?: Record<string, boolean>;
  contacts?: {
    primary?: ExternalAuthorityContact;
    secondary?: ExternalAuthorityContact;
  };
};

export type WorkflowExternalAuthorityConfig = {
  enabled?: boolean;
  autoSuggest?: boolean;
  defaultChannel?: string;
  requiresApproval?: boolean;
  allowedRequesterRoles?: Record<string, boolean>;
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
};

export type WorkflowExternalNotificationsConfig = {
  enabled?: boolean;
  mode?: ExternalNotificationMode | string;
  authorities?: Record<string, WorkflowExternalAuthorityConfig>;
};

export type FlatExternalTriggerConfig = {
  onCreated?: boolean;
  onVerified?: boolean;
  onUnderControl?: boolean;
};

export type FlatExternalPolicy = {
  externalEnabled?: boolean;
  externalMode?: ExternalNotificationMode | string;
  externalAuthorityTypes?: Record<string, boolean>;
  externalAuthorityIds?: Record<string, boolean>;
  externalTriggers?: FlatExternalTriggerConfig;
  externalNotificationPolicy?: {
    enabled?: boolean;
    mode?: ExternalNotificationMode | string;
    authorityTypes?: Record<string, boolean>;
    authorityIds?: Record<string, boolean>;
    triggers?: FlatExternalTriggerConfig;
  };
};

export type IncidentPolicyRecord = FlatExternalPolicy & {
  category?: string;
  displayName?: string;
  workflowExtensions?: {
    externalNotifications?: WorkflowExternalNotificationsConfig;
  };
};

export type ResolverFlags = {
  evacuationRequired?: boolean;
  externalAuthoritiesRequired?: boolean;
  injuriesReported?: boolean;
  fireConfirmed?: boolean;
  policeRequired?: boolean;
  environmentalEscalationRequired?: boolean;
};

export type ResolverIncidentState = {
  active?: boolean;
  verified?: boolean;
  underControl?: boolean;
  closureRequested?: boolean;
};

export type ResolveExternalNotificationsInput = {
  siteId: string;
  incidentId: string;
  category: string;
  subtype?: string | null;
  severity?: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | null;
  triggerEvent: ExternalResolverTrigger;
  policy: IncidentPolicyRecord | null | undefined;
  authoritiesRegistry?: Record<string, ExternalAuthorityRegistryEntry> | null;
  flags?: ResolverFlags | null;
  incidentState?: ResolverIncidentState | null;
  currentUser?: {
    uid?: string;
    displayName?: string;
    roles?: Record<string, boolean>;
  } | null;
};

export type ResolvedAuthorityPlan = {
  authorityType: ExternalAuthorityType;
  authorityId: string;
  authorityName: string;
  shouldCreate: boolean;
  required: boolean;
  autoSuggested: boolean;
  approvalRequired: boolean;
  defaultChannel: ExternalNotificationChannel;
  allowedRequesterRoles: Record<string, boolean>;
  allowedApproverRoles: Record<string, boolean>;
  allowedExecutorRoles: Record<string, boolean>;
  mode: ExternalNotificationMode;
  triggerEvent: ExternalResolverTrigger;
  contacts: {
    primary: ExternalAuthorityContact;
    secondary: ExternalAuthorityContact;
  };
  dedupeKey: string;
  reasonCodes: string[];
  source: {
    resolutionMode: "CANONICAL_V1" | "LEGACY_COMPAT";
    policyPath: string;
  };
};

export type ResolveExternalNotificationsOutput = {
  enabled: boolean;
  mode: ExternalNotificationMode;
  shouldCreateAny: boolean;
  plans: ResolvedAuthorityPlan[];
  diagnostics: {
    usedLegacyFields: boolean;
    skippedBecause: string[];
    matchedAuthorities: string[];
  };
};

const KNOWN_AUTHORITIES: ExternalAuthorityType[] = [
  "CIVIL_PROTECTION",
  "EMS",
  "ENVIRONMENTAL_AUTHORITY",
  "FIRE_BRIGADE",
  "POLICE",
];

const DEFAULT_APPROVER_ROLES: Record<string, boolean> = {
  HSE_MANAGER: true,
  SITE_MANAGER: true,
};

const DEFAULT_EXECUTOR_ROLES: Record<string, boolean> = {
  CONTROL_ROOM: true,
  HSE_MANAGER: true,
};

const DEFAULT_REQUESTER_ROLES: Record<string, boolean> = {
  CONTROL_ROOM: true,
  HSE_MANAGER: true,
};

export function resolveExternalNotifications(
  input: ResolveExternalNotificationsInput
): ResolveExternalNotificationsOutput {
  const policy = (input.policy || {}) as IncidentPolicyRecord;
  const authoritiesRegistry = sanitizeRegistry(input.authoritiesRegistry || {});
  const diagnostics: ResolveExternalNotificationsOutput["diagnostics"] = {
    usedLegacyFields: false,
    skippedBecause: [],
    matchedAuthorities: [],
  };

  const canonicalConfig = sanitizeWorkflowConfig(
    policy.workflowExtensions?.externalNotifications
  );

  const hasCanonicalAuthorities =
    canonicalConfig.enabled !== false &&
    Object.keys(canonicalConfig.authorities).length > 0;

  const enabled = resolvePolicyEnabled(policy, canonicalConfig);
  if (!enabled) {
    diagnostics.skippedBecause.push("POLICY_DISABLED");
    return {
      enabled: false,
      mode: resolvePolicyMode(policy, canonicalConfig),
      shouldCreateAny: false,
      plans: [],
      diagnostics,
    };
  }

  const mode = resolvePolicyMode(policy, canonicalConfig);
  const triggerAllowed = isTriggerAllowed(input.triggerEvent, policy, canonicalConfig);

  if (!triggerAllowed) {
    diagnostics.skippedBecause.push("TRIGGER_NOT_ALLOWED");
    return {
      enabled: true,
      mode,
      shouldCreateAny: false,
      plans: [],
      diagnostics,
    };
  }

  if (mode !== "AUTO" && input.triggerEvent !== "MANUAL_REQUEST") {
    diagnostics.skippedBecause.push("NON_AUTO_MODE_FOR_LIFECYCLE_TRIGGER");
    return {
      enabled: true,
      mode,
      shouldCreateAny: false,
      plans: [],
      diagnostics,
    };
  }

  const plans: ResolvedAuthorityPlan[] = [];
  const sourceMode: "CANONICAL_V1" | "LEGACY_COMPAT" = hasCanonicalAuthorities
    ? "CANONICAL_V1"
    : "LEGACY_COMPAT";

  if (!hasCanonicalAuthorities) {
    diagnostics.usedLegacyFields = true;
  }

  const authorityKeys = hasCanonicalAuthorities
    ? Object.keys(canonicalConfig.authorities)
    : resolveLegacyAuthorityKeys(policy);

  for (const rawAuthorityKey of authorityKeys) {
    const authorityType = normalizeAuthorityType(rawAuthorityKey);
    if (!authorityType) {
      diagnostics.skippedBecause.push(`UNKNOWN_AUTHORITY:${rawAuthorityKey}`);
      continue;
    }

    const registryEntry = resolveAuthorityRegistryEntry(authoritiesRegistry, authorityType);
    if (!registryEntry) {
      diagnostics.skippedBecause.push(`SITE_AUTHORITY_NOT_CONFIGURED:${authorityType}`);
      continue;
    }

    if (registryEntry.enabled === false || registryEntry.active === false) {
      diagnostics.skippedBecause.push(`SITE_AUTHORITY_DISABLED:${authorityType}`);
      continue;
    }

    const authorityPolicy = hasCanonicalAuthorities
      ? sanitizeAuthorityPolicy(canonicalConfig.authorities[authorityType])
      : buildLegacyAuthorityPolicy(policy, authorityType, registryEntry, mode);

    if (authorityPolicy.enabled === false) {
      diagnostics.skippedBecause.push(`POLICY_AUTHORITY_DISABLED:${authorityType}`);
      continue;
    }

    if (
      input.triggerEvent === "MANUAL_REQUEST" &&
      !canRequesterUseAuthority(authorityPolicy, input.currentUser?.roles || {})
    ) {
      diagnostics.skippedBecause.push(`REQUESTER_NOT_ALLOWED:${authorityType}`);
      continue;
    }

    const channel = resolveChannel(
  safeString(authorityPolicy.defaultChannel),
  registryEntry.defaultChannel,
  registryEntry.supportedChannels
);

    const authorityId =
      safeString(registryEntry.id) || safeString(registryEntry.type) || authorityType;

    const authorityName =
      safeString(registryEntry.name) || authorityType;

    const approvalRequired = resolveApprovalRequired(mode, authorityPolicy.requiresApproval);

    const plan: ResolvedAuthorityPlan = {
      authorityType,
      authorityId,
      authorityName,
      shouldCreate: true,
      required: authorityPolicy.autoSuggest !== true,
      autoSuggested: authorityPolicy.autoSuggest === true,
      approvalRequired,
      defaultChannel: channel,
      allowedRequesterRoles:
        sanitizeBooleanMap(authorityPolicy.allowedRequesterRoles).size > 0
          ? sanitizeBooleanMap(authorityPolicy.allowedRequesterRoles).map
          : { ...DEFAULT_REQUESTER_ROLES },
      allowedApproverRoles:
        sanitizeBooleanMap(authorityPolicy.allowedApproverRoles).size > 0
          ? sanitizeBooleanMap(authorityPolicy.allowedApproverRoles).map
          : { ...DEFAULT_APPROVER_ROLES },
      allowedExecutorRoles:
        sanitizeBooleanMap(authorityPolicy.allowedExecutorRoles).size > 0
          ? sanitizeBooleanMap(authorityPolicy.allowedExecutorRoles).map
          : { ...DEFAULT_EXECUTOR_ROLES },
      mode,
      triggerEvent: input.triggerEvent,
      contacts: {
        primary: sanitizeContact(registryEntry.contacts?.primary),
        secondary: sanitizeContact(registryEntry.contacts?.secondary),
      },
      dedupeKey: buildDedupeKey(input.incidentId, authorityId, input.triggerEvent),
      reasonCodes: buildReasonCodes(input, authorityType, mode, sourceMode, approvalRequired),
      source: {
        resolutionMode: sourceMode,
        policyPath: hasCanonicalAuthorities
          ? "workflowExtensions.externalNotifications.authorities"
          : "legacy.externalNotificationPolicy",
      },
    };

    diagnostics.matchedAuthorities.push(authorityType);
    plans.push(plan);
  }

  return {
    enabled: true,
    mode,
    shouldCreateAny: plans.length > 0,
    plans,
    diagnostics,
  };
}

function sanitizeWorkflowConfig(
  raw: WorkflowExternalNotificationsConfig | null | undefined
): {
  enabled: boolean;
  mode: ExternalNotificationMode;
  authorities: Record<string, WorkflowExternalAuthorityConfig>;
} {
  return {
    enabled: raw?.enabled !== false,
    mode: normalizeMode(raw?.mode || "MANUAL_LOGGED"),
    authorities:
      raw?.authorities && typeof raw.authorities === "object" ? raw.authorities : {},
  };
}

function resolvePolicyEnabled(
  policy: IncidentPolicyRecord,
  canonicalConfig: { enabled: boolean; mode: ExternalNotificationMode; authorities: Record<string, WorkflowExternalAuthorityConfig> }
): boolean {
  if (canonicalConfig.enabled === true && Object.keys(canonicalConfig.authorities).length > 0) {
    return true;
  }

  if (policy.externalNotificationPolicy?.enabled === true) return true;
  if (policy.externalEnabled === true) return true;

  return false;
}

function resolvePolicyMode(
  policy: IncidentPolicyRecord,
  canonicalConfig: { enabled: boolean; mode: ExternalNotificationMode; authorities: Record<string, WorkflowExternalAuthorityConfig> }
): ExternalNotificationMode {
  if (canonicalConfig.mode) return canonicalConfig.mode;
  if (policy.externalNotificationPolicy?.mode) {
    return normalizeMode(policy.externalNotificationPolicy.mode);
  }
  if (policy.externalMode) {
    return normalizeMode(policy.externalMode);
  }
  return "MANUAL_LOGGED";
}

function isTriggerAllowed(
  trigger: ExternalResolverTrigger,
  policy: IncidentPolicyRecord,
  canonicalConfig: { enabled: boolean; mode: ExternalNotificationMode; authorities: Record<string, WorkflowExternalAuthorityConfig> }
): boolean {
  if (trigger === "MANUAL_REQUEST") return true;

  const legacyTriggers =
    policy.externalNotificationPolicy?.triggers ||
    policy.externalTriggers || {};

  switch (trigger) {
    case "INCIDENT_CREATED":
      return legacyTriggers.onCreated === true;
    case "INCIDENT_VERIFIED":
      return legacyTriggers.onVerified === true;
    case "INCIDENT_UNDER_CONTROL":
      return legacyTriggers.onUnderControl === true;
    default:
      return false;
  }
}

function resolveLegacyAuthorityKeys(policy: IncidentPolicyRecord): string[] {
  const result = new Set<string>();

  const workflowAuthorities =
    policy.workflowExtensions?.externalNotifications?.authorities || {};
  Object.entries(workflowAuthorities).forEach(([key, cfg]) => {
    if (cfg?.enabled !== false) {
      result.add(key);
    }
  });

  Object.entries(policy.externalNotificationPolicy?.authorityTypes || {}).forEach(([key, enabled]) => {
    if (enabled === true) result.add(key);
  });

  Object.entries(policy.externalAuthorityTypes || {}).forEach(([key, enabled]) => {
    if (enabled === true) result.add(key);
  });

  Object.entries(policy.externalNotificationPolicy?.authorityIds || {}).forEach(([key, enabled]) => {
    if (enabled === true) result.add(key);
  });

  Object.entries(policy.externalAuthorityIds || {}).forEach(([key, enabled]) => {
    if (enabled === true) result.add(key);
  });

  return Array.from(result);
}

function sanitizeAuthorityPolicy(
  raw: WorkflowExternalAuthorityConfig | null | undefined
): WorkflowExternalAuthorityConfig {
  return {
    enabled: raw?.enabled !== false,
    autoSuggest: raw?.autoSuggest === true,
    defaultChannel: safeString(raw?.defaultChannel || ""),
    requiresApproval: raw?.requiresApproval !== false,
    allowedRequesterRoles:
      raw?.allowedRequesterRoles && typeof raw.allowedRequesterRoles === "object"
        ? raw.allowedRequesterRoles
        : {},
    allowedApproverRoles:
      raw?.allowedApproverRoles && typeof raw.allowedApproverRoles === "object"
        ? raw.allowedApproverRoles
        : {},
    allowedExecutorRoles:
      raw?.allowedExecutorRoles && typeof raw.allowedExecutorRoles === "object"
        ? raw.allowedExecutorRoles
        : {},
  };
}

function buildLegacyAuthorityPolicy(
  policy: IncidentPolicyRecord,
  authorityType: ExternalAuthorityType,
  registryEntry: ExternalAuthorityRegistryEntry,
  mode: ExternalNotificationMode
): WorkflowExternalAuthorityConfig {
  const workflowAuthority =
    policy.workflowExtensions?.externalNotifications?.authorities?.[authorityType];

  if (workflowAuthority && workflowAuthority.enabled !== false) {
    return sanitizeAuthorityPolicy(workflowAuthority);
  }

  return {
    enabled: true,
    autoSuggest: false,
    defaultChannel: safeString(registryEntry.defaultChannel || "PHONE") || "PHONE",
    requiresApproval: mode === "MANUAL_APPROVAL" || mode === "MANUAL_LOGGED",
    allowedRequesterRoles: { ...DEFAULT_REQUESTER_ROLES },
    allowedApproverRoles: { ...DEFAULT_APPROVER_ROLES },
    allowedExecutorRoles: { ...DEFAULT_EXECUTOR_ROLES },
  };
}

function canRequesterUseAuthority(
  authorityPolicy: WorkflowExternalAuthorityConfig,
  actorRoles: Record<string, boolean>
): boolean {
  const requesterRoles = sanitizeBooleanMap(authorityPolicy.allowedRequesterRoles);
  if (requesterRoles.size === 0) return true;

  return Object.keys(actorRoles || {}).some((role) => actorRoles[role] === true && requesterRoles.map[role] === true);
}

function resolveApprovalRequired(
  mode: ExternalNotificationMode,
  authorityRequiresApproval: boolean | undefined
): boolean {
  if (mode === "MANUAL_APPROVAL") return true;
  if (mode === "MANUAL_LOGGED") return authorityRequiresApproval !== false;
  if (mode === "AUTO") return authorityRequiresApproval === true;
  return authorityRequiresApproval !== false;
}

function resolveChannel(
  policyChannel: string,
  registryDefaultChannel: string | undefined,
  supportedChannels: Record<string, boolean> | undefined
): ExternalNotificationChannel {
  const preferred = normalizeChannel(policyChannel || registryDefaultChannel || "PHONE");
  const supported = sanitizeBooleanMap(supportedChannels).map;

  if (Object.keys(supported).length === 0) {
    return preferred;
  }

  if (supported[preferred] === true) {
    return preferred;
  }

  if (supported.PHONE === true) return "PHONE";
  if (supported.EMAIL === true) return "EMAIL";
  if (supported.SMS === true) return "SMS";
  if (supported.API === true) return "API";

  return preferred;
}

function buildDedupeKey(
  incidentId: string,
  authorityId: string,
  triggerEvent: ExternalResolverTrigger
): string {
  return `${safeString(incidentId)}::${safeString(authorityId)}::${safeString(triggerEvent)}`;
}

function buildReasonCodes(
  input: ResolveExternalNotificationsInput,
  authorityType: ExternalAuthorityType,
  mode: ExternalNotificationMode,
  sourceMode: "CANONICAL_V1" | "LEGACY_COMPAT",
  approvalRequired: boolean
): string[] {
  const result: string[] = [
    `TRIGGER:${input.triggerEvent}`,
    `AUTHORITY:${authorityType}`,
    `MODE:${mode}`,
    `SOURCE:${sourceMode}`,
    `APPROVAL:${approvalRequired ? "REQUIRED" : "NOT_REQUIRED"}`,
  ];

  if (input.severity) {
    result.push(`SEVERITY:${normalizeEnumText(input.severity)}`);
  }

  if (input.flags?.externalAuthoritiesRequired === true) {
    result.push("FLAG:EXTERNAL_AUTHORITIES_REQUIRED");
  }
  if (input.flags?.evacuationRequired === true) {
    result.push("FLAG:EVACUATION_REQUIRED");
  }
  if (input.flags?.injuriesReported === true) {
    result.push("FLAG:INJURIES_REPORTED");
  }
  if (input.flags?.fireConfirmed === true) {
    result.push("FLAG:FIRE_CONFIRMED");
  }
  if (input.flags?.policeRequired === true) {
    result.push("FLAG:POLICE_REQUIRED");
  }
  if (input.flags?.environmentalEscalationRequired === true) {
    result.push("FLAG:ENVIRONMENTAL_ESCALATION_REQUIRED");
  }

  return result;
}

function normalizeAuthorityType(value: unknown): ExternalAuthorityType | null {
  const normalized = normalizeEnumText(value);
  if (!normalized) return null;
  if (normalized === "FIRE_DEPARTMENT") return "FIRE_BRIGADE";
  if (KNOWN_AUTHORITIES.includes(normalized as ExternalAuthorityType)) {
    return normalized as ExternalAuthorityType;
  }
  return null;
}

function resolveAuthorityRegistryEntry(
  registry: Record<string, ExternalAuthorityRegistryEntry>,
  authorityType: ExternalAuthorityType
): ExternalAuthorityRegistryEntry | null {
  const byDirectKey = registry[authorityType];
  if (byDirectKey) return byDirectKey;

  for (const entry of Object.values(registry)) {
    const entryType = normalizeAuthorityType(entry?.type || entry?.id || "");
    if (entryType === authorityType) {
      return entry;
    }
  }

  return null;
}

function sanitizeRegistry(
  raw: Record<string, ExternalAuthorityRegistryEntry>
): Record<string, ExternalAuthorityRegistryEntry> {
  return raw && typeof raw === "object" ? raw : {};
}

function sanitizeContact(raw: ExternalAuthorityContact | null | undefined): ExternalAuthorityContact {
  return {
    phone: safeString(raw?.phone || ""),
    email: safeString(raw?.email || ""),
    address: safeString(raw?.address || ""),
    notes: safeString(raw?.notes || ""),
  };
}

function sanitizeBooleanMap(
  raw: Record<string, boolean> | undefined
): { map: Record<string, boolean>; size: number } {
  const result: Record<string, boolean> = {};
  if (!raw || typeof raw !== "object") {
    return { map: result, size: 0 };
  }

  Object.entries(raw).forEach(([key, value]) => {
    if (value === true) {
      const normalizedKey = safeString(key);
      if (normalizedKey) {
        result[normalizedKey] = true;
      }
    }
  });

  return {
    map: result,
    size: Object.keys(result).length,
  };
}

function normalizeMode(value: unknown): ExternalNotificationMode {
  const normalized = normalizeEnumText(value);
  switch (normalized) {
    case "AUTO":
      return "AUTO";
    case "MANUAL":
      return "MANUAL";
    case "MANUAL_APPROVAL":
      return "MANUAL_APPROVAL";
    case "MANUAL_LOGGED":
      return "MANUAL_LOGGED";
    default:
      return "MANUAL_LOGGED";
  }
}

function normalizeChannel(value: unknown): ExternalNotificationChannel {
  const normalized = normalizeEnumText(value);
  switch (normalized) {
    case "EMAIL":
      return "EMAIL";
    case "SMS":
      return "SMS";
    case "API":
      return "API";
    case "PHONE":
    default:
      return "PHONE";
  }
}

function normalizeEnumText(value: unknown): string {
  return String(value ?? "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}