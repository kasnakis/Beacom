import * as admin from "firebase-admin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";

type ExternalNotificationAction =
  | "APPROVE"
  | "REJECT"
  | "MARK_SENT"
  | "ACKNOWLEDGE"
  | "FAIL"
  | "CANCEL";

type ActorContext = {
  userId: string;
  displayName: string;
  siteId: string;
  roles: string[];
  sessionType?: "REAL_SESSION" | "PILOT_SESSION";
};

type NotificationRecordKind = "LEGACY" | "CANONICAL";

type ManageExternalNotificationData = {
  notificationId: string;
  recordKind?: NotificationRecordKind;
  actor?: ActorContext;
  notes?: string;
  reason?: string;
  resultNotes?: string;
  receivedBy?: string;
};

type ExternalNotificationRecord = {
  id?: string;
  incidentId?: string;
  siteId?: string;
  authorityType?: string;
  authorityId?: string;
  authorityName?: string;
  channel?: string;
  trigger?: string;
  source?: string;
  mode?: string;
  status?: string;
  playbookId?: string;
  playbookTitle?: string;
  stepId?: string;
  stepTitle?: string;
  legacyRequestId?: string;
  notes?: string;
  requestedByUserId?: string;
  requestedByName?: string;
  requestedByRole?: string;
  allowedRequesterRoles?: Record<string, boolean>;
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
  approval?: {
    required?: boolean;
    status?: string;
    approvedByUserId?: string | null;
    approvedByName?: string | null;
    approvedByRole?: string | null;
    approvedAt?: number | null;
    rejectedByUserId?: string | null;
    rejectedByName?: string | null;
    rejectedByRole?: string | null;
    rejectedAt?: number | null;
    decisionAt?: number | null;
    decisionByUserId?: string | null;
    decisionByName?: string | null;
    decisionByRole?: string | null;
    rejectionReason?: string | null;
  };
  execution?: {
    status?: string;
    executedByUserId?: string | null;
    executedByName?: string | null;
    executedAt?: number | null;
    resultNotes?: string | null;
  };
  acknowledgement?: {
    status?: string;
    receivedAt?: number | null;
    receivedBy?: string | null;
    notes?: string | null;
  };
};

const FUNCTION_OPTIONS = {
  region: "europe-west1" as const,
  maxInstances: 10,
};

function normalizeKey(value: unknown): string {
  return value == null ? "" : String(value).trim().toUpperCase();
}

function safeString(value: unknown): string {
  return value == null ? "" : String(value).trim();
}

function nullableString(value: unknown): string | null {
  const valueStr = safeString(value);
  return valueStr.length > 0 ? valueStr : null;
}

function toBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object") return {};
  return value as Record<string, boolean>;
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.map((x) => safeString(x)).filter(Boolean)));
}

function hasAnyAllowedRole(
  actorRoles: string[],
  allowedRoles: Record<string, boolean>
): boolean {
  if (!actorRoles.length) return false;
  return actorRoles.some((role) => allowedRoles[normalizeKey(role)] === true);
}

function sanitizeNotification(value: unknown): ExternalNotificationRecord {
  const raw = (value || {}) as ExternalNotificationRecord;

  return {
    id: safeString(raw.id),
    incidentId: safeString(raw.incidentId),
    siteId: safeString(raw.siteId),
    authorityType: normalizeKey(raw.authorityType),
    authorityId: safeString(raw.authorityId),
    authorityName: safeString(raw.authorityName),
    channel: normalizeKey(raw.channel),
    trigger: normalizeKey(raw.trigger),
    source: safeString(raw.source),
    mode: normalizeKey(raw.mode),
    status: normalizeKey(raw.status),
    playbookId: safeString(raw.playbookId),
    playbookTitle: safeString(raw.playbookTitle),
    stepId: safeString(raw.stepId),
    stepTitle: safeString(raw.stepTitle),
    legacyRequestId: safeString(raw.legacyRequestId),
    notes: safeString(raw.notes),
    requestedByUserId: safeString(raw.requestedByUserId),
    requestedByName: safeString(raw.requestedByName),
    requestedByRole: safeString(raw.requestedByRole),
    allowedRequesterRoles: toBooleanRecord(raw.allowedRequesterRoles),
    allowedApproverRoles: toBooleanRecord(raw.allowedApproverRoles),
    allowedExecutorRoles: toBooleanRecord(raw.allowedExecutorRoles),
    approval: {
      required: raw.approval?.required === true,
      status: normalizeKey(raw.approval?.status),
      approvedByUserId: nullableString(raw.approval?.approvedByUserId),
      approvedByName: nullableString(raw.approval?.approvedByName),
      approvedByRole: nullableString(raw.approval?.approvedByRole),
      approvedAt:
        typeof raw.approval?.approvedAt === "number" ? raw.approval.approvedAt : null,
      rejectedByUserId: nullableString(raw.approval?.rejectedByUserId),
      rejectedByName: nullableString(raw.approval?.rejectedByName),
      rejectedByRole: nullableString(raw.approval?.rejectedByRole),
      rejectedAt:
        typeof raw.approval?.rejectedAt === "number" ? raw.approval.rejectedAt : null,
      decisionAt:
        typeof raw.approval?.decisionAt === "number" ? raw.approval.decisionAt : null,
      decisionByUserId: nullableString(raw.approval?.decisionByUserId),
      decisionByName: nullableString(raw.approval?.decisionByName),
      decisionByRole: nullableString(raw.approval?.decisionByRole),
      rejectionReason: nullableString(raw.approval?.rejectionReason),
    },
    execution: {
      status: normalizeKey(raw.execution?.status),
      executedByUserId: nullableString(raw.execution?.executedByUserId),
      executedByName: nullableString(raw.execution?.executedByName),
      executedAt:
        typeof raw.execution?.executedAt === "number" ? raw.execution.executedAt : null,
      resultNotes: nullableString(raw.execution?.resultNotes),
    },
    acknowledgement: {
      status: normalizeKey(raw.acknowledgement?.status),
      receivedAt:
        typeof raw.acknowledgement?.receivedAt === "number"
          ? raw.acknowledgement.receivedAt
          : null,
      receivedBy: nullableString(raw.acknowledgement?.receivedBy),
      notes: nullableString(raw.acknowledgement?.notes),
    },
  };
}

function normalizeRecordKind(value: unknown): NotificationRecordKind {
  return normalizeKey(value) === "CANONICAL" ? "CANONICAL" : "LEGACY";
}

function canonicalPath(kind: NotificationRecordKind, notificationId: string): string {
  return kind === "CANONICAL"
    ? `external_notification_requests/${notificationId}`
    : `external_notifications/${notificationId}`;
}

async function loadNotificationOrThrow(
  notificationId: string,
  kind: NotificationRecordKind
): Promise<{
  ref: admin.database.Reference;
  record: ExternalNotificationRecord;
  kind: NotificationRecordKind;
}> {
  const path = canonicalPath(kind, notificationId);
  const ref = admin.database().ref(path);
  const snap = await ref.get();

  if (!snap.exists()) {
    throw new HttpsError("not-found", "Η εξωτερική ειδοποίηση δεν βρέθηκε");
  }

  return {
    ref,
    record: sanitizeNotification(snap.val()),
    kind,
  };
}

function validateActor(actor: ActorContext | undefined): Required<ActorContext> {
  if (!actor) {
    throw new HttpsError("invalid-argument", "Λείπουν τα στοιχεία του χρήστη");
  }

  const userId = safeString(actor.userId);
  const displayName = safeString(actor.displayName);
  const siteId = safeString(actor.siteId);
  const roles = uniqueStrings((actor.roles || []).map((x) => normalizeKey(x)));

  if (!userId || !displayName || !siteId || roles.length === 0) {
    throw new HttpsError("invalid-argument", "Μη έγκυρα στοιχεία χρήστη");
  }

  return {
    userId,
    displayName,
    siteId,
    roles,
    sessionType:
      actor.sessionType === "PILOT_SESSION" && userId.startsWith("uid_")
        ? "PILOT_SESSION"
        : "REAL_SESSION",
  };
}

function ensureSameSite(actor: Required<ActorContext>, record: ExternalNotificationRecord) {
  if (safeString(record.siteId) !== actor.siteId) {
    throw new HttpsError(
      "permission-denied",
      "Δεν επιτρέπεται ενέργεια σε ειδοποίηση άλλου site"
    );
  }
}

function isCanonicalRecord(record: ExternalNotificationRecord, kind: NotificationRecordKind) {
  return kind === "CANONICAL";
}

function ensureCanApprove(
  actor: Required<ActorContext>,
  record: ExternalNotificationRecord,
  kind: NotificationRecordKind
) {
  if (isCanonicalRecord(record, kind)) {
    return;
  }

  const allowed = toBooleanRecord(record.allowedApproverRoles);
  if (!hasAnyAllowedRole(actor.roles, allowed)) {
    throw new HttpsError(
      "permission-denied",
      "Δεν έχετε δικαίωμα έγκρισης/απόρριψης εξωτερικής ειδοποίησης"
    );
  }
}

function ensureCanExecute(
  actor: Required<ActorContext>,
  record: ExternalNotificationRecord,
  kind: NotificationRecordKind
) {
  if (isCanonicalRecord(record, kind)) {
    return;
  }

  const allowed = toBooleanRecord(record.allowedExecutorRoles);
  if (!hasAnyAllowedRole(actor.roles, allowed)) {
    throw new HttpsError(
      "permission-denied",
      "Δεν έχετε δικαίωμα εκτέλεσης εξωτερικής ειδοποίησης"
    );
  }
}

function ensureCanCancel(
  actor: Required<ActorContext>,
  record: ExternalNotificationRecord,
  kind: NotificationRecordKind
) {
  if (isCanonicalRecord(record, kind)) {
    return;
  }

  const approvers = toBooleanRecord(record.allowedApproverRoles);
  const executors = toBooleanRecord(record.allowedExecutorRoles);
  const canCancel =
    hasAnyAllowedRole(actor.roles, approvers) || hasAnyAllowedRole(actor.roles, executors);

  if (!canCancel) {
    throw new HttpsError(
      "permission-denied",
      "Δεν έχετε δικαίωμα ακύρωσης εξωτερικής ειδοποίησης"
    );
  }
}

function assertStatusIn(currentStatus: string, allowed: string[], message: string) {
  if (!allowed.includes(currentStatus)) {
    throw new HttpsError("failed-precondition", message);
  }
}

function applyDecisionAuditFields(
  updates: Record<string, unknown>,
  actor: Required<ActorContext>,
  now: number
) {
  updates["approval/decisionAt"] = now;
  updates["approval/decisionByUserId"] = actor.userId;
  updates["approval/decisionByName"] = actor.displayName;
  updates["approval/decisionByRole"] = actor.roles[0] || "";
}

async function logIncidentEvent(
  record: ExternalNotificationRecord,
  action: ExternalNotificationAction,
  actor: Required<ActorContext>,
  now: number,
  status: string,
  notes: string,
  resultNotes: string,
  reason: string,
  receivedBy: string
) {
  const incidentId = safeString(record.incidentId);
  const siteId = safeString(record.siteId);

  if (!incidentId || !siteId) return;

  let eventType = "EXTERNAL_NOTIFICATION_UPDATED";

  switch (action) {
    case "APPROVE":
      eventType = "EXTERNAL_NOTIFICATION_APPROVED";
      break;
    case "REJECT":
      eventType = "EXTERNAL_NOTIFICATION_REJECTED";
      break;
    case "MARK_SENT":
      eventType = "EXTERNAL_NOTIFICATION_SENT";
      break;
    case "ACKNOWLEDGE":
      eventType = "EXTERNAL_NOTIFICATION_ACK";
      break;
    case "FAIL":
      eventType = "EXTERNAL_NOTIFICATION_FAILED";
      break;
    case "CANCEL":
      eventType = "EXTERNAL_NOTIFICATION_CANCELLED";
      break;
  }

  const eventRef = admin.database().ref("incident_events").push();
  await eventRef.set({
    id: eventRef.key,
    incidentId,
    siteId,
    source: "FUNCTION",
    userId: actor.userId,
    userName: actor.displayName,
    createdAt: now,
    eventType,
    extra: {
      authorityId: record.authorityId || "",
      authorityType: record.authorityType || "",
      authorityName: record.authorityName || "",
      channel: record.channel || "",
      mode: record.mode || "",
      source: record.source || "",
      trigger: record.trigger || "",
      newStatus: status,
      notes,
      resultNotes,
      rejectionReason: reason,
      receivedBy,
      playbookId: record.playbookId || "",
      playbookTitle: record.playbookTitle || "",
      stepId: record.stepId || "",
      stepTitle: record.stepTitle || "",
      legacyRequestId: record.legacyRequestId || "",
    },
  });
}

async function applyAction(
  action: ExternalNotificationAction,
  data: ManageExternalNotificationData
) {
  const notificationId = safeString(data.notificationId);
  if (!notificationId) {
    throw new HttpsError("invalid-argument", "Λείπει το notificationId");
  }

  const kind = normalizeRecordKind(data.recordKind);
  const actor = validateActor(data.actor);
  const { ref, record } = await loadNotificationOrThrow(notificationId, kind);

  ensureSameSite(actor, record);

  const now = Date.now();
  const currentStatus = normalizeKey(record.status);
  const notes = safeString(data.notes);
  const reason = safeString(data.reason);
  const resultNotes = safeString(data.resultNotes);
  const receivedBy = safeString(data.receivedBy);

  const updates: Record<string, unknown> = {
    updatedAt: now,
  };

  switch (action) {
    case "APPROVE": {
      ensureCanApprove(actor, record, kind);
      assertStatusIn(
        currentStatus,
        ["REQUESTED"],
        "Η ειδοποίηση δεν είναι διαθέσιμη για έγκριση"
      );

      updates["status"] = "APPROVED";
      updates["approval/status"] = "APPROVED";
      updates["approval/approvedByUserId"] = actor.userId;
      updates["approval/approvedByName"] = actor.displayName;
      updates["approval/approvedByRole"] = actor.roles[0] || "";
      updates["approval/approvedAt"] = now;
      updates["approval/rejectedByUserId"] = null;
      updates["approval/rejectedByName"] = null;
      updates["approval/rejectedByRole"] = null;
      updates["approval/rejectedAt"] = null;
      updates["approval/rejectionReason"] = null;
      applyDecisionAuditFields(updates, actor, now);

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    case "REJECT": {
      ensureCanApprove(actor, record, kind);
      assertStatusIn(
        currentStatus,
        ["REQUESTED", "APPROVED"],
        "Η ειδοποίηση δεν είναι διαθέσιμη για απόρριψη"
      );

      if (!reason) {
        throw new HttpsError("invalid-argument", "Απαιτείται λόγος απόρριψης");
      }

      updates["status"] = "REJECTED";
      updates["approval/status"] = "REJECTED";

      updates["approval/approvedByUserId"] = actor.userId;
      updates["approval/approvedByName"] = actor.displayName;
      updates["approval/approvedByRole"] = actor.roles[0] || "";
      updates["approval/approvedAt"] = now;

      updates["approval/rejectedByUserId"] = actor.userId;
      updates["approval/rejectedByName"] = actor.displayName;
      updates["approval/rejectedByRole"] = actor.roles[0] || "";
      updates["approval/rejectedAt"] = now;
      updates["approval/rejectionReason"] = reason;
      applyDecisionAuditFields(updates, actor, now);

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    case "MARK_SENT": {
      ensureCanExecute(actor, record, kind);

      const approvalRequired = record.approval?.required === true;
      if (approvalRequired) {
        assertStatusIn(
          currentStatus,
          ["APPROVED"],
          "Η ειδοποίηση πρέπει πρώτα να εγκριθεί"
        );
      } else {
        assertStatusIn(
          currentStatus,
          ["REQUESTED", "APPROVED"],
          "Η ειδοποίηση δεν είναι διαθέσιμη για αποστολή"
        );
      }

      updates["status"] = "SENT";
      updates["execution/status"] = "SENT";
      updates["execution/executedByUserId"] = actor.userId;
      updates["execution/executedByName"] = actor.displayName;
      updates["execution/executedAt"] = now;
      updates["execution/resultNotes"] = resultNotes || notes || "";

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    case "ACKNOWLEDGE": {
      ensureCanExecute(actor, record, kind);
      assertStatusIn(
        currentStatus,
        ["SENT"],
        "Η ειδοποίηση πρέπει πρώτα να σταλεί"
      );

      updates["status"] = "ACKNOWLEDGED";
      updates["acknowledgement/status"] = "ACKNOWLEDGED";
      updates["acknowledgement/receivedAt"] = now;
      updates["acknowledgement/receivedBy"] = receivedBy || actor.displayName;
      updates["acknowledgement/notes"] = notes || resultNotes || "";

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    case "FAIL": {
      ensureCanExecute(actor, record, kind);
      assertStatusIn(
        currentStatus,
        ["REQUESTED", "APPROVED", "SENT"],
        "Η ειδοποίηση δεν είναι διαθέσιμη για αποτυχία"
      );

      updates["status"] = "FAILED";
      updates["execution/status"] = "FAILED";
      updates["execution/executedByUserId"] = actor.userId;
      updates["execution/executedByName"] = actor.displayName;
      updates["execution/executedAt"] = now;
      updates["execution/resultNotes"] = resultNotes || notes || "FAILED";

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    case "CANCEL": {
      ensureCanCancel(actor, record, kind);
      assertStatusIn(
        currentStatus,
        ["REQUESTED", "APPROVED", "SENT"],
        "Η ειδοποίηση δεν είναι διαθέσιμη για ακύρωση"
      );

      updates["status"] = "CANCELLED";
      updates["closedAt"] = now;
      updates["closedBy"] = actor.displayName;

      if (notes) {
        updates["notes"] = notes;
      }
      break;
    }

    default:
      throw new HttpsError("invalid-argument", "Μη υποστηριζόμενη ενέργεια");
  }

  await ref.update(updates);

  const finalStatus = String(updates["status"] || currentStatus);
  await logIncidentEvent(
    record,
    action,
    actor,
    now,
    finalStatus,
    notes,
    resultNotes,
    reason,
    receivedBy || actor.displayName
  );

  logger.info("External notification action completed", {
    action,
    notificationId,
    recordKind: kind,
    incidentId: record.incidentId,
    siteId: record.siteId,
    actorUserId: actor.userId,
    actorRoles: actor.roles,
  });

  return {
    ok: true,
    notificationId,
    recordKind: kind,
    action,
    status: finalStatus,
    incidentId: record.incidentId || "",
    siteId: record.siteId || "",
  };
}

export const approveExternalNotification = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("APPROVE", request.data as ManageExternalNotificationData);
  }
);

export const rejectExternalNotification = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("REJECT", request.data as ManageExternalNotificationData);
  }
);

export const markExternalNotificationSent = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("MARK_SENT", request.data as ManageExternalNotificationData);
  }
);

export const acknowledgeExternalNotification = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("ACKNOWLEDGE", request.data as ManageExternalNotificationData);
  }
);

export const failExternalNotification = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("FAIL", request.data as ManageExternalNotificationData);
  }
);

export const cancelExternalNotification = onCall(
  FUNCTION_OPTIONS,
  async (request) => {
    return applyAction("CANCEL", request.data as ManageExternalNotificationData);
  }
);