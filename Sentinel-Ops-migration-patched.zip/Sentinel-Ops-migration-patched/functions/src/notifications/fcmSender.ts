import { messaging } from "./db";
import { DeliveryResultRecord, ResolvedRecipient } from "./types";

interface SendPushInput {
  title: string;
  body: string;
  recipients: ResolvedRecipient[];
  data?: Record<string, string>;
}

export interface SendPushResult {
  successCount: number;
  failureCount: number;
  failedTokens: string[];
  invalidTokens: string[];
  retryableFailedTokens: string[];
  deliveryResults: DeliveryResultRecord[];
}

export async function sendPushToRecipients(
  input: SendPushInput
): Promise<SendPushResult> {
  const recipients = dedupeRecipients(input.recipients);

  if (recipients.length === 0) {
    return {
      successCount: 0,
      failureCount: 0,
      failedTokens: [],
      invalidTokens: [],
      retryableFailedTokens: [],
      deliveryResults: [],
    };
  }

  const response = await messaging().sendEachForMulticast({
    tokens: recipients.map((recipient) => recipient.token),
    notification: {
      title: input.title,
      body: input.body,
    },
    data: input.data || {},
    android: {
      priority: "high",
      notification: {
        channelId: "safe_mplus_alerts",
      },
    },
  });

  const failedTokens: string[] = [];
  const invalidTokens: string[] = [];
  const retryableFailedTokens: string[] = [];
  const deliveryResults: DeliveryResultRecord[] = [];

  response.responses.forEach((result, index) => {
    const recipient = recipients[index];
    const errorCode = String(result.error?.code || "").trim();
    const errorMessage = String(result.error?.message || "").trim();
    const invalidToken = isInvalidTokenError(errorCode);
    const retryable = !result.success && !invalidToken;

    if (!result.success) {
      failedTokens.push(recipient.token);
      if (invalidToken) {
        invalidTokens.push(recipient.token);
      } else {
        retryableFailedTokens.push(recipient.token);
      }
    }

    const deliveryRecord: DeliveryResultRecord = {
      userId: recipient.userId,
      displayName: recipient.displayName,
      token: recipient.token,
      success: result.success,
      invalidToken,
      retryable,
    };

    if (errorCode) {
      deliveryRecord.errorCode = errorCode;
    }
    if (errorMessage) {
      deliveryRecord.errorMessage = errorMessage;
    }

    deliveryResults.push(deliveryRecord);
  });

  return {
    successCount: response.successCount,
    failureCount: response.failureCount,
    failedTokens: uniqueStrings(failedTokens),
    invalidTokens: uniqueStrings(invalidTokens),
    retryableFailedTokens: uniqueStrings(retryableFailedTokens),
    deliveryResults,
  };
}

function dedupeRecipients(recipients: ResolvedRecipient[]): ResolvedRecipient[] {
  const seen = new Set<string>();
  const unique: ResolvedRecipient[] = [];

  recipients.forEach((recipient) => {
    const key = `${recipient.userId}|${recipient.token}`;
    if (seen.has(key)) return;
    seen.add(key);
    unique.push(recipient);
  });

  return unique;
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

function isInvalidTokenError(errorCode: string): boolean {
  return [
    "messaging/invalid-registration-token",
    "messaging/registration-token-not-registered",
    "messaging/invalid-argument",
  ].includes(String(errorCode || "").trim());
}
