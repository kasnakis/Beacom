export type NotificationType =
  | "VERIFY_INCIDENT"
  | "DISPATCH_INCIDENT"
  | "ESCALATE_INCIDENT"
  | "EMERGENCY_ALERT"
  | "SITE_BROADCAST";

export type NotificationStatus =
  | "PENDING"
  | "PROCESSING"
  | "SENT"
  | "PARTIAL"
  | "FAILED"
  | "NO_TARGETS"
  | "RETRY_SCHEDULED"
  | "ESCALATED";

export type NotificationTriggerEvent =
  | "INCIDENT_CREATED"
  | "INCIDENT_VERIFIED"
  | "INCIDENT_CLOSED"
  | "INCIDENT_UNDER_CONTROL"
  | "INCIDENT_DEACTIVATED"
  | "NOTIFICATION_ESCALATION";

export interface NotificationRequestRecord {
  id?: string;
  incidentId?: string;
  siteId?: string;
  category?: string;
  type?: NotificationType | string;
  status?: NotificationStatus | string;

  meta?: NotificationMetaBlock;
  policy?: NotificationPolicyBlock;
  targeting?: NotificationTargetingBlock;
  resolution?: NotificationResolutionBlock;
  delivery?: NotificationDeliveryBlock;
  retry?: NotificationRetryBlock;
}

export interface NotificationMetaBlock {
  schemaVersion: number;
  source: "SYSTEM" | "MANUAL";
  triggerEvent: NotificationTriggerEvent | string;
  createdAt: number;
  processedAt: number;
  lastAttemptAt?: number;
}

export interface NotificationPolicyBlock {
  policyUsed: boolean;
  policySourcePath: string;
  matchedPolicyIds: Record<string, boolean>;
}

export interface NotificationTargetingBlock {
  mode: "VERIFY_FIRST" | "DISPATCH" | "ESCALATION" | "SITE_BROADCAST";
  siteScope: "SITE_ONLY";
  siteId: string;
  targetRoles: Record<string, boolean>;
  targetTeams: Record<string, boolean>;
  explicitUsers: Record<string, boolean>;
}

export interface ResolvedUserEntry {
  siteId: string;
  displayName: string;
  viaRoles: Record<string, boolean>;
  viaTeams: Record<string, boolean>;
  viaExplicit: boolean;
  tokens: Record<string, string>;
}

export interface NotificationResolutionBlock {
  resolvedUsers: Record<string, ResolvedUserEntry>;
  resolvedUserCount: number;
  droppedUsers: Record<string, string>;
  droppedUserCount: number;
}

export interface DeliveryResultRecord {
  userId: string;
  displayName: string;
  token: string;
  success: boolean;
  errorCode?: string;
  errorMessage?: string;
  invalidToken?: boolean;
  retryable?: boolean;
}

export interface NotificationDeliveryBlock {
  channel: "FCM";
  attemptedRecipientCount: number;
  validRecipientCount: number;
  successCount: number;
  failureCount: number;
  invalidTokenCount: number;
  deliveryResults: Record<string, DeliveryResultRecord>;
}

export interface RetryHistoryRecord {
  at: number;
  retryNumber: number;
  reason: string;
  nextRetryAt: number;
}

export interface NotificationRetryBlock {
  enabled: boolean;
  retryCount: number;
  maxRetryCount: number;
  retryReason: string;
  nextRetryAt: number;
  backoffSeconds: Record<string, number>;
  history: Record<string, RetryHistoryRecord>;
}

export interface UserSiteMembershipRecord {
  active?: boolean;
  roles?: Record<string, boolean | string> | string[];
  teams?: Record<string, boolean | string> | string[];
  permissions?: Record<string, boolean | string> | string[];
}

export interface UserProfileRecord {
  userId?: string;
  uid?: string;
  displayName?: string;
  siteId?: string;
  primarySiteId?: string;
  active?: boolean;
  enabled?: boolean;
  status?: string;
  fcmToken?: string;
  fcmTokens?: Record<string, string>;
  roles?: Record<string, boolean | string> | string[];
  teams?: Record<string, boolean | string> | string[];
  siteMemberships?: Record<string, UserSiteMembershipRecord>;
}

export interface IncidentRecord {
  id?: string;
  title?: string;
  category?: string;
  severity?: string;
  siteId?: string;
  site?: string;
  createdByName?: string;
  verificationStatus?: string;
  status?: string;
}

export interface ResolvedRecipient {
  userId: string;
  displayName: string;
  siteId: string;
  token: string;
  tokenKey?: string;
}

export interface RetryPolicyResolved {
  enabled: boolean;
  maxRetries: number;
  backoffSeconds: number[];
  retryOnNoTargets: boolean;
  retryOnPartialFailure: boolean;
  retryOnFailed: boolean;
  escalationEnabled: boolean;
  escalationDelaySeconds: number;
  escalationTargetRoles: Record<string, boolean>;
  escalationTargetTeams: Record<string, boolean>;
  sourcePath: string;
}