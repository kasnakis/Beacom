import { db } from "./db";

export type IncidentNotificationTriggerEvent =
  | "INCIDENT_CREATED"
  | "INCIDENT_VERIFIED"
  | "INCIDENT_CLOSED"
  | "INCIDENT_UNDER_CONTROL"
  | "INCIDENT_DEACTIVATED"
  | "INCIDENT_REVIEW_PROGRESS"
  | "INCIDENT_DIMENSIONS_EXPANDED";

export interface NotificationPolicyV2 {
  active: boolean;
  sourcePath: string;
  policyId: string;
  targetRoles: Record<string, boolean>;
  targetTeams: Record<string, boolean>;
  mode: "VERIFY_FIRST" | "DISPATCH" | "ESCALATE" | "SITE_BROADCAST";
  retry: {
    enabled: boolean;
    maxRetries: number;
    backoffSeconds: number[];
  };
  titleTemplate?: string;
  bodyTemplate?: string;
}

export async function resolveNotificationPoliciesV2(
  siteId: string,
  category: string,
  eventType: IncidentNotificationTriggerEvent
): Promise<NotificationPolicyV2 | null> {
  const normalizedSiteId = normalizeSiteId(siteId);
  const normalizedCategory = normalizeEnum(category);
  const normalizedEventType = normalizeEnum(eventType);

  if (!normalizedSiteId || !normalizedCategory || !normalizedEventType) {
    return null;
  }

  const path = `site_config_data/${normalizedSiteId}/incident_policies/${normalizedCategory}`;
  const snapshot = await db().ref(path).get();
  if (!snapshot.exists()) return null;

  const policy = snapshot.val() || {};
  if (policy.enabled === false) return null;

  const notifications = policy.notifications || {};
  const workflow = policy.workflow || {};
  const retryNode = policy.retry || {};

  let notificationNode: any = null;

  if (normalizedEventType === "INCIDENT_VERIFIED") {
    notificationNode = notifications.onVerified;
  } else if (normalizedEventType === "INCIDENT_CLOSED") {
    notificationNode = notifications.onClosed;
  } else if (normalizedEventType === "INCIDENT_UNDER_CONTROL") {
    notificationNode = notifications.onUnderControl;
  } else if (normalizedEventType === "INCIDENT_DEACTIVATED") {
    notificationNode = notifications.onDeactivated;
  } else if (normalizedEventType === "INCIDENT_REVIEW_PROGRESS") {
    notificationNode =
      notifications.onReviewProgress || notifications.onCreate;
  } else {
    notificationNode = notifications.onCreate;
  }

  if (!notificationNode || notificationNode.enabled === false) {
    return null;
  }

  const targetRoles = normalizeBooleanMap(notificationNode.targetRoles);
  const targetTeams = normalizeBooleanMap(notificationNode.targetTeams);

  const mode =
    workflow.requiresVerification === true &&
    (normalizedEventType === "INCIDENT_CREATED" ||
      normalizedEventType === "INCIDENT_REVIEW_PROGRESS")
      ? "VERIFY_FIRST"
      : "DISPATCH";

  return {
    active: true,
    sourcePath: path,
    policyId: normalizedCategory,
    targetRoles,
    targetTeams,
    mode,
    retry: {
      enabled: retryNode.enabled === true,
      maxRetries: toSafeInt(retryNode.maxRetries, 0),
      backoffSeconds: normalizeNumberArray(retryNode.backoffSeconds),
    },
    titleTemplate: asOptionalString(notificationNode.titleTemplate),
    bodyTemplate: asOptionalString(notificationNode.bodyTemplate),
  };
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function normalizeEnum(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function normalizeBooleanMap(value: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};
  if (!value) return result;

  if (Array.isArray(value)) {
    value.forEach((item) => {
      const key = String(item || "").trim();
      if (key) result[key] = true;
    });
    return result;
  }

  if (typeof value === "object") {
    Object.entries(value as Record<string, unknown>).forEach(([key, raw]) => {
      const normalizedKey = String(key || "").trim();
      if (!normalizedKey) return;

      const enabled = raw === true || String(raw).toLowerCase() === "true";
      if (enabled) result[normalizedKey] = true;
    });
  }

  return result;
}

function normalizeNumberArray(value: unknown): number[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((v) => Number(v))
    .filter((v) => Number.isFinite(v) && v > 0)
    .map((v) => Math.floor(v));
}

function toSafeInt(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.floor(parsed)) : fallback;
}

function asOptionalString(value: unknown): string | undefined {
  const text = String(value || "").trim();
  return text ? text : undefined;
}