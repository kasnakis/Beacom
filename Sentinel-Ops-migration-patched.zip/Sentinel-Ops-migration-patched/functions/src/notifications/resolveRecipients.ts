import { db } from "./db";

export async function resolveRecipients(
  siteId: string,
  roles: string[]
): Promise<string[]> {

  const usersSnap = await db()
    .ref("users")
    .get();

  if (!usersSnap.exists()) return [];

  const users = usersSnap.val();

  const tokens: string[] = [];

  Object.keys(users).forEach((userId) => {

    const user = users[userId];

    if (!user.siteId) return;

    if (user.siteId !== siteId) return;

    if (!roles.includes(user.role)) return;

    if (user.fcmToken) {
      tokens.push(user.fcmToken);
    }

  });

  return tokens;
}