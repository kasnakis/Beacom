import { getDatabase } from "firebase-admin/database";

export async function resolveNotificationPolicies(category: string) {

  const db = getDatabase();
  const snapshot = await db.ref("notification_policies").once("value");

  const policies = snapshot.val();

  if (!policies) return [];

  const roles: string[] = [];

  Object.values(policies).forEach((policy: any) => {

    if (!policy.active) return;

    if (policy.category && policy.category !== category) return;

    if (policy.roles) {
      policy.roles.forEach((role: string) => roles.push(role));
    }

  });

  return [...new Set(roles)];
}