import { onValueCreated } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

const DATABASE_INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const REGION = "europe-west1";

export const resolveIncidentActionCompletionNotifications = onValueCreated(
  {
    ref: "/incident_events/{eventId}",
    instance: DATABASE_INSTANCE,
    region: REGION,
  },
  async (event) => {
    const eventId = event.params.eventId;
    const data = event.data.exists() ? event.data.val() : null;

    if (!data) {
      logger.warn("ACTION_COMPLETE_NOTIFY skipped: no data", { eventId });
      return;
    }

    const eventType = safeString(data.eventType);
    if (eventType !== "INCIDENT_ACTION_COMPLETED") {
      return;
    }

    const incidentId = safeString(data.incidentId);
    const siteId = normalizeSiteId(data.siteId);
    const actionId = safeString(data?.extra?.actionId);
    const completedByUid = safeString(data.userId || data?.extra?.actorUserId);
    const completedByName = safeString(data.userName) || "Χρήστης";

    if (!incidentId || !siteId || !actionId) {
      logger.warn("ACTION_COMPLETE_NOTIFY missing required fields", {
        eventId,
        incidentId,
        siteId,
        actionId,
      });
      return;
    }

    const db = admin.database();
    const now = Date.now();

    // Διαβάζουμε το incident και εντοπίζουμε το action
    const incidentSnap = await db.ref(`incidents/${incidentId}`).get();
    if (!incidentSnap.exists()) {
      logger.warn("ACTION_COMPLETE_NOTIFY incident not found", {
        eventId,
        incidentId,
        actionId,
      });
      return;
    }

    const incident = incidentSnap.val() || {};
    const singleTrackActions = incident.singleTrackActions || {};
    const actionNode = singleTrackActions[actionId] || null;

    if (!actionNode) {
      logger.warn("ACTION_COMPLETE_NOTIFY action not found in singleTrackActions", {
        eventId,
        incidentId,
        actionId,
      });
      return;
    }

    const recipientUid = safeString(actionNode.createdBy);
    const recipientName = safeString(actionNode.createdByName) || "Environmental Officer";
    const actionTitle = safeString(actionNode.title) || "Ενέργεια";
    const completionNotes = safeString(actionNode.completionNotes);

    if (!recipientUid) {
      logger.warn("ACTION_COMPLETE_NOTIFY missing recipient createdBy", {
        eventId,
        incidentId,
        actionId,
      });
      return;
    }

    // Anti-duplicate guard
    try {
      const existingSnap = await db
        .ref("notification_requests")
        .orderByChild("incidentId")
        .equalTo(incidentId)
        .limitToLast(15)
        .get();

      if (existingSnap.exists()) {
        const existing = existingSnap.val() || {};

        for (const req of Object.values<any>(existing)) {
          const sameType = safeString(req?.type) === "INCIDENT_ACTION_COMPLETED";
          const sameTrigger =
            safeString(req?.meta?.triggerEvent) === "INCIDENT_ACTION_COMPLETED";
          const sameActionId =
            safeString(req?.context?.actionId) === actionId;
          const sameUser =
            req?.targeting?.explicitUsers &&
            req.targeting.explicitUsers[recipientUid] === true;
          const recentEnough =
            Math.abs(Number(req?.meta?.createdAt || 0) - now) < 4000;

          if (sameType && sameTrigger && sameActionId && sameUser && recentEnough) {
            logger.info("ACTION_COMPLETE_NOTIFY duplicate skipped", {
              eventId,
              incidentId,
              actionId,
              recipientUid,
              existingRequestId: req?.id || "",
            });
            return;
          }
        }
      }
    } catch (error: any) {
      logger.warn("ACTION_COMPLETE_NOTIFY duplicate guard failed", {
        eventId,
        incidentId,
        actionId,
        recipientUid,
        error: error?.message || "unknown_error",
      });
    }

    // Resolve explicit recipient now, ώστε το processNotificationRequest να βρει έτοιμο resolvedUsers
    const usersSnap = await db.ref("users").get();
    const users = usersSnap.exists() ? usersSnap.val() || {} : {};

    const resolvedUsers: Record<string, any> = {};
    const droppedUsers: Record<string, string> = {};

    const user = users[recipientUid];
    if (!user) {
      droppedUsers[recipientUid] = "USER_NOT_FOUND";
    } else {
      const userSiteId = normalizeSiteId(user.siteId);
      if (userSiteId && userSiteId !== siteId) {
        droppedUsers[recipientUid] = "SITE_MISMATCH";
      } else if (user.active === false) {
        droppedUsers[recipientUid] = "USER_INACTIVE";
      } else {
        const tokenMap = normalizeTokenMap(user.fcmTokens, user.fcmToken);

        if (Object.keys(tokenMap).length === 0) {
          droppedUsers[recipientUid] = "NO_TOKENS";
        } else {
          resolvedUsers[recipientUid] = {
            displayName: safeString(user.displayName) || recipientName || recipientUid,
            siteId,
            viaRoles: {},
            viaTeams: {},
            viaExplicit: true,
            tokens: tokenMap,
          };
        }
      }
    }

    const requestRef = db.ref("notification_requests").push();

    await requestRef.set({
      id: requestRef.key,
      incidentId,
      siteId,
      category: "ACTION",
      type: "INCIDENT_ACTION_COMPLETED",
      status: "PENDING",

      meta: {
        schemaVersion: 2,
        source: "SYSTEM",
        triggerEvent: "INCIDENT_ACTION_COMPLETED",
        createdAt: now,
        processedAt: 0,
        lastAttemptAt: 0,
      },

      policy: {
        policyUsed: false,
        policySourcePath: "",
        matchedPolicyIds: {},
        dynamicTargeting: false,
        dynamicTargetSource: "EXPLICIT_ACTION_COMPLETION",
      },

      targeting: {
        mode: "DIRECT",
        siteScope: "SITE_ONLY",
        siteId,
        targetRoles: {},
        targetTeams: {},
        explicitUsers: {
          [recipientUid]: true,
        },
      },

      context: {
        actionId,
        title: actionTitle,
        completedByUid,
        completedByName,
        completionNotes,
        recipientName,
        type: "ACTION_COMPLETED",
      },

      resolution: {
        resolvedUsers,
        resolvedUserCount: Object.keys(resolvedUsers).length,
        droppedUsers,
        droppedUserCount: Object.keys(droppedUsers).length,
      },

      delivery: {
        channel: "FCM",
        attemptedRecipientCount: 0,
        validRecipientCount: 0,
        successCount: 0,
        failureCount: 0,
        invalidTokenCount: 0,
        deliveryResults: {},
        failedTokens: [],
        invalidTokens: [],
        retryableFailedTokens: [],
      },

      retry: {
        enabled: true,
        retryCount: 0,
        maxRetryCount: 2,
        retryReason: "",
        nextRetryAt: 0,
        backoffSeconds: {
          "0": 60,
          "1": 180,
        },
        history: {},
      },
    });

    logger.info("ACTION_COMPLETE_NOTIFY created notification_request", {
      requestId: requestRef.key,
      eventId,
      incidentId,
      siteId,
      actionId,
      recipientUid,
      completedByUid,
      resolvedUserCount: Object.keys(resolvedUsers).length,
      droppedUserCount: Object.keys(droppedUsers).length,
      droppedUsers,
    });
  }
);

function normalizeTokenMap(
  fcmTokens: unknown,
  fallbackToken?: unknown
): Record<string, string> {
  const result: Record<string, string> = {};

  if (fcmTokens && typeof fcmTokens === "object") {
    Object.entries(fcmTokens as Record<string, unknown>).forEach(([key, value]) => {
      const token = safeString(value);
      if (token) {
        result[key] = token;
      }
    });
  }

  const fallback = safeString(fallbackToken);
  if (fallback && !Object.values(result).includes(fallback)) {
    result.default = fallback;
  }

  return result;
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}