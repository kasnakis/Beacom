import { db } from "./db";
import {
  ResolvedRecipient,
  UserProfileRecord,
  UserSiteMembershipRecord,
} from "./types";

export async function resolveRecipientsV2(
  siteId: string,
  targetMode: "ROLE" | "SITE_ALL",
  targetRoles: Record<string, boolean>,
  targetTeams: Record<string, boolean>
): Promise<ResolvedRecipient[]> {
  const normalizedSiteId = normalizeSiteId(siteId);
  const usersSnap = await db().ref("users").get();
  const users = (usersSnap.val() || {}) as Record<string, UserProfileRecord>;

  const recipients: ResolvedRecipient[] = [];

  Object.entries(users).forEach(([userId, user]) => {
    if (!user) return;
    if (userId === "anonymous") return;
    if (!isUserEnabled(user)) return;

    const baseSiteId = normalizeSiteId(user.siteId || "");
    const primarySiteId = normalizeSiteId((user as any).primarySiteId || "");
    const membership = getMembershipForSite(user.siteMemberships, normalizedSiteId);
    const baseSiteMatches = baseSiteId === normalizedSiteId || primarySiteId === normalizedSiteId;
    const effectiveSiteId = baseSiteMatches ? (baseSiteId || primarySiteId) : normalizedSiteId;

    if (normalizedSiteId) {
      if (baseSiteMatches) {
        // User belongs primarily to this site.
      } else if (membership) {
        if (membership.active === false) return;

        const permissions = normalizeBooleanMap((membership as any).permissions);
        const canReceiveCrossSite =
          permissions.RECEIVE_SITE_NOTIFICATIONS === true ||
          permissions.PARTICIPATE_IN_SITE_RESPONSE === true;

        if (!canReceiveCrossSite) return;
      } else {
        return;
      }
    }

    const displayName = normalizeDisplayName(user.displayName, userId);
    const roleMap = baseSiteMatches
      ? mergeBooleanMaps(
          normalizeBooleanMap(user.roles),
          normalizeBooleanMap(membership?.roles)
        )
      : normalizeBooleanMap(membership?.roles);
    const teamMap = baseSiteMatches
      ? mergeBooleanMaps(
          normalizeBooleanMap(user.teams),
          normalizeBooleanMap(membership?.teams)
        )
      : normalizeBooleanMap(membership?.teams);
    const tokenMap = normalizeTokenMap(user.fcmTokens, user.fcmToken);

    if (Object.keys(tokenMap).length === 0) return;

    let matches = false;

    if (targetMode === "SITE_ALL") {
      matches = true;
    } else {
      const hasRoleMatch = Object.keys(targetRoles).some((role) => {
        return Boolean(targetRoles[role]) && Boolean(roleMap[role]);
      });
      const hasTeamMatch = Object.keys(targetTeams).some((team) => {
        return Boolean(targetTeams[team]) && Boolean(teamMap[team]);
      });
      matches = hasRoleMatch || hasTeamMatch;
    }

    if (!matches) return;

    Object.entries(tokenMap).forEach(([tokenKey, token]) => {
      const normalizedToken = String(token || "").trim();
      if (!normalizedToken) return;

      recipients.push({
        userId,
        displayName,
        siteId: effectiveSiteId || normalizedSiteId,
        token: normalizedToken,
        tokenKey,
      });
    });
  });

  return dedupeRecipients(recipients);
}

function isUserEnabled(profile: UserProfileRecord): boolean {
  if (profile.active === false) return false;
  if (profile.enabled === false) return false;

  const status = String(profile.status || "").trim().toUpperCase();
  if (status && status !== "ACTIVE") return false;

  return true;
}

function getMembershipForSite(
  siteMemberships: Record<string, UserSiteMembershipRecord> | undefined,
  siteId: string
): UserSiteMembershipRecord | undefined {
  if (!siteMemberships || !siteId) return undefined;

  const matchKey = Object.keys(siteMemberships).find(
    (key) => normalizeSiteId(key) === siteId
  );

  return matchKey ? siteMemberships[matchKey] : undefined;
}

function normalizeDisplayName(displayName: unknown, fallbackUserId: string): string {
  const value = String(displayName || "").trim();
  return value || fallbackUserId;
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function normalizeBooleanMap(value: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!value) return result;

  if (Array.isArray(value)) {
    value.forEach((item) => {
      const key = String(item || "").trim();
      if (key) result[key] = true;
    });
    return result;
  }

  if (typeof value === "object") {
    Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
      const normalizedKey = String(key || "").trim();
      if (!normalizedKey) return;

      result[normalizedKey] =
        enabled === true || String(enabled).toLowerCase() === "true";
    });
    return result;
  }

  const single = String(value).trim();
  if (single) result[single] = true;

  return result;
}

function mergeBooleanMaps(
  primary: Record<string, boolean>,
  secondary: Record<string, boolean>
): Record<string, boolean> {
  return {
    ...primary,
    ...secondary,
  };
}

function normalizeTokenMap(
  fcmTokens: unknown,
  fallbackToken?: unknown
): Record<string, string> {
  const result: Record<string, string> = {};

  if (fcmTokens && typeof fcmTokens === "object") {
    Object.entries(fcmTokens as Record<string, unknown>).forEach(([key, value]) => {
      const token = String(value || "").trim();
      if (token) {
        result[key] = token;
      }
    });
  }

  const fallback = String(fallbackToken || "").trim();
  if (fallback) {
    const alreadyExists = Object.values(result).includes(fallback);
    if (!alreadyExists) {
      result.default = fallback;
    }
  }

  return result;
}

function dedupeRecipients(recipients: ResolvedRecipient[]): ResolvedRecipient[] {
  const seen = new Set<string>();
  const unique: ResolvedRecipient[] = [];

  recipients.forEach((recipient) => {
    const key = `${recipient.userId}|${recipient.token}`;
    if (seen.has(key)) return;

    seen.add(key);
    unique.push(recipient);
  });

  return unique;
}