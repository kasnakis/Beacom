import { logger } from "firebase-functions";
import { db } from "./db";
import {
  NotificationRequestRecord,
  ResolvedRecipient,
  UserProfileRecord,
  UserSiteMembershipRecord,
} from "./types";

type SaekResolvedTargets = {
  roles: Record<string, boolean>;
  teams: Record<string, boolean>;
};

export async function resolveRecipients(
  request: NotificationRequestRecord
): Promise<ResolvedRecipient[]> {
  const usersSnap = await db().ref("users").get();
  const users = (usersSnap.val() ?? {}) as Record<string, UserProfileRecord>;

  const incident = await loadIncidentForRequest(request);
  const targeting = request.targeting;

  const siteId = normalizeSiteId(
    targeting?.siteId ||
      request.siteId ||
      incident?.siteId ||
      incident?.site ||
      ""
  );

  const targetMode = String(targeting?.mode || "DISPATCH").trim().toUpperCase();

  const originalTargetRoles = normalizeTargetKeys(targeting?.targetRoles);
  const originalTargetTeams = normalizeTargetKeys(targeting?.targetTeams);
  const explicitUsers = normalizeTargetKeys(targeting?.explicitUsers);

  const saekTargets = resolveSaekTargets(request, incident);

  const targetRoles = mergeBooleanMaps(originalTargetRoles, saekTargets.roles);
  const targetTeams = mergeBooleanMaps(originalTargetTeams, saekTargets.teams);

  const recipients: ResolvedRecipient[] = [];

  for (const [userId, profile] of Object.entries(users)) {
    if (!profile) continue;
    if (userId === "anonymous") continue;

    const baseSiteId = normalizeSiteId(profile.siteId || "");
    const primarySiteId = normalizeSiteId(profile.primarySiteId || "");
    const membership = getMembershipForSite(profile.siteMemberships, siteId);
    const baseSiteMatches = baseSiteId === siteId || primarySiteId === siteId;
    const effectiveSiteId = baseSiteMatches ? (baseSiteId || primarySiteId) : siteId;

    if (!isUserEligibleForSite(profile, membership, siteId, baseSiteId, primarySiteId)) {
      continue;
    }

    const tokenMap = normalizeTokenMap(profile.fcmTokens, profile.fcmToken);
    if (Object.keys(tokenMap).length === 0) continue;

    const roleMap = baseSiteMatches
      ? mergeBooleanMaps(
          normalizeBooleanMap(profile.roles),
          normalizeBooleanMap(membership?.roles)
        )
      : normalizeBooleanMap(membership?.roles);

    const teamMap = baseSiteMatches
      ? mergeBooleanMaps(
          normalizeBooleanMaps(profile.teams),
          normalizeBooleanMaps(membership?.teams)
        )
      : normalizeBooleanMaps(membership?.teams);

    const hasRoleMatch = Object.keys(targetRoles).some((role) => Boolean(roleMap[role]));
    const hasTeamMatch = Object.keys(targetTeams).some((team) => Boolean(teamMap[team]));
    const hasExplicitMatch = explicitUsers[userId] === true;

    const matches =
      hasExplicitMatch ||
      hasRoleMatch ||
      hasTeamMatch ||
      targetMode === "SITE_BROADCAST";

    if (!matches) continue;

    Object.entries(tokenMap).forEach(([tokenKey, token]) => {
      const normalizedToken = String(token || "").trim();
      if (!normalizedToken) return;

      recipients.push({
        userId,
        displayName: normalizeDisplayName(profile.displayName, userId),
        siteId: effectiveSiteId,
        token: normalizedToken,
        tokenKey,
      });
    });
  }

  if (recipients.length === 0) {
    logger.info("No recipients resolved from targeting block", {
      requestId: request.id || "",
      incidentId: request.incidentId || "",
      siteId,
      targetMode,
      originalTargetRoles: Object.keys(originalTargetRoles),
      originalTargetTeams: Object.keys(originalTargetTeams),
      saekTargetRoles: Object.keys(saekTargets.roles),
      saekTargetTeams: Object.keys(saekTargets.teams),
      effectiveTargetRoles: Object.keys(targetRoles),
      effectiveTargetTeams: Object.keys(targetTeams),
      explicitUsers: Object.keys(explicitUsers),
    });
  }

  return uniqueRecipients(recipients);
}

async function loadIncidentForRequest(
  request: NotificationRequestRecord
): Promise<Record<string, any> | null> {
  const incidentId = String(request.incidentId || "").trim();
  if (!incidentId) return null;

  try {
    const snap = await db().ref(`incidents/${incidentId}`).get();
    return (snap.val() ?? null) as Record<string, any> | null;
  } catch (error) {
    logger.warn("Failed to load incident while resolving recipients", {
      requestId: request.id || "",
      incidentId,
      error,
    });
    return null;
  }
}

function resolveSaekTargets(
  request: NotificationRequestRecord,
  incident: Record<string, any> | null
): SaekResolvedTargets {
  const roles: Record<string, boolean> = {};
  const teams: Record<string, boolean> = {};

  const category = normalizeIncidentKey(
    getFirstValue(
      incident?.category,
      incident?.type,
      (request as any).category,
      (request as any).incidentCategory,
      (request as any).incidentType
    )
  );

  const subtype = normalizeIncidentKey(
    getFirstValue(
      incident?.subtype,
      incident?.matchType,
      incident?.incidentType,
      (request as any).subtype,
      (request as any).matchType
    )
  );

  const trigger = normalizeIncidentKey(
    getFirstValue(
      (request as any).trigger,
      (request as any).eventType,
      (request as any).notificationTrigger
    )
  );

  const evacuationRequired = toBoolean(
    getFirstValue(
      incident?.activation?.evacuationRequired,
      incident?.evacuationRequired,
      (request as any).evacuationRequired
    )
  );

  const externalAuthoritiesRequired = toBoolean(
    getFirstValue(
      incident?.activation?.externalAuthoritiesRequired,
      incident?.externalAuthoritiesRequired,
      (request as any).externalAuthoritiesRequired
    )
  );

  const dimensions = resolveDimensions(incident, request);

  if (!category) {
    return { roles, teams };
  }

  if (category === "EMERGENCY" || category === "EMERGENCY_ACTIVATION") {
    addRoles(roles, [
      "EMERGENCY_COMMANDER",
      "COMMUNICATIONS_OFFICER",
      "HSE_MANAGER",
      "SITE_MANAGER",
      "CONTROL_ROOM",
      "SECURITY_OFFICER",
    ]);

    addTeams(teams, [
      "SECURITY_TEAM",
      "EMERGENCY_TEAM",
    ]);

    if (subtype === "FIRE" || subtype === "EXPLOSION" || subtype === "SMOKE") {
      addRoles(roles, ["FIRE_SAFETY_COORDINATOR"]);
      addTeams(teams, ["FIRE_TEAM"]);
    }

    if (
      subtype === "INJURY" ||
      subtype === "MEDICAL" ||
      subtype === "HSE_ACCIDENT" ||
      subtype === "SAFETY_ACCIDENT"
    ) {
      addRoles(roles, ["FIRST_AID_COORDINATOR"]);
      addTeams(teams, ["FIRST_AID_TEAM"]);
    }

    if (evacuationRequired) {
      addRoles(roles, ["PERSONNEL_COORDINATOR"]);
      addTeams(teams, ["EVACUATION_TEAM"]);
    }

    if (externalAuthoritiesRequired) {
      addRoles(roles, ["COMMUNICATIONS_OFFICER", "CONTROL_ROOM"]);
    }

    if (Object.keys(teams).length === 2) {
      addRoles(roles, [
        "FIRE_SAFETY_COORDINATOR",
        "FIRST_AID_COORDINATOR",
        "PERSONNEL_COORDINATOR",
      ]);
      addTeams(teams, [
        "FIRE_TEAM",
        "FIRST_AID_TEAM",
        "EVACUATION_TEAM",
      ]);
    }

    return { roles, teams };
  }

  if (category === "SOS" || category === "HSE_ACCIDENT" || category === "SAFETY_ACCIDENT") {
    addRoles(roles, [
      "HSE_MANAGER",
      "SITE_MANAGER",
      "SUPERVISOR",
      "FIRST_AID_COORDINATOR",
    ]);

    addTeams(teams, [
      "FIRST_AID_TEAM",
      "HSE_TEAM",
    ]);

    return { roles, teams };
  }

  if (category === "ENVIRONMENTAL_INCIDENT" || subtype === "ENVIRONMENTAL_RELEASE") {
    addRoles(roles, [
      "ENVIRONMENTAL_OFFICER",
      "HSE_MANAGER",
      "SITE_MANAGER",
    ]);

    if (trigger === "INCIDENT_VERIFIED") {
      addTeams(teams, [
        "ENVIRONMENT_TEAM",
      ]);
    }

    return { roles, teams };
  }

  if (category === "UNSAFE_CONDITION") {
    addRoles(roles, [
      "SITE_MANAGER",
      "SUPERVISOR",
    ]);

    if (dimensions.hse) {
      addRoles(roles, ["HSE_MANAGER"]);
      addTeams(teams, ["HSE_TEAM"]);
    }

    if (dimensions.environment) {
      addRoles(roles, ["ENVIRONMENTAL_OFFICER"]);
      addTeams(teams, ["ENVIRONMENT_TEAM"]);
    }

    if (dimensions.businessContinuity) {
      addRoles(roles, ["SUPERVISOR", "SITE_MANAGER", "PERSONNEL_COORDINATOR"]);
      addTeams(teams, ["MANAGEMENT"]);
    }

    if (!dimensions.hse && !dimensions.environment && !dimensions.businessContinuity) {
      addRoles(roles, ["HSE_MANAGER", "SUPERVISOR"]);
    }

    return { roles, teams };
  }

  if (category === "UNSAFE_ACTION") {
    addRoles(roles, [
      "SUPERVISOR",
      "HSE_MANAGER",
      "SITE_MANAGER",
    ]);

    return { roles, teams };
  }

  if (category === "NEAR_MISS") {
    addRoles(roles, [
      "SUPERVISOR",
      "HSE_MANAGER",
      "SITE_MANAGER",
    ]);

    addTeams(teams, [
      "HSE_TEAM",
    ]);

    return { roles, teams };
  }

  addRoles(roles, [
    "SITE_MANAGER",
    "HSE_MANAGER",
  ]);

  return { roles, teams };
}

function resolveDimensions(
  incident: Record<string, any> | null,
  request: NotificationRequestRecord
): {
  hse: boolean;
  environment: boolean;
  businessContinuity: boolean;
} {
  const rawDimensions =
    incident?.dimensions ||
    incident?.relevantDimensions ||
    (request as any).dimensions ||
    (request as any).relevantDimensions ||
    {};

  const hse =
    toBoolean(rawDimensions.HSE) ||
    toBoolean(rawDimensions.hse) ||
    toBoolean(rawDimensions.HEALTH_SAFETY) ||
    toBoolean(rawDimensions.healthSafety);

  const environment =
    toBoolean(rawDimensions.ENVIRONMENT) ||
    toBoolean(rawDimensions.environment);

  const businessContinuity =
    toBoolean(rawDimensions.BUSINESS_CONTINUITY) ||
    toBoolean(rawDimensions.businessContinuity) ||
    toBoolean(rawDimensions.OPERATIONS) ||
    toBoolean(rawDimensions.operations);

  return {
    hse,
    environment,
    businessContinuity,
  };
}

function addRoles(target: Record<string, boolean>, roles: string[]): void {
  roles.forEach((role) => {
    const key = String(role || "").trim();
    if (key) target[key] = true;
  });
}

function addTeams(target: Record<string, boolean>, teams: string[]): void {
  teams.forEach((team) => {
    const key = String(team || "").trim();
    if (key) target[key] = true;
  });
}

function getFirstValue(...values: unknown[]): unknown {
  for (const value of values) {
    if (value === undefined || value === null) continue;
    const text = String(value).trim();
    if (text) return value;
  }
  return "";
}

function normalizeIncidentKey(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function toBoolean(value: unknown): boolean {
  if (value === true) return true;
  if (value === false) return false;

  const text = String(value || "").trim().toLowerCase();
  return text === "true" || text === "1" || text === "yes" || text === "y";
}

function isUserEligibleForSite(
  profile: UserProfileRecord,
  membership: UserSiteMembershipRecord | undefined,
  requestedSiteId: string,
  baseSiteId: string,
  primarySiteId: string
): boolean {
  if (!isUserEnabled(profile)) return false;

  if (!requestedSiteId) {
    return baseSiteId !== "" || primarySiteId !== "";
  }

  if (baseSiteId === requestedSiteId || primarySiteId === requestedSiteId) {
    return true;
  }

  if (!membership || membership.active === false) {
    return false;
  }

  /*
   * Enterprise-safe cross-site notification access.
   *
   * A legacy active siteMembership is NOT enough to receive push notifications.
   * Cross-site recipients must have an explicit permission on that membership.
   */
  return hasMembershipPermission(membership, [
    "RECEIVE_SITE_NOTIFICATIONS",
    "PARTICIPATE_IN_SITE_RESPONSE",
  ]);
}

function hasMembershipPermission(
  membership: UserSiteMembershipRecord | undefined,
  permissionKeys: string[]
): boolean {
  if (!membership) return false;

  const permissions = normalizeBooleanMap((membership as any).permissions);
  return permissionKeys.some((key) => permissions[key] === true);
}

function isUserEnabled(profile: UserProfileRecord): boolean {
  if (profile.active === false) return false;
  if (profile.enabled === false) return false;

  const status = String(profile.status || "").trim().toUpperCase();
  if (status && status !== "ACTIVE") return false;

  return true;
}

function getMembershipForSite(
  siteMemberships: Record<string, UserSiteMembershipRecord> | undefined,
  siteId: string
): UserSiteMembershipRecord | undefined {
  if (!siteMemberships || !siteId) return undefined;

  const matchKey = Object.keys(siteMemberships).find(
    (key) => normalizeSiteId(key) === siteId
  );

  return matchKey ? siteMemberships[matchKey] : undefined;
}

function normalizeDisplayName(displayName: unknown, fallbackUserId: string): string {
  const value = String(displayName || "").trim();
  return value || fallbackUserId;
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function normalizeBooleanMap(
  value: Record<string, boolean | string> | string[] | undefined
): Record<string, boolean> {
  const result: Record<string, boolean> = {};
  if (!value) return result;

  if (Array.isArray(value)) {
    value.forEach((entry) => {
      const key = String(entry || "").trim();
      if (key) result[key] = true;
    });
    return result;
  }

  Object.entries(value).forEach(([key, raw]) => {
    const normalizedKey = String(key || "").trim();
    if (!normalizedKey) return;

    const enabled = raw === true || String(raw).toLowerCase() === "true";
    if (enabled) result[normalizedKey] = true;
  });

  return result;
}

function normalizeBooleanMaps(
  value: Record<string, boolean | string> | string[] | undefined
): Record<string, boolean> {
  return normalizeBooleanMap(value);
}

function mergeBooleanMaps(
  primary: Record<string, boolean>,
  secondary: Record<string, boolean>
): Record<string, boolean> {
  return {
    ...primary,
    ...secondary,
  };
}

function normalizeTargetKeys(value: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (Array.isArray(value)) {
    value.forEach((entry) => {
      const key = String(entry || "").trim();
      if (key) result[key] = true;
    });
  } else if (value && typeof value === "object") {
    Object.entries(value as Record<string, unknown>).forEach(([key, raw]) => {
      const normalizedKey = String(key || "").trim();
      if (!normalizedKey) return;

      const enabled = raw === true || String(raw).toLowerCase() === "true";
      if (enabled) result[normalizedKey] = true;
    });
  }

  return result;
}

function normalizeTokenMap(
  fcmTokens: Record<string, string> | undefined,
  fallbackToken?: string
): Record<string, string> {
  const result: Record<string, string> = {};

  Object.entries(fcmTokens || {}).forEach(([key, token]) => {
    const normalizedToken = String(token || "").trim();
    if (normalizedToken) {
      result[key] = normalizedToken;
    }
  });

  const fallback = String(fallbackToken || "").trim();
  if (fallback && !Object.values(result).includes(fallback)) {
    result.default = fallback;
  }

  return result;
}

function uniqueRecipients(recipients: ResolvedRecipient[]): ResolvedRecipient[] {
  const seen = new Set<string>();
  const unique: ResolvedRecipient[] = [];

  for (const recipient of recipients) {
    const key = `${recipient.userId}|${recipient.token}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(recipient);
  }

  return unique;
}