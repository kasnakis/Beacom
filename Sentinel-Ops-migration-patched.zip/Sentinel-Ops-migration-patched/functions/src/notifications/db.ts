import { App, getApps, initializeApp } from "firebase-admin/app";
import { Database, getDatabase } from "firebase-admin/database";
import { Messaging, getMessaging } from "firebase-admin/messaging";

const DEFAULT_DB_URL =
  "https://ppc-sentinel-ops-pilot-001-default-rtdb.europe-west1.firebasedatabase.app";

let cachedApp: App | null = null;

export function adminApp(): App {
  if (cachedApp) return cachedApp;

  const apps = getApps();
  if (apps.length > 0) {
    cachedApp = apps[0];
    return cachedApp;
  }

  cachedApp = initializeApp({
    databaseURL: DEFAULT_DB_URL,
  });

  return cachedApp;
}

export function db(): Database {
  return getDatabase(adminApp());
}

export function messaging(): Messaging {
  return getMessaging(adminApp());
}