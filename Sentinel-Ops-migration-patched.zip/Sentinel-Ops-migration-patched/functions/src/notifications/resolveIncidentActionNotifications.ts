import { onValueCreated } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

const DATABASE_INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const REGION = "europe-west1";

export const resolveIncidentActionNotifications = onValueCreated(
  {
    ref: "/incident_events/{eventId}",
    instance: DATABASE_INSTANCE,
    region: REGION,
  },
  async (event) => {
    const eventId = event.params.eventId;
    const data = event.data.exists() ? event.data.val() : null;

    if (!data) {
      logger.warn("ACTION_NOTIFY skipped: no data", { eventId });
      return;
    }

    const eventType = safeString(data.eventType);
    if (eventType !== "INCIDENT_ACTION_ASSIGNED") {
      return;
    }

    const incidentId = safeString(data.incidentId);
    const siteId = normalizeSiteId(data.siteId);
    const assigneeUid = safeString(data?.extra?.assigneeUid);
    const assigneeName = safeString(data?.extra?.assigneeName) || "User";
    const actionId = safeString(data?.extra?.actionId);
    const actionTitle = safeString(data?.extra?.title) || "Νέα ανάθεση ενέργειας";

    if (!incidentId || !siteId || !assigneeUid) {
      logger.warn("ACTION_NOTIFY missing required fields", {
        eventId,
        incidentId,
        siteId,
        assigneeUid,
      });
      return;
    }

    const db = admin.database();
    const now = Date.now();

    // Anti-duplicate guard
    try {
      const existingSnap = await db
        .ref("notification_requests")
        .orderByChild("incidentId")
        .equalTo(incidentId)
        .limitToLast(10)
        .get();

      if (existingSnap.exists()) {
        const existing = existingSnap.val() || {};

        for (const req of Object.values<any>(existing)) {
          const sameType = safeString(req?.type) === "INCIDENT_ACTION_ASSIGNED";
          const sameTrigger =
            safeString(req?.meta?.triggerEvent) === "INCIDENT_ACTION_ASSIGNED";
          const sameUser =
            req?.targeting?.explicitUsers &&
            req.targeting.explicitUsers[assigneeUid] === true;
          const recentEnough =
            Math.abs(Number(req?.meta?.createdAt || 0) - now) < 3000;

          if (sameType && sameTrigger && sameUser && recentEnough) {
            logger.info("ACTION_NOTIFY duplicate skipped", {
              eventId,
              incidentId,
              assigneeUid,
              existingRequestId: req?.id || "",
            });
            return;
          }
        }
      }
    } catch (error: any) {
      logger.warn("ACTION_NOTIFY duplicate guard failed", {
        eventId,
        incidentId,
        assigneeUid,
        error: error?.message || "unknown_error",
      });
    }

    // Resolve explicit user now, because processNotificationRequest
    // expects resolution.resolvedUsers to be already populated.
    const usersSnap = await db.ref("users").get();
    const users = usersSnap.exists() ? usersSnap.val() || {} : {};

    const resolvedUsers: Record<string, any> = {};
    const droppedUsers: Record<string, string> = {};

    const user = users[assigneeUid];
    if (!user) {
      droppedUsers[assigneeUid] = "USER_NOT_FOUND";
    } else {
      const userSiteId = normalizeSiteId(user.siteId);
      if (userSiteId && userSiteId !== siteId) {
        droppedUsers[assigneeUid] = "SITE_MISMATCH";
      } else if (user.active === false) {
        droppedUsers[assigneeUid] = "USER_INACTIVE";
      } else {
        const tokenMap = normalizeTokenMap(user.fcmTokens, user.fcmToken);

        if (Object.keys(tokenMap).length === 0) {
          droppedUsers[assigneeUid] = "NO_TOKENS";
        } else {
          resolvedUsers[assigneeUid] = {
            displayName: safeString(user.displayName) || assigneeName || assigneeUid,
            siteId,
            viaRoles: {},
            viaTeams: {},
            viaExplicit: true,
            tokens: tokenMap,
          };
        }
      }
    }

    const requestRef = db.ref("notification_requests").push();

    await requestRef.set({
      id: requestRef.key,
      incidentId,
      siteId,
      category: "ACTION",
      type: "INCIDENT_ACTION_ASSIGNED",
      status: "PENDING",

      meta: {
        schemaVersion: 2,
        source: "SYSTEM",
        triggerEvent: "INCIDENT_ACTION_ASSIGNED",
        createdAt: now,
        processedAt: 0,
        lastAttemptAt: 0,
      },

      policy: {
        policyUsed: false,
        policySourcePath: "",
        matchedPolicyIds: {},
        dynamicTargeting: false,
        dynamicTargetSource: "EXPLICIT_ASSIGNMENT",
      },

      targeting: {
        mode: "DIRECT",
        siteScope: "SITE_ONLY",
        siteId,
        targetRoles: {},
        targetTeams: {},
        explicitUsers: {
          [assigneeUid]: true,
        },
      },

      context: {
        actionId,
        title: actionTitle,
        assigneeName,
        type: "ACTION_ASSIGNED",
      },

      resolution: {
        resolvedUsers,
        resolvedUserCount: Object.keys(resolvedUsers).length,
        droppedUsers,
        droppedUserCount: Object.keys(droppedUsers).length,
      },

      delivery: {
        channel: "FCM",
        attemptedRecipientCount: 0,
        validRecipientCount: 0,
        successCount: 0,
        failureCount: 0,
        invalidTokenCount: 0,
        deliveryResults: {},
        failedTokens: [],
        invalidTokens: [],
        retryableFailedTokens: [],
      },

      retry: {
        enabled: true,
        retryCount: 0,
        maxRetryCount: 2,
        retryReason: "",
        nextRetryAt: 0,
        backoffSeconds: {
          "0": 60,
          "1": 180,
        },
        history: {},
      },
    });

    logger.info("ACTION_NOTIFY created notification_request", {
      requestId: requestRef.key,
      eventId,
      incidentId,
      siteId,
      assigneeUid,
      resolvedUserCount: Object.keys(resolvedUsers).length,
      droppedUserCount: Object.keys(droppedUsers).length,
      droppedUsers,
    });
  }
);

function normalizeTokenMap(
  fcmTokens: unknown,
  fallbackToken?: unknown
): Record<string, string> {
  const result: Record<string, string> = {};

  if (fcmTokens && typeof fcmTokens === "object") {
    Object.entries(fcmTokens as Record<string, unknown>).forEach(([key, value]) => {
      const token = safeString(value);
      if (token) {
        result[key] = token;
      }
    });
  }

  const fallback = safeString(fallbackToken);
  if (fallback && !Object.values(result).includes(fallback)) {
    result.default = fallback;
  }

  return result;
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}