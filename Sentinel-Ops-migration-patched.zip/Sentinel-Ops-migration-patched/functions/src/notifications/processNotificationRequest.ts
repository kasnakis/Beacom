import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import {
  NotificationRequestRecord,
  NotificationDeliveryBlock,
  NotificationRetryBlock,
  DeliveryResultRecord,
  ResolvedUserEntry,
} from "./types";

const DATABASE_INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const REGION = "europe-west1";

export const processNotificationRequest = onValueWritten(
  {
    ref: "/notification_requests/{requestId}",
    instance: DATABASE_INSTANCE,
    region: REGION,
  },
  async (event) => {
    const requestId = event.params.requestId;
    const afterExists = event.data.after.exists();

    if (!afterExists) return;

    const after = event.data.after.val() as NotificationRequestRecord | null;
    if (!after) return;

    const status = normalizeText(after.status);
    if (status !== "PENDING" && status !== "RETRY_SCHEDULED") {
      return;
    }

    const db = admin.database();
    const requestRef = db.ref(`notification_requests/${requestId}`);
    const now = Date.now();

    try {
      await requestRef.child("status").set("PROCESSING");
      await requestRef.child("meta/lastAttemptAt").set(now);

      const siteId = normalizeSiteId(after.siteId);
      const incidentId = safeString(after.incidentId);
      const category = normalizeText(after.category);
      const type = normalizeText(after.type);

      const resolution = after.resolution || {
        resolvedUsers: {},
        resolvedUserCount: 0,
        droppedUsers: {},
        droppedUserCount: 0,
      };

      const existingRetry = after.retry || {
        enabled: true,
        retryCount: 0,
        maxRetryCount: 0,
        retryReason: "",
        nextRetryAt: 0,
        backoffSeconds: {},
        history: {},
      };

      const resolvedUsers = resolution.resolvedUsers || {};
      const resolvedUserEntries = Object.entries(resolvedUsers) as Array<
        [string, ResolvedUserEntry]
      >;

      if (resolvedUserEntries.length === 0) {
        const retryUpdate = buildRetryUpdate({
          retry: existingRetry,
          reason: "NO_TARGETS",
          now,
        });

        const nextStatus = retryUpdate.shouldRetry ? "RETRY_SCHEDULED" : "NO_TARGETS";

        await requestRef.update({
          status: nextStatus,
          "meta/processedAt": now,
          delivery: {
            channel: "FCM",
            attemptedRecipientCount: 0,
            validRecipientCount: 0,
            successCount: 0,
            failureCount: 0,
            invalidTokenCount: 0,
            deliveryResults: {},
            failedTokens: [],
            invalidTokens: [],
            retryableFailedTokens: [],
          },
          retry: retryUpdate.retryBlock,
        });

        logger.warn("Notification request has no resolved users", {
          requestId,
          incidentId,
          siteId,
          category,
          type,
          nextStatus,
        });

        return;
      }

      const attemptedRecipients: Array<{
        userId: string;
        displayName: string;
        tokenKey: string;
        token: string;
      }> = [];

      const droppedUsers = { ...(resolution.droppedUsers || {}) };

      for (const [userId, userEntry] of resolvedUserEntries) {
        const displayName = safeString(userEntry.displayName) || userId;
        const tokens = userEntry.tokens || {};
        const tokenEntries = Object.entries(tokens);

        if (tokenEntries.length === 0) {
          droppedUsers[userId] = "NO_TOKENS";
          continue;
        }

        for (const [tokenKey, token] of tokenEntries) {
          const normalizedToken = safeString(token);
          if (!normalizedToken) continue;

          attemptedRecipients.push({
            userId,
            displayName,
            tokenKey,
            token: normalizedToken,
          });
        }
      }

      if (attemptedRecipients.length === 0) {
        const retryUpdate = buildRetryUpdate({
          retry: existingRetry,
          reason: "NO_VALID_RECIPIENTS",
          now,
        });

        const nextStatus = retryUpdate.shouldRetry ? "RETRY_SCHEDULED" : "NO_TARGETS";

        await requestRef.update({
          status: nextStatus,
          "meta/processedAt": now,
          resolution: {
            ...resolution,
            droppedUsers,
            droppedUserCount: Object.keys(droppedUsers).length,
          },
          delivery: {
            channel: "FCM",
            attemptedRecipientCount: 0,
            validRecipientCount: 0,
            successCount: 0,
            failureCount: 0,
            invalidTokenCount: 0,
            deliveryResults: {},
            failedTokens: [],
            invalidTokens: [],
            retryableFailedTokens: [],
          },
          retry: retryUpdate.retryBlock,
        });

        logger.warn("Notification request has no valid recipients/tokens", {
          requestId,
          incidentId,
          siteId,
          category,
          type,
          nextStatus,
        });

        return;
      }

      const incident = await readIncident(incidentId);

      const deliveryResults: Record<string, DeliveryResultRecord> = {};
      const failedTokens: string[] = [];
      const invalidTokens: string[] = [];
      const retryableFailedTokens: string[] = [];

      let successCount = 0;
      let failureCount = 0;
      let invalidTokenCount = 0;

      for (const recipient of attemptedRecipients) {
        const message = buildFcmMessage({
          token: recipient.token,
          request: after,
          incident,
        });

        try {
          await admin.messaging().send(message);

          successCount++;

          deliveryResults[`${recipient.userId}:${recipient.tokenKey}`] = {
            userId: recipient.userId,
            displayName: recipient.displayName,
            token: recipient.token,
            success: true,
            invalidToken: false,
            retryable: false,
          };
        } catch (error) {
          failureCount++;

          const parsed = parseMessagingError(error);
          if (parsed.invalidToken) {
            invalidTokenCount++;
            invalidTokens.push(recipient.token);
            await removeInvalidTokenFromUser(recipient.userId, recipient.token).catch(() => undefined);
          }

          if (parsed.retryable) {
            retryableFailedTokens.push(recipient.token);
          }

          failedTokens.push(recipient.token);

          deliveryResults[`${recipient.userId}:${recipient.tokenKey}`] = {
            userId: recipient.userId,
            displayName: recipient.displayName,
            token: recipient.token,
            success: false,
            invalidToken: parsed.invalidToken,
            retryable: parsed.retryable,
            errorCode: parsed.code,
            errorMessage: parsed.message,
          };
        }
      }

      const validRecipientCount = attemptedRecipients.length;

      const delivery: NotificationDeliveryBlock & {
        failedTokens: string[];
        invalidTokens: string[];
        retryableFailedTokens: string[];
      } = {
        channel: "FCM",
        attemptedRecipientCount: validRecipientCount,
        validRecipientCount,
        successCount,
        failureCount,
        invalidTokenCount,
        deliveryResults,
        failedTokens,
        invalidTokens,
        retryableFailedTokens,
      };

      let nextStatus: string;
      let retryBlock: NotificationRetryBlock = existingRetry;

      if (successCount > 0 && failureCount === 0) {
        nextStatus = "SENT";
        retryBlock = clearRetry(existingRetry);
      } else if (successCount > 0 && failureCount > 0) {
        const retryUpdate = buildRetryUpdate({
          retry: existingRetry,
          reason: "PARTIAL_FAILURE",
          now,
        });
        nextStatus = retryUpdate.shouldRetry ? "RETRY_SCHEDULED" : "PARTIAL";
        retryBlock = retryUpdate.retryBlock;
      } else {
        const retryUpdate = buildRetryUpdate({
          retry: existingRetry,
          reason: "FAILED",
          now,
        });
        nextStatus = retryUpdate.shouldRetry ? "RETRY_SCHEDULED" : "FAILED";
        retryBlock = retryUpdate.retryBlock;
      }

      await requestRef.update({
        status: nextStatus,
        "meta/processedAt": now,
        resolution: {
          ...resolution,
          droppedUsers,
          droppedUserCount: Object.keys(droppedUsers).length,
        },
        delivery,
        retry: retryBlock,
      });

      logger.info("Notification request processed", {
        requestId,
        incidentId,
        siteId,
        category,
        type,
        status: nextStatus,
        validRecipientCount,
        successCount,
        failureCount,
        invalidTokenCount,
      });
    } catch (error) {
      logger.error("Notification processing failed", {
        requestId,
        error: stringifyError(error),
      });

      await requestRef.update({
        status: "FAILED",
        "meta/processedAt": now,
      }).catch(() => undefined);

      throw error;
    }
  }
);

async function readIncident(incidentId: string): Promise<Record<string, unknown>> {
  if (!incidentId) return {};
  const snap = await admin.database().ref(`incidents/${incidentId}`).get();
  return snap.exists() ? snap.val() || {} : {};
}

function buildFcmMessage(args: {
  token: string;
  request: NotificationRequestRecord;
  incident: Record<string, unknown>;
}): admin.messaging.Message {
  const { token, request, incident } = args;

  const title = buildTitle(request, incident);
  const body = buildBody(request, incident);

  return {
    token,
    notification: {
      title,
      body,
    },
    data: {
      requestId: safeString(request.id),
      incidentId: safeString(request.incidentId),
      siteId: safeString(request.siteId),
      category: safeString(request.category),
      type: safeString(request.type),
      triggerEvent: safeString(request.meta?.triggerEvent),
      status: safeString(incident.status),
      title,
      body,
    },
    android: {
      priority: "high",
    },
  };
}

function buildTitle(
  request: NotificationRequestRecord,
  incident: Record<string, unknown>
): string {
  const category = normalizeText(request.category);
  const type = normalizeText(request.type);
  const mode = normalizeText(request.targeting?.mode);
  const triggerEvent = normalizeText(request.meta?.triggerEvent);
  const incidentTitle = safeString(incident.title);
  const activation = (incident["activation"] || {}) as Record<string, unknown>;
  const activationLevel = safeString(activation["activationLevel"]);
  const activationScenario = safeString(activation["activatedScenario"]);

  if (type === "INCIDENT_ACTION_ASSIGNED") {
    return "📝 Νέα ανάθεση ενέργειας";
  }

  if (type === "INCIDENT_ACTION_COMPLETED") {
    return "✅ Ολοκληρώθηκε ενέργεια";
  }

  if (mode === "VERIFY_FIRST") {
    return incidentTitle
      ? `Απαιτείται επιβεβαίωση: ${incidentTitle}`
      : "Απαιτείται επιβεβαίωση συμβάντος";
  }

  if (type === "DISPATCH_INCIDENT") {
    return incidentTitle
      ? `✔ Επιβεβαιώθηκε συμβάν: ${incidentTitle}`
      : "✔ Επιβεβαιώθηκε συμβάν";
  }

  if (triggerEvent === "INCIDENT_UNDER_CONTROL") {
    return incidentTitle
      ? `🟡 Υπό έλεγχο: ${incidentTitle}`
      : "🟡 Η κατάσταση τέθηκε υπό έλεγχο";
  }

  if (triggerEvent === "INCIDENT_DEACTIVATED") {
    return incidentTitle
      ? `✅ Απενεργοποίηση ΣΑΕΚ: ${incidentTitle}`
      : "✅ Απενεργοποιήθηκε το ΣΑΕΚ";
  }

  if (category === "SOS") return "🚨 Νέο SOS";
  if (category === "HSE_ACCIDENT") return "🚑 Νέο ατύχημα ΥΑΕ";
  if (category === "ENVIRONMENTAL_INCIDENT") return "🌿 Νέο περιβαλλοντικό συμβάν";
  if (category === "EMERGENCY_ACTIVATION") {
    if (activationScenario && activationLevel) {
      return `🔥 ΣΑΕΚ ${activationLevel}: ${activationScenario}`;
    }
    if (activationScenario) {
      return `🔥 ΣΑΕΚ: ${activationScenario}`;
    }
    return "🔥 Ενεργοποίηση έκτακτης κατάστασης";
  }

  return incidentTitle ? `Νέο συμβάν: ${incidentTitle}` : "Νέο συμβάν";
}

function buildBody(
  request: NotificationRequestRecord,
  incident: Record<string, unknown>
): string {
  const category = normalizeText(request.category);
  const type = normalizeText(request.type);
  const severity = safeString(incident.severity);
  const incidentTitle = safeString(incident.title);
  const mode = normalizeText(request.targeting?.mode);
  const triggerEvent = normalizeText(request.meta?.triggerEvent);
  const activation = (incident["activation"] || {}) as Record<string, unknown>;
  const activationLevel = safeString(activation["activationLevel"]);
  const activationScenario = safeString(activation["activatedScenario"]);
  const evacuationRequired = activation["evacuationRequired"] === true;
  const externalAuthoritiesRequired =
    activation["externalAuthoritiesRequired"] === true;
  const ctx = getRequestContext(request);

  if (type === "INCIDENT_ACTION_ASSIGNED") {
    const actionTitle = safeString(ctx["title"]) || "ενέργεια";
    const incidentPart = incidentTitle
      ? ` για το συμβάν "${incidentTitle}"`
      : "";

    return `Σας ανατέθηκε η ενέργεια "${actionTitle}"${incidentPart}.`;
  }

  if (type === "INCIDENT_ACTION_COMPLETED") {
    const completedByName = safeString(ctx["completedByName"]) || "χρήστης";
    const actionTitle = safeString(ctx["title"]) || "ενέργεια";
    const completionNotes = safeString(ctx["completionNotes"]);

    if (completionNotes) {
      return `Ο ${completedByName} ολοκλήρωσε την ενέργεια "${actionTitle}". Σχόλιο: ${completionNotes}`;
    }

    return `Ο ${completedByName} ολοκλήρωσε την ενέργεια "${actionTitle}".`;
  }

  if (mode === "VERIFY_FIRST") {
    return incidentTitle
      ? `Το συμβάν "${incidentTitle}" απαιτεί επιβεβαίωση.`
      : "Ένα νέο συμβάν απαιτεί επιβεβαίωση.";
  }

  if (type === "DISPATCH_INCIDENT") {
    const verifiedByName = safeString(
      (incident as Record<string, unknown>)["verifiedByName"]
    );

    if (incidentTitle && verifiedByName) {
      return `Το συμβάν "${incidentTitle}" επιβεβαιώθηκε από ${verifiedByName}.`;
    }

    if (incidentTitle) {
      return `Το συμβάν "${incidentTitle}" επιβεβαιώθηκε.`;
    }

    return "Ένα συμβάν επιβεβαιώθηκε.";
  }

  if (triggerEvent === "INCIDENT_UNDER_CONTROL") {
    return incidentTitle
      ? `Το συμβάν "${incidentTitle}" τέθηκε υπό έλεγχο.`
      : "Η κατάσταση τέθηκε υπό έλεγχο.";
  }

  if (triggerEvent === "INCIDENT_DEACTIVATED") {
    return incidentTitle
      ? `Το ΣΑΕΚ για το συμβάν "${incidentTitle}" απενεργοποιήθηκε.`
      : "Το ΣΑΕΚ απενεργοποιήθηκε.";
  }

  if (category === "EMERGENCY_ACTIVATION") {
    const detailParts: string[] = [];

    if (incidentTitle) {
      detailParts.push(incidentTitle);
    }

    if (activationScenario) {
      detailParts.push(`Σενάριο: ${activationScenario}`);
    }

    if (activationLevel) {
      detailParts.push(`Επίπεδο: ${activationLevel}`);
    }

    if (evacuationRequired) {
      detailParts.push("Απαιτείται εκκένωση");
    }

    if (externalAuthoritiesRequired) {
      detailParts.push("Ενημέρωση εξωτερικών αρχών");
    }

    if (detailParts.length > 0) {
      return detailParts.join(" • ");
    }

    return "Νέα ενεργοποίηση έκτακτης κατάστασης.";
  }

  if (incidentTitle && severity) {
    return `${incidentTitle} • Σοβαρότητα: ${severity}`;
  }

  if (incidentTitle) return incidentTitle;
  if (severity) return `Συμβάν ${category} • Σοβαρότητα: ${severity}`;

  return "Υπάρχει νέο επιχειρησιακό συμβάν.";
}

function getRequestContext(request: NotificationRequestRecord): Record<string, unknown> {
  const raw = (request as unknown as { context?: unknown }).context;
  if (raw && typeof raw === "object") {
    return raw as Record<string, unknown>;
  }
  return {};
}

function buildRetryUpdate(args: {
  retry: NotificationRetryBlock;
  reason: string;
  now: number;
}): {
  shouldRetry: boolean;
  retryBlock: NotificationRetryBlock;
} {
  const { retry, reason, now } = args;

  const enabled = retry.enabled === true;
  const retryCount = Number(retry.retryCount || 0);
  const maxRetryCount = Number(retry.maxRetryCount || 0);
  const backoffValues = Object.values(retry.backoffSeconds || {})
    .map((v) => Number(v))
    .filter((v) => Number.isFinite(v) && v > 0);

  if (!enabled || retryCount >= maxRetryCount) {
    return {
      shouldRetry: false,
      retryBlock: {
        ...retry,
        retryReason: reason,
        nextRetryAt: 0,
      },
    };
  }

  const nextRetryNumber = retryCount + 1;
  const backoffSeconds =
    backoffValues[retryCount] ??
    backoffValues[backoffValues.length - 1] ??
    60;

  const nextRetryAt = now + backoffSeconds * 1000;
  const historyKey = String(nextRetryNumber);

  return {
    shouldRetry: true,
    retryBlock: {
      ...retry,
      retryCount: nextRetryNumber,
      retryReason: reason,
      nextRetryAt,
      history: {
        ...(retry.history || {}),
        [historyKey]: {
          at: now,
          retryNumber: nextRetryNumber,
          reason,
          nextRetryAt,
        },
      },
    },
  };
}

function clearRetry(retry: NotificationRetryBlock): NotificationRetryBlock {
  return {
    ...retry,
    retryReason: "",
    nextRetryAt: 0,
  };
}

async function removeInvalidTokenFromUser(userId: string, token: string): Promise<void> {
  if (!userId || !token) return;

  const userRef = admin.database().ref(`users/${userId}`);
  const snap = await userRef.get();
  if (!snap.exists()) return;

  const user = snap.val() || {};
  const updates: Record<string, null> = {};

  if (typeof user.fcmToken === "string" && user.fcmToken.trim() === token) {
    updates["fcmToken"] = null;
  }

  const fcmTokens = user.fcmTokens || {};
  Object.entries(fcmTokens as Record<string, unknown>).forEach(([key, value]) => {
    if (String(value || "").trim() === token) {
      updates[`fcmTokens/${key}`] = null;
    }
  });

  if (Object.keys(updates).length > 0) {
    await userRef.update(updates);
  }
}

function parseMessagingError(error: unknown): {
  code: string;
  message: string;
  invalidToken: boolean;
  retryable: boolean;
} {
  const code = safeString((error as { code?: string })?.code);
  const message =
    safeString((error as { message?: string })?.message) || stringifyError(error);

  const invalidToken =
    code === "messaging/registration-token-not-registered" ||
    code === "messaging/invalid-registration-token";

  const retryable =
    code === "messaging/internal-error" ||
    code === "messaging/server-unavailable" ||
    code === "messaging/unknown-error" ||
    code === "app/network-error";

  return {
    code,
    message,
    invalidToken,
    retryable,
  };
}

function normalizeText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function stringifyError(error: unknown): string {
  if (error instanceof Error) {
    return `${error.name}: ${error.message}`;
  }
  try {
    return JSON.stringify(error);
  } catch {
    return String(error);
  }
}