import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import { resolveExternalNotifications } from "./externalNotifications/resolveExternalNotifications";

type ExternalTriggerConfig = {
  onCreated?: boolean;
  onVerified?: boolean;
  onUnderControl?: boolean;
};

type FlatExternalPolicy = {
  externalEnabled?: boolean;
  externalMode?: "AUTO" | "MANUAL" | "MANUAL_APPROVAL" | "MANUAL_LOGGED";
  externalAuthorityTypes?: Record<string, boolean>;
  externalAuthorityIds?: Record<string, boolean>;
  externalTriggers?: ExternalTriggerConfig;
  externalNotificationPolicy?: {
    enabled?: boolean;
    mode?: "AUTO" | "MANUAL" | "MANUAL_APPROVAL" | "MANUAL_LOGGED";
    authorityTypes?: Record<string, boolean>;
    authorityIds?: Record<string, boolean>;
    triggers?: ExternalTriggerConfig;
  };
};

type WorkflowExternalAuthorityConfig = {
  enabled?: boolean;
  autoSuggest?: boolean;
  defaultChannel?: string;
  requiresApproval?: boolean;
  allowedRequesterRoles?: Record<string, boolean>;
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
};

type WorkflowExtensions = {
  externalNotifications?: {
    enabled?: boolean;
    mode?: "AUTO" | "MANUAL" | "MANUAL_APPROVAL" | "MANUAL_LOGGED";
    authorities?: Record<string, WorkflowExternalAuthorityConfig>;
  };
};

type IncidentPolicyRecord = FlatExternalPolicy & {
  workflowExtensions?: WorkflowExtensions;
};

type ExternalAuthorityRecord = {
  id?: string;
  name?: string;
  type?: string;
  siteId?: string;
  enabled?: boolean;
  active?: boolean;
  defaultChannel?: string;
  supportedChannels?: Record<string, boolean>;
  contacts?: {
    primary?: {
      phone?: string;
      email?: string;
      address?: string;
      notes?: string;
    };
    secondary?: {
      phone?: string;
      email?: string;
      address?: string;
      notes?: string;
    };
  };
};

type CanonicalExternalRequest = {
  dedupeKey?: string;
};

type IncidentExternalAuthoritySummary = {
  required?: boolean;
  requested?: boolean;
  displayName?: string;
  authorityType?: string;
  status?: string;
  channel?: string;
  mode?: string;
  lastUpdatedAt?: number;
  canonicalNotificationId?: string;
  legacyRequestId?: string;
  approvalRequired?: boolean;
  approvedAt?: number | null;
  rejectedAt?: number | null;
  executedAt?: number | null;
  acknowledgedAt?: number | null;
  failedAt?: number | null;
  closedAt?: number | null;
  acknowledgedBy?: string;
};

const FUNCTION_NAME = "externalNotificationEngine";
const FUNCTION_SOURCE = "FUNCTION";
const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";

const SYSTEM_REQUESTER_ROLES: Record<string, boolean> = {
  CONTROL_ROOM: true,
  ENVIRONMENTAL_OFFICER: true,
  HSE_MANAGER: true,
  SITE_MANAGER: true,
  SUPERVISOR: true,
};

function isVerifiedStatus(value: unknown): boolean {
  return value === "VERIFIED" || value === "AUTO_VERIFIED";
}

function resolvePolicyEnabled(policy: IncidentPolicyRecord): boolean {
  if (policy.externalNotificationPolicy?.enabled === true) return true;
  if (policy.externalEnabled === true) return true;
  if (policy.workflowExtensions?.externalNotifications?.enabled === true) return true;
  return false;
}

export const externalNotificationEngine = onValueWritten(
  {
    ref: "/incidents/{incidentId}",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const before = event.data.before.val();
    const after = event.data.after.val();

    if (!after) return;

    const incidentId = event.params.incidentId as string;
    const siteId = typeof after.siteId === "string" ? after.siteId : undefined;
    const category = typeof after.category === "string" ? after.category : undefined;

    if (!siteId || !category) return;

    const wasExisting = Boolean(before);
    const isCreate = !wasExisting;

    const beforeVerified = isVerifiedStatus(before?.verificationStatus);
    const afterVerified = isVerifiedStatus(after?.verificationStatus);
    const isVerifiedTransition = !beforeVerified && afterVerified;

    let trigger: "INCIDENT_CREATED" | "INCIDENT_VERIFIED" | null = null;

    if (isCreate) {
      trigger = "INCIDENT_CREATED";
    } else if (isVerifiedTransition) {
      trigger = "INCIDENT_VERIFIED";
    }

    if (!trigger) return;

    const db = admin.database();

    const policySnap = await db
      .ref(`site_config_data/${siteId}/incident_policies/${category}`)
      .get();

    if (!policySnap.exists()) {
      logger.warn("externalNotificationEngine: policy missing", {
        incidentId,
        siteId,
        category,
      });
      return;
    }

    const policy = policySnap.val() as IncidentPolicyRecord;
    if (!resolvePolicyEnabled(policy)) {
      logger.info("externalNotificationEngine: policy disabled", {
        incidentId,
        siteId,
        category,
        trigger,
      });
      return;
    }

    const authoritiesSnap = await db
      .ref(`site_config_data/${siteId}/external_authorities`)
      .get();

    const authoritiesRegistry = authoritiesSnap.exists()
      ? (authoritiesSnap.val() as Record<string, ExternalAuthorityRecord>)
      : {};

    const resolverResult = resolveExternalNotifications({
      siteId,
      incidentId,
      category,
      subtype: safeString(after.subtype ?? after.type ?? ""),
      severity: normalizeSeverity(after.severity),
      triggerEvent: trigger,
      policy,
      authoritiesRegistry,
      flags: {
        externalAuthoritiesRequired:
          toBoolean(after.activation?.externalAuthoritiesRequired) === true ||
          toBoolean(after.externalAuthoritiesRequired) === true,
        evacuationRequired:
          toBoolean(after.activation?.evacuationRequired) === true ||
          toBoolean(after.evacuationRequired) === true,
        injuriesReported: toBoolean(after.injuriesReported) === true,
        fireConfirmed:
          normalizeEnumText(after.subtype || after.type || "") === "FIRE" ||
          toBoolean(after.fireConfirmed) === true,
        policeRequired: toBoolean(after.policeRequired) === true,
        environmentalEscalationRequired:
          toBoolean(after.environmentalEscalationRequired) === true,
      },
      incidentState: {
        active: toBoolean(after.active) === true,
        verified: isVerifiedStatus(after.verificationStatus),
        underControl:
          toBoolean(after.underControl) === true ||
          normalizeEnumText(after.status) === "UNDER_CONTROL",
        closureRequested: toBoolean(after.closureRequested) === true,
      },
      currentUser: {
        uid: FUNCTION_NAME,
        displayName: FUNCTION_NAME,
        roles: SYSTEM_REQUESTER_ROLES,
      },
    });

    if (!resolverResult.shouldCreateAny || resolverResult.plans.length === 0) {
      logger.info("externalNotificationEngine: no external notifications created", {
        incidentId,
        siteId,
        category,
        trigger,
        diagnostics: resolverResult.diagnostics,
      });
      return;
    }

    const externalNotificationsSnap = await db.ref("external_notifications").get();
    const externalNotifications = externalNotificationsSnap.exists()
      ? (externalNotificationsSnap.val() as Record<string, any>)
      : {};

    const existingNotificationDedupeKeys = new Set<string>(
      Object.values(externalNotifications)
        .map((item) => item?.resolver?.dedupeKey || item?.dedupeKey)
        .filter((value): value is string => Boolean(value))
    );

    const shadowQueueSnap = await db.ref("external_notification_requests").get();
    const shadowQueue = shadowQueueSnap.exists()
      ? (shadowQueueSnap.val() as Record<string, CanonicalExternalRequest>)
      : {};

    const existingShadowDedupeKeys = new Set<string>(
      Object.values(shadowQueue)
        .map((item) => item?.dedupeKey)
        .filter((value): value is string => Boolean(value))
    );

    const incidentExternalAuthorities =
      after.externalAuthorities && typeof after.externalAuthorities === "object"
        ? (after.externalAuthorities as Record<string, IncidentExternalAuthoritySummary>)
        : {};

    const now = Date.now();
    const updates: Record<string, unknown> = {};
    let preparedCount = 0;

    for (const plan of resolverResult.plans) {
      if (!plan.shouldCreate) continue;

      const dedupeKey = plan.dedupeKey;
      if (existingNotificationDedupeKeys.has(dedupeKey)) continue;
      if (existingShadowDedupeKeys.has(dedupeKey)) continue;

      const existingCanonical = Object.values(externalNotifications).some((item) => {
        return (
          item?.incidentId === incidentId &&
          (item?.authorityId === plan.authorityId ||
            item?.authorityType === plan.authorityType)
        );
      });

      if (existingCanonical) continue;

      const queueId = db.ref("external_notification_requests").push().key;
      const eventId = db.ref("incident_events").push().key;

      if (!queueId || !eventId) continue;

      const canonicalNotificationId = buildCanonicalExternalNotificationId(
        incidentId,
        trigger,
        plan.authorityType
      );

      const canonicalPath = `external_notifications/${canonicalNotificationId}`;
      const existingCanonicalPathSnap = await db.ref(canonicalPath).get();
      if (existingCanonicalPathSnap.exists()) continue;

      updates[`external_notification_requests/${queueId}`] = {
        id: queueId,
        incidentId,
        siteId,
        category,
        trigger,
        mode: plan.mode,
        source: "POLICY_ENGINE",
        authorityId: plan.authorityId,
        authorityType: plan.authorityType,
        authorityName: plan.authorityName,
        channel: plan.defaultChannel,
        status: "REQUESTED",
        dedupeKey,
        contacts: {
          primary: plan.contacts.primary,
          secondary: plan.contacts.secondary,
        },
        approval: {
          required: plan.approvalRequired,
          status: plan.approvalRequired ? "PENDING" : "NOT_REQUIRED",
        },
        execution: {
          status: "PENDING",
          resultNotes: "",
        },
        acknowledgement: {
          status: "NONE",
          receivedAt: null,
          receivedBy: "",
          notes: "",
        },
        createdAt: now,
        updatedAt: now,
        requestedByUserId: FUNCTION_NAME,
        requestedByName: FUNCTION_NAME,
        resolver: {
          mode: plan.source.resolutionMode,
          policyPath: plan.source.policyPath,
          reasonCodes: plan.reasonCodes,
          dedupeKey,
        },
        canonicalNotificationId,
      };

      updates[`${canonicalPath}/id`] = canonicalNotificationId;
      updates[`${canonicalPath}/incidentId`] = incidentId;
      updates[`${canonicalPath}/siteId`] = siteId;
      updates[`${canonicalPath}/category`] = category;

      updates[`${canonicalPath}/authorityType`] = plan.authorityType;
      updates[`${canonicalPath}/authorityId`] = plan.authorityId;
      updates[`${canonicalPath}/authorityName`] = plan.authorityName;

      updates[`${canonicalPath}/contact/phone`] = safeString(plan.contacts.primary.phone);
      updates[`${canonicalPath}/contact/email`] = safeString(plan.contacts.primary.email);
      updates[`${canonicalPath}/contact/address`] = safeString(plan.contacts.primary.address);
      updates[`${canonicalPath}/contact/notes`] = safeString(plan.contacts.primary.notes);

      updates[`${canonicalPath}/contactSecondary/phone`] = safeString(
        plan.contacts.secondary.phone
      );
      updates[`${canonicalPath}/contactSecondary/email`] = safeString(
        plan.contacts.secondary.email
      );
      updates[`${canonicalPath}/contactSecondary/address`] = safeString(
        plan.contacts.secondary.address
      );
      updates[`${canonicalPath}/contactSecondary/notes`] = safeString(
        plan.contacts.secondary.notes
      );

      updates[`${canonicalPath}/channel`] = plan.defaultChannel;
      updates[`${canonicalPath}/requestedByUserId`] = FUNCTION_NAME;
      updates[`${canonicalPath}/requestedByName`] = FUNCTION_NAME;
      updates[`${canonicalPath}/requestedByRole`] = "SYSTEM";

      updates[`${canonicalPath}/approval/required`] = plan.approvalRequired;
      updates[`${canonicalPath}/approval/status`] = plan.approvalRequired
        ? "PENDING"
        : "NOT_REQUIRED";
      updates[`${canonicalPath}/approval/approvedByUserId`] = null;
      updates[`${canonicalPath}/approval/approvedByName`] = null;
      updates[`${canonicalPath}/approval/approvedByRole`] = null;
      updates[`${canonicalPath}/approval/approvedAt`] = null;
      updates[`${canonicalPath}/approval/rejectionReason`] = null;

      updates[`${canonicalPath}/execution/status`] = "PENDING";
      updates[`${canonicalPath}/execution/executedByUserId`] = null;
      updates[`${canonicalPath}/execution/executedByName`] = null;
      updates[`${canonicalPath}/execution/executedAt`] = null;
      updates[`${canonicalPath}/execution/resultNotes`] = "";

      updates[`${canonicalPath}/acknowledgement/status`] = "NONE";
      updates[`${canonicalPath}/acknowledgement/receivedAt`] = null;
      updates[`${canonicalPath}/acknowledgement/receivedBy`] = "";
      updates[`${canonicalPath}/acknowledgement/notes`] = "";

      updates[`${canonicalPath}/attempts`] = 0;
      updates[`${canonicalPath}/lastAttemptAt`] = null;

      updates[`${canonicalPath}/status`] = "REQUESTED";
      updates[`${canonicalPath}/mode`] = plan.mode;
      updates[`${canonicalPath}/source`] = "POLICY_ENGINE";
      updates[`${canonicalPath}/targets`] = {
        [plan.authorityType]: true,
      };
      updates[`${canonicalPath}/createdAt`] = now;
      updates[`${canonicalPath}/updatedAt`] = now;
      updates[`${canonicalPath}/closedAt`] = null;
      updates[`${canonicalPath}/notes`] = "";
      updates[`${canonicalPath}/legacyRequestId`] = queueId;
      updates[`${canonicalPath}/trigger`] = trigger;
      updates[`${canonicalPath}/resolver/mode`] = plan.source.resolutionMode;
      updates[`${canonicalPath}/resolver/policyPath`] = plan.source.policyPath;
      updates[`${canonicalPath}/resolver/reasonCodes`] = plan.reasonCodes;
      updates[`${canonicalPath}/resolver/dedupeKey`] = dedupeKey;
      updates[`${canonicalPath}/allowedRequesterRoles`] = plan.allowedRequesterRoles;
      updates[`${canonicalPath}/allowedApproverRoles`] = plan.allowedApproverRoles;
      updates[`${canonicalPath}/allowedExecutorRoles`] = plan.allowedExecutorRoles;

      const existingSummary = sanitizeIncidentExternalAuthoritySummary(
        incidentExternalAuthorities[plan.authorityType]
      );

      updates[`incidents/${incidentId}/externalAuthorities/${plan.authorityType}/required`] = true;
      updates[`incidents/${incidentId}/externalAuthorities/${plan.authorityType}/requested`] = true;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/displayName`
      ] = plan.authorityName;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/authorityType`
      ] = plan.authorityType;
      updates[`incidents/${incidentId}/externalAuthorities/${plan.authorityType}/status`] =
        "REQUESTED";
      updates[`incidents/${incidentId}/externalAuthorities/${plan.authorityType}/channel`] =
        plan.defaultChannel;
      updates[`incidents/${incidentId}/externalAuthorities/${plan.authorityType}/mode`] =
        plan.mode;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/lastUpdatedAt`
      ] = now;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/canonicalNotificationId`
      ] = canonicalNotificationId;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/legacyRequestId`
      ] = queueId;
      updates[
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/approvalRequired`
      ] = plan.approvalRequired;

      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/approvedAt`,
        existingSummary.approvedAt
      );
      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/rejectedAt`,
        existingSummary.rejectedAt
      );
      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/executedAt`,
        existingSummary.executedAt
      );
      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/acknowledgedAt`,
        existingSummary.acknowledgedAt
      );
      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/failedAt`,
        existingSummary.failedAt
      );
      copyOptionalTimestampUpdate(
        updates,
        `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/closedAt`,
        existingSummary.closedAt
      );

      if (safeString(existingSummary.acknowledgedBy)) {
        updates[
          `incidents/${incidentId}/externalAuthorities/${plan.authorityType}/acknowledgedBy`
        ] = safeString(existingSummary.acknowledgedBy);
      }

      updates[`incident_events/${eventId}`] = {
        id: eventId,
        incidentId,
        siteId,
        source: FUNCTION_SOURCE,
        userId: FUNCTION_NAME,
        userName: FUNCTION_NAME,
        createdAt: now,
        eventType: "EXTERNAL_NOTIFICATION_REQUESTED",
        extra: {
          authorityId: plan.authorityId,
          authorityType: plan.authorityType,
          authorityName: plan.authorityName,
          channel: plan.defaultChannel,
          trigger,
          mode: plan.mode,
          status: "REQUESTED",
          dedupeKey,
          canonicalRequestId: canonicalNotificationId,
          legacyRequestId: queueId,
          resolverReasonCodes: plan.reasonCodes,
        },
      };

      preparedCount += 1;
    }

    if (Object.keys(updates).length === 0) {
      logger.info("externalNotificationEngine: no updates prepared", {
        incidentId,
        siteId,
        category,
        trigger,
      });
      return;
    }

    await db.ref().update(updates);

    logger.info("externalNotificationEngine: external notifications created", {
      incidentId,
      siteId,
      category,
      trigger,
      preparedCount,
    });
  }
);

function buildCanonicalExternalNotificationId(
  incidentId: string,
  trigger: string,
  authorityType: string
): string {
  return [
    safeKeyPart(incidentId),
    safeKeyPart(trigger),
    safeKeyPart(authorityType),
  ].join("_");
}

function sanitizeIncidentExternalAuthoritySummary(
  value: unknown
): IncidentExternalAuthoritySummary {
  const raw = (value || {}) as IncidentExternalAuthoritySummary;
  return {
    required: toBoolean(raw.required) === true,
    requested: toBoolean(raw.requested) === true,
    displayName: safeString(raw.displayName),
    authorityType: normalizeAuthorityType(raw.authorityType || ""),
    status: normalizeEnumText(raw.status || ""),
    channel: normalizeEnumText(raw.channel || ""),
    mode: safeString(raw.mode),
    lastUpdatedAt: toNumberOrNull(raw.lastUpdatedAt) ?? undefined,
    canonicalNotificationId: safeString(raw.canonicalNotificationId),
    legacyRequestId: safeString(raw.legacyRequestId),
    approvalRequired: toBoolean(raw.approvalRequired) === true,
    approvedAt: toNumberOrNull(raw.approvedAt),
    rejectedAt: toNumberOrNull(raw.rejectedAt),
    executedAt: toNumberOrNull(raw.executedAt),
    acknowledgedAt: toNumberOrNull(raw.acknowledgedAt),
    failedAt: toNumberOrNull(raw.failedAt),
    closedAt: toNumberOrNull(raw.closedAt),
    acknowledgedBy: safeString(raw.acknowledgedBy),
  };
}

function copyOptionalTimestampUpdate(
  updates: Record<string, unknown>,
  path: string,
  value: unknown
): void {
  const ts = toNumberOrNull(value);
  if (ts != null && ts > 0) {
    updates[path] = ts;
  }
}

function normalizeAuthorityType(value: unknown): string {
  const normalized = normalizeEnumText(value);
  if (!normalized) return "";
  if (normalized === "FIRE_DEPARTMENT") return "FIRE_BRIGADE";
  return normalized;
}

function normalizeSeverity(
  value: unknown
): "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | null {
  const normalized = normalizeEnumText(value);
  if (
    normalized === "LOW" ||
    normalized === "MEDIUM" ||
    normalized === "HIGH" ||
    normalized === "CRITICAL"
  ) {
    return normalized;
  }
  return null;
}

function normalizeEnumText(value: unknown): string {
  return String(value ?? "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function safeKeyPart(value: unknown): string {
  return safeString(value).replace(/[.#$/\[\]\s]+/g, "_");
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}