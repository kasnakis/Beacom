import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RuntimeStep = {
  id?: string;
  type?: string;
  title?: string;
  description?: string;
  enabled?: boolean;
  status?: string;
  createdAt?: number;
  startedAt?: number | null;
  completedAt?: number | null;
  executionMode?: string;
  executionResult?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  targetRoles?: string[];
  team?: string;
  mode?: string;
  targets?: string[];
};

type RuntimePlaybook = {
  id?: string;
  title?: string;
  description?: string;
  priority?: number;
  status?: string;
  activatedAt?: number;
  lastEvaluatedAt?: number;
  trigger?: Record<string, unknown>;
  steps?: Record<string, RuntimeStep>;
};

type ExecutionRuntime = {
  schemaVersion?: number;
  category?: string;
  overallRisk?: string;
  updatedAt?: number;
  playbooks?: Record<string, RuntimePlaybook>;
  status?: string;
};

type IncidentLike = Record<string, any>;

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "executeEvacuationSteps";

export const executeEvacuationSteps = onValueWritten(
  {
    ref: "/incidents/{incidentId}/incident_playbook_execution",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    if (!event.data.after.exists()) {
      logger.info("Evacuation executor skipped - runtime removed", {
        incidentId,
      });
      return;
    }

    const runtime = sanitizeExecutionRuntime(event.data.after.val() || {});
    if (normalizeEnumText(runtime.status || "") === "CLOSED") {
      logger.info("Evacuation executor skipped - playbook execution already closed", {
        incidentId,
      });
      return;
    }

    const incidentSnap = await db.ref(`incidents/${incidentId}`).get();
    if (!incidentSnap.exists()) {
      logger.warn("Evacuation executor skipped - incident missing", {
        incidentId,
      });
      return;
    }

    const incident = (incidentSnap.val() || {}) as IncidentLike;
    const siteId = safeString(incident.siteId ?? incident.site ?? "");

    if (!siteId) {
      logger.warn("Evacuation executor skipped - missing siteId", {
        incidentId,
      });
      return;
    }

    const incidentStatus = normalizeEnumText(incident.status || "");
    const incidentActive = toBoolean(incident.active) === true;
    if (!incidentActive || incidentStatus === "DEACTIVATED" || incidentStatus === "CLOSED") {
      logger.info("Evacuation executor skipped - incident not operational", {
        incidentId,
        siteId,
        incidentStatus,
        incidentActive,
      });
      return;
    }

    const actions = resolveEvacuationActions(runtime);

    if (actions.length === 0) {
      logger.info("Evacuation executor skipped - no evacuation steps", {
        incidentId,
        siteId,
      });
      return;
    }

    const evacuationStateSnap = await db
      .ref(`incidents/${incidentId}/evacuation_state`)
      .get();

    const existingState = evacuationStateSnap.exists()
      ? (evacuationStateSnap.val() as Record<string, unknown>)
      : {};

    const updates: Record<string, unknown> = {};
    const eventWrites: Array<Promise<void>> = [];
    const now = Date.now();

    for (const action of actions) {
      const currentStateStatus = normalizeEnumText(existingState["status"] || "");
      const currentStateActive = toBoolean(existingState["active"]) === true;

      if (action.kind === "PREPARE") {
        const alreadyPrepared =
          currentStateStatus === "PREPARING" || currentStateStatus === "ACTIVE";

        if (!alreadyPrepared) {
          updates[`incidents/${incidentId}/evacuation_state/active`] = true;
          updates[`incidents/${incidentId}/evacuation_state/status`] = "PREPARING";
          updates[`incidents/${incidentId}/evacuation_state/mode`] = action.mode;
          updates[`incidents/${incidentId}/evacuation_state/triggeredBy`] = "PLAYBOOK";
          updates[`incidents/${incidentId}/evacuation_state/triggeredAt`] = now;
          updates[`incidents/${incidentId}/evacuation_state/preparedAt`] = now;
          updates[`incidents/${incidentId}/evacuation_state/assemblyPointsReady`] = false;
          updates[`incidents/${incidentId}/evacuation_state/evacuationStarted`] = false;
          updates[`incidents/${incidentId}/evacuation_state/sourcePlaybookId`] =
            action.playbookId;
          updates[`incidents/${incidentId}/evacuation_state/sourceStepId`] = action.stepId;

          updates[
            `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/evacuationStateStatus`
          ] = "PREPARING";

          eventWrites.push(
            pushIncidentEvent(db, incidentId, siteId, "EVACUATION_PREPARED", {
              playbookId: action.playbookId,
              playbookTitle: action.playbookTitle,
              stepId: action.stepId,
              stepTitle: action.stepTitle,
              mode: action.mode,
              status: "PREPARING",
            })
          );
        }

        continue;
      }

      if (action.kind === "START") {
        const alreadyActive = currentStateStatus === "ACTIVE" && currentStateActive === true;
        const startedAtExisting = toNumberOrNull(existingState["startedAt"]);
        const eventAlreadyRepresented = alreadyActive || startedAtExisting != null;

        if (!eventAlreadyRepresented) {
          updates[`incidents/${incidentId}/evacuation_state/active`] = true;
          updates[`incidents/${incidentId}/evacuation_state/status`] = "ACTIVE";
          updates[`incidents/${incidentId}/evacuation_state/mode`] = action.mode;
          updates[`incidents/${incidentId}/evacuation_state/triggeredBy`] = "PLAYBOOK";
          updates[`incidents/${incidentId}/evacuation_state/triggeredAt`] =
            toNumber(existingState["triggeredAt"], now);
          updates[`incidents/${incidentId}/evacuation_state/preparedAt`] =
            toNumber(existingState["preparedAt"], now);
          updates[`incidents/${incidentId}/evacuation_state/startedAt`] = now;
          updates[`incidents/${incidentId}/evacuation_state/assemblyPointsReady`] = true;
          updates[`incidents/${incidentId}/evacuation_state/evacuationStarted`] = true;
          updates[`incidents/${incidentId}/evacuation_state/sourcePlaybookId`] =
            action.playbookId;
          updates[`incidents/${incidentId}/evacuation_state/sourceStepId`] = action.stepId;

          updates[
            `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/evacuationStateStatus`
          ] = "ACTIVE";

          eventWrites.push(
            pushIncidentEvent(db, incidentId, siteId, "EVACUATION_STARTED", {
              playbookId: action.playbookId,
              playbookTitle: action.playbookTitle,
              stepId: action.stepId,
              stepTitle: action.stepTitle,
              mode: action.mode,
              status: "ACTIVE",
            })
          );
        } else {
          const needsBackfillStatus =
            safeString(
              (runtime.playbooks?.[action.playbookId]?.steps?.[action.stepId]
                ?.executionResult as Record<string, unknown> | undefined)
                ?.evacuationStateStatus
            ) !== "ACTIVE";

          if (needsBackfillStatus) {
            updates[
              `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/evacuationStateStatus`
            ] = "ACTIVE";
          }
        }
      }
    }

    if (Object.keys(updates).length === 0) {
      logger.info("Evacuation executor skipped - state already aligned", {
        incidentId,
        siteId,
      });
      return;
    }

    await db.ref().update(updates);
    await Promise.all(eventWrites);

    logger.info("Evacuation executor completed", {
      incidentId,
      siteId,
      updateKeys: Object.keys(updates).length,
    });
  }
);

function resolveEvacuationActions(runtime: ExecutionRuntime): Array<{
  kind: "PREPARE" | "START";
  playbookId: string;
  playbookTitle: string;
  stepId: string;
  stepTitle: string;
  mode: string;
}> {
  const actions: Array<{
    kind: "PREPARE" | "START";
    playbookId: string;
    playbookTitle: string;
    stepId: string;
    stepTitle: string;
    mode: string;
  }> = [];

  const playbooks = runtime.playbooks || {};

  Object.entries(playbooks).forEach(([playbookId, playbookRaw]) => {
    const playbook = playbookRaw as RuntimePlaybook;
    if (normalizeEnumText(playbook.status || "") === "CLOSED") return;

    const playbookTitle = safeString(playbook.title || playbookId);
    const steps = playbook.steps || {};

    Object.entries(steps).forEach(([stepId, stepRaw]) => {
      const step = stepRaw as RuntimeStep;

      if (step.enabled === false) return;
      if (normalizeEnumText(step.status || "") !== "IN_PROGRESS") return;

      const stepType = normalizeEnumText(step.type || "");
      const stepTitle = safeString(step.title || stepId);
      const mode = safeString(step.mode || "PARTIAL") || "PARTIAL";

      if (stepType === "PREPARE_EVACUATION") {
        const existingStatus = safeString(
          (step.executionResult as Record<string, unknown> | undefined)
            ?.evacuationStateStatus
        );

        if (normalizeEnumText(existingStatus) === "PREPARING") return;

        actions.push({
          kind: "PREPARE",
          playbookId,
          playbookTitle,
          stepId,
          stepTitle,
          mode,
        });
        return;
      }

      if (stepType === "EVACUATION") {
        const existingStatus = safeString(
          (step.executionResult as Record<string, unknown> | undefined)
            ?.evacuationStateStatus
        );

        if (normalizeEnumText(existingStatus) === "ACTIVE") return;

        actions.push({
          kind: "START",
          playbookId,
          playbookTitle,
          stepId,
          stepTitle,
          mode,
        });
      }
    });
  });

  return actions;
}

function sanitizeExecutionRuntime(value: unknown): ExecutionRuntime {
  const runtime = (value || {}) as ExecutionRuntime;
  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object" ? runtime.playbooks : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput).forEach(([playbookId, playbookRaw]) => {
    const playbook = (playbookRaw || {}) as RuntimePlaybook;
    const stepsInput =
      playbook.steps && typeof playbook.steps === "object" ? playbook.steps : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as RuntimeStep;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title || stepId),
        description: safeString(step.description),
        enabled: step.enabled !== false,
        status: normalizeEnumText(step.status || "PENDING"),
        createdAt: toNumber(step.createdAt, 0),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
        executionMode: safeString(step.executionMode),
        executionResult:
          step.executionResult && typeof step.executionResult === "object"
            ? step.executionResult
            : {},
        metadata: step.metadata && typeof step.metadata === "object" ? step.metadata : {},
        targetRoles: Array.isArray(step.targetRoles)
          ? step.targetRoles.map((x) => safeString(x)).filter(Boolean)
          : [],
        team: safeString(step.team),
        mode: safeString(step.mode),
        targets: Array.isArray(step.targets)
          ? step.targets.map((x) => safeString(x)).filter(Boolean)
          : [],
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title || playbookId),
      description: safeString(playbook.description),
      priority: toNumber(playbook.priority, 100),
      status: safeString(playbook.status || "ACTIVE"),
      activatedAt: toNumber(playbook.activatedAt, 0),
      lastEvaluatedAt: toNumber(playbook.lastEvaluatedAt, 0),
      trigger: playbook.trigger && typeof playbook.trigger === "object" ? playbook.trigger : {},
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    status: normalizeEnumText(runtime.status || ""),
    playbooks: sanitizedPlaybooks,
  };
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function normalizeEnumText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}