import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type ExternalNotificationRecord = {
  id?: string;
  incidentId?: string;
  siteId?: string;
  category?: string;
  authorityType?: string;
  authorityId?: string;
  authorityName?: string;
  channel?: string;
  mode?: string;
  playbookId?: string;
  playbookTitle?: string;
  stepId?: string;
  stepTitle?: string;
  legacyRequestId?: string;
  status?: string;
  createdAt?: number | null;
  updatedAt?: number | null;
  closedAt?: number | null;
  closedBy?: string;
  notes?: string;
  requestedByUserId?: string;
  requestedByName?: string;
  requestedByRole?: string;
  targets?: Record<string, boolean>;
  approval?: {
    required?: boolean;
    status?: string;
    approvedByUserId?: string | null;
    approvedByName?: string | null;
    approvedByRole?: string | null;
    approvedAt?: number | null;
    decisionAt?: number | null;
    decisionByUserId?: string | null;
    decisionByName?: string | null;
    decisionByRole?: string | null;
    rejectedAt?: number | null;
    rejectedByUserId?: string | null;
    rejectedByName?: string | null;
    rejectedByRole?: string | null;
    rejectionReason?: string | null;
  };
  execution?: {
    status?: string;
    executedByUserId?: string | null;
    executedByName?: string | null;
    executedAt?: number | null;
    resultNotes?: string | null;
  };
  acknowledgement?: {
    status?: string;
    receivedAt?: number | null;
    receivedBy?: string | null;
    notes?: string | null;
  };
};

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "syncExternalNotificationLifecycle";
const STEP_COMPLETION_TRIGGER_STATUSES = new Set(["ACKNOWLEDGED", "SENT"]);
const TERMINAL_STEP_STATUSES = new Set([
  "COMPLETED",
  "CLOSED",
  "CANCELLED",
  "COMPLETED_BY_INCIDENT_CLOSURE",
]);

export const syncExternalNotificationLifecycle = onValueWritten(
  {
    ref: "/external_notifications/{notificationId}",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const notificationId = event.params.notificationId;
    const db = admin.database();

    if (!event.data.after.exists()) {
      logger.info("External notification lifecycle sync skipped - notification deleted", {
        notificationId,
      });
      return;
    }

    const beforeValue = event.data.before.exists()
      ? sanitizeExternalNotification(event.data.before.val() || {})
      : null;

    const afterValue = sanitizeExternalNotification(event.data.after.val() || {});

    const incidentId = safeString(afterValue.incidentId);
    const siteId = safeString(afterValue.siteId);
    const playbookId = safeString(afterValue.playbookId);
    const stepId = safeString(afterValue.stepId);
    const legacyRequestId = safeString(afterValue.legacyRequestId);

    if (!incidentId || !siteId) {
      logger.warn("External notification lifecycle sync skipped - missing incident/site", {
        notificationId,
        incidentId,
        siteId,
      });
      return;
    }

    const beforeStatus = normalizeEnumText(beforeValue?.status || "");
    const afterStatus = normalizeEnumText(afterValue.status || "");

    if (!afterStatus) {
      logger.info("External notification lifecycle sync skipped - empty status", {
        notificationId,
        incidentId,
      });
      return;
    }

    if (beforeStatus === afterStatus) {
      logger.info("External notification lifecycle sync skipped - no status change", {
        notificationId,
        incidentId,
        beforeStatus,
        afterStatus,
      });
      return;
    }

    if (!isAllowedLifecycleTransition(beforeStatus, afterStatus)) {
      logger.warn("External notification lifecycle sync skipped - invalid status transition", {
        notificationId,
        incidentId,
        beforeStatus,
        afterStatus,
      });
      return;
    }

    const now = Date.now();
    const updates: Record<string, unknown> = {};
    const eventWrites: Array<Promise<void>> = [];

    updates[`external_notifications/${notificationId}/updatedAt`] = now;

    const authoritySummaryKey = normalizeAuthorityType(
      afterValue.authorityType || afterValue.authorityId || "UNKNOWN"
    );
    const incidentAuthorityBase =
      `incidents/${incidentId}/externalAuthorities/${authoritySummaryKey || "UNKNOWN"}`;

    // ------------------------------------------------------------------
    // Incident summary projection
    // ------------------------------------------------------------------
    updates[`${incidentAuthorityBase}/required`] = true;
    updates[`${incidentAuthorityBase}/requested`] = true;
    updates[`${incidentAuthorityBase}/displayName`] =
      safeString(afterValue.authorityName) || authoritySummaryKey || "UNKNOWN";
    updates[`${incidentAuthorityBase}/authorityType`] = authoritySummaryKey || "";
    updates[`${incidentAuthorityBase}/status`] = afterStatus;
    updates[`${incidentAuthorityBase}/channel`] = safeString(afterValue.channel);
    updates[`${incidentAuthorityBase}/mode`] = safeString(afterValue.mode);
    updates[`${incidentAuthorityBase}/lastUpdatedAt`] = now;
    updates[`${incidentAuthorityBase}/canonicalNotificationId`] = notificationId;
    updates[`${incidentAuthorityBase}/legacyRequestId`] = legacyRequestId;
    updates[`${incidentAuthorityBase}/approvalRequired`] =
      toBoolean(afterValue.approval?.required) === true;

    // ------------------------------------------------------------------
    // Compatibility mirror to legacy-style request nodes
    // ------------------------------------------------------------------
    if (legacyRequestId) {
      const incidentLegacyBase = `incidents/${incidentId}/external_notification_requests/${legacyRequestId}`;
      const topLevelLegacyBase = `external_notification_requests/${legacyRequestId}`;

      updates[`${incidentLegacyBase}/status`] = mapCanonicalStatusToLegacy(afterStatus);
      updates[`${incidentLegacyBase}/updatedAt`] = now;

      updates[`${topLevelLegacyBase}/status`] = mapCanonicalStatusToLegacy(afterStatus);
      updates[`${topLevelLegacyBase}/updatedAt`] = now;

      if (afterStatus === "CANCELLED" || afterStatus === "CLOSED") {
        const closedAt = coalesceNumber(afterValue.closedAt, now);
        const closedBy = safeString(afterValue.closedBy) || FUNCTION_NAME;

        updates[`${incidentLegacyBase}/closedAt`] = closedAt;
        updates[`${incidentLegacyBase}/closedBy`] = closedBy;

        updates[`${topLevelLegacyBase}/closedAt`] = closedAt;
        updates[`${topLevelLegacyBase}/closedBy`] = closedBy;
      }

      if (afterStatus === "APPROVED") {
        const approvedAt = safeApprovalTime(
          afterValue.approval?.approvedAt || afterValue.approval?.decisionAt,
          now
        );
        const approvedBy =
          safeString(afterValue.approval?.approvedByName) ||
          safeString(afterValue.approval?.decisionByName) ||
          FUNCTION_NAME;

        updates[`${incidentLegacyBase}/approvedAt`] = approvedAt;
        updates[`${incidentLegacyBase}/approvedBy`] = approvedBy;
        updates[`${topLevelLegacyBase}/approvedAt`] = approvedAt;
        updates[`${topLevelLegacyBase}/approvedBy`] = approvedBy;
      }

      if (afterStatus === "REJECTED") {
        const rejectedAt = safeRejectedTime(
          afterValue.approval?.rejectedAt || afterValue.approval?.decisionAt,
          now
        );
        const rejectedBy =
          safeString(afterValue.approval?.rejectedByName) ||
          safeString(afterValue.approval?.decisionByName) ||
          FUNCTION_NAME;
        const rejectionReason = safeString(afterValue.approval?.rejectionReason);

        updates[`${incidentLegacyBase}/rejectedAt`] = rejectedAt;
        updates[`${incidentLegacyBase}/rejectedBy`] = rejectedBy;
        updates[`${incidentLegacyBase}/rejectionReason`] = rejectionReason;

        updates[`${topLevelLegacyBase}/rejectedAt`] = rejectedAt;
        updates[`${topLevelLegacyBase}/rejectedBy`] = rejectedBy;
        updates[`${topLevelLegacyBase}/rejectionReason`] = rejectionReason;
      }

      if (afterStatus === "SENT") {
        const executedAt = safeExecutionTime(afterValue.execution?.executedAt, now);
        const executedBy = safeString(afterValue.execution?.executedByName) || FUNCTION_NAME;

        updates[`${incidentLegacyBase}/executedAt`] = executedAt;
        updates[`${incidentLegacyBase}/executedBy`] = executedBy;

        updates[`${topLevelLegacyBase}/executedAt`] = executedAt;
        updates[`${topLevelLegacyBase}/executedBy`] = executedBy;
      }

      if (afterStatus === "ACKNOWLEDGED") {
        const acknowledgedAt = safeAckTime(afterValue.acknowledgement?.receivedAt, now);
        const acknowledgedBy = safeString(afterValue.acknowledgement?.receivedBy);

        updates[`${incidentLegacyBase}/acknowledgedAt`] = acknowledgedAt;
        updates[`${incidentLegacyBase}/acknowledgedBy`] = acknowledgedBy;

        updates[`${topLevelLegacyBase}/acknowledgedAt`] = acknowledgedAt;
        updates[`${topLevelLegacyBase}/acknowledgedBy`] = acknowledgedBy;
      }

      if (afterStatus === "FAILED") {
        const failureNotes = safeString(afterValue.execution?.resultNotes || afterValue.notes);

        updates[`${incidentLegacyBase}/failedAt`] = now;
        updates[`${incidentLegacyBase}/failureNotes`] = failureNotes;

        updates[`${topLevelLegacyBase}/failedAt`] = now;
        updates[`${topLevelLegacyBase}/failureNotes`] = failureNotes;
      }
    }

    // ------------------------------------------------------------------
    // Playbook runtime sync
    // ------------------------------------------------------------------
    if (playbookId && stepId) {
      const stepBase =
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/steps/${stepId}`;
      const runtimeResultBase = `${stepBase}/executionResult`;

      updates[`${runtimeResultBase}/canonicalNotificationId`] = notificationId;
      if (legacyRequestId) {
        updates[`${runtimeResultBase}/externalRequestId`] = legacyRequestId;
      }
      updates[`${runtimeResultBase}/externalRequestStatus`] = afterStatus;
      updates[`${runtimeResultBase}/lastLifecycleSyncAt`] = now;
      updates[`${runtimeResultBase}/lastLifecycleSyncBy`] = FUNCTION_NAME;

      if (afterStatus === "APPROVED") {
        updates[`${runtimeResultBase}/approvedAt`] = safeApprovalTime(
          afterValue.approval?.approvedAt || afterValue.approval?.decisionAt,
          now
        );
      }

      if (afterStatus === "SENT") {
        updates[`${runtimeResultBase}/sentAt`] = safeExecutionTime(
          afterValue.execution?.executedAt,
          now
        );
      }

      if (afterStatus === "ACKNOWLEDGED") {
        updates[`${runtimeResultBase}/acknowledgedAt`] = safeAckTime(
          afterValue.acknowledgement?.receivedAt,
          now
        );
      }

      if (afterStatus === "FAILED") {
        updates[`${runtimeResultBase}/failedAt`] = now;
      }

      if (afterStatus === "REJECTED") {
        updates[`${runtimeResultBase}/rejectedAt`] = safeRejectedTime(
          afterValue.approval?.rejectedAt || afterValue.approval?.decisionAt,
          now
        );
        updates[`${runtimeResultBase}/rejectionReason`] = safeString(
          afterValue.approval?.rejectionReason
        );
      }

      if (afterStatus === "CANCELLED" || afterStatus === "CLOSED") {
        updates[`${runtimeResultBase}/closedAt`] = coalesceNumber(afterValue.closedAt, now);
      }

      if (STEP_COMPLETION_TRIGGER_STATUSES.has(afterStatus)) {
        const stepStatusSnap = await db.ref(`${stepBase}/status`).get();
        const currentStepStatus = normalizeEnumText(stepStatusSnap.val() || "");

        if (!TERMINAL_STEP_STATUSES.has(currentStepStatus)) {
          const completedAt =
            afterStatus === "ACKNOWLEDGED"
              ? safeAckTime(afterValue.acknowledgement?.receivedAt, now)
              : safeExecutionTime(afterValue.execution?.executedAt, now);

          updates[`${stepBase}/status`] = "COMPLETED";
          updates[`${stepBase}/completedAt`] = completedAt;
          updates[`${runtimeResultBase}/completedBy`] = FUNCTION_NAME;
          updates[`${runtimeResultBase}/completionReason`] =
            afterStatus === "ACKNOWLEDGED"
              ? "EXTERNAL_NOTIFICATION_ACKNOWLEDGED"
              : "EXTERNAL_NOTIFICATION_SENT";

          eventWrites.push(
            pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_STEP_COMPLETED", {
              playbookId,
              playbookTitle: safeString(afterValue.playbookTitle),
              stepId,
              stepTitle: safeString(afterValue.stepTitle),
              stepType: "EXTERNAL_NOTIFICATION",
              previousStatus: currentStepStatus || "IN_PROGRESS",
              newStatus: "COMPLETED",
              completionTriggerStatus: afterStatus,
              canonicalNotificationId: notificationId,
              legacyRequestId,
            })
          );
        }
      }
    }

    // ------------------------------------------------------------------
    // Canonical node normalization
    // ------------------------------------------------------------------
    if (
      (afterStatus === "CANCELLED" || afterStatus === "CLOSED") &&
      !toFiniteNumberOrNull(afterValue.closedAt)
    ) {
      updates[`external_notifications/${notificationId}/closedAt`] = now;
      updates[`external_notifications/${notificationId}/closedBy`] =
        safeString(afterValue.closedBy) || FUNCTION_NAME;
    }

    if (
      afterStatus === "APPROVED" &&
      normalizeEnumText(afterValue.approval?.status || "") !== "APPROVED"
    ) {
      updates[`external_notifications/${notificationId}/approval/status`] = "APPROVED";
      updates[`external_notifications/${notificationId}/approval/approvedAt`] =
        safeApprovalTime(afterValue.approval?.approvedAt || afterValue.approval?.decisionAt, now);
      updates[`external_notifications/${notificationId}/approval/decisionAt`] =
        safeApprovalTime(afterValue.approval?.decisionAt || afterValue.approval?.approvedAt, now);
    }

    if (
      afterStatus === "REJECTED" &&
      normalizeEnumText(afterValue.approval?.status || "") !== "REJECTED"
    ) {
      updates[`external_notifications/${notificationId}/approval/status`] = "REJECTED";
      updates[`external_notifications/${notificationId}/approval/rejectedAt`] =
        safeRejectedTime(afterValue.approval?.rejectedAt || afterValue.approval?.decisionAt, now);
      updates[`external_notifications/${notificationId}/approval/decisionAt`] =
        safeRejectedTime(afterValue.approval?.decisionAt || afterValue.approval?.rejectedAt, now);
    }

    if (
      afterStatus === "SENT" &&
      normalizeEnumText(afterValue.execution?.status || "") !== "SENT"
    ) {
      updates[`external_notifications/${notificationId}/execution/status`] = "SENT";
      updates[`external_notifications/${notificationId}/execution/executedAt`] =
        safeExecutionTime(afterValue.execution?.executedAt, now);
    }

    if (
      afterStatus === "FAILED" &&
      normalizeEnumText(afterValue.execution?.status || "") !== "FAILED"
    ) {
      updates[`external_notifications/${notificationId}/execution/status`] = "FAILED";
    }

    if (
      afterStatus === "ACKNOWLEDGED" &&
      normalizeEnumText(afterValue.acknowledgement?.status || "") !== "ACKNOWLEDGED"
    ) {
      updates[`external_notifications/${notificationId}/acknowledgement/status`] = "ACKNOWLEDGED";
      updates[`external_notifications/${notificationId}/acknowledgement/receivedAt`] =
        safeAckTime(afterValue.acknowledgement?.receivedAt, now);
    }

    // ------------------------------------------------------------------
    // Extra incident summary lifecycle fields
    // ------------------------------------------------------------------
    if (afterStatus === "APPROVED") {
      updates[`${incidentAuthorityBase}/approvedAt`] = safeApprovalTime(
        afterValue.approval?.approvedAt || afterValue.approval?.decisionAt,
        now
      );
      updates[`${incidentAuthorityBase}/approvedByName`] =
        safeString(afterValue.approval?.approvedByName) ||
        safeString(afterValue.approval?.decisionByName);
    }

    if (afterStatus === "REJECTED") {
      updates[`${incidentAuthorityBase}/rejectedAt`] = safeRejectedTime(
        afterValue.approval?.rejectedAt || afterValue.approval?.decisionAt,
        now
      );
      updates[`${incidentAuthorityBase}/rejectedByName`] =
        safeString(afterValue.approval?.rejectedByName) ||
        safeString(afterValue.approval?.decisionByName);
      updates[`${incidentAuthorityBase}/rejectionReason`] = safeString(
        afterValue.approval?.rejectionReason
      );
    }

    if (afterStatus === "SENT") {
      updates[`${incidentAuthorityBase}/executedAt`] = safeExecutionTime(
        afterValue.execution?.executedAt,
        now
      );
      updates[`${incidentAuthorityBase}/executedByName`] = safeString(
        afterValue.execution?.executedByName
      );
      updates[`${incidentAuthorityBase}/resultNotes`] = safeString(
        afterValue.execution?.resultNotes
      );
    }

    if (afterStatus === "ACKNOWLEDGED") {
      updates[`${incidentAuthorityBase}/acknowledgedAt`] = safeAckTime(
        afterValue.acknowledgement?.receivedAt,
        now
      );
      updates[`${incidentAuthorityBase}/acknowledgedBy`] = safeString(
        afterValue.acknowledgement?.receivedBy
      );
      updates[`${incidentAuthorityBase}/acknowledgementStatus`] = "ACKNOWLEDGED";
    }

    if (afterStatus === "FAILED") {
      updates[`${incidentAuthorityBase}/failedAt`] = now;
      updates[`${incidentAuthorityBase}/resultNotes`] = safeString(
        afterValue.execution?.resultNotes || afterValue.notes
      );
    }

    if (afterStatus === "CANCELLED" || afterStatus === "CLOSED") {
      updates[`${incidentAuthorityBase}/closedAt`] = coalesceNumber(afterValue.closedAt, now);
      updates[`${incidentAuthorityBase}/closedBy`] =
        safeString(afterValue.closedBy) || FUNCTION_NAME;
    }

    // ------------------------------------------------------------------
    // Canonical lifecycle eventing
    // Keep only terminal cleanup events here to avoid duplicate APPROVED/SENT logs.
    // REQUESTED is emitted on creation, APPROVED/SENT/ACK are emitted by action flows.
    // ------------------------------------------------------------------
    const eventType = mapCanonicalStatusToIncidentEvent(afterStatus);
    const shouldEmitLifecycleEvent =
      eventType === "EXTERNAL_NOTIFICATION_CANCELLED" ||
      eventType === "EXTERNAL_NOTIFICATION_CLOSED" ||
      eventType === "EXTERNAL_NOTIFICATION_REJECTED" ||
      eventType === "EXTERNAL_NOTIFICATION_FAILED";

    if (eventType && shouldEmitLifecycleEvent) {
      eventWrites.push(
        pushIncidentEvent(db, incidentId, siteId, eventType, {
          canonicalNotificationId: notificationId,
          legacyRequestId,
          authorityType: safeString(afterValue.authorityType),
          authorityId: safeString(afterValue.authorityId),
          authorityName: safeString(afterValue.authorityName),
          channel: safeString(afterValue.channel),
          playbookId,
          playbookTitle: safeString(afterValue.playbookTitle),
          stepId,
          stepTitle: safeString(afterValue.stepTitle),
          previousStatus: beforeStatus,
          newStatus: afterStatus,
          approvalRequired: toBoolean(afterValue.approval?.required) === true,
          approvalStatus: normalizeEnumText(afterValue.approval?.status || ""),
          executionStatus: normalizeEnumText(afterValue.execution?.status || ""),
          acknowledgementStatus: normalizeEnumText(
            afterValue.acknowledgement?.status || ""
          ),
          notes: safeString(afterValue.notes),
          resultNotes: safeString(afterValue.execution?.resultNotes),
          rejectionReason: safeString(afterValue.approval?.rejectionReason),
        })
      );
    }
    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
    }

    if (eventWrites.length > 0) {
      await Promise.all(eventWrites);
    }

    logger.info("External notification lifecycle sync completed", {
      notificationId,
      incidentId,
      siteId,
      beforeStatus,
      afterStatus,
      legacyRequestId,
      stepCompletionSynced:
        playbookId && stepId && STEP_COMPLETION_TRIGGER_STATUSES.has(afterStatus),
    });
  }
);

function sanitizeExternalNotification(value: unknown): ExternalNotificationRecord {
  const raw = (value || {}) as ExternalNotificationRecord;

  return {
    id: safeString(raw.id),
    incidentId: safeString(raw.incidentId),
    siteId: safeString(raw.siteId),
    category: safeString(raw.category),
    authorityType: normalizeEnumText(raw.authorityType || ""),
    authorityId: safeString(raw.authorityId),
    authorityName: safeString(raw.authorityName),
    channel: normalizeEnumText(raw.channel || ""),
    mode: safeString(raw.mode),
    playbookId: safeString(raw.playbookId),
    playbookTitle: safeString(raw.playbookTitle),
    stepId: safeString(raw.stepId),
    stepTitle: safeString(raw.stepTitle),
    legacyRequestId: safeString(raw.legacyRequestId),
    status: normalizeEnumText(raw.status || ""),
    createdAt: toFiniteNumberOrNull(raw.createdAt),
    updatedAt: toFiniteNumberOrNull(raw.updatedAt),
    closedAt: toFiniteNumberOrNull(raw.closedAt),
    closedBy: safeString(raw.closedBy),
    notes: safeString(raw.notes),
    requestedByUserId: safeString(raw.requestedByUserId),
    requestedByName: safeString(raw.requestedByName),
    requestedByRole: safeString(raw.requestedByRole),
    targets:
      raw.targets && typeof raw.targets === "object"
        ? (raw.targets as Record<string, boolean>)
        : {},
    approval: {
      required: toBoolean(raw.approval?.required) ?? false,
      status: normalizeEnumText(raw.approval?.status || ""),
      approvedByUserId: nullableString(raw.approval?.approvedByUserId),
      approvedByName: nullableString(raw.approval?.approvedByName),
      approvedByRole: nullableString(raw.approval?.approvedByRole),
      approvedAt: toFiniteNumberOrNull(raw.approval?.approvedAt),
      decisionAt: toFiniteNumberOrNull(raw.approval?.decisionAt),
      decisionByUserId: nullableString(raw.approval?.decisionByUserId),
      decisionByName: nullableString(raw.approval?.decisionByName),
      decisionByRole: nullableString(raw.approval?.decisionByRole),
      rejectedAt: toFiniteNumberOrNull(raw.approval?.rejectedAt),
      rejectedByUserId: nullableString(raw.approval?.rejectedByUserId),
      rejectedByName: nullableString(raw.approval?.rejectedByName),
      rejectedByRole: nullableString(raw.approval?.rejectedByRole),
      rejectionReason: nullableString(raw.approval?.rejectionReason),
    },
    execution: {
      status: normalizeEnumText(raw.execution?.status || ""),
      executedByUserId: nullableString(raw.execution?.executedByUserId),
      executedByName: nullableString(raw.execution?.executedByName),
      executedAt: toFiniteNumberOrNull(raw.execution?.executedAt),
      resultNotes: nullableString(raw.execution?.resultNotes),
    },
    acknowledgement: {
      status: normalizeEnumText(raw.acknowledgement?.status || ""),
      receivedAt: toFiniteNumberOrNull(raw.acknowledgement?.receivedAt),
      receivedBy: nullableString(raw.acknowledgement?.receivedBy),
      notes: nullableString(raw.acknowledgement?.notes),
    },
  };
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function mapCanonicalStatusToLegacy(status: string): string {
  switch (status) {
    case "APPROVED":
      return "APPROVED";
    case "REJECTED":
      return "REJECTED";
    case "SENT":
      return "SENT";
    case "ACKNOWLEDGED":
      return "ACKNOWLEDGED";
    case "FAILED":
      return "FAILED";
    case "CANCELLED":
      return "CANCELLED";
    case "CLOSED":
      return "CLOSED";
    default:
      return status || "REQUESTED";
  }
}

function mapCanonicalStatusToIncidentEvent(status: string): string {
  switch (status) {
    case "APPROVED":
      return "EXTERNAL_NOTIFICATION_APPROVED";
    case "REJECTED":
      return "EXTERNAL_NOTIFICATION_REJECTED";
    case "SENT":
      return "EXTERNAL_NOTIFICATION_SENT";
    case "ACKNOWLEDGED":
      return "EXTERNAL_NOTIFICATION_ACK";
    case "FAILED":
      return "EXTERNAL_NOTIFICATION_FAILED";
    case "CANCELLED":
      return "EXTERNAL_NOTIFICATION_CANCELLED";
    case "CLOSED":
      return "EXTERNAL_NOTIFICATION_CLOSED";
    default:
      return "";
  }
}

function isAllowedLifecycleTransition(previousStatus: string, nextStatus: string): boolean {
  if (!previousStatus) return true;
  if (previousStatus === nextStatus) return true;

  const allowedTransitions: Record<string, Set<string>> = {
    REQUESTED: new Set(["APPROVED", "REJECTED", "SENT", "FAILED", "CANCELLED", "CLOSED"]),
    APPROVED: new Set(["SENT", "FAILED", "CANCELLED", "CLOSED"]),
    SENT: new Set(["ACKNOWLEDGED", "FAILED", "CANCELLED", "CLOSED"]),
    ACKNOWLEDGED: new Set(["CLOSED"]),
    FAILED: new Set(["SENT", "CANCELLED", "CLOSED"]),
    REJECTED: new Set(["CLOSED"]),
    CANCELLED: new Set(),
    CLOSED: new Set(),
  };

  return allowedTransitions[previousStatus]?.has(nextStatus) ?? false;
}

function normalizeAuthorityType(value: unknown): string {
  const normalized = normalizeEnumText(value);
  if (!normalized) return "";
  if (normalized === "FIRE_DEPARTMENT") return "FIRE_BRIGADE";
  return normalized;
}

function normalizeEnumText(value: unknown): string {
  return String(value ?? "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function nullableString(value: unknown): string | null {
  const normalized = safeString(value);
  return normalized ? normalized : null;
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toFiniteNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function coalesceNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function safeApprovalTime(value: unknown, fallback: number): number {
  return coalesceNumber(value, fallback);
}

function safeRejectedTime(value: unknown, fallback: number): number {
  return coalesceNumber(value, fallback);
}

function safeExecutionTime(value: unknown, fallback: number): number {
  return coalesceNumber(value, fallback);
}

function safeAckTime(value: unknown, fallback: number): number {
  return coalesceNumber(value, fallback);
}