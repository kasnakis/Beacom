import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

type PlaybookTrigger = {
  minRisk?: string;
  categories?: Record<string, boolean>;
  subtypes?: Record<string, boolean>;
  severities?: Record<string, boolean>;
  requiresEvacuation?: boolean;
  requiresExternalAuthorities?: boolean;
};

type PlaybookStep = {
  id?: string;
  type?: string;
  title?: string;
  description?: string;
  enabled?: boolean;
  targetRoles?: string[];
  team?: string;
  mode?: string;
  targets?: string[];
  metadata?: Record<string, unknown>;
};

type PlaybookConfig = {
  enabled?: boolean;
  title?: string;
  description?: string;
  priority?: number;
  trigger?: PlaybookTrigger;
  steps?: PlaybookStep[];
};

type IncidentLike = Record<string, any>;

type ComparableStep = {
  id: string;
  type: string;
  enabled: boolean;
};

type RuntimeStep = {
  id: string;
  type: string;
  title: string;
  description: string;
  enabled: boolean;
  status: string;
  createdAt: number;
  startedAt: number | null;
  completedAt: number | null;
  metadata: Record<string, unknown>;
  targetRoles: string[];
  team: string;
  mode: string;
  targets: string[];
};

type RuntimePlaybook = {
  id: string;
  title: string;
  description: string;
  priority: number;
  status: string;
  activatedAt: number;
  lastEvaluatedAt: number;
  trigger: Record<string, unknown>;
  steps: Record<string, RuntimeStep>;
};

type PlaybookExecutionRuntime = {
  schemaVersion: number;
  category: string;
  overallRisk: string;
  updatedAt: number;
  playbooks: Record<string, RuntimePlaybook>;
};

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "evaluateIncidentPlaybook";
const PLAYBOOK_SCHEMA_VERSION = 1;

export const evaluateIncidentPlaybook = onValueWritten(
  {
    ref: "/incidents/{incidentId}",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    const beforeExists = event.data.before.exists();
    const afterExists = event.data.after.exists();

    if (!afterExists) {
      logger.info("Playbook evaluation skipped - incident deleted", {
        incidentId,
      });
      return;
    }

    const beforeIncident = (beforeExists ? event.data.before.val() : {}) as IncidentLike;
    const afterIncident = (event.data.after.val() || {}) as IncidentLike;

    const siteId = safeSiteId(afterIncident.siteId ?? afterIncident.site ?? "");
    if (!siteId) {
      logger.warn("Playbook evaluation skipped - missing siteId", {
        incidentId,
      });
      return;
    }

    const category = normalizeEnumText(afterIncident.category ?? "");
    if (!category) {
      logger.warn("Playbook evaluation skipped - missing category", {
        incidentId,
        siteId,
      });
      return;
    }

    const overallRisk = normalizeRiskLevel(
      afterIncident.riskAssessment?.overallRisk,
      null
    );

    if (!overallRisk) {
      logger.info("Playbook evaluation skipped - risk not computed yet", {
        incidentId,
        siteId,
        category,
      });
      return;
    }

    const shouldEvaluate = resolveShouldEvaluatePlaybooks(beforeIncident, afterIncident);
    if (!shouldEvaluate) {
      logger.info("Playbook evaluation skipped - no relevant changes", {
        incidentId,
        siteId,
        category,
        overallRisk,
      });
      return;
    }

    try {
      const playbooksSnap = await db
        .ref(`site_config_data/${siteId}/playbooks/${category}`)
        .get();

      if (!playbooksSnap.exists()) {
        logger.info("Playbook evaluation skipped - no playbooks configured", {
          incidentId,
          siteId,
          category,
        });
        return;
      }

      const playbooksRaw = (playbooksSnap.val() || {}) as Record<string, PlaybookConfig>;
      const matchedPlaybooks = resolveMatchedPlaybooks({
        incident: afterIncident,
        category,
        overallRisk,
        playbooksRaw,
      });

      const previousRuntime = sanitizePlaybookExecutionRuntime(
        afterIncident.incident_playbook_execution || {}
      );

      const nextRuntime = buildNextPlaybookExecutionRuntime({
        incident: afterIncident,
        matchedPlaybooks,
        previousRuntime,
      });

      const previousComparable = comparablePlaybookRuntime(previousRuntime);
      const nextComparable = comparablePlaybookRuntime(nextRuntime);

      if (stableStringify(previousComparable) === stableStringify(nextComparable)) {
        logger.info("Playbook evaluation skipped - runtime unchanged", {
          incidentId,
          siteId,
          category,
          overallRisk,
          matchedPlaybookCount: matchedPlaybooks.length,
        });
        return;
      }

      await db
        .ref(`incidents/${incidentId}/incident_playbook_execution`)
        .set(nextRuntime);

      const previousIds = new Set(Object.keys(previousRuntime.playbooks || {}));
      const nextIds = new Set(Object.keys(nextRuntime.playbooks || {}));

      const newlyActivated = [...nextIds].filter((id) => !previousIds.has(id));

      for (const playbookId of newlyActivated) {
        const runtimePlaybook = nextRuntime.playbooks[playbookId];
        await pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_ACTIVATED", {
          playbookId,
          title: safeString(runtimePlaybook?.title),
          category,
          overallRisk,
          schemaVersion: PLAYBOOK_SCHEMA_VERSION,
          stepCount: Object.keys(runtimePlaybook?.steps || {}).length,
        });
      }

      logger.info("Playbook evaluation completed", {
        incidentId,
        siteId,
        category,
        overallRisk,
        matchedPlaybooks: matchedPlaybooks.map((p) => p.id),
      });
    } catch (error) {
      logger.error("Playbook evaluation failed", {
        incidentId,
        siteId,
        category,
        error: stringifyError(error),
      });
      throw error;
    }
  }
);

function resolveShouldEvaluatePlaybooks(
  beforeIncident: IncidentLike,
  afterIncident: IncidentLike
): boolean {
  const beforeComparable = {
    category: normalizeEnumText(beforeIncident.category ?? ""),
    subtype: normalizeEnumText(beforeIncident.subtype ?? ""),
    severity: normalizeEnumText(beforeIncident.severity ?? ""),
    active: toBoolean(beforeIncident.active) === true,
    status: normalizeEnumText(beforeIncident.status ?? ""),
    risk: normalizeEnumText(beforeIncident.riskAssessment?.overallRisk ?? ""),
    score: toNumberOrNull(beforeIncident.riskAssessment?.score),
    activation: sanitizeActivationComparable(beforeIncident.activation || {}),
  };

  const afterComparable = {
    category: normalizeEnumText(afterIncident.category ?? ""),
    subtype: normalizeEnumText(afterIncident.subtype ?? ""),
    severity: normalizeEnumText(afterIncident.severity ?? ""),
    active: toBoolean(afterIncident.active) === true,
    status: normalizeEnumText(afterIncident.status ?? ""),
    risk: normalizeEnumText(afterIncident.riskAssessment?.overallRisk ?? ""),
    score: toNumberOrNull(afterIncident.riskAssessment?.score),
    activation: sanitizeActivationComparable(afterIncident.activation || {}),
  };

  return stableStringify(beforeComparable) !== stableStringify(afterComparable);
}

function resolveMatchedPlaybooks(args: {
  incident: IncidentLike;
  category: string;
  overallRisk: RiskLevel;
  playbooksRaw: Record<string, PlaybookConfig>;
}): Array<{ id: string; config: PlaybookConfig }> {
  const { incident, category, overallRisk, playbooksRaw } = args;

  const subtype = normalizeEnumText(incident.subtype ?? "");
  const severity = normalizeEnumText(incident.severity ?? "");
  const activation = incident.activation || {};
  const evacuationRequired = toBoolean(activation.evacuationRequired) === true;
  const externalAuthoritiesRequired =
    toBoolean(activation.externalAuthoritiesRequired) === true;

  const matched: Array<{ id: string; config: PlaybookConfig }> = [];

  Object.entries(playbooksRaw).forEach(([playbookId, config]) => {
    if (!config || config.enabled === false) return;

    const trigger = config.trigger || {};

    if (!riskMeetsMinRisk(overallRisk, normalizeRiskLevel(trigger.minRisk, "LOW") || "LOW")) {
      return;
    }

    if (!matchesOptionalEnumSet(category, trigger.categories)) return;
    if (!matchesOptionalEnumSet(subtype, trigger.subtypes)) return;
    if (!matchesOptionalEnumSet(severity, trigger.severities)) return;

    if (
      typeof trigger.requiresEvacuation === "boolean" &&
      trigger.requiresEvacuation !== evacuationRequired
    ) {
      return;
    }

    if (
      typeof trigger.requiresExternalAuthorities === "boolean" &&
      trigger.requiresExternalAuthorities !== externalAuthoritiesRequired
    ) {
      return;
    }

    matched.push({ id: playbookId, config });
  });

  return matched.sort((a, b) => {
    const priorityA = toNumber(a.config.priority, 100);
    const priorityB = toNumber(b.config.priority, 100);
    if (priorityA !== priorityB) return priorityA - priorityB;
    return a.id.localeCompare(b.id);
  });
}

function buildNextPlaybookExecutionRuntime(args: {
  incident: IncidentLike;
  matchedPlaybooks: Array<{ id: string; config: PlaybookConfig }>;
  previousRuntime: PlaybookExecutionRuntime;
}): PlaybookExecutionRuntime {
  const { incident, matchedPlaybooks, previousRuntime } = args;

  const now = Date.now();
  const previousPlaybooks = previousRuntime.playbooks || {};

  const nextPlaybooks: Record<string, RuntimePlaybook> = {};

  matchedPlaybooks.forEach(({ id, config }) => {
    const previous = previousPlaybooks[id];
    const steps = sanitizeConfiguredSteps(config.steps || []);

    const nextSteps: Record<string, RuntimeStep> = {};

    steps.forEach((step) => {
      const previousStep = previous?.steps?.[step.id];

      nextSteps[step.id] = {
        id: step.id,
        type: step.type,
        title: step.title || "",
        description: step.description || "",
        enabled: step.enabled,
        status: safeString(previousStep?.status || "PENDING") || "PENDING",
        createdAt: toNumber(previousStep?.createdAt, now),
        startedAt: toNumberOrNull(previousStep?.startedAt),
        completedAt: toNumberOrNull(previousStep?.completedAt),
        metadata: step.metadata || {},
        targetRoles: step.targetRoles || [],
        team: step.team || "",
        mode: step.mode || "",
        targets: step.targets || [],
      };
    });

    nextPlaybooks[id] = {
      id,
      title: safeString(config.title || id),
      description: safeString(config.description),
      priority: toNumber(config.priority, 100),
      status: safeString(previous?.status || "ACTIVE") || "ACTIVE",
      activatedAt: toNumber(previous?.activatedAt, now),
      lastEvaluatedAt: now,
      trigger: sanitizeTriggerForRuntime(config.trigger || {}),
      steps: nextSteps,
    };
  });

  return {
    schemaVersion: PLAYBOOK_SCHEMA_VERSION,
    category: normalizeEnumText(incident.category ?? ""),
    overallRisk: normalizeEnumText(incident.riskAssessment?.overallRisk ?? ""),
    updatedAt: now,
    playbooks: nextPlaybooks,
  };
}

function sanitizeConfiguredSteps(steps: PlaybookStep[]): Array<
  Required<Pick<PlaybookStep, "id" | "type" | "enabled">> &
    Omit<PlaybookStep, "id" | "type" | "enabled">
> {
  return steps
    .map((step, index) => {
      const id = safeString(step.id || `step_${index + 1}`);
      const type = normalizeEnumText(step.type || "TASK_ASSIGNMENT");
      const enabled = step.enabled !== false;

      return {
        ...step,
        id,
        type,
        enabled,
      };
    })
    .filter((step) => step.enabled);
}

function comparablePlaybookRuntime(
  runtime: PlaybookExecutionRuntime
): Record<string, unknown> {
  const playbooks = runtime.playbooks || {};
  const comparablePlaybooks: Record<string, unknown> = {};

  Object.entries(playbooks).forEach(([playbookId, rawPlaybook]) => {
    const playbook = rawPlaybook as RuntimePlaybook;
    const steps = playbook.steps || {};
    const comparableSteps: Record<string, ComparableStep> = {};

    Object.entries(steps).forEach(([stepId, rawStep]) => {
      const step = rawStep as RuntimeStep;
      comparableSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        enabled: step.enabled !== false,
      };
    });

    comparablePlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title),
      priority: toNumber(playbook.priority, 100),
      trigger: playbook.trigger || {},
      steps: comparableSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    playbooks: comparablePlaybooks,
  };
}

function sanitizePlaybookExecutionRuntime(value: unknown): PlaybookExecutionRuntime {
  const runtime = (value || {}) as Partial<PlaybookExecutionRuntime>;

  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object"
      ? runtime.playbooks
      : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput as Record<string, unknown>).forEach(([playbookId, raw]) => {
    const playbook = (raw || {}) as Partial<RuntimePlaybook>;

    const stepsInput =
      playbook.steps && typeof playbook.steps === "object" ? playbook.steps : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput as Record<string, unknown>).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as Partial<RuntimeStep>;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title),
        description: safeString(step.description),
        enabled: step.enabled !== false,
        status: safeString(step.status || "PENDING") || "PENDING",
        createdAt: toNumber(step.createdAt, 0),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
        metadata:
          step.metadata && typeof step.metadata === "object"
            ? (step.metadata as Record<string, unknown>)
            : {},
        targetRoles: Array.isArray(step.targetRoles)
          ? step.targetRoles.map((x) => safeString(x)).filter(Boolean)
          : [],
        team: safeString(step.team),
        mode: safeString(step.mode),
        targets: Array.isArray(step.targets)
          ? step.targets.map((x) => safeString(x)).filter(Boolean)
          : [],
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title),
      description: safeString(playbook.description),
      priority: toNumber(playbook.priority, 100),
      status: safeString(playbook.status || "ACTIVE") || "ACTIVE",
      activatedAt: toNumber(playbook.activatedAt, 0),
      lastEvaluatedAt: toNumber(playbook.lastEvaluatedAt, 0),
      trigger:
        playbook.trigger && typeof playbook.trigger === "object"
          ? (playbook.trigger as Record<string, unknown>)
          : {},
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    playbooks: sanitizedPlaybooks,
  };
}

function sanitizeTriggerForRuntime(trigger: PlaybookTrigger): Record<string, unknown> {
  return {
    minRisk: normalizeEnumText(trigger.minRisk || ""),
    categories: trigger.categories || {},
    subtypes: trigger.subtypes || {},
    severities: trigger.severities || {},
    requiresEvacuation:
      typeof trigger.requiresEvacuation === "boolean" ? trigger.requiresEvacuation : null,
    requiresExternalAuthorities:
      typeof trigger.requiresExternalAuthorities === "boolean"
        ? trigger.requiresExternalAuthorities
        : null,
  };
}

function riskMeetsMinRisk(current: RiskLevel, min: RiskLevel): boolean {
  const ranking: Record<RiskLevel, number> = {
    LOW: 1,
    MEDIUM: 2,
    HIGH: 3,
    CRITICAL: 4,
  };

  return ranking[current] >= ranking[min];
}

function matchesOptionalEnumSet(
  value: string,
  allowed?: Record<string, boolean>
): boolean {
  if (!allowed || Object.keys(allowed).length === 0) return true;
  if (!value) return false;
  return allowed[normalizeEnumText(value)] === true;
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function sanitizeActivationComparable(value: unknown): Record<string, unknown> {
  const activation = (value || {}) as Record<string, unknown>;
  return {
    activationLevel: normalizeEnumText(activation.activationLevel || ""),
    evacuationRequired: toBoolean(activation.evacuationRequired) === true,
    externalAuthoritiesRequired:
      toBoolean(activation.externalAuthoritiesRequired) === true,
  };
}

function normalizeEnumText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function normalizeRiskLevel(
  value: unknown,
  fallback: RiskLevel | null
): RiskLevel | null {
  const normalized = normalizeEnumText(value);
  if (
    normalized === "LOW" ||
    normalized === "MEDIUM" ||
    normalized === "HIGH" ||
    normalized === "CRITICAL"
  ) {
    return normalized;
  }
  return fallback;
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function safeSiteId(value: unknown): string {
  return String(value || "").trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;

  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }

  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function stableStringify(value: unknown): string {
  return JSON.stringify(sortDeep(value));
}

function sortDeep(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(sortDeep);
  }

  if (value && typeof value === "object") {
    const sorted: Record<string, unknown> = {};
    Object.keys(value as Record<string, unknown>)
      .sort()
      .forEach((key) => {
        sorted[key] = sortDeep((value as Record<string, unknown>)[key]);
      });
    return sorted;
  }

  return value;
}

function stringifyError(error: unknown): Record<string, unknown> {
  if (error instanceof Error) {
    return {
      message: error.message,
      stack: error.stack || "",
      name: error.name,
    };
  }

  return {
    value: String(error),
  };
}