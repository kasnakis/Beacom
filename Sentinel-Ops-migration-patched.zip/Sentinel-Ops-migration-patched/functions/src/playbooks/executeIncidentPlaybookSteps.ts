import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RuntimeStep = {
  id?: string;
  type?: string;
  title?: string;
  description?: string;
  enabled?: boolean;
  status?: string;
  createdAt?: number;
  startedAt?: number | null;
  completedAt?: number | null;
  executionMode?: string;
  executionResult?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  targetRoles?: string[];
  team?: string;
  mode?: string;
  targets?: string[];
};

type RuntimePlaybook = {
  id?: string;
  title?: string;
  description?: string;
  priority?: number;
  status?: string;
  activatedAt?: number;
  lastEvaluatedAt?: number;
  trigger?: Record<string, unknown>;
  steps?: Record<string, RuntimeStep>;
};

type ExecutionRuntime = {
  schemaVersion?: number;
  category?: string;
  overallRisk?: string;
  updatedAt?: number;
  playbooks?: Record<string, RuntimePlaybook>;
};

type IncidentLike = Record<string, any>;

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "executeIncidentPlaybookSteps";

export const executeIncidentPlaybookSteps = onValueWritten(
  {
    ref: "/incidents/{incidentId}/incident_playbook_execution",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    const afterExists = event.data.after.exists();
    if (!afterExists) {
      logger.info("Playbook step execution skipped - runtime removed", {
        incidentId,
      });
      return;
    }

    const runtime = sanitizeExecutionRuntime(event.data.after.val() || {});
    const incidentSnap = await db.ref(`incidents/${incidentId}`).get();

    if (!incidentSnap.exists()) {
      logger.warn("Playbook step execution skipped - incident not found", {
        incidentId,
      });
      return;
    }

    const incident = (incidentSnap.val() || {}) as IncidentLike;
    const siteId = safeString(incident.siteId ?? incident.site ?? "");

    if (!siteId) {
      logger.warn("Playbook step execution skipped - missing siteId", {
        incidentId,
      });
      return;
    }

    const executionPlan = resolveExecutionActions(runtime);

    if (executionPlan.length === 0) {
      logger.info("Playbook step execution skipped - no executable steps", {
        incidentId,
        siteId,
      });
      return;
    }

    const now = Date.now();
    const updates: Record<string, unknown> = {};
    const eventWrites: Array<Promise<void>> = [];

    for (const action of executionPlan) {
      const stepBasePath = `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}`;

      updates[`${stepBasePath}/status`] = action.nextStatus;
      updates[`${stepBasePath}/executionMode`] = action.executionMode;
      updates[`${stepBasePath}/executionResult`] = action.executionResult;

      if (action.nextStatus === "IN_PROGRESS") {
        updates[`${stepBasePath}/startedAt`] = action.startedAt ?? now;
      }

      if (action.nextStatus === "COMPLETED") {
        updates[`${stepBasePath}/startedAt`] = action.startedAt ?? now;
        updates[`${stepBasePath}/completedAt`] = now;
      }

      if (action.emitStartedEvent) {
        eventWrites.push(
          pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_STEP_STARTED", {
            playbookId: action.playbookId,
            playbookTitle: action.playbookTitle,
            stepId: action.stepId,
            stepType: action.stepType,
            stepTitle: action.stepTitle,
            status: action.nextStatus,
            executionMode: action.executionMode,
          })
        );
      }

      if (action.emitCompletedEvent) {
        eventWrites.push(
          pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_STEP_COMPLETED", {
            playbookId: action.playbookId,
            playbookTitle: action.playbookTitle,
            stepId: action.stepId,
            stepType: action.stepType,
            stepTitle: action.stepTitle,
            status: action.nextStatus,
            executionMode: action.executionMode,
          })
        );
      }
    }

    updates[`incidents/${incidentId}/incident_playbook_execution/updatedAt`] = now;

    await db.ref().update(updates);
    await Promise.all(eventWrites);

    logger.info("Playbook step execution completed", {
      incidentId,
      siteId,
      executedSteps: executionPlan.map((x) => ({
        playbookId: x.playbookId,
        stepId: x.stepId,
        nextStatus: x.nextStatus,
      })),
    });
  }
);

function resolveExecutionActions(runtime: ExecutionRuntime): Array<{
  playbookId: string;
  playbookTitle: string;
  stepId: string;
  stepType: string;
  stepTitle: string;
  nextStatus: string;
  startedAt?: number | null;
  executionMode: string;
  executionResult: Record<string, unknown>;
  emitStartedEvent: boolean;
  emitCompletedEvent: boolean;
}> {
  const actions: Array<{
    playbookId: string;
    playbookTitle: string;
    stepId: string;
    stepType: string;
    stepTitle: string;
    nextStatus: string;
    startedAt?: number | null;
    executionMode: string;
    executionResult: Record<string, unknown>;
    emitStartedEvent: boolean;
    emitCompletedEvent: boolean;
  }> = [];

  const playbooks = runtime.playbooks || {};

  Object.entries(playbooks).forEach(([playbookId, playbookRaw]) => {
    const playbook = playbookRaw as RuntimePlaybook;
    const playbookTitle = safeString(playbook.title || playbookId);
    const steps = playbook.steps || {};

    Object.entries(steps).forEach(([stepId, stepRaw]) => {
      const step = stepRaw as RuntimeStep;

      if (step.enabled === false) return;

      const currentStatus = normalizeEnumText(step.status || "PENDING");
      const stepType = normalizeEnumText(step.type || "");
      const stepTitle = safeString(step.title || stepId);

      if (currentStatus !== "PENDING") return;

      if (stepType === "NOTIFICATION") {
        actions.push({
          playbookId,
          playbookTitle,
          stepId,
          stepType,
          stepTitle,
          nextStatus: "COMPLETED",
          startedAt: step.startedAt ?? null,
          executionMode: "AUTO_IMMEDIATE",
          executionResult: {
            handledBy: FUNCTION_NAME,
            autoCompleted: true,
            reason: "NOTIFICATION_STEP_MARKED_COMPLETED_V1",
          },
          emitStartedEvent: true,
          emitCompletedEvent: true,
        });
        return;
      }

      if (stepType === "DISPATCH_TEAM") {
        actions.push({
          playbookId,
          playbookTitle,
          stepId,
          stepType,
          stepTitle,
          nextStatus: "IN_PROGRESS",
          startedAt: step.startedAt ?? null,
          executionMode: "AUTO_TRANSITION",
          executionResult: {
            handledBy: FUNCTION_NAME,
            autoStarted: true,
            team: safeString(step.team),
            reason: "DISPATCH_TEAM_STEP_STARTED_V1",
          },
          emitStartedEvent: true,
          emitCompletedEvent: false,
        });
        return;
      }

      if (stepType === "PREPARE_EVACUATION") {
        actions.push({
          playbookId,
          playbookTitle,
          stepId,
          stepType,
          stepTitle,
          nextStatus: "IN_PROGRESS",
          startedAt: step.startedAt ?? null,
          executionMode: "AUTO_TRANSITION",
          executionResult: {
            handledBy: FUNCTION_NAME,
            autoStarted: true,
            reason: "PREPARE_EVACUATION_STEP_STARTED_V1",
          },
          emitStartedEvent: true,
          emitCompletedEvent: false,
        });
        return;
      }

      if (stepType === "EVACUATION") {
        actions.push({
          playbookId,
          playbookTitle,
          stepId,
          stepType,
          stepTitle,
          nextStatus: "IN_PROGRESS",
          startedAt: step.startedAt ?? null,
          executionMode: "AUTO_TRANSITION",
          executionResult: {
            handledBy: FUNCTION_NAME,
            autoStarted: true,
            mode: safeString(step.mode),
            reason: "EVACUATION_STEP_STARTED_V1",
          },
          emitStartedEvent: true,
          emitCompletedEvent: false,
        });
        return;
      }

      if (stepType === "EXTERNAL_NOTIFICATION") {
        actions.push({
          playbookId,
          playbookTitle,
          stepId,
          stepType,
          stepTitle,
          nextStatus: "IN_PROGRESS",
          startedAt: step.startedAt ?? null,
          executionMode: "AUTO_TRANSITION",
          executionResult: {
            handledBy: FUNCTION_NAME,
            autoStarted: true,
            targets: Array.isArray(step.targets) ? step.targets : [],
            reason: "EXTERNAL_NOTIFICATION_STEP_STARTED_V1",
          },
          emitStartedEvent: true,
          emitCompletedEvent: false,
        });
        return;
      }
    });
  });

  return actions;
}

function sanitizeExecutionRuntime(value: unknown): ExecutionRuntime {
  const runtime = (value || {}) as ExecutionRuntime;
  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object" ? runtime.playbooks : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput).forEach(([playbookId, playbookRaw]) => {
    const playbook = (playbookRaw || {}) as RuntimePlaybook;
    const stepsInput =
      playbook.steps && typeof playbook.steps === "object" ? playbook.steps : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as RuntimeStep;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title || stepId),
        description: safeString(step.description),
        enabled: step.enabled !== false,
        status: normalizeEnumText(step.status || "PENDING"),
        createdAt: toNumber(step.createdAt, 0),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
        executionMode: safeString(step.executionMode),
        executionResult:
          step.executionResult && typeof step.executionResult === "object"
            ? step.executionResult
            : {},
        metadata: step.metadata && typeof step.metadata === "object" ? step.metadata : {},
        targetRoles: Array.isArray(step.targetRoles)
          ? step.targetRoles.map((x) => safeString(x)).filter(Boolean)
          : [],
        team: safeString(step.team),
        mode: safeString(step.mode),
        targets: Array.isArray(step.targets)
          ? step.targets.map((x) => safeString(x)).filter(Boolean)
          : [],
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title || playbookId),
      description: safeString(playbook.description),
      priority: toNumber(playbook.priority, 100),
      status: safeString(playbook.status || "ACTIVE"),
      activatedAt: toNumber(playbook.activatedAt, 0),
      lastEvaluatedAt: toNumber(playbook.lastEvaluatedAt, 0),
      trigger: playbook.trigger && typeof playbook.trigger === "object" ? playbook.trigger : {},
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    playbooks: sanitizedPlaybooks,
  };
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function normalizeEnumText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function stringifyError(error: unknown): Record<string, unknown> {
  if (error instanceof Error) {
    return {
      message: error.message,
      stack: error.stack || "",
      name: error.name,
    };
  }

  return {
    value: String(error),
  };
}