import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import { resolveExternalNotifications } from "../externalNotifications/resolveExternalNotifications";

type RuntimeStep = {
  id?: string;
  type?: string;
  title?: string;
  description?: string;
  enabled?: boolean;
  status?: string;
  createdAt?: number;
  startedAt?: number | null;
  completedAt?: number | null;
  executionMode?: string;
  executionResult?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  targetRoles?: string[];
  team?: string;
  mode?: string;
  targets?: string[];
};

type RuntimePlaybook = {
  id?: string;
  title?: string;
  description?: string;
  priority?: number;
  status?: string;
  activatedAt?: number;
  lastEvaluatedAt?: number;
  trigger?: Record<string, unknown>;
  steps?: Record<string, RuntimeStep>;
};

type ExecutionRuntime = {
  schemaVersion?: number;
  category?: string;
  overallRisk?: string;
  updatedAt?: number;
  playbooks?: Record<string, RuntimePlaybook>;
  status?: string;
};

type IncidentLike = Record<string, any>;

type ExternalNotificationAuthorityPolicy = {
  enabled?: boolean;
  autoSuggest?: boolean;
  requiresApproval?: boolean;
  defaultChannel?: string;
  allowedRequesterRoles?: Record<string, boolean>;
  allowedApproverRoles?: Record<string, boolean>;
  allowedExecutorRoles?: Record<string, boolean>;
};

type ExternalNotificationConfig = {
  enabled?: boolean;
  mode?: string;
  authorities?: Record<string, ExternalNotificationAuthorityPolicy>;
};

type ExternalAuthorityContact = {
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
};

type ExternalAuthorityRegistryEntry = {
  id?: string;
  name?: string;
  enabled?: boolean;
  active?: boolean;
  defaultChannel?: string;
  supportedChannels?: Record<string, boolean>;
  contacts?: {
    primary?: ExternalAuthorityContact;
    secondary?: ExternalAuthorityContact;
  };
};

type IncidentExternalAuthoritySummary = {
  required?: boolean;
  requested?: boolean;
  displayName?: string;
  authorityType?: string;
  status?: string;
  channel?: string;
  mode?: string;
  lastUpdatedAt?: number;
  canonicalNotificationId?: string;
  legacyRequestId?: string;
  approvalRequired?: boolean;
  approvedAt?: number | null;
  rejectedAt?: number | null;
  executedAt?: number | null;
  acknowledgedAt?: number | null;
  failedAt?: number | null;
  closedAt?: number | null;
  acknowledgedBy?: string;
};

type IncidentPolicyRecord = {
  category?: string;
  displayName?: string;
  externalEnabled?: boolean;
  externalMode?: string;
  externalAuthorityTypes?: Record<string, boolean>;
  externalAuthorityIds?: Record<string, boolean>;
  externalTriggers?: {
    onCreated?: boolean;
    onVerified?: boolean;
    onUnderControl?: boolean;
  };
  externalNotificationPolicy?: {
    enabled?: boolean;
    mode?: string;
    authorityTypes?: Record<string, boolean>;
    authorityIds?: Record<string, boolean>;
    triggers?: {
      onCreated?: boolean;
      onVerified?: boolean;
      onUnderControl?: boolean;
    };
  };
  workflowExtensions?: {
    externalNotifications?: ExternalNotificationConfig;
  };
};

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "executeExternalNotificationSteps";

const SYSTEM_REQUESTER_ROLES: Record<string, boolean> = {
  CONTROL_ROOM: true,
  ENVIRONMENTAL_OFFICER: true,
  HSE_MANAGER: true,
  SITE_MANAGER: true,
  SUPERVISOR: true,
};

export const executeExternalNotificationSteps = onValueWritten(
  {
    ref: "/incidents/{incidentId}/incident_playbook_execution",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    if (!event.data.after.exists()) {
      logger.info("External notification executor skipped - runtime removed", {
        incidentId,
      });
      return;
    }

    const runtime = sanitizeExecutionRuntime(event.data.after.val() || {});
    if (normalizeEnumText(runtime.status || "") === "CLOSED") {
      logger.info("External notification executor skipped - playbook execution closed", {
        incidentId,
      });
      return;
    }

    const incidentSnap = await db.ref(`incidents/${incidentId}`).get();
    if (!incidentSnap.exists()) {
      logger.warn("External notification executor skipped - incident missing", {
        incidentId,
      });
      return;
    }

    const incident = (incidentSnap.val() || {}) as IncidentLike;
    const siteId = safeString(incident.siteId ?? incident.site ?? "");
    const category = normalizeEnumText(incident.category ?? "");

    if (!siteId || !category) {
      logger.warn("External notification executor skipped - missing site/category", {
        incidentId,
        siteId,
        category,
      });
      return;
    }

    const incidentStatus = normalizeEnumText(incident.status || "");
    const incidentActive = toBoolean(incident.active) === true;
    if (!incidentActive || incidentStatus === "DEACTIVATED" || incidentStatus === "CLOSED") {
      logger.info("External notification executor skipped - incident not operational", {
        incidentId,
        siteId,
        category,
        incidentStatus,
        incidentActive,
      });
      return;
    }

    const policySnap = await db
      .ref(`site_config_data/${siteId}/incident_policies/${category}`)
      .get();

    const policyRecord = (policySnap.exists() ? policySnap.val() : {}) as IncidentPolicyRecord;

    const externalConfig = (policyRecord.workflowExtensions?.externalNotifications || {}) as ExternalNotificationConfig;

    if (
      externalConfig.enabled === false &&
      policyRecord.externalEnabled === false &&
      policyRecord.externalNotificationPolicy?.enabled === false
    ) {
      logger.info("External notification executor skipped - policy disabled", {
        incidentId,
        siteId,
        category,
      });
      return;
    }

    const authoritiesRegistrySnap = await db
      .ref(`site_config_data/${siteId}/external_authorities`)
      .get();

    const authoritiesRegistry = (authoritiesRegistrySnap.exists()
      ? authoritiesRegistrySnap.val()
      : {}) as Record<string, ExternalAuthorityRegistryEntry>;

    const policyMode = safeString(externalConfig.mode || policyRecord.externalMode || "MANUAL_LOGGED") || "MANUAL_LOGGED";

    const actions = resolveExternalNotificationActions(runtime);

    const rootUpdates: Record<string, unknown> = {};
    const createdEvents: Array<Promise<void>> = [];
    let createdCount = 0;

    // -------------------------------------------------------------------
    // preload all enabled policy authorities into incident summary
    // -------------------------------------------------------------------
    const incidentExternalAuthorities =
      incident.externalAuthorities && typeof incident.externalAuthorities === "object"
        ? (incident.externalAuthorities as Record<string, IncidentExternalAuthoritySummary>)
        : {};

    const policyAuthorities =
      externalConfig.authorities && typeof externalConfig.authorities === "object"
        ? externalConfig.authorities
        : {};

    Object.entries(policyAuthorities).forEach(([rawAuthorityType, rawPolicy]) => {
      const authorityType = normalizeAuthorityType(rawAuthorityType);
      const policy = (rawPolicy || {}) as ExternalNotificationAuthorityPolicy;
      if (!authorityType || policy.enabled === false) return;

      const registryEntry = resolveAuthorityRegistry(authoritiesRegistry, authorityType);
      const existing = sanitizeIncidentExternalAuthoritySummary(
        incidentExternalAuthorities[authorityType]
      );

      const displayName =
        safeString(existing.displayName) ||
        safeString(registryEntry?.name || authorityType);

      const channel =
        normalizeEnumText(existing.channel || policy.defaultChannel || registryEntry?.defaultChannel || "PHONE") || "PHONE";

      const mode = safeString(existing.mode || policyMode) || policyMode;
      const status =
        normalizeEnumText(existing.status || "") ||
        (toBoolean(existing.requested) === true ? "REQUESTED" : "NOT_REQUESTED");

      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/required`] = true;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/requested`] =
        toBoolean(existing.requested) === true;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/displayName`] =
        displayName;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/authorityType`] =
        authorityType;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/status`] = status;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/channel`] = channel;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${authorityType}/mode`] = mode;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${authorityType}/approvalRequired`
      ] = policy.requiresApproval !== false;

      const existingLastUpdatedAt = toNumberOrNull(existing.lastUpdatedAt);
      if (existingLastUpdatedAt != null) {
        rootUpdates[
          `incidents/${incidentId}/externalAuthorities/${authorityType}/lastUpdatedAt`
        ] = existingLastUpdatedAt;
      }

      if (safeString(existing.canonicalNotificationId)) {
        rootUpdates[
          `incidents/${incidentId}/externalAuthorities/${authorityType}/canonicalNotificationId`
        ] = safeString(existing.canonicalNotificationId);
      }

      if (safeString(existing.legacyRequestId)) {
        rootUpdates[
          `incidents/${incidentId}/externalAuthorities/${authorityType}/legacyRequestId`
        ] = safeString(existing.legacyRequestId);
      }

      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/approvedAt`,
        existing.approvedAt
      );
      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/rejectedAt`,
        existing.rejectedAt
      );
      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/executedAt`,
        existing.executedAt
      );
      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/acknowledgedAt`,
        existing.acknowledgedAt
      );
      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/failedAt`,
        existing.failedAt
      );
      copyOptionalTimestampUpdate(
        rootUpdates,
        `incidents/${incidentId}/externalAuthorities/${authorityType}/closedAt`,
        existing.closedAt
      );

      if (safeString(existing.acknowledgedBy)) {
        rootUpdates[
          `incidents/${incidentId}/externalAuthorities/${authorityType}/acknowledgedBy`
        ] = safeString(existing.acknowledgedBy);
      }
    });

    if (actions.length === 0) {
      if (Object.keys(rootUpdates).length > 0) {
        await db.ref().update(rootUpdates);
      }

      logger.info("External notification executor skipped - no external steps", {
        incidentId,
        siteId,
        category,
        policyAuthoritiesPreloaded: Object.keys(policyAuthorities).length,
      });
      return;
    }

    for (const action of actions) {
      const normalizedTargets = action.targets
        .map((target) => normalizeAuthorityType(target))
        .filter(Boolean);

      const requestedPrimaryTarget = normalizedTargets[0] || "";

      const resolverResult = resolveExternalNotifications({
        siteId,
        incidentId,
        category,
        subtype: safeString(incident.subtype ?? incident.type ?? ""),
        severity: normalizeSeverity(incident.severity),
        triggerEvent: "MANUAL_REQUEST",
        policy: policyRecord,
        authoritiesRegistry,
        flags: {
          externalAuthoritiesRequired: true,
          evacuationRequired: toBoolean(incident.evacuationRequired) === true,
          injuriesReported: toBoolean(incident.injuriesReported) === true,
          fireConfirmed: toBoolean(incident.fireConfirmed) === true,
          policeRequired: toBoolean(incident.policeRequired) === true,
          environmentalEscalationRequired:
            toBoolean(incident.environmentalEscalationRequired) === true,
        },
        incidentState: {
          active: incidentActive,
          verified: toBoolean(incident.verified) === true,
          underControl:
            toBoolean(incident.underControl) === true || incidentStatus === "UNDER_CONTROL",
          closureRequested: toBoolean(incident.closureRequested) === true,
        },
        currentUser: {
          uid: FUNCTION_NAME,
          displayName: FUNCTION_NAME,
          roles: SYSTEM_REQUESTER_ROLES,
        },
      });

      logger.info("External resolver result", {
        incidentId,
        playbookId: action.playbookId,
        stepId: action.stepId,
        requestedTargets: normalizedTargets,
        plans: resolverResult.plans.map((plan) => ({
          authorityType: plan.authorityType,
          authorityId: plan.authorityId,
          mode: plan.mode,
          channel: plan.defaultChannel,
          approvalRequired: plan.approvalRequired,
          dedupeKey: plan.dedupeKey,
        })),
        diagnostics: resolverResult.diagnostics,
      });

      if (!resolverResult.shouldCreateAny || resolverResult.plans.length === 0) {
        logger.info("External notification executor skipped - resolver returned no plans", {
          incidentId,
          playbookId: action.playbookId,
          stepId: action.stepId,
          requestedTargets: normalizedTargets,
          diagnostics: resolverResult.diagnostics,
        });
        continue;
      }

      const selectedPlan =
        resolverResult.plans.find((plan) => plan.authorityType === requestedPrimaryTarget) ||
        resolverResult.plans[0];

      if (!selectedPlan) {
        logger.info("External notification executor skipped - no matching resolver plan", {
          incidentId,
          playbookId: action.playbookId,
          stepId: action.stepId,
          requestedTargets: normalizedTargets,
        });
        continue;
      }

      const primaryTarget = normalizeAuthorityType(selectedPlan.authorityType);
      if (!primaryTarget) {
        logger.warn("External notification executor skipped - invalid selected authority", {
          incidentId,
          playbookId: action.playbookId,
          stepId: action.stepId,
          selectedAuthority: selectedPlan.authorityType,
        });
        continue;
      }

      const legacyRequestId = `${action.playbookId}_${action.stepId}`;
      const legacyRequestPath = `incidents/${incidentId}/external_notification_requests/${legacyRequestId}`;

      const legacyExistingSnap = await db.ref(legacyRequestPath).get();
      if (legacyExistingSnap.exists()) {
        continue;
      }

      const now = Date.now();
      const canonicalNotificationId = buildCanonicalExternalNotificationId(
        incidentId,
        action.playbookId,
        action.stepId,
        primaryTarget
      );

      const canonicalPath = `external_notifications/${canonicalNotificationId}`;
      const canonicalExistingSnap = await db.ref(canonicalPath).get();
      if (canonicalExistingSnap.exists()) {
        continue;
      }

      const authorityId = safeString(selectedPlan.authorityId || primaryTarget);
      const authorityName = safeString(selectedPlan.authorityName || primaryTarget);
      const channel = normalizeEnumText(selectedPlan.defaultChannel || action.mode || "PHONE") || "PHONE";
      const approvalRequired = selectedPlan.approvalRequired;

      const primaryContact = selectedPlan.contacts?.primary || {};
      const secondaryContact = selectedPlan.contacts?.secondary || {};

      const legacyTargetsMap: Record<string, boolean> = {};
      action.targets.forEach((target) => {
        const normalized = safeString(target);
        if (normalized) legacyTargetsMap[normalized] = true;
      });

      // -------------------------------------------------------------------
      // Backward-compatible existing structure
      // -------------------------------------------------------------------
      rootUpdates[`${legacyRequestPath}/id`] = legacyRequestId;
      rootUpdates[`${legacyRequestPath}/incidentId`] = incidentId;
      rootUpdates[`${legacyRequestPath}/siteId`] = siteId;
      rootUpdates[`${legacyRequestPath}/category`] = category;
      rootUpdates[`${legacyRequestPath}/playbookId`] = action.playbookId;
      rootUpdates[`${legacyRequestPath}/playbookTitle`] = action.playbookTitle;
      rootUpdates[`${legacyRequestPath}/stepId`] = action.stepId;
      rootUpdates[`${legacyRequestPath}/stepTitle`] = action.stepTitle;
      rootUpdates[`${legacyRequestPath}/status`] = "REQUESTED";
      rootUpdates[`${legacyRequestPath}/mode`] = selectedPlan.mode || policyMode;
      rootUpdates[`${legacyRequestPath}/requestedAt`] = now;
      rootUpdates[`${legacyRequestPath}/requestedBy`] = FUNCTION_NAME;
      rootUpdates[`${legacyRequestPath}/source`] = "PLAYBOOK_EXECUTOR_V2";
      rootUpdates[`${legacyRequestPath}/eventLogged`] = true;
      rootUpdates[`${legacyRequestPath}/targets`] = legacyTargetsMap;
      rootUpdates[`${legacyRequestPath}/canonicalNotificationId`] = canonicalNotificationId;
      rootUpdates[`${legacyRequestPath}/authorityType`] = primaryTarget;
      rootUpdates[`${legacyRequestPath}/authorityName`] = authorityName;
      rootUpdates[`${legacyRequestPath}/channel`] = channel;
      rootUpdates[`${legacyRequestPath}/approvalRequired`] = approvalRequired;

      // -------------------------------------------------------------------
      // Canonical external_notifications structure
      // -------------------------------------------------------------------
      rootUpdates[`${canonicalPath}/id`] = canonicalNotificationId;
      rootUpdates[`${canonicalPath}/incidentId`] = incidentId;
      rootUpdates[`${canonicalPath}/siteId`] = siteId;
      rootUpdates[`${canonicalPath}/category`] = category;

      rootUpdates[`${canonicalPath}/authorityType`] = primaryTarget;
      rootUpdates[`${canonicalPath}/authorityId`] = authorityId;
      rootUpdates[`${canonicalPath}/authorityName`] = authorityName;

      rootUpdates[`${canonicalPath}/contact/phone`] = safeString(primaryContact.phone);
      rootUpdates[`${canonicalPath}/contact/email`] = safeString(primaryContact.email);
      rootUpdates[`${canonicalPath}/contact/address`] = safeString(primaryContact.address);
      rootUpdates[`${canonicalPath}/contact/notes`] = safeString(primaryContact.notes);

      rootUpdates[`${canonicalPath}/contactSecondary/phone`] = safeString(secondaryContact.phone);
      rootUpdates[`${canonicalPath}/contactSecondary/email`] = safeString(secondaryContact.email);
      rootUpdates[`${canonicalPath}/contactSecondary/address`] = safeString(
        secondaryContact.address
      );
      rootUpdates[`${canonicalPath}/contactSecondary/notes`] = safeString(secondaryContact.notes);

      rootUpdates[`${canonicalPath}/channel`] = channel;

      rootUpdates[`${canonicalPath}/requestedByUserId`] = FUNCTION_NAME;
      rootUpdates[`${canonicalPath}/requestedByName`] = FUNCTION_NAME;
      rootUpdates[`${canonicalPath}/requestedByRole`] = "SYSTEM";

      rootUpdates[`${canonicalPath}/approval/required`] = approvalRequired;
      rootUpdates[`${canonicalPath}/approval/status`] = approvalRequired ? "PENDING" : "APPROVED";
      rootUpdates[`${canonicalPath}/approval/approvedByUserId`] = approvalRequired
        ? null
        : FUNCTION_NAME;
      rootUpdates[`${canonicalPath}/approval/approvedByName`] = approvalRequired
        ? null
        : FUNCTION_NAME;
      rootUpdates[`${canonicalPath}/approval/approvedByRole`] = approvalRequired
        ? null
        : "SYSTEM";
      rootUpdates[`${canonicalPath}/approval/approvedAt`] = approvalRequired ? null : now;
      rootUpdates[`${canonicalPath}/approval/rejectionReason`] = null;

      rootUpdates[`${canonicalPath}/execution/status`] = "PENDING";
      rootUpdates[`${canonicalPath}/execution/executedByUserId`] = null;
      rootUpdates[`${canonicalPath}/execution/executedByName`] = null;
      rootUpdates[`${canonicalPath}/execution/executedAt`] = null;
      rootUpdates[`${canonicalPath}/execution/resultNotes`] = "";

      rootUpdates[`${canonicalPath}/acknowledgement/status`] = "NONE";
      rootUpdates[`${canonicalPath}/acknowledgement/receivedAt`] = null;
      rootUpdates[`${canonicalPath}/acknowledgement/receivedBy`] = "";
      rootUpdates[`${canonicalPath}/acknowledgement/notes`] = "";

      rootUpdates[`${canonicalPath}/attempts`] = 0;
      rootUpdates[`${canonicalPath}/lastAttemptAt`] = null;

      rootUpdates[`${canonicalPath}/status`] = "REQUESTED";
      rootUpdates[`${canonicalPath}/mode`] = selectedPlan.mode || policyMode;
      rootUpdates[`${canonicalPath}/playbookId`] = action.playbookId;
      rootUpdates[`${canonicalPath}/playbookTitle`] = action.playbookTitle;
      rootUpdates[`${canonicalPath}/stepId`] = action.stepId;
      rootUpdates[`${canonicalPath}/stepTitle`] = action.stepTitle;
      rootUpdates[`${canonicalPath}/source`] = "PLAYBOOK_EXECUTOR_V2";
      rootUpdates[`${canonicalPath}/targets`] = legacyTargetsMap;
      rootUpdates[`${canonicalPath}/createdAt`] = now;
      rootUpdates[`${canonicalPath}/updatedAt`] = now;
      rootUpdates[`${canonicalPath}/closedAt`] = null;
      rootUpdates[`${canonicalPath}/notes`] = "";
      rootUpdates[`${canonicalPath}/legacyRequestId`] = legacyRequestId;
      rootUpdates[`${canonicalPath}/resolver/mode`] = selectedPlan.source.resolutionMode;
      rootUpdates[`${canonicalPath}/resolver/policyPath`] = selectedPlan.source.policyPath;
      rootUpdates[`${canonicalPath}/resolver/reasonCodes`] = selectedPlan.reasonCodes;
      rootUpdates[`${canonicalPath}/resolver/dedupeKey`] = selectedPlan.dedupeKey;

      rootUpdates[`${canonicalPath}/allowedRequesterRoles`] = selectedPlan.allowedRequesterRoles;
      rootUpdates[`${canonicalPath}/allowedApproverRoles`] = selectedPlan.allowedApproverRoles;
      rootUpdates[`${canonicalPath}/allowedExecutorRoles`] = selectedPlan.allowedExecutorRoles;

      // -------------------------------------------------------------------
      // Incident-level externalAuthorities summary
      // -------------------------------------------------------------------
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${primaryTarget}/required`] = true;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${primaryTarget}/requested`] = true;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/displayName`
      ] = authorityName;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/authorityType`
      ] = primaryTarget;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${primaryTarget}/status`] =
        "REQUESTED";
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${primaryTarget}/channel`] =
        channel;
      rootUpdates[`incidents/${incidentId}/externalAuthorities/${primaryTarget}/mode`] =
        selectedPlan.mode || policyMode;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/lastUpdatedAt`
      ] = now;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/canonicalNotificationId`
      ] = canonicalNotificationId;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/legacyRequestId`
      ] = legacyRequestId;
      rootUpdates[
        `incidents/${incidentId}/externalAuthorities/${primaryTarget}/approvalRequired`
      ] = approvalRequired;

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/externalRequestId`
      ] = legacyRequestId;

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/externalRequestStatus`
      ] = "REQUESTED";

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/externalRequestMode`
      ] = selectedPlan.mode || policyMode;

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/canonicalNotificationId`
      ] = canonicalNotificationId;

      createdEvents.push(
        pushIncidentEvent(db, incidentId, siteId, "EXTERNAL_NOTIFICATION_REQUESTED", {
          playbookId: action.playbookId,
          playbookTitle: action.playbookTitle,
          stepId: action.stepId,
          stepTitle: action.stepTitle,
          externalRequestId: legacyRequestId,
          canonicalNotificationId,
          authorityType: primaryTarget,
          authorityName,
          channel,
          approvalRequired,
          status: "REQUESTED",
          mode: selectedPlan.mode || policyMode,
          targets: action.targets,
          resolverReasonCodes: selectedPlan.reasonCodes,
          resolverDedupeKey: selectedPlan.dedupeKey,
        })
      );

      createdCount += 1;
    }

    if (Object.keys(rootUpdates).length === 0) {
      logger.info("External notification executor skipped - requests already exist", {
        incidentId,
        siteId,
        category,
      });
      return;
    }

    await db.ref().update(rootUpdates);
    if (createdEvents.length > 0) {
      await Promise.all(createdEvents);
    }

    logger.info("External notification executor completed", {
      incidentId,
      siteId,
      category,
      requestsCreated: createdCount,
      mode: policyMode,
      policyAuthoritiesPreloaded: Object.keys(policyAuthorities).length,
    });
  }
);

function resolveExternalNotificationActions(runtime: ExecutionRuntime): Array<{
  playbookId: string;
  playbookTitle: string;
  stepId: string;
  stepTitle: string;
  targets: string[];
  mode?: string;
}> {
  const actions: Array<{
    playbookId: string;
    playbookTitle: string;
    stepId: string;
    stepTitle: string;
    targets: string[];
    mode?: string;
  }> = [];

  const playbooks = runtime.playbooks || {};

  Object.entries(playbooks).forEach(([playbookId, playbookRaw]) => {
    const playbook = playbookRaw as RuntimePlaybook;
    if (normalizeEnumText(playbook.status || "") === "CLOSED") return;

    const playbookTitle = safeString(playbook.title || playbookId);
    const steps = playbook.steps || {};

    Object.entries(steps).forEach(([stepId, stepRaw]) => {
      const step = stepRaw as RuntimeStep;

      if (step.enabled === false) return;
      if (normalizeEnumText(step.type || "") !== "EXTERNAL_NOTIFICATION") return;
      if (normalizeEnumText(step.status || "") !== "IN_PROGRESS") return;

      const externalRequestId =
        safeString(
          (step.executionResult as Record<string, unknown> | undefined)?.externalRequestId
        ) || "";

      if (externalRequestId) return;

      const targets = Array.isArray(step.targets)
        ? step.targets.map((x) => safeString(x)).filter(Boolean)
        : [];

      if (targets.length === 0) return;

      actions.push({
        playbookId,
        playbookTitle,
        stepId,
        stepTitle: safeString(step.title || stepId),
        targets,
        mode: safeString(step.mode),
      });
    });
  });

  return actions;
}

function resolveAuthorityRegistry(
  registry: Record<string, ExternalAuthorityRegistryEntry>,
  authorityType: string
): ExternalAuthorityRegistryEntry | null {
  const resolved = registry[authorityType];
  if (!resolved || typeof resolved !== "object") return null;
  if (resolved.enabled === false || resolved.active === false) return null;
  return resolved;
}

function buildCanonicalExternalNotificationId(
  incidentId: string,
  playbookId: string,
  stepId: string,
  authorityType: string
): string {
  return [
    safeKeyPart(incidentId),
    safeKeyPart(playbookId),
    safeKeyPart(stepId),
    safeKeyPart(authorityType),
  ].join("_");
}

function sanitizeExecutionRuntime(value: unknown): ExecutionRuntime {
  const runtime = (value || {}) as ExecutionRuntime;
  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object" ? runtime.playbooks : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput).forEach(([playbookId, playbookRaw]) => {
    const playbook = (playbookRaw || {}) as RuntimePlaybook;
    const stepsInput =
      playbook.steps && typeof playbook.steps === "object" ? playbook.steps : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as RuntimeStep;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title || stepId),
        description: safeString(step.description),
        enabled: step.enabled !== false,
        status: normalizeEnumText(step.status || "PENDING"),
        createdAt: toNumber(step.createdAt, 0),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
        executionMode: safeString(step.executionMode),
        executionResult:
          step.executionResult && typeof step.executionResult === "object"
            ? step.executionResult
            : {},
        metadata: step.metadata && typeof step.metadata === "object" ? step.metadata : {},
        targetRoles: Array.isArray(step.targetRoles)
          ? step.targetRoles.map((x) => safeString(x)).filter(Boolean)
          : [],
        team: safeString(step.team),
        mode: safeString(step.mode),
        targets: Array.isArray(step.targets)
          ? step.targets.map((x) => safeString(x)).filter(Boolean)
          : [],
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title || playbookId),
      description: safeString(playbook.description),
      priority: toNumber(playbook.priority, 100),
      status: safeString(playbook.status || "ACTIVE"),
      activatedAt: toNumber(playbook.activatedAt, 0),
      lastEvaluatedAt: toNumber(playbook.lastEvaluatedAt, 0),
      trigger: playbook.trigger && typeof playbook.trigger === "object" ? playbook.trigger : {},
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    status: normalizeEnumText(runtime.status || ""),
    playbooks: sanitizedPlaybooks,
  };
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function sanitizeIncidentExternalAuthoritySummary(
  value: unknown
): IncidentExternalAuthoritySummary {
  const raw = (value || {}) as IncidentExternalAuthoritySummary;
  return {
    required: toBoolean(raw.required) === true,
    requested: toBoolean(raw.requested) === true,
    displayName: safeString(raw.displayName),
    authorityType: normalizeAuthorityType(raw.authorityType || ""),
    status: normalizeEnumText(raw.status || ""),
    channel: normalizeEnumText(raw.channel || ""),
    mode: safeString(raw.mode),
    lastUpdatedAt: toNumberOrNull(raw.lastUpdatedAt) ?? undefined,
    canonicalNotificationId: safeString(raw.canonicalNotificationId),
    legacyRequestId: safeString(raw.legacyRequestId),
    approvalRequired: toBoolean(raw.approvalRequired) === true,
    approvedAt: toNumberOrNull(raw.approvedAt),
    rejectedAt: toNumberOrNull(raw.rejectedAt),
    executedAt: toNumberOrNull(raw.executedAt),
    acknowledgedAt: toNumberOrNull(raw.acknowledgedAt),
    failedAt: toNumberOrNull(raw.failedAt),
    closedAt: toNumberOrNull(raw.closedAt),
    acknowledgedBy: safeString(raw.acknowledgedBy),
  };
}

function copyOptionalTimestampUpdate(
  updates: Record<string, unknown>,
  path: string,
  value: unknown
): void {
  const ts = toNumberOrNull(value);
  if (ts != null) {
    updates[path] = ts;
  }
}

function normalizeAuthorityType(value: unknown): string {
  const normalized = normalizeEnumText(value);
  if (!normalized) return "";
  if (normalized === "FIRE_DEPARTMENT") return "FIRE_BRIGADE";
  return normalized;
}

function normalizeSeverity(
  value: unknown
): "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | null {
  const normalized = normalizeEnumText(value);
  if (
    normalized === "LOW" ||
    normalized === "MEDIUM" ||
    normalized === "HIGH" ||
    normalized === "CRITICAL"
  ) {
    return normalized;
  }
  return null;
}

function normalizeEnumText(value: unknown): string {
  return String(value ?? "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function safeKeyPart(value: unknown): string {
  return safeString(value).replace(/[.#$/\[\]\s]+/g, "_");
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}