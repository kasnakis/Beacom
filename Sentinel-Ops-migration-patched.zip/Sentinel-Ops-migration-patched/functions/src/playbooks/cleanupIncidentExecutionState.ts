import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RuntimeStep = {
  id?: string;
  type?: string;
  title?: string;
  status?: string;
  startedAt?: number | null;
  completedAt?: number | null;
};

type RuntimePlaybook = {
  id?: string;
  title?: string;
  status?: string;
  steps?: Record<string, RuntimeStep>;
};

type ExecutionRuntime = {
  schemaVersion?: number;
  category?: string;
  overallRisk?: string;
  updatedAt?: number;
  playbooks?: Record<string, RuntimePlaybook>;
  status?: string;
};

type IncidentPolicy = {
  enabled?: boolean;
  category?: string;
  workflowExtensions?: {
    closure?: {
      mode?: string;
      requiresActionsCompleted?: boolean;
      requiresInvestigationCompleted?: boolean;
    };
    investigation?: {
      enabled?: boolean;
      requiredBeforeClosure?: boolean;
    };
    actions?: {
      enabled?: boolean;
    };
  };
};

type ClosureReadiness = {
  canClose: boolean;
  requiresActionsCompleted: boolean;
  requiresInvestigationCompleted: boolean;
  openStepCount: number;
  openDispatchRequestCount: number;
  openExternalNotificationCount: number;
  openSingleTrackActionCount: number;
  openDimensionActionCount: number;
  incompleteInvestigationCount: number;
  blockingReasons: string[];
};

type IncidentLike = Record<string, any>;

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "cleanupIncidentExecutionState";

export const cleanupIncidentExecutionState = onValueWritten(
  {
    ref: "/incidents/{incidentId}",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    if (!event.data.after.exists()) {
      logger.info("Cleanup skipped - incident deleted", { incidentId });
      return;
    }

    const beforeIncident = (
      event.data.before.exists() ? event.data.before.val() : {}
    ) as IncidentLike;
    const afterIncident = (event.data.after.val() || {}) as IncidentLike;

    const siteId = safeString(afterIncident.siteId ?? afterIncident.site ?? "");
    if (!siteId) {
      logger.warn("Cleanup skipped - missing siteId", { incidentId });
      return;
    }

    const beforeStatus = normalizeEnumText(beforeIncident.status || "");
    const afterStatus = normalizeEnumText(afterIncident.status || "");
    const beforeActive = toBoolean(beforeIncident.active);
    const afterActive = toBoolean(afterIncident.active);

    const shouldCleanup =
      afterStatus === "CLOSED" ||
      afterStatus === "DEACTIVATED" ||
      afterActive === false;

    if (!shouldCleanup) {
      logger.info("Cleanup skipped - incident still active", {
        incidentId,
        siteId,
        status: afterStatus,
      });
      return;
    }

    const stateChanged =
      beforeStatus !== afterStatus || beforeActive !== afterActive;
    if (!stateChanged) {
      logger.info("Cleanup skipped - no lifecycle transition", {
        incidentId,
        siteId,
        status: afterStatus,
      });
      return;
    }

    const executionRuntime = sanitizeExecutionRuntime(
      afterIncident.incident_playbook_execution || {},
    );

    const playbookDispatchRequests =
      afterIncident.playbook_dispatch_requests &&
      typeof afterIncident.playbook_dispatch_requests === "object"
        ? (afterIncident.playbook_dispatch_requests as Record<string, any>)
        : {};

    const externalNotificationRequests =
      afterIncident.external_notification_requests &&
      typeof afterIncident.external_notification_requests === "object"
        ? (afterIncident.external_notification_requests as Record<string, any>)
        : {};

    const evacuationState =
      afterIncident.evacuation_state &&
      typeof afterIncident.evacuation_state === "object"
        ? (afterIncident.evacuation_state as Record<string, any>)
        : null;

    const now = Date.now();

    const resolvedPolicy = await resolveIncidentPolicy(
      db,
      siteId,
      afterIncident,
    );
    const readiness = evaluateClosureReadiness(
      afterIncident,
      executionRuntime,
      playbookDispatchRequests,
      externalNotificationRequests,
      resolvedPolicy?.policy || null,
    );

    if (!readiness.canClose) {
      const restoredStatus = resolveRestoredStatus(beforeStatus);
      const blockUpdates: Record<string, unknown> = {
        [`incidents/${incidentId}/status`]: restoredStatus,
        [`incidents/${incidentId}/active`]: true,
        [`incidents/${incidentId}/closureValidation`]: {
          status: "BLOCKED",
          checkedAt: now,
          checkedBy: FUNCTION_NAME,
          attemptedStatus: afterStatus || "INACTIVE",
          restoredStatus,
          policyKey: resolvedPolicy?.policyKey || "",
          requiresActionsCompleted: readiness.requiresActionsCompleted,
          requiresInvestigationCompleted:
            readiness.requiresInvestigationCompleted,
          closureMode: safeString(afterIncident.closureMode || ""),
          openStepCount: readiness.openStepCount,
          openDispatchRequestCount: readiness.openDispatchRequestCount,
          openExternalNotificationCount:
            readiness.openExternalNotificationCount,
          openSingleTrackActionCount: readiness.openSingleTrackActionCount,
          openDimensionActionCount: readiness.openDimensionActionCount,
          incompleteInvestigationCount: readiness.incompleteInvestigationCount,
          blockingReasons: readiness.blockingReasons,
        },
        [`incidents/${incidentId}/closureBlockedAt`]: now,
        [`incidents/${incidentId}/closureBlockedBy`]: FUNCTION_NAME,
      };

      await db.ref().update(blockUpdates);
      await pushIncidentEvent(
        db,
        incidentId,
        siteId,
        "INCIDENT_CLOSURE_BLOCKED",
        {
          attemptedStatus: afterStatus || "INACTIVE",
          restoredStatus,
          policyKey: resolvedPolicy?.policyKey || "",
          requiresActionsCompleted: readiness.requiresActionsCompleted,
          requiresInvestigationCompleted:
            readiness.requiresInvestigationCompleted,
          closureMode: safeString(afterIncident.closureMode || ""),
          openStepCount: readiness.openStepCount,
          openDispatchRequestCount: readiness.openDispatchRequestCount,
          openExternalNotificationCount:
            readiness.openExternalNotificationCount,
          openSingleTrackActionCount: readiness.openSingleTrackActionCount,
          openDimensionActionCount: readiness.openDimensionActionCount,
          incompleteInvestigationCount: readiness.incompleteInvestigationCount,
          blockingReasons: readiness.blockingReasons,
        },
      );

      logger.warn("Incident closure/deactivation blocked by policy", {
        incidentId,
        siteId,
        attemptedStatus: afterStatus,
        restoredStatus,
        policyKey: resolvedPolicy?.policyKey || "",
        blockingReasons: readiness.blockingReasons,
      });
      return;
    }

    const updates: Record<string, unknown> = {};
    const eventWrites: Array<Promise<void>> = [];

    let openStepCount = 0;
    let closedPlaybookCount = 0;
    let closedDispatchRequestCount = 0;
    let closedExternalRequestCount = 0;
    let skippedTerminalExternalRequestCount = 0;
    let closedEvacuation = false;
    let cancelledResponderCount = 0;

    const executionAlreadyClosed =
      normalizeEnumText(executionRuntime.status || "") === "CLOSED";

    const playbooks = executionRuntime.playbooks || {};

    Object.entries(playbooks).forEach(([playbookId, playbookRaw]) => {
      const playbook = playbookRaw as RuntimePlaybook;
      const playbookTitle = safeString(playbook.title || playbookId);

      if (normalizeEnumText(playbook.status || "") !== "CLOSED") {
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/status`
        ] = "CLOSED";
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/closedAt`
        ] = now;
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/closedBy`
        ] = FUNCTION_NAME;
        closedPlaybookCount += 1;
      }

      const steps = playbook.steps || {};
      Object.entries(steps).forEach(([stepId, stepRaw]) => {
        const step = stepRaw as RuntimeStep;
        const currentStatus = normalizeEnumText(step.status || "PENDING");
        const stepTitle = safeString(step.title || stepId);

        if (
          currentStatus === "COMPLETED" ||
          currentStatus === "CLOSED" ||
          currentStatus === "CANCELLED" ||
          currentStatus === "COMPLETED_BY_INCIDENT_CLOSURE"
        ) {
          return;
        }

        const nextStatus =
          afterStatus === "CLOSED"
            ? "COMPLETED_BY_INCIDENT_CLOSURE"
            : "CANCELLED";

        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/steps/${stepId}/status`
        ] = nextStatus;
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/steps/${stepId}/completedAt`
        ] = now;
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/steps/${stepId}/executionResult/cleanupBy`
        ] = FUNCTION_NAME;
        updates[
          `incidents/${incidentId}/incident_playbook_execution/playbooks/${playbookId}/steps/${stepId}/executionResult/cleanupReason`
        ] = `INCIDENT_${afterStatus || "INACTIVE"}_CLEANUP`;

        openStepCount += 1;

        eventWrites.push(
          pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_STEP_CLOSED", {
            playbookId,
            playbookTitle,
            stepId,
            stepTitle,
            previousStatus: currentStatus,
            newStatus: nextStatus,
            incidentStatus: afterStatus,
          }),
        );
      });
    });

    const shouldEmitExecutionClosed =
      !executionAlreadyClosed || openStepCount > 0 || closedPlaybookCount > 0;

    if (Object.keys(playbooks).length > 0) {
      updates[`incidents/${incidentId}/incident_playbook_execution/status`] =
        "CLOSED";
      updates[`incidents/${incidentId}/incident_playbook_execution/closedAt`] =
        now;
      updates[`incidents/${incidentId}/incident_playbook_execution/closedBy`] =
        FUNCTION_NAME;
      updates[`incidents/${incidentId}/incident_playbook_execution/updatedAt`] =
        now;

      if (shouldEmitExecutionClosed) {
        eventWrites.push(
          pushIncidentEvent(
            db,
            incidentId,
            siteId,
            "PLAYBOOK_EXECUTION_CLOSED",
            {
              incidentStatus: afterStatus,
              openStepCount,
              closedPlaybookCount,
            },
          ),
        );
      }
    }

    Object.entries(playbookDispatchRequests).forEach(
      ([requestId, requestRaw]) => {
        const request = (requestRaw || {}) as Record<string, unknown>;
        const currentStatus = normalizeEnumText(request["status"] || "");

        if (
          currentStatus === "CLOSED" ||
          currentStatus === "CANCELLED" ||
          currentStatus === "COMPLETED"
        ) {
          return;
        }

        const nextStatus = afterStatus === "CLOSED" ? "CLOSED" : "CANCELLED";

        updates[
          `incidents/${incidentId}/playbook_dispatch_requests/${requestId}/status`
        ] = nextStatus;
        updates[
          `incidents/${incidentId}/playbook_dispatch_requests/${requestId}/closedAt`
        ] = now;
        updates[
          `incidents/${incidentId}/playbook_dispatch_requests/${requestId}/closedBy`
        ] = FUNCTION_NAME;

        closedDispatchRequestCount += 1;

        eventWrites.push(
          pushIncidentEvent(
            db,
            incidentId,
            siteId,
            "PLAYBOOK_DISPATCH_CLOSED",
            {
              dispatchRequestId: requestId,
              previousStatus: currentStatus,
              newStatus: nextStatus,
              incidentStatus: afterStatus,
            },
          ),
        );
      },
    );

    Object.entries(externalNotificationRequests).forEach(
      ([requestId, requestRaw]) => {
        const request = (requestRaw || {}) as Record<string, unknown>;
        const currentStatus = normalizeEnumText(request["status"] || "");

        if (isTerminalExternalNotificationStatus(currentStatus)) {
          skippedTerminalExternalRequestCount += 1;
          return;
        }

        const nextStatus = afterStatus === "CLOSED" ? "CLOSED" : "CANCELLED";

        updates[
          `incidents/${incidentId}/external_notification_requests/${requestId}/status`
        ] = nextStatus;
        updates[
          `incidents/${incidentId}/external_notification_requests/${requestId}/closedAt`
        ] = now;
        updates[
          `incidents/${incidentId}/external_notification_requests/${requestId}/closedBy`
        ] = FUNCTION_NAME;

        closedExternalRequestCount += 1;
      },
    );

    if (evacuationState) {
      const evacuationStatus = normalizeEnumText(
        evacuationState["status"] || "",
      );
      const evacuationActive = toBoolean(evacuationState["active"]) === true;

      if (
        evacuationActive ||
        (evacuationStatus && evacuationStatus !== "CLOSED")
      ) {
        updates[`incidents/${incidentId}/evacuation_state/active`] = false;
        updates[`incidents/${incidentId}/evacuation_state/status`] = "CLOSED";
        updates[`incidents/${incidentId}/evacuation_state/closedAt`] = now;
        updates[`incidents/${incidentId}/evacuation_state/closedBy`] =
          FUNCTION_NAME;
        updates[`incidents/${incidentId}/evacuation_state/evacuationStarted`] =
          false;

        closedEvacuation = true;

        eventWrites.push(
          pushIncidentEvent(db, incidentId, siteId, "EVACUATION_CLOSED", {
            previousStatus: evacuationStatus,
            newStatus: "CLOSED",
            incidentStatus: afterStatus,
          }),
        );
      }
    }

    const responderCleanup = buildResponderCleanupUpdates(
      incidentId,
      afterIncident,
      afterStatus,
      now,
    );
    Object.assign(updates, responderCleanup.updates);
    cancelledResponderCount = responderCleanup.cancelledResponderCount;
    if (responderCleanup.shouldEmitEvent) {
      eventWrites.push(
        pushIncidentEvent(
          db,
          incidentId,
          siteId,
          "DISPATCH_RESPONDERS_CANCELLED_BY_DEACTIVATION",
          {
            incidentStatus: afterStatus,
            cancelledResponderCount: responderCleanup.cancelledResponderCount,
            previousPendingRequestedResponders:
              responderCleanup.previousPendingRequestedResponders,
            previousActiveResponders: responderCleanup.previousActiveResponders,
            cleanupReason: `INCIDENT_${afterStatus || "INACTIVE"}_CLEANUP`,
          },
        ),
      );
    }

    if (Object.keys(updates).length === 0 && eventWrites.length === 0) {
      logger.info("Cleanup skipped - nothing to close", {
        incidentId,
        siteId,
        status: afterStatus,
      });
      return;
    }

    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
    }
    if (eventWrites.length > 0) {
      await Promise.all(eventWrites);
    }

    logger.info("Incident execution cleanup completed", {
      incidentId,
      siteId,
      incidentStatus: afterStatus,
      openStepCount,
      closedPlaybookCount,
      closedDispatchRequestCount,
      closedExternalRequestCount,
      skippedTerminalExternalRequestCount,
      closedEvacuation,
      cancelledResponderCount,
    });
  },
);

type ResponderCleanupResult = {
  updates: Record<string, unknown>;
  cancelledResponderCount: number;
  previousPendingRequestedResponders: number;
  previousActiveResponders: number;
  shouldEmitEvent: boolean;
};

function buildResponderCleanupUpdates(
  incidentId: string,
  incident: IncidentLike,
  afterStatus: string,
  now: number,
): ResponderCleanupResult {
  const updates: Record<string, unknown> = {};
  const isFinalClosure = afterStatus === "CLOSED";
  const nextOpenResponderStatus = isFinalClosure
    ? "COMPLETED_BY_INCIDENT_CLOSURE"
    : "CANCELLED";
  const nextDispatchStatus = isFinalClosure ? "CLOSED" : "CANCELLED";
  const responders = safeRecord(incident.responders);
  const dispatchState = safeRecord(incident.dispatch_state);

  let cancelledResponderCount = 0;
  let completedResponderCount = 0;
  let requestedResponderCount = 0;

  Object.entries(responders).forEach(([userId, responderRaw]) => {
    const responder = safeRecord(responderRaw);
    const status = normalizeEnumText(responder.status || "");

    if (
      status === "COMPLETED" ||
      status === "CANCELLED" ||
      status === "COMPLETED_BY_INCIDENT_CLOSURE"
    ) {
      if (status === "COMPLETED" || status === "COMPLETED_BY_INCIDENT_CLOSURE")
        completedResponderCount += 1;
      return;
    }

    if (
      status === "REQUESTED" ||
      status === "RESPONDING" ||
      status === "ARRIVED" ||
      status === "ON_SCENE" ||
      status === "IN_PROGRESS" ||
      status === "EN_ROUTE" ||
      !status
    ) {
      updates[`incidents/${incidentId}/responders/${userId}/status`] =
        nextOpenResponderStatus;
      updates[`incidents/${incidentId}/responders/${userId}/statusUpdatedAt`] =
        now;
      updates[`incidents/${incidentId}/responders/${userId}/lastUpdatedAt`] =
        now;
      updates[`incidents/${incidentId}/responders/${userId}/cancelledAt`] =
        isFinalClosure ? 0 : now;
      updates[`incidents/${incidentId}/responders/${userId}/completedAt`] =
        isFinalClosure ? now : toNumber(responder.completedAt, 0);
      updates[`incidents/${incidentId}/responders/${userId}/cleanupBy`] =
        FUNCTION_NAME;
      updates[`incidents/${incidentId}/responders/${userId}/cleanupReason`] =
        `INCIDENT_${afterStatus || "INACTIVE"}_CLEANUP`;
      cancelledResponderCount += 1;
      if (isFinalClosure) completedResponderCount += 1;
    }
  });

  const previousPendingRequestedResponders = toNumber(
    incident.pendingRequestedResponders ??
      dispatchState.pendingRequestedResponders,
    0,
  );
  const previousActiveResponders = toNumber(
    incident.activeResponders ??
      dispatchState.activeResponders ??
      dispatchState.effectiveResponders,
    0,
  );
  const totalTrackedResponders = Math.max(
    Object.keys(responders).length,
    toNumber(
      incident.totalTrackedResponders ?? dispatchState.totalTrackedResponders,
      0,
    ),
  );
  requestedResponderCount = Math.max(
    totalTrackedResponders - completedResponderCount - cancelledResponderCount,
    0,
  );

  updates[`dispatch_state/${incidentId}/status`] = nextDispatchStatus;
  updates[`dispatch_state/${incidentId}/lastDispatchUpdate`] = now;
  updates[`dispatch_state/${incidentId}/pendingRequestedResponders`] = 0;
  updates[`dispatch_state/${incidentId}/activeResponders`] = 0;
  updates[`dispatch_state/${incidentId}/effectiveResponders`] = 0;
  updates[`dispatch_state/${incidentId}/respondingResponders`] = 0;
  updates[`dispatch_state/${incidentId}/arrivedResponders`] = 0;
  updates[`dispatch_state/${incidentId}/hasRequestedResponder`] = false;
  updates[`dispatch_state/${incidentId}/hasRespondingResponder`] = false;
  updates[`dispatch_state/${incidentId}/hasArrivedResponder`] = false;
  updates[`dispatch_state/${incidentId}/cancelledResponders`] =
    cancelledResponderCount;
  updates[`dispatch_state/${incidentId}/completedResponders`] =
    completedResponderCount;
  updates[`dispatch_state/${incidentId}/requestedResponders`] =
    totalTrackedResponders;
  updates[`dispatch_state/${incidentId}/totalTrackedResponders`] =
    totalTrackedResponders;
  updates[`dispatch_state/${incidentId}/respondersByStatus`] = {
    ...(completedResponderCount > 0
      ? { COMPLETED: completedResponderCount }
      : {}),
    ...(cancelledResponderCount > 0
      ? { [nextOpenResponderStatus]: cancelledResponderCount }
      : {}),
    ...(requestedResponderCount > 0
      ? { REQUESTED: requestedResponderCount }
      : {}),
  };

  Object.entries(responders).forEach(([userId, responderRaw]) => {
    const responder = safeRecord(responderRaw);
    const status = normalizeEnumText(responder.status || "");
    if (
      status === "COMPLETED" ||
      status === "CANCELLED" ||
      status === "COMPLETED_BY_INCIDENT_CLOSURE"
    ) {
      return;
    }
    updates[`dispatch_state/${incidentId}/responders/${userId}/status`] =
      nextOpenResponderStatus;
    updates[
      `dispatch_state/${incidentId}/responders/${userId}/statusUpdatedAt`
    ] = now;
    updates[`dispatch_state/${incidentId}/responders/${userId}/lastUpdatedAt`] =
      now;
    updates[`dispatch_state/${incidentId}/responders/${userId}/cancelledAt`] =
      isFinalClosure ? 0 : now;
    updates[`dispatch_state/${incidentId}/responders/${userId}/completedAt`] =
      isFinalClosure ? now : toNumber(responder.completedAt, 0);
    updates[`dispatch_state/${incidentId}/responders/${userId}/cleanupBy`] =
      FUNCTION_NAME;
    updates[`dispatch_state/${incidentId}/responders/${userId}/cleanupReason`] =
      `INCIDENT_${afterStatus || "INACTIVE"}_CLEANUP`;
  });

  return {
    updates,
    cancelledResponderCount,
    previousPendingRequestedResponders,
    previousActiveResponders,
    shouldEmitEvent:
      cancelledResponderCount > 0 ||
      previousPendingRequestedResponders > 0 ||
      previousActiveResponders > 0,
  };
}

async function resolveIncidentPolicy(
  db: admin.database.Database,
  siteId: string,
  incident: IncidentLike,
): Promise<{ policyKey: string; policy: IncidentPolicy } | null> {
  const policiesSnap = await db
    .ref(`site_config_data/${siteId}/incident_policies`)
    .get();

  if (!policiesSnap.exists()) {
    return null;
  }

  const incidentCategory = normalizeEnumText(incident.category);
  const incidentType = normalizeEnumText(incident.type);
  const incidentSubtype = normalizeEnumText(incident.subtype);

  let exactMatch: { policyKey: string; policy: IncidentPolicy } | null = null;
  let fallbackByCategory: { policyKey: string; policy: IncidentPolicy } | null =
    null;

  policiesSnap.forEach((child) => {
    const policyKey = child.key || "";
    const policy = (child.val() || {}) as IncidentPolicy;

    if (policy.enabled === false) return false;

    const matchCategories = sanitizeBooleanRecord(
      (policy as any).matchCategories,
    );
    const matchTypes = sanitizeBooleanRecord((policy as any).matchTypes);

    const categoryMatched =
      matchCategories[incidentCategory] === true ||
      normalizeEnumText(policy.category) === incidentCategory ||
      normalizeEnumText(policyKey) === incidentCategory;

    const typeMatched =
      matchTypes[incidentType] === true ||
      matchTypes[incidentSubtype] === true ||
      normalizeEnumText(policyKey) === incidentType ||
      normalizeEnumText(policyKey) === incidentSubtype;

    if (categoryMatched && typeMatched) {
      exactMatch = { policyKey, policy };
      return true;
    }

    if (categoryMatched && fallbackByCategory == null) {
      fallbackByCategory = { policyKey, policy };
    }

    return false;
  });

  return exactMatch ?? fallbackByCategory;
}

function evaluateClosureReadiness(
  incident: IncidentLike,
  executionRuntime: ExecutionRuntime,
  playbookDispatchRequests: Record<string, any>,
  externalNotificationRequests: Record<string, any>,
  policy: IncidentPolicy | null,
): ClosureReadiness {
  const requiresActionsCompleted =
    policy?.workflowExtensions?.closure?.requiresActionsCompleted === true;
  const requiresInvestigationCompleted =
    policy?.workflowExtensions?.closure?.requiresInvestigationCompleted ===
    true;
  const isOverrideClosure =
    normalizeEnumText(incident.closureMode || "") === "OVERRIDE";

  const openStepCount = countOpenRuntimeSteps(executionRuntime, incident);
  const openDispatchRequestCount = countOpenDispatchRequests(
    playbookDispatchRequests,
    incident,
  );
  const openExternalNotificationCount = countOpenExternalNotifications(
    externalNotificationRequests,
  );
  const openSingleTrackActionCount = countOpenSingleTrackActions(incident);
  const openDimensionActionCount = countOpenDimensionActions(incident);
  const incompleteInvestigationCount = countIncompleteInvestigations(
    incident,
    policy,
  );

  const blockingReasons: string[] = [];

  if (!isOverrideClosure) {
    if (openStepCount > 0) blockingReasons.push("OPEN_PLAYBOOK_STEPS");
    if (openDispatchRequestCount > 0)
      blockingReasons.push("OPEN_DISPATCH_REQUESTS");
    if (openExternalNotificationCount > 0) {
      blockingReasons.push("OPEN_EXTERNAL_NOTIFICATIONS");
    }
  }

  if (requiresActionsCompleted && !isOverrideClosure) {
    if (openSingleTrackActionCount > 0) blockingReasons.push("OPEN_ACTIONS");
    if (openDimensionActionCount > 0)
      blockingReasons.push("OPEN_DIMENSION_ACTIONS");
  }

  if (
    requiresInvestigationCompleted &&
    !isOverrideClosure &&
    incompleteInvestigationCount > 0
  ) {
    blockingReasons.push("INCOMPLETE_INVESTIGATION");
  }

  return {
    canClose: blockingReasons.length === 0,
    requiresActionsCompleted,
    requiresInvestigationCompleted,
    openStepCount,
    openDispatchRequestCount,
    openExternalNotificationCount,
    openSingleTrackActionCount,
    openDimensionActionCount,
    incompleteInvestigationCount,
    blockingReasons,
  };
}

function countOpenRuntimeSteps(
  executionRuntime: ExecutionRuntime,
  incident: IncidentLike,
): number {
  let count = 0;
  Object.values(executionRuntime.playbooks || {}).forEach((playbook) => {
    Object.values(playbook.steps || {}).forEach((stepRaw) => {
      const step = safeRecord(stepRaw);
      const status = normalizeEnumText(step.status || "PENDING");
      if (isTerminalStepStatus(status)) return;

      // Enterprise test rule:
      // REQUESTED responders who never accepted/started must not block closure.
      // Dispatch / evacuation preparation steps block closure only when there is
      // real active field movement (RESPONDING / ARRIVED / ON_SCENE / IN_PROGRESS).
      if (
        isFieldMovementStepType(normalizeEnumText(step.type || "")) &&
        !hasActiveUncompletedResponders(incident)
      ) {
        return;
      }

      count += 1;
    });
  });
  return count;
}

function countOpenDispatchRequests(
  requests: Record<string, any>,
  incident: IncidentLike,
): number {
  let count = 0;
  Object.entries(requests || {}).forEach(([requestKey, requestRaw]) => {
    const request = safeRecord(requestRaw);
    const status = normalizeEnumText(request.status || "");
    if (isTerminalDispatchStatus(status)) return;

    // A dispatch request that only has untouched REQUESTED responders should not
    // prevent closure. It becomes blocking only if at least one responder actually
    // started moving toward the incident and has not completed/cancelled.
    if (
      hasActiveUncompletedResponderForDispatchRequest(
        incident,
        requestKey,
        request,
      )
    ) {
      count += 1;
    }
  });
  return count;
}

function isFieldMovementStepType(stepType: string): boolean {
  return (
    stepType === "DISPATCH_TEAM" ||
    stepType === "PREPARE_EVACUATION" ||
    stepType === "EVACUATION"
  );
}

function hasActiveUncompletedResponders(incident: IncidentLike): boolean {
  return Object.values(safeRecord(incident.responders)).some((responderRaw) =>
    isActiveUncompletedResponder(safeRecord(responderRaw)),
  );
}

function hasActiveUncompletedResponderForDispatchRequest(
  incident: IncidentLike,
  requestKey: string,
  request: Record<string, any>,
): boolean {
  const requestId = String(request.id || requestKey || "");
  const requestTeam = normalizeEnumText(request.team || "");

  return Object.values(safeRecord(incident.responders)).some((responderRaw) => {
    const responder = safeRecord(responderRaw);
    if (!isActiveUncompletedResponder(responder)) return false;

    const responderDispatchId = String(responder.sourceDispatchRequestId || "");
    const responderTeam = normalizeEnumText(responder.team || "");

    return (
      (requestId.length > 0 && responderDispatchId === requestId) ||
      (requestTeam.length > 0 && responderTeam === requestTeam)
    );
  });
}

function isActiveUncompletedResponder(responder: Record<string, any>): boolean {
  const status = normalizeEnumText(responder.status || "");
  return (
    status === "RESPONDING" ||
    status === "ARRIVED" ||
    status === "ON_SCENE" ||
    status === "IN_PROGRESS" ||
    status === "EN_ROUTE"
  );
}

function countOpenExternalNotifications(requests: Record<string, any>): number {
  let count = 0;
  Object.values(requests || {}).forEach((requestRaw) => {
    const status = normalizeEnumText((requestRaw || {}).status || "");
    if (!isTerminalExternalNotificationStatus(status)) count += 1;
  });
  return count;
}

function countOpenSingleTrackActions(incident: IncidentLike): number {
  const summary = safeRecord(incident.incidentActionsSummary);
  const status = normalizeEnumText(summary.status || "");

  if (!Object.keys(summary).length) return 0;
  if (
    status === "NOT_REQUIRED" ||
    status === "COMPLETED" ||
    status === "CLOSED"
  ) {
    return 0;
  }

  const total = toNumber(summary.total, 0);
  const open = toNumber(summary.open, 0);
  const accepted = toNumber(summary.accepted, 0);
  const overdue = toNumber(summary.overdue, 0);
  const completed = toNumber(summary.completed, 0);

  if (total <= 0) return 0;
  return Math.max(open + accepted + overdue, total - completed, 0);
}

function countOpenDimensionActions(incident: IncidentLike): number {
  let count = 0;
  const dimensionActions = safeRecord(incident.dimensionActions);

  Object.values(dimensionActions).forEach((actionsRaw) => {
    const actions = safeRecord(actionsRaw);
    Object.values(actions).forEach((actionRaw) => {
      const status = normalizeEnumText(safeRecord(actionRaw).status || "");
      if (
        status !== "COMPLETED" &&
        status !== "CLOSED" &&
        status !== "CANCELLED"
      ) {
        count += 1;
      }
    });
  });

  return count;
}

function countIncompleteInvestigations(
  incident: IncidentLike,
  policy: IncidentPolicy | null,
): number {
  const closureRequiresInvestigation =
    policy?.workflowExtensions?.closure?.requiresInvestigationCompleted ===
    true;
  const investigationRequiredByPolicy =
    policy?.workflowExtensions?.investigation?.enabled === true &&
    policy?.workflowExtensions?.investigation?.requiredBeforeClosure === true;

  if (!closureRequiresInvestigation && !investigationRequiredByPolicy) {
    return 0;
  }

  const selectedReviewDimensions = sanitizeBooleanRecord(
    incident.selectedReviewDimensions,
  );
  const dimensionTracks = safeRecord(incident.dimensionTracks);
  const dimensionInvestigations = safeRecord(incident.dimensionInvestigations);
  const activeDimensionKeys = new Set<string>();

  Object.keys(selectedReviewDimensions).forEach((key) =>
    activeDimensionKeys.add(key),
  );
  Object.keys(dimensionTracks).forEach((key) =>
    activeDimensionKeys.add(normalizeEnumText(key)),
  );
  Object.keys(dimensionInvestigations).forEach((key) =>
    activeDimensionKeys.add(normalizeEnumText(key)),
  );

  if (activeDimensionKeys.size > 0) {
    let count = 0;
    activeDimensionKeys.forEach((dimensionKey) => {
      const investigation = safeRecord(
        dimensionInvestigations[dimensionKey] ||
          dimensionInvestigations[dimensionKey.toLowerCase()],
      );
      const status = normalizeEnumText(investigation.status || "");
      if (status !== "COMPLETED" && status !== "NOT_REQUIRED") {
        count += 1;
      }
    });
    return count;
  }

  const investigation = safeRecord(incident.investigation);
  const status = normalizeEnumText(investigation.status || "");
  return status === "COMPLETED" || status === "NOT_REQUIRED" ? 0 : 1;
}

function resolveRestoredStatus(beforeStatus: string): string {
  if (
    beforeStatus &&
    beforeStatus !== "CLOSED" &&
    beforeStatus !== "DEACTIVATED" &&
    beforeStatus !== "REJECTED"
  ) {
    return beforeStatus;
  }
  return "UNDER_CONTROL";
}

function isTerminalStepStatus(status: string): boolean {
  return (
    status === "COMPLETED" ||
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE"
  );
}

function isTerminalDispatchStatus(status: string): boolean {
  return (
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE"
  );
}

function sanitizeBooleanRecord(value: unknown): Record<string, boolean> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};

  const result: Record<string, boolean> = {};
  Object.entries(value as Record<string, unknown>).forEach(([key, enabled]) => {
    if (enabled === true) {
      result[normalizeEnumText(key)] = true;
    }
  });
  return result;
}

function safeRecord(value: unknown): Record<string, any> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, any>)
    : {};
}

function sanitizeExecutionRuntime(value: unknown): ExecutionRuntime {
  const runtime = (value || {}) as ExecutionRuntime;
  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object"
      ? runtime.playbooks
      : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput).forEach(([playbookId, playbookRaw]) => {
    const playbook = (playbookRaw || {}) as RuntimePlaybook;
    const stepsInput =
      playbook.steps && typeof playbook.steps === "object"
        ? playbook.steps
        : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as RuntimeStep;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title || stepId),
        status: normalizeEnumText(step.status || "PENDING"),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title || playbookId),
      status: normalizeEnumText(playbook.status || "ACTIVE"),
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    status: normalizeEnumText(runtime.status || ""),
    playbooks: sanitizedPlaybooks,
  };
}

function isTerminalExternalNotificationStatus(status: string): boolean {
  return (
    status === "CLOSED" ||
    status === "CANCELLED" ||
    status === "COMPLETED" ||
    status === "COMPLETED_BY_INCIDENT_CLOSURE" ||
    status === "REJECTED" ||
    status === "FAILED" ||
    status === "SENT" ||
    status === "ACKNOWLEDGED"
  );
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>,
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function normalizeEnumText(value: unknown): string {
  return String(value || "")
    .trim()
    .toUpperCase();
}

function safeString(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}
