import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RuntimeStep = {
  id?: string;
  type?: string;
  title?: string;
  description?: string;
  enabled?: boolean;
  status?: string;
  createdAt?: number;
  startedAt?: number | null;
  completedAt?: number | null;
  executionMode?: string;
  executionResult?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  targetRoles?: string[];
  team?: string;
  mode?: string;
  targets?: string[];
};

type RuntimePlaybook = {
  id?: string;
  title?: string;
  description?: string;
  priority?: number;
  status?: string;
  activatedAt?: number;
  lastEvaluatedAt?: number;
  trigger?: Record<string, unknown>;
  steps?: Record<string, RuntimeStep>;
};

type ExecutionRuntime = {
  schemaVersion?: number;
  category?: string;
  overallRisk?: string;
  updatedAt?: number;
  playbooks?: Record<string, RuntimePlaybook>;
  status?: string;
};

type IncidentLike = Record<string, any>;

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "executeDispatchTeamSteps";

export const executeDispatchTeamSteps = onValueWritten(
  {
    ref: "/incidents/{incidentId}/incident_playbook_execution",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    if (!event.data.after.exists()) {
      logger.info("Dispatch team executor skipped - runtime removed", {
        incidentId,
      });
      return;
    }

    const runtime = sanitizeExecutionRuntime(event.data.after.val() || {});
    if (normalizeEnumText(runtime.status || "") === "CLOSED") {
      logger.info("Dispatch team executor skipped - playbook execution closed", {
        incidentId,
      });
      return;
    }

    const incidentSnap = await db.ref(`incidents/${incidentId}`).get();
    if (!incidentSnap.exists()) {
      logger.warn("Dispatch team executor skipped - incident missing", {
        incidentId,
      });
      return;
    }

    const incident = (incidentSnap.val() || {}) as IncidentLike;
    const siteId = safeString(incident.siteId ?? incident.site ?? "");

    if (!siteId) {
      logger.warn("Dispatch team executor skipped - missing siteId", {
        incidentId,
      });
      return;
    }

    const incidentStatus = normalizeEnumText(incident.status || "");
    const incidentActive = toBoolean(incident.active) === true;
    if (!incidentActive || incidentStatus === "DEACTIVATED" || incidentStatus === "CLOSED") {
      logger.info("Dispatch team executor skipped - incident not operational", {
        incidentId,
        siteId,
        incidentStatus,
        incidentActive,
      });
      return;
    }

    const actions = resolveDispatchTeamActions(runtime);

    if (actions.length === 0) {
      logger.info("Dispatch team executor skipped - no dispatch steps", {
        incidentId,
        siteId,
      });
      return;
    }

    const rootUpdates: Record<string, unknown> = {};
    const createdEvents: Array<Promise<void>> = [];
    let createdCount = 0;

    for (const action of actions) {
      const requestId = `${action.playbookId}_${action.stepId}`;
      const requestPath = `incidents/${incidentId}/playbook_dispatch_requests/${requestId}`;

      const existingSnap = await db.ref(requestPath).get();
      if (existingSnap.exists()) {
        continue;
      }

      const now = Date.now();

      rootUpdates[`${requestPath}/id`] = requestId;
      rootUpdates[`${requestPath}/incidentId`] = incidentId;
      rootUpdates[`${requestPath}/siteId`] = siteId;
      rootUpdates[`${requestPath}/playbookId`] = action.playbookId;
      rootUpdates[`${requestPath}/playbookTitle`] = action.playbookTitle;
      rootUpdates[`${requestPath}/stepId`] = action.stepId;
      rootUpdates[`${requestPath}/stepTitle`] = action.stepTitle;
      rootUpdates[`${requestPath}/team`] = action.team;
      rootUpdates[`${requestPath}/status`] = "REQUESTED";
      rootUpdates[`${requestPath}/requestedAt`] = now;
      rootUpdates[`${requestPath}/requestedBy`] = FUNCTION_NAME;
      rootUpdates[`${requestPath}/source`] = "PLAYBOOK_EXECUTOR_V1";
      rootUpdates[`${requestPath}/eventLogged`] = true;

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/dispatchRequestId`
      ] = requestId;

      rootUpdates[
        `incidents/${incidentId}/incident_playbook_execution/playbooks/${action.playbookId}/steps/${action.stepId}/executionResult/dispatchRequestStatus`
      ] = "REQUESTED";

      createdEvents.push(
        pushIncidentEvent(db, incidentId, siteId, "PLAYBOOK_DISPATCH_REQUESTED", {
          playbookId: action.playbookId,
          playbookTitle: action.playbookTitle,
          stepId: action.stepId,
          stepTitle: action.stepTitle,
          team: action.team,
          dispatchRequestId: requestId,
          status: "REQUESTED",
        })
      );

      createdCount += 1;
    }

    if (Object.keys(rootUpdates).length === 0) {
      logger.info("Dispatch team executor skipped - requests already exist", {
        incidentId,
        siteId,
      });
      return;
    }

    await db.ref().update(rootUpdates);
    await Promise.all(createdEvents);

    logger.info("Dispatch team executor completed", {
      incidentId,
      siteId,
      requestsCreated: createdCount,
    });
  }
);

function resolveDispatchTeamActions(runtime: ExecutionRuntime): Array<{
  playbookId: string;
  playbookTitle: string;
  stepId: string;
  stepTitle: string;
  team: string;
}> {
  const actions: Array<{
    playbookId: string;
    playbookTitle: string;
    stepId: string;
    stepTitle: string;
    team: string;
  }> = [];

  const playbooks = runtime.playbooks || {};

  Object.entries(playbooks).forEach(([playbookId, playbookRaw]) => {
    const playbook = playbookRaw as RuntimePlaybook;
    if (normalizeEnumText(playbook.status || "") === "CLOSED") return;

    const playbookTitle = safeString(playbook.title || playbookId);
    const steps = playbook.steps || {};

    Object.entries(steps).forEach(([stepId, stepRaw]) => {
      const step = stepRaw as RuntimeStep;

      if (step.enabled === false) return;
      if (normalizeEnumText(step.type || "") !== "DISPATCH_TEAM") return;
      if (normalizeEnumText(step.status || "") !== "IN_PROGRESS") return;

      const dispatchRequestId =
        safeString(
          (step.executionResult as Record<string, unknown> | undefined)?.dispatchRequestId
        ) || "";

      if (dispatchRequestId) return;

      const team = safeString(step.team);
      if (!team) return;

      actions.push({
        playbookId,
        playbookTitle,
        stepId,
        stepTitle: safeString(step.title || stepId),
        team,
      });
    });
  });

  return actions;
}

function sanitizeExecutionRuntime(value: unknown): ExecutionRuntime {
  const runtime = (value || {}) as ExecutionRuntime;
  const playbooksInput =
    runtime.playbooks && typeof runtime.playbooks === "object" ? runtime.playbooks : {};

  const sanitizedPlaybooks: Record<string, RuntimePlaybook> = {};

  Object.entries(playbooksInput).forEach(([playbookId, playbookRaw]) => {
    const playbook = (playbookRaw || {}) as RuntimePlaybook;
    const stepsInput =
      playbook.steps && typeof playbook.steps === "object" ? playbook.steps : {};

    const sanitizedSteps: Record<string, RuntimeStep> = {};

    Object.entries(stepsInput).forEach(([stepId, stepRaw]) => {
      const step = (stepRaw || {}) as RuntimeStep;

      sanitizedSteps[stepId] = {
        id: safeString(step.id || stepId),
        type: normalizeEnumText(step.type || ""),
        title: safeString(step.title || stepId),
        description: safeString(step.description),
        enabled: step.enabled !== false,
        status: normalizeEnumText(step.status || "PENDING"),
        createdAt: toNumber(step.createdAt, 0),
        startedAt: toNumberOrNull(step.startedAt),
        completedAt: toNumberOrNull(step.completedAt),
        executionMode: safeString(step.executionMode),
        executionResult:
          step.executionResult && typeof step.executionResult === "object"
            ? step.executionResult
            : {},
        metadata: step.metadata && typeof step.metadata === "object" ? step.metadata : {},
        targetRoles: Array.isArray(step.targetRoles)
          ? step.targetRoles.map((x) => safeString(x)).filter(Boolean)
          : [],
        team: safeString(step.team),
        mode: safeString(step.mode),
        targets: Array.isArray(step.targets)
          ? step.targets.map((x) => safeString(x)).filter(Boolean)
          : [],
      };
    });

    sanitizedPlaybooks[playbookId] = {
      id: safeString(playbook.id || playbookId),
      title: safeString(playbook.title || playbookId),
      description: safeString(playbook.description),
      priority: toNumber(playbook.priority, 100),
      status: safeString(playbook.status || "ACTIVE"),
      activatedAt: toNumber(playbook.activatedAt, 0),
      lastEvaluatedAt: toNumber(playbook.lastEvaluatedAt, 0),
      trigger: playbook.trigger && typeof playbook.trigger === "object" ? playbook.trigger : {},
      steps: sanitizedSteps,
    };
  });

  return {
    schemaVersion: toNumber(runtime.schemaVersion, 1),
    category: normalizeEnumText(runtime.category || ""),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    updatedAt: toNumber(runtime.updatedAt, 0),
    status: normalizeEnumText(runtime.status || ""),
    playbooks: sanitizedPlaybooks,
  };
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function normalizeEnumText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}