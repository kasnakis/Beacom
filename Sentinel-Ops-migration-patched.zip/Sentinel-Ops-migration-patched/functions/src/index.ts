import * as admin from "firebase-admin";
import { setGlobalOptions } from "firebase-functions/v2";

import { processNotificationRequest } from "./notifications/processNotificationRequest";
import { resolveIncidentNotifications } from "./resolveIncidentNotifications";
import { resolveIncidentActionNotifications } from "./notifications/resolveIncidentActionNotifications";
import { resolveIncidentActionCompletionNotifications } from "./notifications/resolveIncidentActionCompletionNotifications";
import { evaluateIncidentDispatch } from "./dispatch/evaluateIncidentDispatch";
import { materializeDispatchRespondersFromPlaybookRequest } from "./dispatch/materializeDispatchRespondersFromPlaybookRequest";
import { evaluateIncidentRisk } from "./risk/evaluateIncidentRisk";
import { evaluateIncidentPlaybook } from "./playbooks/evaluateIncidentPlaybook";
import { executeIncidentPlaybookSteps } from "./playbooks/executeIncidentPlaybookSteps";
import { executeDispatchTeamSteps } from "./playbooks/executeDispatchTeamSteps";
import { executeEvacuationSteps } from "./playbooks/executeEvacuationSteps";
import { executeExternalNotificationSteps } from "./playbooks/executeExternalNotificationSteps";
import { cleanupIncidentExecutionState } from "./playbooks/cleanupIncidentExecutionState";
import { syncExternalNotificationLifecycle } from "./playbooks/syncExternalNotificationLifecycle";
import {
  approveExternalNotification,
  rejectExternalNotification,
  markExternalNotificationSent,
  acknowledgeExternalNotification,
  failExternalNotification,
  cancelExternalNotification,
} from "./externalNotifications/manageExternalNotification";
import { runPendingNotificationRetries } from "./runPendingNotificationRetries";
import { submitReviewAction } from "./review/submitReviewAction";
import { expandIncidentDimensions } from "./review/expandIncidentDimensions";
import { assignDimensionAction } from "./review/assignDimensionAction";
import { respondDimensionAction } from "./review/respondDimensionAction";
import { closeIncident } from "./review/closeIncident";
import { completeDimensionInvestigation } from "./review/completeDimensionInvestigation";
import { completeDimensionAction } from "./review/completeDimensionAction";
import { upsertEnvironmentalInvestigation } from "./review/upsertEnvironmentalInvestigation";
import { upsertEnvironmentalAction } from "./review/environmentalActions";
import { createAdminUser } from "./userManagement/createAdminUser";

// ✅ ΝΕΟ ENGINE (External Notification Engine)
import { externalNotificationEngine } from "./externalNotificationEngine";

admin.initializeApp();

setGlobalOptions({
  region: "europe-west1",
  maxInstances: 10,
  timeoutSeconds: 60,
  memory: "256MiB",
});

export {
  processNotificationRequest,
  resolveIncidentNotifications,
  resolveIncidentActionNotifications,
  resolveIncidentActionCompletionNotifications,
  evaluateIncidentDispatch,
  materializeDispatchRespondersFromPlaybookRequest,
  evaluateIncidentRisk,
  evaluateIncidentPlaybook,
  executeIncidentPlaybookSteps,
  executeDispatchTeamSteps,
  executeEvacuationSteps,
  executeExternalNotificationSteps,
  cleanupIncidentExecutionState,
  syncExternalNotificationLifecycle,
  approveExternalNotification,
  rejectExternalNotification,
  markExternalNotificationSent,
  acknowledgeExternalNotification,
  failExternalNotification,
  cancelExternalNotification,
  runPendingNotificationRetries,
  submitReviewAction,
  expandIncidentDimensions,
  assignDimensionAction,
  respondDimensionAction,
  closeIncident,
  completeDimensionInvestigation,
  completeDimensionAction,
  upsertEnvironmentalInvestigation,
  upsertEnvironmentalAction,
  createAdminUser,

  // ✅ ΝΕΟ EXPORT
  externalNotificationEngine,
};