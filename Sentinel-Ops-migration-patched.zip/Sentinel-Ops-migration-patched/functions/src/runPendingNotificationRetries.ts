import { onSchedule } from "firebase-functions/v2/scheduler";
import { logger } from "firebase-functions";
import { db } from "./notifications/db";

export const runPendingNotificationRetries = onSchedule(
  {
    schedule: "every 2 minutes",
    timeZone: "Europe/Athens",
    region: "europe-west1",
    memory: "256MiB",
    timeoutSeconds: 120,
  },
  async () => {
    const now = Date.now();
    const snap = await db()
      .ref("notification_requests")
      .orderByChild("status")
      .equalTo("RETRY_SCHEDULED")
      .get();

    if (!snap.exists()) {
      logger.info("No notification retries pending");
      return;
    }

    const requests = snap.val() || {};
    const dueEntries = Object.entries<any>(requests)
      .filter(([, value]) => Number(value?.retry?.nextRetryAt || 0) <= now)
      .sort(
        (a, b) =>
          Number(a[1]?.retry?.nextRetryAt || 0) -
          Number(b[1]?.retry?.nextRetryAt || 0)
      )
      .slice(0, 50);

    logger.info("Notification retries scan", {
      totalScheduled: Object.keys(requests).length,
      dueCount: dueEntries.length,
    });

    for (const [requestId] of dueEntries) {
      try {
        await db().ref(`notification_requests/${requestId}`).update({
          status: "PENDING",
          "meta/processedAt": 0,
        });
      } catch (error) {
        logger.error("Retry reschedule failed", {
          requestId,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }
);