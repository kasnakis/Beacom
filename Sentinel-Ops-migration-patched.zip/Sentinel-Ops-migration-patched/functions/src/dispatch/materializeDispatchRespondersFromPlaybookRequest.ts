import { onValueCreated } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type JsonMap = Record<string, any>;

type DispatchPolicyConfig = {
  enabled?: boolean;
  trackingEnabled?: boolean;
  responseTeams?: Record<string, boolean> | string[];
  responderRoles?: Record<string, boolean> | string[];
  allowedRoles?: Record<string, boolean> | string[];
  excludedRoles?: Record<string, boolean> | string[];
};

type UserRecordShape = {
  uid?: string;
  id?: string;
  userId?: string;
  displayName?: string;
  name?: string;
  fullName?: string;
  siteId?: string;
  primarySiteId?: string;
  site?: string;
  role?: string;
  roles?: Record<string, boolean> | string[];
  operationalRoles?: Record<string, boolean> | string[];
  teams?: Record<string, boolean> | string[];
  responseTeams?: Record<string, boolean> | string[];
  active?: boolean;
  enabled?: boolean;
};

function normalizeText(value: unknown): string {
  return String(value ?? "").trim();
}

function normalizeUpper(value: unknown): string {
  return normalizeText(value).toUpperCase();
}

function asBoolean(value: unknown, fallback = false): boolean {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const v = value.trim().toLowerCase();
    if (v === "true" || v === "1" || v === "yes") return true;
    if (v === "false" || v === "0" || v === "no") return false;
  }
  return fallback;
}

function readStringSet(value: unknown): Set<string> {
  const result = new Set<string>();

  if (Array.isArray(value)) {
    for (const item of value) {
      const normalized = normalizeUpper(item);
      if (normalized) result.add(normalized);
    }
    return result;
  }

  if (value && typeof value === "object") {
    for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
      if (asBoolean(raw, false)) {
        const normalized = normalizeUpper(key);
        if (normalized) result.add(normalized);
      }
    }
    return result;
  }

  const single = normalizeUpper(value);
  if (single) result.add(single);

  return result;
}

function userRolesOf(user: UserRecordShape): Set<string> {
  const roles = new Set<string>();

  const directRole = normalizeUpper(user.role);
  if (directRole) roles.add(directRole);

  for (const role of readStringSet(user.roles)) {
    roles.add(role);
  }

  for (const role of readStringSet(user.operationalRoles)) {
    roles.add(role);
  }

  return roles;
}

function userTeamsOf(user: UserRecordShape): Set<string> {
  const teams = new Set<string>();

  for (const team of readStringSet(user.teams)) {
    teams.add(team);
  }

  for (const team of readStringSet(user.responseTeams)) {
    teams.add(team);
  }

  return teams;
}

function isUserEnabled(user: UserRecordShape): boolean {
  if (typeof user.enabled !== "undefined") {
    return asBoolean(user.enabled, true);
  }
  if (typeof user.active !== "undefined") {
    return asBoolean(user.active, true);
  }
  return true;
}

function resolveUserDisplayName(user: UserRecordShape, userId: string): string {
  return (
    normalizeText(user.displayName) ||
    normalizeText(user.name) ||
    normalizeText(user.fullName) ||
    userId
  );
}

function getUserSiteId(user: UserRecordShape): string {
  return normalizeText(user.siteId || user.site);
}

function getUserPrimarySiteId(user: UserRecordShape): string {
  return normalizeText(user.primarySiteId);
}

function hasMembershipPermission(
  membership: any | null | undefined,
  permissionKeys: string[],
): boolean {
  if (!membership || typeof membership !== "object") return false;

  const permissions = readStringSet(membership.permissions);
  for (const key of permissionKeys) {
    if (permissions.has(normalizeUpper(key))) return true;
  }

  return false;
}


function intersects(a: Set<string>, b: Set<string>): boolean {
  for (const item of a) {
    if (b.has(item)) return true;
  }
  return false;
}

function hasAny(set: Set<string>): boolean {
  return set.size > 0;
}

function isOriginallyRequested(item: Record<string, unknown>): boolean {
  return (
    asBoolean(item.initialRequested, false) ||
    typeof item.requestedAt === "number" ||
    normalizeUpper(item.source) === "PLAYBOOK_REQUEST" ||
    normalizeText(item.sourceDispatchRequestId).length > 0 ||
    normalizeText(item.sourcePlaybookId).length > 0
  );
}

function cloneBooleanMap(
  value: unknown,
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!value || typeof value !== "object") {
    return result;
  }

  for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
    if (asBoolean(raw, false)) {
      const normalizedKey = normalizeText(key);
      if (normalizedKey) {
        result[normalizedKey] = true;
      }
    }
  }

  return result;
}

function buildDispatchCounters(
  responders: Record<string, any> | null | undefined,
  currentStatus?: string,
  existingInitialRequestedUserIds?: Record<string, boolean>,
) {
  const values = Object.entries(responders || {});
  let pendingRequestedResponders = 0;
  let respondingResponders = 0;
  let arrivedResponders = 0;
  let cancelledResponders = 0;
  let completedResponders = 0;
  let staleResponderCount = 0;
  const respondersByStatus: Record<string, number> = {};
  const respondersByTeam: Record<string, number> = {};
  const requestedTeams: Record<string, boolean> = {};
  const requestedByPlaybooks: Record<string, boolean> = {};
  const initialRequestedUserIds = cloneBooleanMap(existingInitialRequestedUserIds);

  for (const [uid, raw] of values) {
    const item = (raw || {}) as Record<string, unknown>;
    const status = normalizeUpper(item.status);
    const team = normalizeText(item.team);
    const sourcePlaybookId = normalizeText(item.sourcePlaybookId);
    const isStale = asBoolean(item.isStale, false);

    if (team) {
      respondersByTeam[team] = (respondersByTeam[team] || 0) + 1;
      requestedTeams[team] = true;
    }

    if (sourcePlaybookId) {
      requestedByPlaybooks[sourcePlaybookId] = true;
    }

    if (status) {
      respondersByStatus[status] = (respondersByStatus[status] || 0) + 1;
    }

    if (isStale) staleResponderCount += 1;

    if (isOriginallyRequested(item)) {
      initialRequestedUserIds[uid] = true;
      if (status === "REQUESTED") {
        pendingRequestedResponders += 1;
      }
    }

    switch (status) {
      case "RESPONDING":
        if (!isStale) respondingResponders += 1;
        break;
      case "ARRIVED":
        if (!isStale) arrivedResponders += 1;
        break;
      case "CANCELLED":
        cancelledResponders += 1;
        break;
      case "COMPLETED":
        completedResponders += 1;
        break;
      default:
        break;
    }
  }

  const initialRequestedResponders = Object.keys(initialRequestedUserIds).length;
  const activeResponders = respondingResponders + arrivedResponders;
  const status =
    currentStatus && currentStatus.trim().length > 0 ? currentStatus : "PENDING_DISPATCH";

  return {
    status,
    activeResponders,
    effectiveResponders: activeResponders,
    totalTrackedResponders: values.length,

    initialRequestedResponders,
    requestedResponders: initialRequestedResponders,
    pendingRequestedResponders,

    respondingResponders,
    arrivedResponders,
    cancelledResponders,
    completedResponders,
    staleResponderCount,

    hasRequestedResponder: pendingRequestedResponders > 0,
    hasRespondingResponder: respondingResponders > 0,
    hasArrivedResponder: arrivedResponders > 0,

    respondersByStatus,
    respondersByTeam,
    requestedTeams,
    requestedByPlaybooks,
    initialRequestedUserIds,

    lastDispatchUpdate: admin.database.ServerValue.TIMESTAMP,
    dispatchVersion: 6,
    serverOwned: true,
  };
}

async function getIncidentPolicyDispatch(
  siteId: string,
  category: string,
): Promise<DispatchPolicyConfig> {
  const db = admin.database();
  const snap = await db
    .ref(`site_config_data/${siteId}/incident_policies/${category}/dispatch`)
    .get();

  if (!snap.exists()) {
    return {};
  }

  return (snap.val() || {}) as DispatchPolicyConfig;
}

function userMatchesTeam(
  user: UserRecordShape,
  requestedTeam: string,
  responderTeams: Set<string>,
): boolean {
  if (!requestedTeam) {
    return true;
  }

  const normalizedRequestedTeam = normalizeUpper(requestedTeam);
  const userTeams = userTeamsOf(user);

  if (userTeams.has(normalizedRequestedTeam)) {
    return true;
  }

  if (responderTeams.has(normalizedRequestedTeam)) {
    return true;
  }

  return false;
}

function userMatchesAllowedRoles(
  userRoles: Set<string>,
  allowedRoles: Set<string>,
  responderRoles: Set<string>,
): boolean {
  const effectiveAllowed = new Set<string>([...allowedRoles, ...responderRoles]);

  if (!hasAny(effectiveAllowed)) {
    return true;
  }

  return intersects(userRoles, effectiveAllowed);
}

function userMatchesExcludedRoles(
  userRoles: Set<string>,
  excludedRoles: Set<string>,
): boolean {
  if (!hasAny(excludedRoles)) {
    return true;
  }

  return !intersects(userRoles, excludedRoles);
}

function getUserMembershipForSite(
  user: UserRecordShape,
  siteId: string
): any | null {
  const memberships = (user as any).siteMemberships;
  if (!memberships || typeof memberships !== "object") return null;

  const matchKey = Object.keys(memberships).find(
    (key) => normalizeText(key) === siteId
  );

  return matchKey ? memberships[matchKey] : null;
}

export const materializeDispatchRespondersFromPlaybookRequest = onValueCreated(
  {
    ref: "/incidents/{incidentId}/playbook_dispatch_requests/{requestId}",
    instance: "ppc-sentinel-ops-pilot-001-default-rtdb",
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const requestId = event.params.requestId;
    const request = (event.data.val() || {}) as JsonMap;

    const db = admin.database();

    try {
      const siteId = normalizeText(request.siteId);
      const team = normalizeText(request.team);
      const status = normalizeUpper(request.status);

      if (!siteId || !incidentId || !requestId) {
        logger.warn("materializeDispatchRespondersFromPlaybookRequest: missing identifiers", {
          incidentId,
          requestId,
          siteId,
        });
        return;
      }

      if (status && status !== "REQUESTED") {
        logger.info("materializeDispatchRespondersFromPlaybookRequest: skipped non-requested item", {
          incidentId,
          requestId,
          status,
        });
        return;
      }

      const incidentSnap = await db.ref(`incidents/${incidentId}`).get();
      if (!incidentSnap.exists()) {
        logger.warn("materializeDispatchRespondersFromPlaybookRequest: incident not found", {
          incidentId,
          requestId,
        });
        return;
      }

      const incident = (incidentSnap.val() || {}) as JsonMap;
      const category = normalizeText(incident.category || incident.type);

      if (!category) {
        logger.warn("materializeDispatchRespondersFromPlaybookRequest: incident category missing", {
          incidentId,
          requestId,
        });
        return;
      }

      const dispatchPolicy = await getIncidentPolicyDispatch(siteId, category);
      const dispatchEnabled = asBoolean(dispatchPolicy.enabled, true);
      const trackingEnabled = asBoolean(dispatchPolicy.trackingEnabled, true);

      if (!dispatchEnabled) {
        logger.info("materializeDispatchRespondersFromPlaybookRequest: dispatch disabled by policy", {
          incidentId,
          requestId,
          siteId,
          category,
        });
        return;
      }

      const responderRoles = readStringSet(dispatchPolicy.responderRoles);
      const responderTeams = readStringSet(dispatchPolicy.responseTeams);
      const allowedRoles = readStringSet(dispatchPolicy.allowedRoles);
      const excludedRoles = readStringSet(dispatchPolicy.excludedRoles);

      const usersSnap = await db.ref("users").get();
      const users = (usersSnap.val() || {}) as Record<string, UserRecordShape>;

      const responderUpdates: Record<string, any> = {};
      const selectedUsers: Array<{
        userId: string;
        displayName: string;
        role: string;
        team: string;
      }> = [];

      for (const [userId, rawUser] of Object.entries(users)) {
        const user = (rawUser || {}) as UserRecordShape;

        if (!isUserEnabled(user)) {
          continue;
        }

const userSiteId = getUserSiteId(user);
const userPrimarySiteId = getUserPrimarySiteId(user);
const membership = getUserMembershipForSite(user, siteId);
const baseSiteMatches = userSiteId === siteId || userPrimarySiteId === siteId;

if (!baseSiteMatches) {
  if (!membership || membership.active === false) {
    continue;
  }

  // Enterprise-safe cross-site dispatch:
  // legacy active memberships are not enough to be materialized as responders.
  if (!hasMembershipPermission(membership, ["PARTICIPATE_IN_SITE_RESPONSE"])) {
    continue;
  }
}

if (membership && membership.active === false) {
  continue;
}

// roles / teams.
// For primary-site users we preserve legacy top-level compatibility.
// For cross-site users we use only the explicitly scoped membership roles/teams.
const userRoles = baseSiteMatches
  ? new Set([
      ...userRolesOf(user),
      ...readStringSet(membership?.roles),
    ])
  : new Set([
      ...readStringSet(membership?.roles),
    ]);

const userTeams = baseSiteMatches
  ? new Set([
      ...userTeamsOf(user),
      ...readStringSet(membership?.teams),
    ])
  : new Set([
      ...readStringSet(membership?.teams),
    ]);

        if (!userMatchesTeam(user, team, responderTeams)) {
          continue;
        }

        if (!userMatchesAllowedRoles(userRoles, allowedRoles, responderRoles)) {
          continue;
        }

        if (!userMatchesExcludedRoles(userRoles, excludedRoles)) {
          continue;
        }

        const displayName = resolveUserDisplayName(user, userId);
        const primaryRole = [...userRoles][0] || normalizeUpper(user.role) || "";
        const resolvedTeam = team || [...userTeams][0] || [...responderTeams][0] || "";
        const sourcePlaybookId = normalizeText(request.playbookId);
        const sourceStepId = normalizeText(request.stepId);

        responderUpdates[`incidents/${incidentId}/responders/${userId}`] = {
          userId,
          displayName,
          role: primaryRole,
          team: resolvedTeam,
          siteId,
          status: "REQUESTED",
          requestedAt: admin.database.ServerValue.TIMESTAMP,
          initialRequested: true,
          initialRequestedAt: admin.database.ServerValue.TIMESTAMP,
          statusUpdatedAt: admin.database.ServerValue.TIMESTAMP,
          isStale: false,
          source: "PLAYBOOK_REQUEST",
          sourceDispatchRequestId: requestId,
          sourcePlaybookId,
          sourceStepId,
        };

        selectedUsers.push({
          userId,
          displayName,
          role: primaryRole,
          team: resolvedTeam,
        });
      }

      const respondersPathSnap = await db.ref(`incidents/${incidentId}/responders`).get();
      const existingResponders = (respondersPathSnap.val() || {}) as Record<string, any>;
      const mergedResponders: Record<string, any> = { ...existingResponders };

      for (const user of selectedUsers) {
        mergedResponders[user.userId] = {
          ...(mergedResponders[user.userId] || {}),
          userId: user.userId,
          displayName: user.displayName,
          role: user.role,
          team: user.team,
          siteId,
          status: "REQUESTED",
          requestedAt:
            mergedResponders[user.userId]?.requestedAt ??
            admin.database.ServerValue.TIMESTAMP,
          initialRequested:
            typeof mergedResponders[user.userId]?.initialRequested === "boolean"
              ? mergedResponders[user.userId]?.initialRequested
              : true,
          initialRequestedAt:
            mergedResponders[user.userId]?.initialRequestedAt ??
            admin.database.ServerValue.TIMESTAMP,
          statusUpdatedAt: admin.database.ServerValue.TIMESTAMP,
          isStale: false,
          source: "PLAYBOOK_REQUEST",
          sourceDispatchRequestId: requestId,
          sourcePlaybookId: normalizeText(request.playbookId),
          sourceStepId: normalizeText(request.stepId),
        };
      }

      const currentDispatchStateSnap = await db.ref(`dispatch_state/${incidentId}`).get();
      const currentDispatchState = (currentDispatchStateSnap.val() || {}) as JsonMap;

      const dispatchCounters = buildDispatchCounters(
        mergedResponders,
        normalizeText(currentDispatchState.status || incident.dispatchStatus || "PENDING_DISPATCH"),
        cloneBooleanMap(currentDispatchState.initialRequestedUserIds),
      );

      const dispatchStateUpdate = {
        incidentId,
        category,
        siteId,
        trackingEnabled,
        ...dispatchCounters,
      };

      const updates: Record<string, any> = {
        ...responderUpdates,
        [`dispatch_state/${incidentId}`]: {
          ...(currentDispatchState || {}),
          ...dispatchStateUpdate,
        },
        [`incidents/${incidentId}/dispatchStatus`]: "PENDING_DISPATCH",
        [`incidents/${incidentId}/updatedAt`]: admin.database.ServerValue.TIMESTAMP,
        [`incidents/${incidentId}/playbook_dispatch_requests/${requestId}/materializedAt`]:
          admin.database.ServerValue.TIMESTAMP,
        [`incidents/${incidentId}/playbook_dispatch_requests/${requestId}/materializedCount`]:
          selectedUsers.length,
        [`incidents/${incidentId}/playbook_dispatch_requests/${requestId}/materializedUsers`]:
          selectedUsers.reduce<Record<string, boolean>>((acc, item) => {
            acc[item.userId] = true;
            return acc;
          }, {}),
        [`incidents/${incidentId}/playbook_dispatch_requests/${requestId}/eventLogged`]: true,
      };

      await db.ref().update(updates);

      const eventRef = db.ref("incident_events").push();
      await eventRef.set({
        id: eventRef.key,
        incidentId,
        siteId,
        createdAt: Date.now(),
        source: "FUNCTION",
        userId: "materializeDispatchRespondersFromPlaybookRequest",
        userName: "materializeDispatchRespondersFromPlaybookRequest",
        eventType: "PLAYBOOK_DISPATCH_MATERIALIZED",
        extra: {
          dispatchRequestId: requestId,
          playbookId: normalizeText(request.playbookId),
          playbookTitle: normalizeText(request.playbookTitle),
          stepId: normalizeText(request.stepId),
          stepTitle: normalizeText(request.stepTitle),
          team,
          materializedCount: selectedUsers.length,
          users: selectedUsers.map((u) => ({
            userId: u.userId,
            displayName: u.displayName,
            role: u.role,
            team: u.team,
          })),
        },
      });

      logger.info("materializeDispatchRespondersFromPlaybookRequest: completed", {
        incidentId,
        requestId,
        siteId,
        category,
        team,
        materializedCount: selectedUsers.length,
        selectedUsers,
        initialRequestedResponders: dispatchStateUpdate.initialRequestedResponders,
        requestedResponders: dispatchStateUpdate.requestedResponders,
        pendingRequestedResponders: dispatchStateUpdate.pendingRequestedResponders,
        activeResponders: dispatchStateUpdate.activeResponders,
        respondingResponders: dispatchStateUpdate.respondingResponders,
        arrivedResponders: dispatchStateUpdate.arrivedResponders,
      });
    } catch (error) {
      logger.error("materializeDispatchRespondersFromPlaybookRequest: failed", {
        incidentId,
        requestId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  },
);