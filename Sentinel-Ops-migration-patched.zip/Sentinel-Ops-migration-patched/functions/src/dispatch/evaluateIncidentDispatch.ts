import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type ResponderStatus =
  | "REQUESTED"
  | "RESPONDING"
  | "ARRIVED"
  | "CANCELLED"
  | "COMPLETED"
  | string;

type ResponderRuntime = {
  userId?: string | null;
  status?: ResponderStatus;
  role?: string | null;
  team?: string | null;
  latitude?: number;
  longitude?: number;
  etaSeconds?: number | null;
  lastUpdatedAt?: number | null;
  statusUpdatedAt?: number | null;
  requestedAt?: number | null;
  respondingAt?: number | null;
  arrivedAt?: number | null;
  completedAt?: number | null;
  cancelledAt?: number | null;
  displayName?: string | null;
  siteId?: string | null;
  sourcePlaybookId?: string | null;
  sourceStepId?: string | null;
  sourceDispatchRequestId?: string | null;
  source?: string | null;
  isStale?: boolean | null;
  initialRequested?: boolean | null;
  initialRequestedAt?: number | null;
};

type DispatchResponderSnapshot = {
  userId?: string | null;
  status: string;
  role?: string | null;
  team?: string | null;
  latitude: number | null;
  longitude: number | null;
  distanceMeters: number | null;
  etaSeconds: number | null;
  lastUpdatedAt: number | null;
  statusUpdatedAt: number | null;
  requestedAt: number | null;
  respondingAt: number | null;
  arrivedAt: number | null;
  completedAt: number | null;
  cancelledAt: number | null;
  isStale: boolean;
  displayName?: string | null;
  sourcePlaybookId?: string | null;
  sourceStepId?: string | null;
  sourceDispatchRequestId?: string | null;
  source?: string | null;
  initialRequested?: boolean;
  initialRequestedAt?: number | null;
};

type DispatchProjection = {
  initialRequestedResponders: number;
  requestedResponders: number;
  pendingRequestedResponders: number;
  respondingResponders: number;
  arrivedResponders: number;
  completedResponders: number;
  cancelledResponders: number;
  staleResponderCount: number;
  activeResponders: number;
  effectiveResponders: number;
  totalTrackedResponders: number;
  hasRequestedResponder: boolean;
  hasRespondingResponder: boolean;
  hasArrivedResponder: boolean;
  closestResponderId: string | null;
  closestDistanceMeters: number | null;
  closestEtaSeconds: number | null;
  closestActiveResponderId: string | null;
  closestActiveDistanceMeters: number | null;
  closestActiveEtaSeconds: number | null;
  closestRespondingResponderId: string | null;
  closestRespondingDistanceMeters: number | null;
  closestRespondingEtaSeconds: number | null;
  closestArrivedResponderId: string | null;
  closestArrivedDistanceMeters: number | null;
  respondersByStatus: Record<string, number>;
  respondersByTeam: Record<string, number>;
  requestedTeams: Record<string, boolean>;
  requestedByPlaybooks: Record<string, boolean>;
  initialRequestedUserIds: Record<string, boolean>;
  responders: Record<string, DispatchResponderSnapshot>;
};

export const evaluateIncidentDispatch = onValueWritten(
  {
    ref: "/incidents/{incidentId}/responders/{userId}",
    instance: "ppc-sentinel-ops-pilot-001-default-rtdb",
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();
    const now = Date.now();

    try {
      const incidentSnap = await db.ref(`incidents/${incidentId}`).get();

      if (!incidentSnap.exists()) {
        logger.warn("Dispatch evaluation skipped - incident not found", {
          incidentId,
        });

        await db.ref(`dispatch_state/${incidentId}`).remove().catch(() => undefined);
        return;
      }

      const incident = incidentSnap.val() || {};
      const currentDispatchSnap = await db.ref(`dispatch_state/${incidentId}`).get();
      const currentDispatchState = currentDispatchSnap.exists()
        ? currentDispatchSnap.val() || {}
        : {};

      const siteId = normalizeSiteId(incident.siteId ?? incident.site ?? "");
      const category = normalizeEnumText(incident.category ?? "");
      const incidentStatus = normalizeEnumText(incident.status ?? "ACTIVE");
      const isActive = toBooleanOrDefault(incident.active, true);

      const incidentLatitude = toNumber(
        incident.incidentLatitude ?? incident.latitude ?? incident.lat ?? null
      );

      const incidentLongitude = toNumber(
        incident.incidentLongitude ?? incident.longitude ?? incident.lon ?? null
      );

      if (!isActive || incidentStatus === "CLOSED" || incidentStatus === "REJECTED") {
        const frozenStatus = incidentStatus === "REJECTED" ? "REJECTED" : "CLOSED";

        const closedSnapshot = buildClosedDispatchSnapshot({
          incidentId,
          siteId,
          category,
          now,
          incidentStatus: frozenStatus,
          existingState: currentDispatchState,
        });

        await db.ref(`dispatch_state/${incidentId}`).set(closedSnapshot);

        await db.ref(`incidents/${incidentId}/responders`).remove().catch(() => undefined);

        logger.info("Dispatch state frozen and responders cleaned", {
          incidentId,
          siteId,
          category,
          incidentStatus: frozenStatus,
        });

        return;
      }

      if (incidentLatitude == null || incidentLongitude == null) {
        logger.warn("Dispatch evaluation skipped - incident coordinates missing", {
          incidentId,
          incidentLatitude,
          incidentLongitude,
        });

        await db.ref(`dispatch_state/${incidentId}`).set({
          incidentId,
          siteId,
          category,
          status: incidentStatus || "ACTIVE",

          initialRequestedResponders:
            toNumber(currentDispatchState.initialRequestedResponders) ?? 0,
          requestedResponders:
            toNumber(currentDispatchState.requestedResponders) ??
            toNumber(currentDispatchState.initialRequestedResponders) ??
            0,
          pendingRequestedResponders: 0,
          respondingResponders: 0,
          arrivedResponders: 0,
          completedResponders: 0,
          cancelledResponders: 0,
          activeResponders: 0,
          effectiveResponders: 0,
          totalTrackedResponders: 0,
          staleResponderCount: 0,

          hasRequestedResponder: false,
          hasRespondingResponder: false,
          hasArrivedResponder: false,

          closestResponderId: null,
          closestDistanceMeters: null,
          closestEtaSeconds: null,
          closestActiveResponderId: null,
          closestActiveDistanceMeters: null,
          closestActiveEtaSeconds: null,
          closestRespondingResponderId: null,
          closestRespondingDistanceMeters: null,
          closestRespondingEtaSeconds: null,
          closestArrivedResponderId: null,
          closestArrivedDistanceMeters: null,

          respondersByStatus: {},
          respondersByTeam: {},
          requestedTeams: {},
          requestedByPlaybooks: {},
          initialRequestedUserIds: cloneBooleanMap(
            currentDispatchState.initialRequestedUserIds
          ),
          responders: {},

          lastDispatchUpdate: now,
          serverOwned: true,
          dispatchVersion: 6,
        });

        return;
      }

      const respondersSnap = await db.ref(`incidents/${incidentId}/responders`).get();
      const respondersRaw = respondersSnap.exists() ? respondersSnap.val() || {} : {};

      const projection = buildDispatchProjection({
        respondersRaw: respondersRaw as Record<string, ResponderRuntime>,
        incidentLatitude,
        incidentLongitude,
        now,
        existingInitialRequestedUserIds: cloneBooleanMap(
          currentDispatchState.initialRequestedUserIds
        ),
      });

      const dispatchState = {
        incidentId,
        siteId,
        category,
        status: incidentStatus || "ACTIVE",

        initialRequestedResponders: projection.initialRequestedResponders,
        requestedResponders: projection.requestedResponders,
        pendingRequestedResponders: projection.pendingRequestedResponders,
        respondingResponders: projection.respondingResponders,
        arrivedResponders: projection.arrivedResponders,
        completedResponders: projection.completedResponders,
        cancelledResponders: projection.cancelledResponders,

        activeResponders: projection.activeResponders,
        effectiveResponders: projection.effectiveResponders,
        totalTrackedResponders: projection.totalTrackedResponders,
        staleResponderCount: projection.staleResponderCount,

        hasRequestedResponder: projection.hasRequestedResponder,
        hasRespondingResponder: projection.hasRespondingResponder,
        hasArrivedResponder: projection.hasArrivedResponder,

        closestResponderId: projection.closestResponderId,
        closestDistanceMeters: projection.closestDistanceMeters,
        closestEtaSeconds: projection.closestEtaSeconds,
        closestActiveResponderId: projection.closestActiveResponderId,
        closestActiveDistanceMeters: projection.closestActiveDistanceMeters,
        closestActiveEtaSeconds: projection.closestActiveEtaSeconds,
        closestRespondingResponderId: projection.closestRespondingResponderId,
        closestRespondingDistanceMeters: projection.closestRespondingDistanceMeters,
        closestRespondingEtaSeconds: projection.closestRespondingEtaSeconds,
        closestArrivedResponderId: projection.closestArrivedResponderId,
        closestArrivedDistanceMeters: projection.closestArrivedDistanceMeters,

        respondersByStatus: projection.respondersByStatus,
        respondersByTeam: projection.respondersByTeam,
        requestedTeams: projection.requestedTeams,
        requestedByPlaybooks: projection.requestedByPlaybooks,
        initialRequestedUserIds: projection.initialRequestedUserIds,
        responders: projection.responders,

        lastDispatchUpdate: now,
        serverOwned: true,
        dispatchVersion: 6,
      };

      await db.ref(`dispatch_state/${incidentId}`).set(dispatchState);

      logger.info("Dispatch state recomputed", {
        incidentId,
        siteId,
        category,
        status: incidentStatus || "ACTIVE",
        initialRequestedResponders: projection.initialRequestedResponders,
        requestedResponders: projection.requestedResponders,
        pendingRequestedResponders: projection.pendingRequestedResponders,
        respondingResponders: projection.respondingResponders,
        arrivedResponders: projection.arrivedResponders,
        completedResponders: projection.completedResponders,
        cancelledResponders: projection.cancelledResponders,
        activeResponders: projection.activeResponders,
        staleResponderCount: projection.staleResponderCount,
        closestResponderId: projection.closestResponderId,
        closestActiveResponderId: projection.closestActiveResponderId,
        closestArrivedResponderId: projection.closestArrivedResponderId,
        responderCount: projection.totalTrackedResponders,
      });
    } catch (error) {
      logger.error("Dispatch evaluation failed", {
        incidentId,
        error: stringifyError(error),
      });
      throw error;
    }
  }
);

type BuildDispatchProjectionArgs = {
  respondersRaw: Record<string, ResponderRuntime>;
  incidentLatitude: number;
  incidentLongitude: number;
  now: number;
  existingInitialRequestedUserIds?: Record<string, boolean>;
};

function buildDispatchProjection({
  respondersRaw,
  incidentLatitude,
  incidentLongitude,
  now,
  existingInitialRequestedUserIds,
}: BuildDispatchProjectionArgs): DispatchProjection {
  let pendingRequestedResponders = 0;
  let respondingResponders = 0;
  let arrivedResponders = 0;
  let completedResponders = 0;
  let cancelledResponders = 0;
  let staleResponderCount = 0;

  let closestResponderId: string | null = null;
  let closestDistanceMeters: number | null = null;
  let closestEtaSeconds: number | null = null;

  let closestActiveResponderId: string | null = null;
  let closestActiveDistanceMeters: number | null = null;
  let closestActiveEtaSeconds: number | null = null;

  let closestRespondingResponderId: string | null = null;
  let closestRespondingDistanceMeters: number | null = null;
  let closestRespondingEtaSeconds: number | null = null;

  let closestArrivedResponderId: string | null = null;
  let closestArrivedDistanceMeters: number | null = null;

  const respondersSnapshot: Record<string, DispatchResponderSnapshot> = {};
  const requestedTeams: Record<string, boolean> = {};
  const requestedByPlaybooks: Record<string, boolean> = {};
  const respondersByStatus: Record<string, number> = {};
  const respondersByTeam: Record<string, number> = {};
  const initialRequestedUserIds = cloneBooleanMap(existingInitialRequestedUserIds);

  const STALE_RESPONDING_THRESHOLD_MS = 2 * 60 * 1000;
  const STALE_ARRIVED_THRESHOLD_MS = 10 * 60 * 1000;

  type ClosestCandidate = {
    uid: string;
    distanceMeters: number;
    etaSeconds: number | null;
  };

  let closestRespondingCandidate: ClosestCandidate | null = null;
  let closestArrivedCandidate: ClosestCandidate | null = null;

  for (const [uid, raw] of Object.entries(respondersRaw)) {
    const responder = raw || {};

    const status = normalizeEnumText(responder.status ?? "");
    const latitude = toNumber(responder.latitude ?? null);
    const longitude = toNumber(responder.longitude ?? null);
    const etaSeconds = toNumber(responder.etaSeconds ?? null);
    const lastUpdatedAt = toNumber(responder.lastUpdatedAt ?? null);
    const statusUpdatedAt = toNumber(responder.statusUpdatedAt ?? null);
    const requestedAt = toNumber(responder.requestedAt ?? null);
    const respondingAt = toNumber(responder.respondingAt ?? null);
    const arrivedAt = toNumber(responder.arrivedAt ?? null);
    const completedAt = toNumber(responder.completedAt ?? null);
    const cancelledAt = toNumber(responder.cancelledAt ?? null);
    const initialRequestedAt = toNumber(responder.initialRequestedAt ?? null);

    const displayName = normalizeNullableText(responder.displayName ?? null);
    const role = normalizeNullableText(responder.role ?? null);
    const team = normalizeNullableText(responder.team ?? null);
    const sourcePlaybookId = normalizeNullableText(responder.sourcePlaybookId ?? null);
    const sourceStepId = normalizeNullableText(responder.sourceStepId ?? null);
    const sourceDispatchRequestId = normalizeNullableText(
      responder.sourceDispatchRequestId ?? null
    );
    const source = normalizeNullableText(responder.source ?? null);

    let distanceMeters: number | null = null;
    let isStale = false;

    if (latitude != null && longitude != null) {
      distanceMeters = haversineMeters(
        incidentLatitude,
        incidentLongitude,
        latitude,
        longitude
      );
    }

    if (lastUpdatedAt != null) {
      const age = now - lastUpdatedAt;
      if (
        (status === "RESPONDING" && age > STALE_RESPONDING_THRESHOLD_MS) ||
        (status === "ARRIVED" && age > STALE_ARRIVED_THRESHOLD_MS)
      ) {
        isStale = true;
        staleResponderCount++;
      }
    }

    if (team) {
      requestedTeams[team] = true;
      respondersByTeam[team] = (respondersByTeam[team] || 0) + 1;
    }

    if (sourcePlaybookId) {
      requestedByPlaybooks[sourcePlaybookId] = true;
    }

    if (status) {
      respondersByStatus[status] = (respondersByStatus[status] || 0) + 1;
    }

    const initiallyRequested =
      toBooleanOrDefault(responder.initialRequested, false) ||
      initialRequestedUserIds[uid] === true ||
      requestedAt != null ||
      source === "PLAYBOOK_REQUEST" ||
      sourceDispatchRequestId != null ||
      sourcePlaybookId != null;

    if (initiallyRequested) {
      initialRequestedUserIds[uid] = true;
      if (status === "REQUESTED") {
        pendingRequestedResponders++;
      }
    }

    switch (status) {
      case "RESPONDING":
        if (!isStale) respondingResponders++;
        break;
      case "ARRIVED":
        if (!isStale) arrivedResponders++;
        break;
      case "COMPLETED":
        completedResponders++;
        break;
      case "CANCELLED":
        cancelledResponders++;
        break;
      default:
        break;
    }

    if (!isStale && distanceMeters != null) {
      const roundedDistance = round1(distanceMeters);
      const roundedEta = etaSeconds != null ? Math.round(etaSeconds) : null;

      if (
        status === "RESPONDING" &&
        (closestRespondingCandidate == null ||
          distanceMeters < closestRespondingCandidate.distanceMeters)
      ) {
        closestRespondingCandidate = {
          uid,
          distanceMeters: roundedDistance,
          etaSeconds: roundedEta,
        };
      }

      if (
        status === "ARRIVED" &&
        (closestArrivedCandidate == null ||
          distanceMeters < closestArrivedCandidate.distanceMeters)
      ) {
        closestArrivedCandidate = {
          uid,
          distanceMeters: roundedDistance,
          etaSeconds: roundedEta,
        };
      }
    }

    respondersSnapshot[uid] = {
      userId: normalizeNullableText(responder.userId ?? uid),
      status,
      role,
      team,
      latitude,
      longitude,
      distanceMeters: distanceMeters != null ? round1(distanceMeters) : null,
      etaSeconds: etaSeconds != null ? Math.round(etaSeconds) : null,
      lastUpdatedAt,
      statusUpdatedAt,
      requestedAt,
      respondingAt,
      arrivedAt,
      completedAt,
      cancelledAt,
      isStale,
      ...(displayName ? { displayName } : {}),
      ...(sourcePlaybookId ? { sourcePlaybookId } : {}),
      ...(sourceStepId ? { sourceStepId } : {}),
      ...(sourceDispatchRequestId ? { sourceDispatchRequestId } : {}),
      ...(source ? { source } : {}),
      ...(initiallyRequested ? { initialRequested: true } : {}),
      ...(initialRequestedAt != null ? { initialRequestedAt } : {}),
    };
  }

  if (closestRespondingCandidate) {
    closestRespondingResponderId = closestRespondingCandidate.uid;
    closestRespondingDistanceMeters = closestRespondingCandidate.distanceMeters;
    closestRespondingEtaSeconds = closestRespondingCandidate.etaSeconds;
  }

  if (closestArrivedCandidate) {
    closestArrivedResponderId = closestArrivedCandidate.uid;
    closestArrivedDistanceMeters = closestArrivedCandidate.distanceMeters;
  }

  const preferredClosest = closestArrivedCandidate ?? closestRespondingCandidate;
  if (preferredClosest) {
    closestResponderId = preferredClosest.uid;
    closestDistanceMeters = preferredClosest.distanceMeters;
    closestEtaSeconds = preferredClosest.etaSeconds;
    closestActiveResponderId = preferredClosest.uid;
    closestActiveDistanceMeters = preferredClosest.distanceMeters;
    closestActiveEtaSeconds = preferredClosest.etaSeconds;
  }

  const initialRequestedResponders = Object.keys(initialRequestedUserIds).length;
  const requestedResponders = initialRequestedResponders;
  const activeResponders = respondingResponders + arrivedResponders;
  const effectiveResponders = activeResponders;
  const totalTrackedResponders = Object.keys(respondersSnapshot).length;

  return {
    initialRequestedResponders,
    requestedResponders,
    pendingRequestedResponders,
    respondingResponders,
    arrivedResponders,
    completedResponders,
    cancelledResponders,
    staleResponderCount,
    activeResponders,
    effectiveResponders,
    totalTrackedResponders,
    hasRequestedResponder: pendingRequestedResponders > 0,
    hasRespondingResponder: respondingResponders > 0,
    hasArrivedResponder: arrivedResponders > 0,
    closestResponderId,
    closestDistanceMeters,
    closestEtaSeconds,
    closestActiveResponderId,
    closestActiveDistanceMeters,
    closestActiveEtaSeconds,
    closestRespondingResponderId,
    closestRespondingDistanceMeters,
    closestRespondingEtaSeconds,
    closestArrivedResponderId,
    closestArrivedDistanceMeters,
    respondersByStatus,
    respondersByTeam,
    requestedTeams,
    requestedByPlaybooks,
    initialRequestedUserIds,
    responders: respondersSnapshot,
  };
}

type ClosedDispatchSnapshotArgs = {
  incidentId: string;
  siteId: string;
  category: string;
  now: number;
  incidentStatus: string;
  existingState: Record<string, any>;
};

function buildClosedDispatchSnapshot({
  incidentId,
  siteId,
  category,
  now,
  incidentStatus,
  existingState,
}: ClosedDispatchSnapshotArgs) {
  const initialRequestedResponders =
    toNumber(existingState.initialRequestedResponders) ??
    toNumber(existingState.requestedResponders) ??
    0;
  const requestedResponders =
    toNumber(existingState.requestedResponders) ??
    toNumber(existingState.initialRequestedResponders) ??
    initialRequestedResponders;
  const pendingRequestedResponders =
    toNumber(existingState.pendingRequestedResponders) ?? 0;
  const respondingResponders = toNumber(existingState.respondingResponders) ?? 0;
  const arrivedResponders = toNumber(existingState.arrivedResponders) ?? 0;
  const completedResponders = toNumber(existingState.completedResponders) ?? 0;
  const cancelledResponders = toNumber(existingState.cancelledResponders) ?? 0;
  const staleResponderCount = toNumber(existingState.staleResponderCount) ?? 0;

  return {
    incidentId,
    siteId,
    category,
    status: incidentStatus || "CLOSED",

    initialRequestedResponders,
    requestedResponders,
    pendingRequestedResponders,
    respondingResponders,
    arrivedResponders,
    completedResponders,
    cancelledResponders,

    activeResponders:
      toNumber(existingState.activeResponders) ?? respondingResponders + arrivedResponders,
    effectiveResponders:
      toNumber(existingState.effectiveResponders) ?? respondingResponders + arrivedResponders,
    totalTrackedResponders:
      toNumber(existingState.totalTrackedResponders) ??
      Object.keys(
        existingState.responders && typeof existingState.responders === "object"
          ? existingState.responders
          : {}
      ).length,

    hasRequestedResponder: toBooleanOrDefault(
      existingState.hasRequestedResponder,
      pendingRequestedResponders > 0
    ),
    hasRespondingResponder: toBooleanOrDefault(
      existingState.hasRespondingResponder,
      respondingResponders > 0
    ),
    hasArrivedResponder: toBooleanOrDefault(
      existingState.hasArrivedResponder,
      arrivedResponders > 0
    ),

    closestResponderId: normalizeNullableText(existingState.closestResponderId ?? null),
    closestDistanceMeters: toNumber(existingState.closestDistanceMeters ?? null),
    closestEtaSeconds: toNumber(existingState.closestEtaSeconds ?? null),
    closestActiveResponderId: normalizeNullableText(
      existingState.closestActiveResponderId ?? null
    ),
    closestActiveDistanceMeters: toNumber(
      existingState.closestActiveDistanceMeters ?? null
    ),
    closestActiveEtaSeconds: toNumber(existingState.closestActiveEtaSeconds ?? null),
    closestRespondingResponderId: normalizeNullableText(
      existingState.closestRespondingResponderId ?? null
    ),
    closestRespondingDistanceMeters: toNumber(
      existingState.closestRespondingDistanceMeters ?? null
    ),
    closestRespondingEtaSeconds: toNumber(
      existingState.closestRespondingEtaSeconds ?? null
    ),
    closestArrivedResponderId: normalizeNullableText(
      existingState.closestArrivedResponderId ?? null
    ),
    closestArrivedDistanceMeters: toNumber(
      existingState.closestArrivedDistanceMeters ?? null
    ),
    staleResponderCount,

    respondersByStatus:
      existingState.respondersByStatus && typeof existingState.respondersByStatus === "object"
        ? existingState.respondersByStatus
        : {},
    respondersByTeam:
      existingState.respondersByTeam && typeof existingState.respondersByTeam === "object"
        ? existingState.respondersByTeam
        : {},
    requestedTeams:
      existingState.requestedTeams && typeof existingState.requestedTeams === "object"
        ? existingState.requestedTeams
        : {},
    requestedByPlaybooks:
      existingState.requestedByPlaybooks &&
      typeof existingState.requestedByPlaybooks === "object"
        ? existingState.requestedByPlaybooks
        : {},
    initialRequestedUserIds: cloneBooleanMap(existingState.initialRequestedUserIds),
    responders:
      existingState.responders && typeof existingState.responders === "object"
        ? existingState.responders
        : {},

    lastDispatchUpdate: now,
    serverOwned: true,
    dispatchVersion: 6,
    closedAt: toNumber(existingState.closedAt) ?? now,
    closedBy: normalizeNullableText(existingState.closedBy ?? null),
    closureMode: normalizeNullableText(existingState.closureMode ?? null),
  };
}

function cloneBooleanMap(
  value: unknown
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!value || typeof value !== "object") {
    return result;
  }

  for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
    if (toBooleanOrDefault(raw, false)) {
      const normalizedKey = normalizeSiteId(key);
      if (normalizedKey) {
        result[normalizedKey] = true;
      }
    }
  }

  return result;
}

function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(value: number): number {
  return (value * Math.PI) / 180;
}

function toNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;

  if (typeof value === "string" && value.trim() !== "") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function toBooleanOrDefault(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") return value;
  return fallback;
}

function normalizeEnumText(value: unknown): string {
  return typeof value === "string" ? value.trim().toUpperCase() : "";
}

function normalizeSiteId(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function normalizeNullableText(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

function stringifyError(error: unknown): string {
  if (error instanceof Error) {
    return `${error.name}: ${error.message}`;
  }
  return String(error);
}