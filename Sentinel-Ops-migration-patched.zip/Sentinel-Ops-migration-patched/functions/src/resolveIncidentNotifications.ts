import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import {
  resolveNotificationPoliciesV2,
  type NotificationPolicyV2,
} from "./notifications/resolveNotificationPoliciesV2";

type IncidentNotificationTriggerEvent =
  | "INCIDENT_CREATED"
  | "INCIDENT_VERIFIED"
  | "INCIDENT_CLOSED"
  | "INCIDENT_UNDER_CONTROL"
  | "INCIDENT_DEACTIVATED"
  | "INCIDENT_REVIEW_PROGRESS"
  | "INCIDENT_DIMENSIONS_EXPANDED";

export const resolveIncidentNotifications = onValueWritten(
  {
    ref: "/incidents/{incidentId}",
    instance: "ppc-sentinel-ops-pilot-001-default-rtdb",
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;

    const before = event.data.before.exists() ? event.data.before.val() : null;
    const after = event.data.after.exists() ? event.data.after.val() : null;

    if (!after) {
      logger.info("resolveIncidentNotifications skipped: after missing", {
        incidentId,
      });
      return;
    }

    const siteId = normalizeSiteId(after.siteId || after.site || "");
    const category = normalizeEnum(after.category || "");
    if (!siteId || !category) {
      logger.warn("resolveIncidentNotifications skipped: missing site/category", {
        incidentId,
        siteId,
        category,
        summary: debugSummary(after),
      });
      return;
    }

    const db = admin.database();

    let triggerEvents = resolveTriggerEvents(before, after, category);

    if (triggerEvents.length === 0) {
      triggerEvents = await resolveMissingCreatedTriggerFallback(
        db,
        incidentId,
        siteId,
        category,
        before,
        after
      );
    }

    logger.info("resolveIncidentNotifications trigger evaluation", {
      incidentId,
      siteId,
      category,
      triggerEvents,
      beforeSummary: debugSummary(before),
      afterSummary: debugSummary(after),
    });

    if (triggerEvents.length === 0) {
      logger.info("resolveIncidentNotifications skipped: no trigger events", {
        incidentId,
        siteId,
        category,
        summary: debugSummary(after),
      });
      return;
    }

    for (const triggerEvent of triggerEvents) {
      const policyTriggerEvent = resolvePolicyTriggerEvent(triggerEvent, category, after);

      logger.info("resolveIncidentNotifications trigger loop start", {
        incidentId,
        siteId,
        category,
        triggerEvent,
        policyTriggerEvent,
        summary: debugSummary(after),
      });

      const policy = await resolveNotificationPoliciesV2(
        siteId,
        category,
        policyTriggerEvent
      );

      const effectivePolicy = policy || buildFallbackSaekNotificationPolicy(
        siteId,
        category,
        policyTriggerEvent,
        after
      );

      if (!policy && effectivePolicy) {
        logger.warn("No canonical notification policy resolved; using SAEK fallback policy", {
          incidentId,
          siteId,
          category,
          triggerEvent,
          policyTriggerEvent,
          fallbackPolicyId: safeString(effectivePolicy.policyId),
          fallbackTargetRoles: Object.keys(normalizeBooleanMap(effectivePolicy.targetRoles)),
          fallbackTargetTeams: Object.keys(normalizeBooleanMap(effectivePolicy.targetTeams)),
          summary: debugSummary(after),
        });
      }

      if (!effectivePolicy) {
        logger.info("No canonical notification policy resolved and no SAEK fallback matched", {
          incidentId,
          siteId,
          category,
          triggerEvent,
          policyTriggerEvent,
          summary: debugSummary(after),
        });
        continue;
      }

      const policyForRequest = effectivePolicy;

      logger.info("resolveIncidentNotifications policy resolved", {
        incidentId,
        siteId,
        category,
        triggerEvent,
        policyTriggerEvent,
        policyId: safeString(policyForRequest.policyId),
        policyMode: safeString(policyForRequest.mode),
        policySourcePath: safeString(policyForRequest.sourcePath),
        policyTargetRoles: Object.keys(normalizeBooleanMap(policyForRequest.targetRoles)),
        policyTargetTeams: Object.keys(normalizeBooleanMap(policyForRequest.targetTeams)),
        summary: debugSummary(after),
      });

      const effectiveTargeting = await resolveEffectiveTargetingForIncident(
        db,
        siteId,
        category,
        triggerEvent,
        before,
        after,
        policyForRequest
      );

      logger.info("resolveIncidentNotifications effective targeting", {
        incidentId,
        siteId,
        category,
        triggerEvent,
        policyTriggerEvent,
        dynamicTargeting: effectiveTargeting.dynamicTargeting,
        dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
        effectiveTargetRoles: Object.keys(effectiveTargeting.targetRoles),
        effectiveTargetTeams: Object.keys(effectiveTargeting.targetTeams),
        summary: debugSummary(after),
      });

      if (
        effectiveTargeting.dynamicTargeting &&
        Object.keys(effectiveTargeting.targetRoles).length === 0 &&
        Object.keys(effectiveTargeting.targetTeams).length === 0
      ) {
        logger.info("Skipping dynamic notification request because no effective targets remain", {
          incidentId,
          siteId,
          category,
          triggerEvent,
          dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
          summary: debugSummary(after),
        });
        continue;
      }

      const dedupeKey = buildNotificationDedupeKey({
        incidentId,
        triggerEvent,
        policyId: safeString(policyForRequest.policyId),
        mode: safeString(policyForRequest.mode || "DISPATCH"),
        dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
        targetRoles: effectiveTargeting.targetRoles,
        targetTeams: effectiveTargeting.targetTeams,
        dimensions: normalizeSelectedDimensionKeys(after),
      });

      const existingDedupeRequest = await findExistingActiveNotificationRequestByDedupeKey(
        db,
        incidentId,
        dedupeKey
      );

      if (existingDedupeRequest) {
        logger.info("resolveIncidentNotifications skipped duplicate notification request", {
          incidentId,
          siteId,
          category,
          triggerEvent,
          policyTriggerEvent,
          dedupeKey,
          existingRequestId: existingDedupeRequest.requestId,
          existingRequestStatus: existingDedupeRequest.status,
          policyId: safeString(policyForRequest.policyId),
          mode: safeString(policyForRequest.mode || "DISPATCH"),
          dynamicTargeting: effectiveTargeting.dynamicTargeting,
          dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
          effectiveTargetRoles: Object.keys(effectiveTargeting.targetRoles),
          effectiveTargetTeams: Object.keys(effectiveTargeting.targetTeams),
          summary: debugSummary(after),
        });
        continue;
      }

      const resolution = await resolveUsersWithProvenance(
        db,
        siteId,
        effectiveTargeting.targetRoles,
        effectiveTargeting.targetTeams,
        {}
      );

      logger.info("resolveIncidentNotifications user resolution", {
        incidentId,
        siteId,
        category,
        triggerEvent,
        resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
        droppedUserCount: Object.keys(resolution.droppedUsers).length,
        resolvedUserIds: Object.keys(resolution.resolvedUsers),
        droppedUsers: resolution.droppedUsers,
        summary: debugSummary(after),
      });

      const now = Date.now();

      // ANTI-DUPLICATE GUARD
      // Policy-driven behavior παραμένει ίδιο.
      // Το μόνο που αλλάζει είναι ότι αν λείπει RTDB index,
      // δεν σκάει η function — απλώς προχωρά χωρίς duplicate query.
      let shouldSkipDuplicate = false;

      try {
        const recentRequestsSnap = await db
          .ref("notification_requests")
          .orderByChild("incidentId")
          .equalTo(incidentId)
          .limitToLast(10)
          .get();

        if (recentRequestsSnap.exists()) {
          const recentRequests = recentRequestsSnap.val();

          for (const req of Object.values<any>(recentRequests)) {
            const sameTrigger = req?.meta?.triggerEvent === triggerEvent;
            const sameRoles =
              JSON.stringify(req?.targeting?.targetRoles || {}) ===
              JSON.stringify(effectiveTargeting.targetRoles);
            const sameTeams =
              JSON.stringify(req?.targeting?.targetTeams || {}) ===
              JSON.stringify(effectiveTargeting.targetTeams);
            const sameSource =
              req?.policy?.dynamicTargetSource === effectiveTargeting.dynamicTargetSource;

            const recentEnough = Math.abs((req?.meta?.createdAt || 0) - now) < 3000;

            if (sameTrigger && sameRoles && sameTeams && sameSource && recentEnough) {
              shouldSkipDuplicate = true;

              logger.info("resolveIncidentNotifications duplicate candidate found", {
                incidentId,
                triggerEvent,
                existingRequestId: req?.id || "",
                sameTrigger,
                sameRoles,
                sameTeams,
                sameSource,
                recentEnough,
                dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
                effectiveTargetRoles: Object.keys(effectiveTargeting.targetRoles),
                effectiveTargetTeams: Object.keys(effectiveTargeting.targetTeams),
              });

              break;
            }
          }

          if (
            !shouldSkipDuplicate &&
            triggerEvent === "INCIDENT_REVIEW_PROGRESS" &&
            isUnsafeConditionDynamicFlow(category, after)
          ) {
            for (const req of Object.values<any>(recentRequests)) {
              const expansionTrigger =
                req?.meta?.triggerEvent === "INCIDENT_DIMENSIONS_EXPANDED";
              const recentEnough = Math.abs((req?.meta?.createdAt || 0) - now) < 4000;

              if (expansionTrigger && recentEnough) {
                shouldSkipDuplicate = true;

                logger.info("resolveIncidentNotifications suppressing review-progress after recent dimension expansion", {
                  incidentId,
                  triggerEvent,
                  recentExpansionRequestId: req?.id || "",
                  recentEnough,
                  effectiveTargetRoles: Object.keys(effectiveTargeting.targetRoles),
                  effectiveTargetTeams: Object.keys(effectiveTargeting.targetTeams),
                });

                break;
              }
            }
          }
        }
      } catch (error: any) {
        logger.warn("resolveIncidentNotifications duplicate guard fallback", {
          incidentId,
          triggerEvent,
          error: error?.message || "unknown_error",
        });
      }

      if (shouldSkipDuplicate) {
        logger.info("Skipping duplicate notification (guard active)", {
          incidentId,
          triggerEvent,
          dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
          targetRoles: Object.keys(effectiveTargeting.targetRoles),
          targetTeams: Object.keys(effectiveTargeting.targetTeams),
          summary: debugSummary(after),
        });
        continue;
      }

      const requestRef = db.ref("notification_requests").push();

      const type =
        policyForRequest.mode === "VERIFY_FIRST"
          ? "VERIFY_INCIDENT"
          : policyForRequest.mode === "ESCALATE"
            ? "ESCALATE_INCIDENT"
            : policyForRequest.mode === "SITE_BROADCAST"
              ? "SITE_BROADCAST"
              : "DISPATCH_INCIDENT";

      const retryConfig = normalizeRetryConfig(policyForRequest.retry);

      await requestRef.set({
        id: requestRef.key,
        incidentId,
        siteId,
        category,
        type,
        status: "PENDING",

        meta: {
          schemaVersion: 2,
          dedupeKey,
          source: "SYSTEM",
          triggerEvent,
          createdAt: now,
          processedAt: 0,
          lastAttemptAt: 0,
        },

        policy: {
          policyUsed: true,
          policySourcePath: safeString(policyForRequest.sourcePath),
          matchedPolicyIds: {
            [safeString(policyForRequest.policyId)]: true,
          },
          dynamicTargeting: effectiveTargeting.dynamicTargeting,
          dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
        },

        targeting: {
          mode: safeString(policyForRequest.mode || "DISPATCH"),
          siteScope: "SITE_ONLY",
          siteId,
          targetRoles: effectiveTargeting.targetRoles,
          targetTeams: effectiveTargeting.targetTeams,
          explicitUsers: {},
        },

        context: {
          dimensionKeys: normalizeSelectedDimensionKeys(after),
          pendingRoles: normalizeBooleanMap(after?.pendingRoles),
          completedRoles: normalizeBooleanMap(after?.completedRoles),
          reviewAggregationStatus: normalizeEnum(after?.reviewAggregationStatus),
          verificationStatus: normalizeEnum(after?.verificationStatus),
        },

        resolution: {
          resolvedUsers: resolution.resolvedUsers,
          resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
          droppedUsers: resolution.droppedUsers,
          droppedUserCount: Object.keys(resolution.droppedUsers).length,
        },

        delivery: {
          channel: "FCM",
          attemptedRecipientCount: 0,
          validRecipientCount: 0,
          successCount: 0,
          failureCount: 0,
          invalidTokenCount: 0,
          deliveryResults: {},
          failedTokens: [],
          invalidTokens: [],
          retryableFailedTokens: [],
        },

        retry: {
          enabled: retryConfig.enabled,
          retryCount: 0,
          maxRetryCount: retryConfig.maxRetryCount,
          retryReason: "",
          nextRetryAt: 0,
          backoffSeconds: retryConfig.backoffSeconds,
          history: {},
        },
      });

      logger.info("Notification request v2 created", {
        requestId: requestRef.key,
        dedupeKey,
        incidentId,
        siteId,
        category,
        triggerEvent,
        policyTriggerEvent,
        type,
        mode: policyForRequest.mode,
        retryEnabled: retryConfig.enabled,
        maxRetryCount: retryConfig.maxRetryCount,
        backoffSeconds: retryConfig.backoffSeconds,
        resolvedUserCount: Object.keys(resolution.resolvedUsers).length,
        droppedUserCount: Object.keys(resolution.droppedUsers).length,
        dynamicTargeting: effectiveTargeting.dynamicTargeting,
        dynamicTargetSource: effectiveTargeting.dynamicTargetSource,
        effectiveTargetRoles: Object.keys(effectiveTargeting.targetRoles),
        effectiveTargetTeams: Object.keys(effectiveTargeting.targetTeams),
        summary: debugSummary(after),
      });
    }
  }
);




function buildNotificationDedupeKey(params: {
  incidentId: string;
  triggerEvent: string;
  policyId: string;
  mode: string;
  dynamicTargetSource: string;
  targetRoles: Record<string, boolean>;
  targetTeams: Record<string, boolean>;
  dimensions?: string[];
}): string {
  const rolePart = stableKeyPart(Object.keys(params.targetRoles));
  const teamPart = stableKeyPart(Object.keys(params.targetTeams));
  const dimensionPart = stableKeyPart(params.dimensions || []);

  return [
    safeString(params.incidentId),
    normalizeEnum(params.triggerEvent),
    safeString(params.policyId),
    normalizeEnum(params.mode || "DISPATCH"),
    normalizeEnum(params.dynamicTargetSource || "POLICY_STATIC"),
    `roles=${rolePart}`,
    `teams=${teamPart}`,
    `dimensions=${dimensionPart}`,
  ].join("|");
}

function stableKeyPart(values: string[]): string {
  return values
    .map((value) => normalizeEnum(value))
    .filter(Boolean)
    .sort()
    .join(",");
}

async function findExistingActiveNotificationRequestByDedupeKey(
  db: admin.database.Database,
  incidentId: string,
  dedupeKey: string
): Promise<{ requestId: string; status: string } | null> {
  try {
    const recentRequestsSnap = await db
      .ref("notification_requests")
      .orderByChild("incidentId")
      .equalTo(incidentId)
      .limitToLast(50)
      .get();

    if (!recentRequestsSnap.exists()) {
      return null;
    }

    const recentRequests = recentRequestsSnap.val() || {};

    for (const [requestId, request] of Object.entries<any>(recentRequests)) {
      const requestDedupeKey = safeString(request?.meta?.dedupeKey);
      if (requestDedupeKey !== dedupeKey) {
        continue;
      }

      const status = normalizeEnum(request?.status || "");
      if (isActiveNotificationRequestStatus(status)) {
        return {
          requestId,
          status,
        };
      }
    }

    return null;
  } catch (error: any) {
    logger.warn("resolveIncidentNotifications canonical dedupe lookup failed", {
      incidentId,
      dedupeKey,
      error: error?.message || "unknown_error",
    });

    return null;
  }
}

function isActiveNotificationRequestStatus(status: string): boolean {
  const normalized = normalizeEnum(status);
  return (
    normalized === "PENDING" ||
    normalized === "PROCESSING" ||
    normalized === "SENT" ||
    normalized === "RETRY_PENDING"
  );
}

function buildFallbackSaekNotificationPolicy(
  siteId: string,
  category: string,
  triggerEvent: IncidentNotificationTriggerEvent,
  incident: any
): NotificationPolicyV2 | null {
  const normalizedCategory = normalizeEnum(category);
  const normalizedTrigger = normalizeEnum(triggerEvent);
  const subtype = normalizeEnum(incident?.subtype || incident?.type || "");
  const evacuationRequired = incident?.activation?.evacuationRequired === true || incident?.evacuationRequired === true;

  const targetRoles: Record<string, boolean> = {};
  const targetTeams: Record<string, boolean> = {};

  if (normalizedTrigger === "INCIDENT_UNDER_CONTROL" || normalizedTrigger === "INCIDENT_DEACTIVATED") {
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    targetRoles.EMERGENCY_COMMANDER = true;
    targetRoles.CONTROL_ROOM = true;
    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "DISPATCH", targetRoles, targetTeams);
  }

  if (normalizedTrigger === "INCIDENT_CLOSED") {
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "DISPATCH", targetRoles, targetTeams);
  }

  if (normalizedCategory === "EMERGENCY_ACTIVATION" || normalizedCategory === "EMERGENCY") {
    targetRoles.EMERGENCY_COMMANDER = true;
    targetRoles.COMMUNICATIONS_OFFICER = true;
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    targetRoles.CONTROL_ROOM = true;
    targetRoles.SECURITY_OFFICER = true;

    targetTeams.EMERGENCY_TEAM = true;
    targetTeams.SECURITY_TEAM = true;

    if (subtype === "FIRE" || subtype === "SMOKE" || subtype === "EXPLOSION") {
      targetRoles.FIRE_SAFETY_COORDINATOR = true;
      targetTeams.FIRE_TEAM = true;
    }

    if (evacuationRequired) {
      targetRoles.PERSONNEL_COORDINATOR = true;
      targetTeams.EVACUATION_TEAM = true;
    }

    targetRoles.FIRST_AID_COORDINATOR = true;
    targetTeams.FIRST_AID_TEAM = true;

    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "DISPATCH", targetRoles, targetTeams);
  }

  if (normalizedCategory === "SOS" || normalizedCategory === "HSE_ACCIDENT" || normalizedCategory === "SAFETY_ACCIDENT") {
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    targetRoles.SUPERVISOR = true;
    targetRoles.FIRST_AID_COORDINATOR = true;
    targetTeams.FIRST_AID_TEAM = true;
    targetTeams.HSE_TEAM = true;
    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "DISPATCH", targetRoles, targetTeams);
  }

  if (normalizedCategory === "ENVIRONMENTAL_INCIDENT") {
    targetRoles.ENVIRONMENTAL_OFFICER = true;
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    if (normalizedTrigger === "INCIDENT_VERIFIED") {
      targetTeams.ENVIRONMENT_TEAM = true;
    }
    return createFallbackPolicy(
      siteId,
      normalizedCategory,
      normalizedTrigger,
      normalizedTrigger === "INCIDENT_CREATED" ? "VERIFY_FIRST" : "DISPATCH",
      targetRoles,
      targetTeams
    );
  }

  if (normalizedCategory === "UNSAFE_CONDITION") {
    targetRoles.SUPERVISOR = true;
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "VERIFY_FIRST", targetRoles, targetTeams);
  }

  if (normalizedCategory === "UNSAFE_ACTION" || normalizedCategory === "NEAR_MISS") {
    targetRoles.SUPERVISOR = true;
    targetRoles.HSE_MANAGER = true;
    targetRoles.SITE_MANAGER = true;
    return createFallbackPolicy(siteId, normalizedCategory, normalizedTrigger, "VERIFY_FIRST", targetRoles, targetTeams);
  }

  targetRoles.HSE_MANAGER = true;
  targetRoles.SITE_MANAGER = true;
  return createFallbackPolicy(siteId, normalizedCategory || "UNKNOWN", normalizedTrigger, "DISPATCH", targetRoles, targetTeams);
}

function createFallbackPolicy(
  siteId: string,
  category: string,
  triggerEvent: string,
  mode: string,
  targetRoles: Record<string, boolean>,
  targetTeams: Record<string, boolean>
): NotificationPolicyV2 {
  return {
    active: true,
    policyId: `saek_fallback_${category.toLowerCase()}_${triggerEvent.toLowerCase()}`,
    sourcePath: `functions/fallback/saek/${siteId}/${category}/${triggerEvent}`,
    mode,
    targetRoles,
    targetTeams,
    retry: {
      enabled: true,
      maxRetries: 2,
      backoffSeconds: [60, 180, 600],
      retryOnFailed: true,
      retryOnNoTargets: false,
      retryOnPartialFailure: true,
    },
  } as NotificationPolicyV2;
}

async function resolveMissingCreatedTriggerFallback(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  category: string,
  before: any,
  after: any
): Promise<IncidentNotificationTriggerEvent[]> {
  if (!after) return [];

  const afterStatus = normalizeEnum(after?.status);
  const afterVerification = normalizeEnum(after?.verificationStatus);
  const afterReviewAggregation = normalizeEnum(after?.reviewAggregationStatus);
  const afterActive = after?.active !== false;
  const afterVisibleToSite = after?.visibleToSite !== false;
  const createdAt = toSafeInt(after?.createdAt || after?.timestamp, 0);
  const ageMs = createdAt > 0 ? Math.abs(Date.now() - createdAt) : 0;

  const canSafelyTreatAsFreshCreate =
    afterActive &&
    afterVisibleToSite &&
    (afterStatus === "CONFIRMED" || afterStatus === "ACTIVE" || afterStatus === "OPEN") &&
    (
      afterVerification === "AUTO_VERIFIED" ||
      afterVerification === "VERIFIED" ||
      afterReviewAggregation === "VERIFIED" ||
      category === "SOS" ||
      category === "HSE_ACCIDENT" ||
      category === "EMERGENCY_ACTIVATION"
    ) &&
    (createdAt === 0 || ageMs < 10 * 60 * 1000);

  if (!canSafelyTreatAsFreshCreate) {
    return [];
  }

  try {
    const recentRequestsSnap = await db
      .ref("notification_requests")
      .orderByChild("incidentId")
      .equalTo(incidentId)
      .limitToLast(25)
      .get();

    if (recentRequestsSnap.exists()) {
      const recentRequests = recentRequestsSnap.val() || {};
      const alreadyHasCreatedRequest = Object.values<any>(recentRequests).some((req) => {
        return req?.meta?.triggerEvent === "INCIDENT_CREATED";
      });

      if (alreadyHasCreatedRequest) {
        return [];
      }
    }
  } catch (error: any) {
    logger.warn("resolveIncidentNotifications created-trigger fallback duplicate check failed", {
      incidentId,
      siteId,
      category,
      error: error?.message || "unknown_error",
    });

    // Αν αποτύχει μόνο το duplicate check, δεν ρισκάρουμε νέο request.
    return [];
  }

  logger.info("resolveIncidentNotifications recovered missing INCIDENT_CREATED trigger", {
    incidentId,
    siteId,
    category,
    beforeSummary: debugSummary(before),
    afterSummary: debugSummary(after),
  });

  return ["INCIDENT_CREATED"];
}

function resolveTriggerEvents(
  before: any,
  after: any,
  category: string
): IncidentNotificationTriggerEvent[] {
  const result: IncidentNotificationTriggerEvent[] = [];

  const isCreate = !before && !!after;
  if (isCreate) {
    result.push("INCIDENT_CREATED");

    // Στο initial create για UNSAFE_CONDITION δεν προσθέτουμε δεύτερο
    // INCIDENT_REVIEW_PROGRESS trigger.
    // Το INCIDENT_CREATED περνά ήδη από dynamic targeting, άρα οι αρχικοί
    // pending reviewers στοχεύονται κανονικά χωρίς δεύτερο request.
    return uniqueTriggerEvents(result);
  }

  const beforeVerification = normalizeEnum(before?.verificationStatus);
  const afterVerification = normalizeEnum(after?.verificationStatus);

  const beforeStatus = normalizeEnum(before?.status);
  const afterStatus = normalizeEnum(after?.status);

  const becameVerified =
    afterVerification === "VERIFIED" &&
    beforeVerification !== "VERIFIED";

  const becameAutoVerified =
    afterVerification === "AUTO_VERIFIED" &&
    beforeVerification !== "AUTO_VERIFIED";

  const becameConfirmed =
    afterStatus === "CONFIRMED" &&
    beforeStatus !== "CONFIRMED";

  const becameClosed =
    afterStatus === "CLOSED" &&
    beforeStatus !== "CLOSED";

  const becameUnderControl =
    afterStatus === "UNDER_CONTROL" &&
    beforeStatus !== "UNDER_CONTROL";

  const becameDeactivated =
    afterStatus === "DEACTIVATED" &&
    beforeStatus !== "DEACTIVATED";

  if (becameVerified || becameAutoVerified || becameConfirmed) {
    result.push("INCIDENT_VERIFIED");
  }

  if (becameUnderControl) {
    result.push("INCIDENT_UNDER_CONTROL");
  }

  if (becameDeactivated) {
    result.push("INCIDENT_DEACTIVATED");
  }

  if (becameClosed) {
    result.push("INCIDENT_CLOSED");
  }

  if (isUnsafeConditionDynamicFlow(category, after)) {
    const beforePendingRoles = normalizeBooleanMap(before?.pendingRoles);
    const afterPendingRoles = normalizeBooleanMap(after?.pendingRoles);

    const beforeCompletedRoles = normalizeBooleanMap(before?.completedRoles);
    const afterCompletedRoles = normalizeBooleanMap(after?.completedRoles);

    const beforeSelectedDimensions = normalizeSelectedDimensionKeys(before);
    const afterSelectedDimensions = normalizeSelectedDimensionKeys(after);

    const beforeAggregation = normalizeEnum(before?.reviewAggregationStatus);
    const afterAggregation = normalizeEnum(after?.reviewAggregationStatus);

    const pendingChanged = !booleanMapsEqual(beforePendingRoles, afterPendingRoles);
    const completedChanged = !booleanMapsEqual(beforeCompletedRoles, afterCompletedRoles);
    const dimensionsChanged = !stringArraysEqual(beforeSelectedDimensions, afterSelectedDimensions);
    const aggregationChanged = beforeAggregation !== afterAggregation;

    const finalAggregation =
      afterAggregation === "VERIFIED" || afterAggregation === "REJECTED";

    const hasPendingRoles = Object.keys(afterPendingRoles).length > 0;
    const addedDimensions = resolveAddedDimensionKeys(before, after);

    if (addedDimensions.length > 0) {
      result.push("INCIDENT_DIMENSIONS_EXPANDED");
    }

    if (
      !finalAggregation &&
      hasPendingRoles &&
      (pendingChanged || completedChanged || aggregationChanged) &&
      addedDimensions.length === 0
    ) {
      result.push("INCIDENT_REVIEW_PROGRESS");
    }
  }

  return uniqueTriggerEvents(result);
}

function resolvePolicyTriggerEvent(
  triggerEvent: IncidentNotificationTriggerEvent,
  _category: string,
  _incident: any
): IncidentNotificationTriggerEvent {
  // Κρατάμε το πραγματικό trigger event όπως είναι.
  // Δεν το κάνουμε remap σε INCIDENT_CREATED, γιατί αυτό
  // μπέρδευε το review-driven flow και άφηνε κενά στα requests.
  return triggerEvent;
}

async function resolveEffectiveTargetingForIncident(
  db: admin.database.Database,
  siteId: string,
  category: string,
  triggerEvent: IncidentNotificationTriggerEvent,
  before: any,
  incident: any,
  policy: NotificationPolicyV2
): Promise<{
  targetRoles: Record<string, boolean>;
  targetTeams: Record<string, boolean>;
  dynamicTargeting: boolean;
  dynamicTargetSource: string;
}> {
  const defaultTargetRoles = normalizeBooleanMap(policy.targetRoles);
  const defaultTargetTeams = normalizeBooleanMap(policy.targetTeams);

  if (!isUnsafeConditionDynamicFlow(category, incident)) {
    return {
      targetRoles: defaultTargetRoles,
      targetTeams: defaultTargetTeams,
      dynamicTargeting: false,
      dynamicTargetSource: "POLICY_STATIC",
    };
  }

  if (
    triggerEvent === "INCIDENT_VERIFIED" ||
    triggerEvent === "INCIDENT_CLOSED" ||
    triggerEvent === "INCIDENT_UNDER_CONTROL" ||
    triggerEvent === "INCIDENT_DEACTIVATED"
  ) {
    return {
      targetRoles: defaultTargetRoles,
      targetTeams: defaultTargetTeams,
      dynamicTargeting: false,
      dynamicTargetSource: "POLICY_STATIC",
    };
  }

  if (triggerEvent === "INCIDENT_DIMENSIONS_EXPANDED") {
    const expansionRoles = await resolveUnsafeConditionExpansionRoles(
      db,
      siteId,
      category,
      before,
      incident
    );

    if (Object.keys(expansionRoles).length > 0) {
      return {
        targetRoles: expansionRoles,
        targetTeams: {},
        dynamicTargeting: true,
        dynamicTargetSource: "UNSAFE_CONDITION_DIMENSION_EXPANSION",
      };
    }

    logger.warn("UNSAFE_CONDITION dimension expansion resolved no new owner roles, falling back to pending roles", {
      siteId,
      category,
      incidentId: safeString(incident?.id),
      summary: debugSummary(incident),
    });
  }

  const dynamicRoles = await resolveUnsafeConditionDynamicRoles(db, siteId, category, incident);
  if (Object.keys(dynamicRoles).length > 0) {
    return {
      targetRoles: dynamicRoles,
      targetTeams: {},
      dynamicTargeting: true,
      dynamicTargetSource:
        triggerEvent === "INCIDENT_CREATED"
          ? "UNSAFE_CONDITION_REVIEW_DIMENSIONS"
          : "UNSAFE_CONDITION_PENDING_REVIEW_ROLES",
    };
  }

  logger.warn("Dynamic UNSAFE_CONDITION targeting returned no roles, falling back to policy", {
    siteId,
    category,
    triggerEvent,
    incidentId: safeString(incident?.id),
    summary: debugSummary(incident),
  });

  return {
    targetRoles: defaultTargetRoles,
    targetTeams: defaultTargetTeams,
    dynamicTargeting: false,
    dynamicTargetSource: "POLICY_STATIC_FALLBACK",
  };
}

function isUnsafeConditionDynamicFlow(
  category: string,
  incident: any
): boolean {
  return (
    normalizeEnum(category) === "UNSAFE_CONDITION" &&
    normalizeEnum(incident?.reviewMode) === "MULTI_DIMENSIONAL"
  );
}

async function resolveUnsafeConditionDynamicRoles(
  db: admin.database.Database,
  siteId: string,
  category: string,
  incident: any
): Promise<Record<string, boolean>> {
  const pendingRoles = normalizeBooleanMap(incident?.pendingRoles);
  if (Object.keys(pendingRoles).length > 0) {
    return pendingRoles;
  }

  const fromDimensionTracks = resolveRolesFromDimensionTracks(incident?.dimensionTracks);
  if (Object.keys(fromDimensionTracks).length > 0) {
    return fromDimensionTracks;
  }

  const fromIncidentDimensions = resolveRolesFromIncidentReviewDimensions(incident?.reviewDimensions);
  if (Object.keys(fromIncidentDimensions).length > 0) {
    return fromIncidentDimensions;
  }

  const selectedDimensions = normalizeSelectedDimensionKeys(incident);
  if (selectedDimensions.length === 0) {
    return {};
  }

  const reviewMatrix = await loadReviewMatrix(db, siteId, category);
  return resolveRolesFromReviewMatrix(selectedDimensions, reviewMatrix);
}

async function resolveUnsafeConditionExpansionRoles(
  db: admin.database.Database,
  siteId: string,
  category: string,
  before: any,
  incident: any
): Promise<Record<string, boolean>> {
  const addedDimensions = resolveAddedDimensionKeys(before, incident);
  if (addedDimensions.length === 0) {
    return {};
  }

  const reviewMatrix = await loadReviewMatrix(db, siteId, category);
  return resolveRolesFromReviewMatrix(addedDimensions, reviewMatrix);
}

function resolveAddedDimensionKeys(before: any, after: any): string[] {
  const beforeDimensions = normalizeSelectedDimensionKeys(before);
  const afterDimensions = normalizeSelectedDimensionKeys(after);

  const beforeSet = new Set(beforeDimensions);
  return afterDimensions.filter((key) => !beforeSet.has(key));
}

function resolveRolesFromDimensionTracks(dimensionTracks: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!dimensionTracks || typeof dimensionTracks !== "object") {
    return result;
  }

  Object.values(dimensionTracks as Record<string, any>).forEach((trackNode) => {
    if (!trackNode || typeof trackNode !== "object") return;

    const active = trackNode.active !== false;
    const reviewStatus = normalizeEnum(trackNode.reviewStatus);
    if (!active) return;
    if (reviewStatus === "RECOGNIZED" || reviewStatus === "REJECTED") return;

    const ownerRoles = normalizeBooleanMap(trackNode.ownerRoles);
    Object.keys(ownerRoles).forEach((role) => {
      result[role] = true;
    });
  });

  return result;
}

function resolveRolesFromIncidentReviewDimensions(reviewDimensions: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!reviewDimensions || typeof reviewDimensions !== "object") {
    return result;
  }

  Object.values(reviewDimensions as Record<string, any>).forEach((dimensionNode) => {
    if (!dimensionNode || typeof dimensionNode !== "object") return;

    const status = normalizeEnum(dimensionNode.status);
    if (status === "RECOGNIZED" || status === "REJECTED") {
      return;
    }

    const requiredRoles = normalizeBooleanMap(dimensionNode.requiredRoles);
    Object.keys(requiredRoles).forEach((role) => {
      result[role] = true;
    });
  });

  return result;
}

function normalizeSelectedDimensionKeys(incident: any): string[] {
  const selected = incident?.selectedReviewDimensions;
  const reviewDimensions = incident?.reviewDimensions;

  const result = new Set<string>();

  if (Array.isArray(selected)) {
    selected.forEach((item) => {
      const key = normalizeEnum(item);
      if (key) result.add(key);
    });
  } else if (selected && typeof selected === "object") {
    Object.entries(selected as Record<string, unknown>).forEach(([key, enabled]) => {
      const normalizedKey = normalizeEnum(key);
      const isEnabled = enabled === true || String(enabled).toLowerCase() === "true";
      if (normalizedKey && isEnabled) {
        result.add(normalizedKey);
      }
    });
  }

  if (result.size === 0 && reviewDimensions && typeof reviewDimensions === "object") {
    Object.keys(reviewDimensions as Record<string, unknown>).forEach((key) => {
      const normalizedKey = normalizeEnum(key);
      if (normalizedKey) {
        result.add(normalizedKey);
      }
    });
  }

  return Array.from(result.values());
}

async function loadReviewMatrix(
  db: admin.database.Database,
  siteId: string,
  category: string
): Promise<Record<string, any>> {
  const path = `site_config_data/${siteId}/incident_policies/${category}/reviewMatrix`;
  const snapshot = await db.ref(path).get();
  if (!snapshot.exists()) {
    return {};
  }

  const value = snapshot.val();
  return value && typeof value === "object" ? value : {};
}

function resolveRolesFromReviewMatrix(
  selectedDimensions: string[],
  reviewMatrix: Record<string, any>
): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  selectedDimensions.forEach((dimensionKey) => {
    const matrixNode = reviewMatrix[dimensionKey];
    if (!matrixNode || typeof matrixNode !== "object") return;

    const requiredRoles = normalizeBooleanMap(matrixNode.requiredRoles);
    Object.keys(requiredRoles).forEach((role) => {
      result[role] = true;
    });
  });

  return result;
}

async function resolveUsersWithProvenance(
  db: admin.database.Database,
  siteId: string,
  targetRoles: Record<string, boolean>,
  targetTeams: Record<string, boolean>,
  explicitUsers: Record<string, boolean>
): Promise<{
  resolvedUsers: Record<string, any>;
  droppedUsers: Record<string, string>;
}> {
  const usersSnap = await db.ref("users").get();
  const users = usersSnap.exists() ? usersSnap.val() || {} : {};

  const resolvedUsers: Record<string, any> = {};
  const droppedUsers: Record<string, string> = {};

  for (const [uid, user] of Object.entries<any>(users)) {
    if (!user) continue;
  if (uid === "anonymous") {
      droppedUsers[uid] = "ANONYMOUS_NOT_TARGETABLE";
      continue;
    }

    if (uid === "anonymous") {
      droppedUsers[uid] = "ANONYMOUS_NOT_TARGETABLE";
      continue;
    }

    if (!isUserEnabledForNotifications(user)) {
      droppedUsers[uid] = "USER_INACTIVE";
      continue;
    }

    const baseSiteId = normalizeSiteId(user.siteId || user.site || "");
    const membership = getUserMembershipForSite(user.siteMemberships, siteId);

    if (!membership && baseSiteId !== siteId) {
      continue;
    }

    if (membership && membership.active === false) {
      droppedUsers[uid] = "USER_INACTIVE";
      continue;
    }

    const roleMap = mergeBooleanMaps(
      normalizeBooleanMap(user.roles),
      normalizeBooleanMap(membership?.roles)
    );
    const teamMap = mergeBooleanMaps(
      normalizeBooleanMap(user.teams),
      normalizeBooleanMap(membership?.teams)
    );
    const tokenMap = normalizeTokenMap(user.fcmTokens, user.fcmToken);

    const matchedRoles = intersectEnabledKeys(roleMap, targetRoles);
    const matchedTeams = intersectEnabledKeys(teamMap, targetTeams);
    const viaExplicit = explicitUsers[uid] === true;

    const isMatch =
      Object.keys(matchedRoles).length > 0 ||
      Object.keys(matchedTeams).length > 0 ||
      viaExplicit;

    if (!isMatch) continue;

    if (Object.keys(tokenMap).length === 0) {
      droppedUsers[uid] = "NO_TOKENS";
      continue;
    }

    resolvedUsers[uid] = {
      siteId,
      displayName: String(user.displayName || user.name || user.fullName || uid).trim() || uid,
      viaRoles: matchedRoles,
      viaTeams: matchedTeams,
      viaExplicit,
      tokens: tokenMap,
    };
  }

  return { resolvedUsers, droppedUsers };
}


function isUserEnabledForNotifications(user: any): boolean {
  if (user?.active === false) return false;
  if (user?.enabled === false) return false;

  const status = normalizeEnum(user?.status || "");
  if (status && status !== "ACTIVE") return false;

  return true;
}

function getUserMembershipForSite(
  siteMemberships: unknown,
  siteId: string
): Record<string, any> | null {
  if (!siteMemberships || typeof siteMemberships !== "object") return null;

  const matchKey = Object.keys(siteMemberships as Record<string, unknown>).find(
    (key) => normalizeSiteId(key) === siteId
  );

  if (!matchKey) return null;
  return ((siteMemberships as Record<string, unknown>)[matchKey] || null) as Record<string, any> | null;
}

function mergeBooleanMaps(
  primary: Record<string, boolean>,
  secondary: Record<string, boolean>
): Record<string, boolean> {
  return {
    ...primary,
    ...secondary,
  };
}

function intersectEnabledKeys(
  source: Record<string, boolean>,
  target: Record<string, boolean>
): Record<string, boolean> {
  const result: Record<string, boolean> = {};
  Object.keys(target).forEach((key) => {
    if (target[key] && source[key]) {
      result[key] = true;
    }
  });
  return result;
}

function normalizeRetryConfig(retry: unknown): {
  enabled: boolean;
  maxRetryCount: number;
  backoffSeconds: Record<string, number>;
} {
  const fallback = {
    enabled: false,
    maxRetryCount: 0,
    backoffSeconds: {} as Record<string, number>,
  };

  if (!retry || typeof retry !== "object") {
    return fallback;
  }

  const raw = retry as Record<string, unknown>;
  const enabled = raw.enabled === true || String(raw.enabled).toLowerCase() === "true";

  const maxRetryCount = toSafeInt(raw.maxRetries, 0);

  const backoffArray = Array.isArray(raw.backoffSeconds)
    ? raw.backoffSeconds
        .map((v) => toSafeInt(v, -1))
        .filter((v) => v > 0)
    : [];

  const backoffSeconds: Record<string, number> = {};
  backoffArray.forEach((value, index) => {
    backoffSeconds[String(index)] = value;
  });

  return {
    enabled,
    maxRetryCount,
    backoffSeconds,
  };
}

function normalizeBooleanMap(value: unknown): Record<string, boolean> {
  const result: Record<string, boolean> = {};

  if (!value) return result;

  if (Array.isArray(value)) {
    value.forEach((item) => {
      const key = String(item || "").trim();
      if (key) result[key] = true;
    });
    return result;
  }

  if (typeof value === "object") {
    Object.entries(value as Record<string, unknown>).forEach(([key, raw]) => {
      const normalizedKey = String(key || "").trim();
      if (!normalizedKey) return;
      if (raw === true || String(raw).toLowerCase() === "true") {
        result[normalizedKey] = true;
      }
    });
  }

  return result;
}

function normalizeTokenMap(
  fcmTokens: unknown,
  fallbackToken?: unknown
): Record<string, string> {
  const result: Record<string, string> = {};

  if (fcmTokens && typeof fcmTokens === "object") {
    Object.entries(fcmTokens as Record<string, unknown>).forEach(([key, value]) => {
      const token = String(value || "").trim();
      if (token) result[key] = token;
    });
  }

  const fallback = String(fallbackToken || "").trim();
  if (fallback && !Object.values(result).includes(fallback)) {
    result.default = fallback;
  }

  return result;
}

function toSafeInt(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.floor(parsed)) : fallback;
}

function normalizeSiteId(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

function normalizeEnum(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function booleanMapsEqual(
  left: Record<string, boolean>,
  right: Record<string, boolean>
): boolean {
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();

  if (leftKeys.length !== rightKeys.length) return false;

  for (let i = 0; i < leftKeys.length; i += 1) {
    if (leftKeys[i] !== rightKeys[i]) return false;
    if (left[leftKeys[i]] !== right[rightKeys[i]]) return false;
  }

  return true;
}

function stringArraysEqual(left: string[], right: string[]): boolean {
  const sortedLeft = [...left].sort();
  const sortedRight = [...right].sort();

  if (sortedLeft.length !== sortedRight.length) return false;

  for (let i = 0; i < sortedLeft.length; i += 1) {
    if (sortedLeft[i] !== sortedRight[i]) return false;
  }

  return true;
}

function uniqueTriggerEvents(
  values: IncidentNotificationTriggerEvent[]
): IncidentNotificationTriggerEvent[] {
  return Array.from(new Set(values));
}

function debugSummary(incident: any): Record<string, unknown> {
  if (!incident) {
    return {
      exists: false,
    };
  }

  return {
    exists: true,
    id: safeString(incident?.id),
    category: normalizeEnum(incident?.category),
    type: normalizeEnum(incident?.type),
    subtype: normalizeEnum(incident?.subtype),
    status: normalizeEnum(incident?.status),
    verificationStatus: normalizeEnum(incident?.verificationStatus),
    reviewMode: normalizeEnum(incident?.reviewMode),
    reviewAggregationStatus: normalizeEnum(incident?.reviewAggregationStatus),
    selectedDimensions: normalizeSelectedDimensionKeys(incident),
    pendingRoles: Object.keys(normalizeBooleanMap(incident?.pendingRoles)),
    completedRoles: Object.keys(normalizeBooleanMap(incident?.completedRoles)),
    reviewDimensions: Object.keys(
      incident?.reviewDimensions && typeof incident.reviewDimensions === "object"
        ? incident.reviewDimensions
        : {}
    ),
    dimensionTracks: Object.keys(
      incident?.dimensionTracks && typeof incident.dimensionTracks === "object"
        ? incident.dimensionTracks
        : {}
    ),
    active: incident?.active === true,
    visibleToSite: incident?.visibleToSite === true,
  };
}