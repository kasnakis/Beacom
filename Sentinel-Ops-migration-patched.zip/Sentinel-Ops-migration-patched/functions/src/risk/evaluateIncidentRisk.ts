import { onValueWritten } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";
import * as admin from "firebase-admin";

type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

type RiskBandConfig = {
  min?: number;
  max?: number;
};

type RiskDimensionProfile = {
  weight?: number;
  base?: string;
};

type RiskProfile = {
  enabled?: boolean;
  baseScore?: number;
  dimensions?: Record<string, RiskDimensionProfile>;
  modifiers?: {
    severity?: Record<string, number>;
    activationLevel?: Record<string, number>;
    evacuationRequired?: number;
    externalAuthoritiesRequired?: number;
  };
  scoreBands?: Record<string, RiskBandConfig>;
};

type RiskEngineConfig = {
  enabled?: boolean;
  schemaVersion?: number;
  computeOnCreate?: boolean;
  computeOnUpdate?: boolean;
  recomputeTriggers?: {
    categoryChanged?: boolean;
    subtypeChanged?: boolean;
    severityChanged?: boolean;
    activationChanged?: boolean;
    locationChanged?: boolean;
    manualOverrideChanged?: boolean;
  };
  defaultProfileKey?: string;
  defaultOverallRisk?: string;
  allowManualOverride?: boolean;
};

type ManualOverrideBlock = {
  active?: boolean;
  overallRisk?: string;
  reason?: string;
  updatedAt?: number;
  updatedBy?: string;
};

type RiskAssessmentRuntime = {
  computed?: boolean;
  computedAt?: number;
  computedBy?: string;
  schemaVersion?: number;
  profileKey?: string;
  source?: {
    siteId?: string;
    category?: string;
    subtype?: string;
    severity?: string;
  };
  dimensions?: Record<
    string,
    {
      level?: string;
      score?: number;
    }
  >;
  overallRisk?: string;
  score?: number;
  manualOverride?: ManualOverrideBlock;
};

type IncidentLike = Record<string, any>;

const INSTANCE = "ppc-sentinel-ops-pilot-001-default-rtdb";
const FUNCTION_SOURCE = "FUNCTION";
const FUNCTION_NAME = "evaluateIncidentRisk";
const RISK_SCHEMA_VERSION = 1;

export const evaluateIncidentRisk = onValueWritten(
  {
    ref: "/incidents/{incidentId}",
    instance: INSTANCE,
    region: "europe-west1",
  },
  async (event) => {
    const incidentId = event.params.incidentId;
    const db = admin.database();

    const beforeExists = event.data.before.exists();
    const afterExists = event.data.after.exists();

    if (!afterExists) {
      logger.info("Risk evaluation skipped - incident deleted", {
        incidentId,
      });
      return;
    }

    const beforeIncident = (beforeExists ? event.data.before.val() : {}) as IncidentLike;
    const afterIncident = (event.data.after.val() || {}) as IncidentLike;

    const siteId = safeSiteId(afterIncident.siteId ?? afterIncident.site ?? "");
    if (!siteId) {
      logger.warn("Risk evaluation skipped - missing siteId", {
        incidentId,
      });
      return;
    }

    const incidentCategory = normalizeEnumText(afterIncident.category ?? "");
    const incidentSubtype = normalizeEnumText(afterIncident.subtype ?? "");
    const incidentSeverity = normalizeEnumText(afterIncident.severity ?? "MEDIUM");

    if (!incidentCategory) {
      logger.warn("Risk evaluation skipped - missing category", {
        incidentId,
        siteId,
      });
      return;
    }

    try {
      const riskEngineSnap = await db
        .ref(`site_config_data/${siteId}/risk_engine`)
        .get();

      const riskEngine = (riskEngineSnap.exists()
        ? riskEngineSnap.val()
        : {}) as RiskEngineConfig;

      if (riskEngine.enabled === false) {
        logger.info("Risk evaluation skipped - risk engine disabled", {
          incidentId,
          siteId,
        });
        return;
      }

      const isCreate = !beforeExists && afterExists;
      const existingRuntime = sanitizeRiskAssessmentRuntime(
        afterIncident.riskAssessment || {}
      );

      const manualOverrideActive =
        riskEngine.allowManualOverride !== false &&
        existingRuntime.manualOverride?.active === true;

      if (manualOverrideActive) {
        logger.info("Risk evaluation skipped - manual override active", {
          incidentId,
          siteId,
          category: incidentCategory,
        });
        return;
      }

      const shouldCompute = resolveShouldCompute({
        beforeIncident,
        afterIncident,
        riskEngine,
        isCreate,
      });

      if (!shouldCompute) {
        logger.info("Risk evaluation skipped - no relevant changes", {
          incidentId,
          siteId,
          category: incidentCategory,
        });
        return;
      }

      const profileResolution = await resolveRiskProfile(
        db,
        siteId,
        incidentCategory,
        normalizeEnumText(afterIncident.type ?? ""),
        incidentSubtype,
        riskEngine.defaultProfileKey || "default"
      );

      const profile = profileResolution.profile;
      const profileKey = profileResolution.profileKey;

      if (!profile || profile.enabled === false) {
        logger.warn("Risk evaluation skipped - no enabled profile found", {
          incidentId,
          siteId,
          category: incidentCategory,
          profileKey,
        });
        return;
      }

      const computed = computeRiskAssessment({
        incident: afterIncident,
        siteId,
        incidentCategory,
        incidentSubtype,
        incidentSeverity,
        profile,
        profileKey,
        riskEngine,
      });

      const previousComparable = sanitizeComparableRiskAssessment(existingRuntime);
      const nextComparable = sanitizeComparableRiskAssessment(computed);

      if (stableStringify(previousComparable) === stableStringify(nextComparable)) {
        logger.info("Risk evaluation skipped - computed state unchanged", {
          incidentId,
          siteId,
          category: incidentCategory,
          overallRisk: computed.overallRisk,
          score: computed.score,
        });
        return;
      }

      await db.ref(`incidents/${incidentId}/riskAssessment`).set(computed);

      const isFirstAssessment =
        !existingRuntime.computed ||
        !normalizeEnumText(existingRuntime.overallRisk || "") ||
        toNumberOrNull(existingRuntime.score) == null;

      const eventType = isFirstAssessment
        ? "RISK_ASSESSMENT_COMPUTED"
        : "RISK_ASSESSMENT_UPDATED";

      await pushIncidentEvent(db, incidentId, siteId, eventType, {
        profileKey: computed.profileKey || "",
        overallRisk: computed.overallRisk || "",
        score: computed.score ?? 0,
        schemaVersion: computed.schemaVersion ?? RISK_SCHEMA_VERSION,
        previousOverallRisk: normalizeEnumText(existingRuntime.overallRisk || ""),
        newOverallRisk: computed.overallRisk || "",
        previousScore: toNumberOrNull(existingRuntime.score),
        newScore: computed.score ?? null,
        category: incidentCategory,
        subtype: incidentSubtype,
        severity: incidentSeverity,
      });

      logger.info("Risk assessment computed", {
        incidentId,
        siteId,
        category: incidentCategory,
        subtype: incidentSubtype,
        severity: incidentSeverity,
        profileKey: computed.profileKey,
        overallRisk: computed.overallRisk,
        score: computed.score,
        eventType,
      });
    } catch (error) {
      logger.error("Risk evaluation failed", {
        incidentId,
        siteId,
        category: incidentCategory,
        error: stringifyError(error),
      });
      throw error;
    }
  }
);

function resolveShouldCompute(args: {
  beforeIncident: IncidentLike;
  afterIncident: IncidentLike;
  riskEngine: RiskEngineConfig;
  isCreate: boolean;
}): boolean {
  const { beforeIncident, afterIncident, riskEngine, isCreate } = args;

  if (isCreate) {
    return riskEngine.computeOnCreate !== false;
  }

  if (riskEngine.computeOnUpdate === false) {
    return false;
  }

  const triggers = riskEngine.recomputeTriggers || {};

  const beforeCategory = normalizeEnumText(beforeIncident.category ?? "");
  const afterCategory = normalizeEnumText(afterIncident.category ?? "");

  const beforeSubtype = normalizeEnumText(beforeIncident.subtype ?? "");
  const afterSubtype = normalizeEnumText(afterIncident.subtype ?? "");

  const beforeSeverity = normalizeEnumText(beforeIncident.severity ?? "");
  const afterSeverity = normalizeEnumText(afterIncident.severity ?? "");

  const beforeActivation = sanitizeActivationComparable(beforeIncident.activation || {});
  const afterActivation = sanitizeActivationComparable(afterIncident.activation || {});

  const beforeLocation = sanitizeLocationComparable(beforeIncident);
  const afterLocation = sanitizeLocationComparable(afterIncident);

  const beforeManualOverride = sanitizeManualOverrideComparable(
    beforeIncident.riskAssessment?.manualOverride || {}
  );
  const afterManualOverride = sanitizeManualOverrideComparable(
    afterIncident.riskAssessment?.manualOverride || {}
  );

  const categoryChanged = beforeCategory !== afterCategory;
  const subtypeChanged = beforeSubtype !== afterSubtype;
  const severityChanged = beforeSeverity !== afterSeverity;
  const activationChanged =
    stableStringify(beforeActivation) !== stableStringify(afterActivation);
  const locationChanged =
    stableStringify(beforeLocation) !== stableStringify(afterLocation);
  const manualOverrideChanged =
    stableStringify(beforeManualOverride) !== stableStringify(afterManualOverride);

  if (triggers.categoryChanged !== false && categoryChanged) return true;
  if (triggers.subtypeChanged !== false && subtypeChanged) return true;
  if (triggers.severityChanged !== false && severityChanged) return true;
  if (triggers.activationChanged !== false && activationChanged) return true;
  if (triggers.locationChanged === true && locationChanged) return true;
  if (triggers.manualOverrideChanged === true && manualOverrideChanged) return true;

  const afterRisk = sanitizeRiskAssessmentRuntime(afterIncident.riskAssessment || {});
  if (!afterRisk.computed || !normalizeEnumText(afterRisk.overallRisk || "")) {
    return true;
  }

  return false;
}

async function resolveRiskProfile(
  db: admin.database.Database,
  siteId: string,
  incidentCategory: string,
  incidentType: string,
  incidentSubtype: string,
  defaultProfileKey: string
): Promise<{ profileKey: string; profile: RiskProfile | null }> {
  const profilesSnap = await db.ref(`site_config_data/${siteId}/risk_profiles`).get();

  if (!profilesSnap.exists()) {
    return { profileKey: defaultProfileKey, profile: null };
  }

  let exactMatch: { profileKey: string; profile: RiskProfile } | null = null;
  let categoryMatch: { profileKey: string; profile: RiskProfile } | null = null;
  let defaultMatch: { profileKey: string; profile: RiskProfile } | null = null;

  profilesSnap.forEach((child) => {
    const profileKey = child.key || "";
    const profile = (child.val() || {}) as RiskProfile;
    const normalizedKey = normalizeEnumText(profileKey);

    if (profile.enabled === false) {
      return false;
    }

    if (normalizedKey === normalizeEnumText(defaultProfileKey)) {
      defaultMatch = { profileKey, profile };
    }

    if (
      normalizedKey &&
      (normalizedKey === incidentSubtype || normalizedKey === incidentType)
    ) {
      exactMatch = { profileKey, profile };
      return true;
    }

    if (normalizedKey && normalizedKey === incidentCategory && categoryMatch == null) {
      categoryMatch = { profileKey, profile };
    }

    return false;
  });

  return (
    exactMatch ??
    categoryMatch ??
    defaultMatch ?? {
      profileKey: defaultProfileKey,
      profile: null,
    }
  );
}

function computeRiskAssessment(args: {
  incident: IncidentLike;
  siteId: string;
  incidentCategory: string;
  incidentSubtype: string;
  incidentSeverity: string;
  profile: RiskProfile;
  profileKey: string;
  riskEngine: RiskEngineConfig;
}): RiskAssessmentRuntime {
  const {
    incident,
    siteId,
    incidentCategory,
    incidentSubtype,
    incidentSeverity,
    profile,
    profileKey,
    riskEngine,
  } = args;

  const activation = incident.activation || {};

  let score = clampScore(toNumber(profile.baseScore, 50));

  score += resolveSeverityModifier(profile, incidentSeverity);
  score += resolveActivationLevelModifier(
    profile,
    normalizeEnumText(activation.activationLevel ?? "")
  );

  if (toBoolean(activation.evacuationRequired) === true) {
    score += toNumber(profile.modifiers?.evacuationRequired, 0);
  }

  if (toBoolean(activation.externalAuthoritiesRequired) === true) {
    score += toNumber(profile.modifiers?.externalAuthoritiesRequired, 0);
  }

  score = clampScore(score);

  const overallRisk = resolveRiskLevelFromScore(
    score,
    profile.scoreBands,
    normalizeRiskLevel(riskEngine.defaultOverallRisk, "MEDIUM")
  );

  const dimensions = computeDimensionResults(profile, score, overallRisk);

  return {
    computed: true,
    computedAt: Date.now(),
    computedBy: FUNCTION_SOURCE,
    schemaVersion: toNumber(riskEngine.schemaVersion, RISK_SCHEMA_VERSION),
    profileKey,
    source: {
      siteId,
      category: incidentCategory,
      subtype: incidentSubtype,
      severity: incidentSeverity,
    },
    dimensions,
    overallRisk,
    score,
    manualOverride: {
      active: false,
      overallRisk: "",
      reason: "",
      updatedAt: 0,
      updatedBy: "",
    },
  };
}

function computeDimensionResults(
  profile: RiskProfile,
  overallScore: number,
  overallRisk: RiskLevel
): Record<string, { level: string; score: number }> {
  const profileDimensions = profile.dimensions || {};
  const results: Record<string, { level: string; score: number }> = {};

  const allDimensionKeys = new Set<string>([
    "humanSafety",
    "environment",
    "operations",
    "assets",
    ...Object.keys(profileDimensions),
  ]);

  allDimensionKeys.forEach((dimensionKey) => {
    const dimensionProfile = profileDimensions[dimensionKey] || {};
    const weight = clampNumber(toNumber(dimensionProfile.weight, 3), 1, 5);
    const baseLevel = normalizeRiskLevel(dimensionProfile.base, overallRisk);

    let dimensionScore = overallScore;

    if (baseLevel === "LOW") dimensionScore -= 15;
    if (baseLevel === "MEDIUM") dimensionScore -= 5;
    if (baseLevel === "HIGH") dimensionScore += 5;
    if (baseLevel === "CRITICAL") dimensionScore += 15;

    dimensionScore += (weight - 3) * 5;
    dimensionScore = clampScore(Math.round(dimensionScore));

    results[dimensionKey] = {
      level: resolveRiskLevelFromScore(dimensionScore, profile.scoreBands, overallRisk),
      score: dimensionScore,
    };
  });

  return results;
}

function resolveSeverityModifier(profile: RiskProfile, severity: string): number {
  const modifiers = profile.modifiers?.severity || {};
  return toNumber(modifiers[severity], 0);
}

function resolveActivationLevelModifier(profile: RiskProfile, activationLevel: string): number {
  const modifiers = profile.modifiers?.activationLevel || {};
  return toNumber(modifiers[activationLevel], 0);
}

function resolveRiskLevelFromScore(
  score: number,
  scoreBands?: Record<string, RiskBandConfig>,
  fallback: RiskLevel = "MEDIUM"
): RiskLevel {
  const normalizedBands = sanitizeScoreBands(scoreBands);

  for (const level of ["LOW", "MEDIUM", "HIGH", "CRITICAL"] as RiskLevel[]) {
    const band = normalizedBands[level];
    if (score >= band.min && score <= band.max) {
      return level;
    }
  }

  if (score <= 24) return "LOW";
  if (score <= 49) return "MEDIUM";
  if (score <= 74) return "HIGH";
  if (score <= 100) return "CRITICAL";

  return fallback;
}

function sanitizeScoreBands(
  scoreBands?: Record<string, RiskBandConfig>
): Record<RiskLevel, { min: number; max: number }> {
  const defaults: Record<RiskLevel, { min: number; max: number }> = {
    LOW: { min: 0, max: 24 },
    MEDIUM: { min: 25, max: 49 },
    HIGH: { min: 50, max: 74 },
    CRITICAL: { min: 75, max: 100 },
  };

  if (!scoreBands || typeof scoreBands !== "object") {
    return defaults;
  }

  const result = { ...defaults };

  for (const level of Object.keys(defaults) as RiskLevel[]) {
    const band = scoreBands[level];
    if (!band) continue;

    result[level] = {
      min: clampScore(toNumber(band.min, defaults[level].min)),
      max: clampScore(toNumber(band.max, defaults[level].max)),
    };
  }

  return result;
}

async function pushIncidentEvent(
  db: admin.database.Database,
  incidentId: string,
  siteId: string,
  eventType: string,
  extra: Record<string, unknown>
): Promise<void> {
  const eventsRef = db.ref("incident_events").push();
  const payload = {
    id: eventsRef.key,
    incidentId,
    siteId,
    eventType,
    createdAt: Date.now(),
    source: FUNCTION_SOURCE,
    userId: FUNCTION_NAME,
    userName: FUNCTION_NAME,
    extra,
  };

  await eventsRef.set(payload);
}

function sanitizeRiskAssessmentRuntime(value: unknown): RiskAssessmentRuntime {
  const runtime = (value || {}) as RiskAssessmentRuntime;
  return {
    computed: toBoolean(runtime.computed) === true,
    computedAt: toNumber(runtime.computedAt, 0),
    computedBy: safeString(runtime.computedBy),
    schemaVersion: toNumber(runtime.schemaVersion, 0),
    profileKey: safeString(runtime.profileKey),
    source: {
      siteId: safeString(runtime.source?.siteId),
      category: safeString(runtime.source?.category),
      subtype: safeString(runtime.source?.subtype),
      severity: safeString(runtime.source?.severity),
    },
    dimensions: sanitizeDimensionComparable(runtime.dimensions || {}),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    score: toNumber(runtime.score, 0),
    manualOverride: sanitizeManualOverrideComparable(runtime.manualOverride || {}),
  };
}

function sanitizeComparableRiskAssessment(runtime: RiskAssessmentRuntime): Record<string, unknown> {
  return {
    computed: runtime.computed === true,
    schemaVersion: toNumber(runtime.schemaVersion, 0),
    profileKey: safeString(runtime.profileKey),
    source: {
      siteId: safeString(runtime.source?.siteId),
      category: normalizeEnumText(runtime.source?.category || ""),
      subtype: normalizeEnumText(runtime.source?.subtype || ""),
      severity: normalizeEnumText(runtime.source?.severity || ""),
    },
    dimensions: sanitizeDimensionComparable(runtime.dimensions || {}),
    overallRisk: normalizeEnumText(runtime.overallRisk || ""),
    score: toNumber(runtime.score, 0),
    manualOverride: sanitizeManualOverrideComparable(runtime.manualOverride || {}),
  };
}

function sanitizeDimensionComparable(
  value: unknown
): Record<string, { level: string; score: number }> {
  if (!value || typeof value !== "object") return {};

  const result: Record<string, { level: string; score: number }> = {};

  Object.entries(value as Record<string, any>).forEach(([key, raw]) => {
    result[key] = {
      level: normalizeEnumText(raw?.level ?? ""),
      score: toNumber(raw?.score, 0),
    };
  });

  return result;
}

function sanitizeManualOverrideComparable(value: unknown): ManualOverrideBlock {
  const block = (value || {}) as ManualOverrideBlock;
  return {
    active: toBoolean(block.active) === true,
    overallRisk: normalizeEnumText(block.overallRisk || ""),
    reason: safeString(block.reason),
    updatedAt: toNumber(block.updatedAt, 0),
    updatedBy: safeString(block.updatedBy),
  };
}

function sanitizeActivationComparable(value: unknown): Record<string, unknown> {
  const activation = (value || {}) as Record<string, unknown>;
  return {
    activationLevel: normalizeEnumText(activation.activationLevel || ""),
    evacuationRequired: toBoolean(activation.evacuationRequired) === true,
    externalAuthoritiesRequired:
      toBoolean(activation.externalAuthoritiesRequired) === true,
  };
}

function sanitizeLocationComparable(incident: IncidentLike): Record<string, unknown> {
  return {
    incidentLatitude: toNumber(
      incident.incidentLatitude ?? incident.latitude ?? incident.lat ?? null,
      0
    ),
    incidentLongitude: toNumber(
      incident.incidentLongitude ?? incident.longitude ?? incident.lon ?? null,
      0
    ),
  };
}

function normalizeEnumText(value: unknown): string {
  return String(value || "").trim().toUpperCase();
}

function normalizeRiskLevel(value: unknown, fallback: RiskLevel): RiskLevel {
  const normalized = normalizeEnumText(value);
  if (
    normalized === "LOW" ||
    normalized === "MEDIUM" ||
    normalized === "HIGH" ||
    normalized === "CRITICAL"
  ) {
    return normalized;
  }
  return fallback;
}

function safeString(value: unknown): string {
  return String(value || "").trim();
}

function safeSiteId(value: unknown): string {
  return String(value || "").trim();
}

function toBoolean(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;

  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }

  return null;
}

function toNumber(value: unknown, fallback: number): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function toNumberOrNull(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function clampScore(value: number): number {
  return clampNumber(Math.round(value), 0, 100);
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function stableStringify(value: unknown): string {
  return JSON.stringify(sortDeep(value));
}

function sortDeep(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(sortDeep);
  }

  if (value && typeof value === "object") {
    const sorted: Record<string, unknown> = {};
    Object.keys(value as Record<string, unknown>)
      .sort()
      .forEach((key) => {
        sorted[key] = sortDeep((value as Record<string, unknown>)[key]);
      });
    return sorted;
  }

  return value;
}

function stringifyError(error: unknown): Record<string, unknown> {
  if (error instanceof Error) {
    return {
      message: error.message,
      stack: error.stack || "",
      name: error.name,
    };
  }

  return {
    value: String(error),
  };
}