const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

exports.resolveIncidentNotifications = functions.database
.ref("/incidents/{incidentId}")
.onCreate(async (snapshot, context) => {

    const incidentId = context.params.incidentId;
    const incident = snapshot.val();

    if (!incident) return null;

    const siteId = incident.siteId;
    const category = incident.category;
    const type = incident.type;

    if (!siteId || !category || !type) {
        console.log("Incident missing fields");
        return null;
    }

    const db = admin.database();

    // load policies
    const policySnap = await db.ref(
        `site_config_data/${siteId}/notification_policies`
    ).once("value");

    if (!policySnap.exists()) {
        console.log("No policies found");
        return null;
    }

    const policies = policySnap.val();

    let matchedPolicies = [];

    for (const policyId in policies) {

        const p = policies[policyId];

        if (!p.active) continue;

        const trigger = p.trigger;

        if (!trigger) continue;

        if (trigger.event !== "INCIDENT_CREATED") continue;

        if (trigger.category !== category) continue;

        if (trigger.type !== type && trigger.type !== "*") continue;

        matchedPolicies.push({
            id: policyId,
            policy: p
        });
    }

    if (matchedPolicies.length === 0) {
        console.log("No matching policies");
        return null;
    }

    // load users
    const usersSnap = await db.ref("users").once("value");

    if (!usersSnap.exists()) {
        console.log("No users found");
        return null;
    }

    const users = usersSnap.val();

    let resolvedUserIds = new Set();

    for (const mp of matchedPolicies) {

        const targets = mp.policy.targets || {};

        const roleTargets = targets.roles || [];
        const teamTargets = targets.teams || [];

        for (const uid in users) {

            const user = users[uid];

            if (!user.active) continue;

            const membership =
                user.siteMemberships &&
                user.siteMemberships[siteId];

            if (!membership) continue;

            if (!membership.active) continue;

            const roles = membership.roles || [];
            const teams = membership.teams || [];

            let roleMatch =
                roles.some(r => roleTargets.includes(r));

            let teamMatch =
                teams.some(t => teamTargets.includes(t));

            if (roleMatch || teamMatch) {
                resolvedUserIds.add(uid);
            }
        }
    }

    const resolvedUsers = Array.from(resolvedUserIds);

    const requestRef = db.ref("notification_requests").push();

    await requestRef.set({
        id: requestRef.key,
        siteId: siteId,
        incidentId: incidentId,
        eventType: "INCIDENT_CREATED",
        category: category,
        type: type,
        status: "PENDING",
        resolvedUsers: resolvedUsers,
        createdAt: Date.now()
    });

    console.log("Notification request created", resolvedUsers);

    return null;

});